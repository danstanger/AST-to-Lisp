(defpackage :excl
  (:use :cl)
  (:export :spreadsheet))

(in-package :excl)

(defun spreadsheet (&optional (rows 10) (cols 10))
  (error "not implemented"))
