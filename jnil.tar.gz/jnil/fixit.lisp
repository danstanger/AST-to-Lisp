(defun recover (e)
 (destructuring-bind (a p) (simple-condition-format-arguments e)
   (substring a p)))

(handler-case (format t "~a ~a" 1) (simple-condition (e) (format t "caught ~%~a~%" (simple-condition-format-arguments e))))
(defun fixit (st fs &rest args)
  (handler-case
    (apply #'format st fs args)
  (simple-condition (e1)
     (let* ((scfa (simple-condition-format-arguments e1))
	    (ofs (first scfa))
	    (err-pos (second scfa))
            (fix (cond ((search "defnew" ofs) "~>")
		       ((search "defclass" ofs) "~}~>")
		       (t (error "no clause in fixit"))))
	    (nfs (concatenate 'string (subseq ofs 0 (- err-pos 3)) fix)))
       (format t "ofs ~a~%" ofs)
       (apply #'format st nfs args)))))

(trace fixit)
(
;sbcl
(handler-case (format t "~a ~a" 1)
  (error (e)
    (format t "caught ~%~a~%" e)
    (format t "caught ~%~a~%" (type-of e))
    (format t "string ~%~a~%" (sb-format::format-error-control-string e))
    (format t "string ~%~a~%" (sb-format::format-error-offset e))
    ))

;sbcl
(handler-case (format t "~a ~a ~a" 1 2)
  (error (e)
    (format t "caught ~%~a~%" e)
    (format t "caught ~%~a~%" (type-of e))
    (format t "string ~%~a~%" (sb-format::format-error-control-string e))
    (format t "string ~%~a~%" (sb-format::format-error-second-relative e))
    ))
;sbcl
(handler-case (format t "~a ~a ~a" 1 2)
  (error (e)
    (format t "caught ~%~a~%" e)
    (format t "caught ~%~a~%" (type-of e))
    (format t "string ~%~a~%" (sb-format::format-error-control-string e))
    (format t "string ~%~a~%" (sb-format::format-error-at e))
    ))

(handler-case
    (format nil "~a ~a" 1)
  (simple-condition (e)
     (let ((scfa (simple-condition-format-arguments e)))
       (format t "caught ~a~%" e)
       (format t "scfa ~a~%" scfa)
       (format t "type-of scfa ~a~%" (type-of scfa))
       (format t "length of scfa ~a~%" (length scfa))
       (format t "type-of first scfa ~a~%" (type-of (first scfa)))
       (format t "type-of second scfa ~a~%" (type-of (second scfa)))
       (destructuring-bind (ofs err-pos) scfa
	   (format t "ofs ~a~%" ofs)
	   (format t "err-pos ~a~%" err-pos)
	   (let ((fs (subseq ofs 0 (- err-pos 3))))
	     (format t fs 1))
       ))))

(handler-case
    (format nil "~a ~a" 1)
  (simple-condition (e)
     (let ((scfa (simple-condition-format-arguments e)))
       (destructuring-bind (ofs err-pos) scfa
	   (let ((fs (subseq ofs 0 (- err-pos 3))))
	     (format nil fs 1))
       ))))

(handler-case
    (format nil "~a ~a" 1)
  (simple-condition (e)
     (let* ((scfa (simple-condition-format-arguments e))
	    (ofs (first scfa))
	    (err-pos (second scfa))
	    (fs (subseq ofs 0 (- err-pos 3))))
	(format nil fs 1))))

(defun fixit (st fs &rest args)
  (apply #'format st fs args))

(defun safe-format (s c &args)
(handler-case
    (apply #'format s c args)
(simple-condition (e)
  (format t "~a" 
     (simple-condition-format-arguments e))
 (destructuring-bind (a p)
     (simple-condition-format-arguments e)
   (subseq a 0 p)))))

(defun divide-with-restarts (x y)
  (restart-case (/ x y)
    (return-zero ()  ;; <-- creates a new restart called "RETURN-ZERO"
      0)
    (divide-by-one ()
      (/ x 1))))

(defun divide-and-handle-error (x y)
  (handler-bind
      ((division-by-zero (lambda (c)
                           (format t "Got error: ~a~%" c) ;; error-message
                           (format t "and will divide by 1~&")
                           (invoke-restart 'divide-by-one))))
    (divide-with-restarts x y)))


