;(jnil:translate-java-project "JnilTests" "~/Desktop/" :common-lisp :compiler-switches '(:optimize-2)) 
(jnil::jnil-generate-code nil :common-lisp t nil)
