(defgeneric f (a b) (:method (a b) (format t "generic~%")))
(defmethod f (a (b (eql 'x))) (format t "x specializer~%")) 
(defmethod f (a (b (eql 'y))) (format t "y specializer~%")) 
