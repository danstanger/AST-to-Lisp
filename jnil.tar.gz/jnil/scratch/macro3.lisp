;(string-upcase (first (last (str:split "." "org.eclipse.jdt.core.dom.IBinding"))))
(defmacro def-java-class (arg1 arg2 arg3 arg4 &rest rest)
  (declare (ignorable rest))
  (let* ((klass-name (first arg1))
         (java-class-string (second arg1))
         (fields (first (first arg4)))
         (field-name (if (first fields) (first fields) 'binding-variable-value))
         (field-val-string (second fields)))

    `(progn
       (defclass java-class ,arg2
         ((,klass-name :initform ,java-class-string
                   :accessor binding-of)
          (,field-name :initform ,field-val-string
                       :accessor ,(intern (symbol-name field-name)))))

       (defun ,klass-name () t)

       (defclass ,klass-name () ()))))
