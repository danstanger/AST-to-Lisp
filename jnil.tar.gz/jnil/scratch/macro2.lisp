;define a lisp macro which turns (def-java-class (binding "org.eclipse.jdt.core.dom.IBinding") () () (((binding-variable-value "VARIABLE"))) ()) into a class whose slots are binding and binding-variable-value with the strings as initial values and also defines a function binding which takes no arguments and also defines a class binding with no slots.
(defmacro def-java-class (class-spec &rest rest)
  (declare (ignorable rest))
  (let* ((class-name (first class-spec))
         (java-class-string (second class-spec))
         
         ;; Extract the nested `binding-variable-value` from the macro form
         (fields (third (fourth (third class-spec))))
         (field-name (first fields))
         (field-val-string (second fields)))
    
    `(progn
       (defclass ,class-name ()
         ((binding :initarg ,java-class-string 
                   :accessor binding-of)
          (,field-name :initarg ,(intern (symbol-name field-name) "KEYWORD")
                       :initform ,field-val-string 
                       :accessor ,(intern (symbol-name field-name)))))

       (defun ,class-name () t)

       (defclass ,class-name () ()))))

