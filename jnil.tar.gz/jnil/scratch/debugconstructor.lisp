(in-package #:jnil.ast)
(macroexpand '(make-constructor simple-name node-parent name-string name-binding))
(make-constructor simple-name node-parent name-string name-binding)
 (setf s (make-simple-name :node-parent "jello" :name-string 2 :name-binding 3))  
 (slot-value s 'jnil.ast::node-parent)
 (slot-value s 'jnil.ast::name-string)
(slot-value s 'jnil.ast::name-binding)
JNIL.AST[53]>

JNIL.AST[55]> (setf s (jnil.ast::make-simple-name :node-parent "jello" :name-string 2 :name-binding 3))

[1]> 
MAKE-CONSTRUCTOR
(setf s (make-simple-name :name-string "jello" :name-binding 1 :node-parent 2))

(defmacro make-constructor (klass &rest args)
  (let ((klass-constructor-name (intern (format nil "MAKE-~a" (symbol-name klass))))
        (new-args (append args '((child nil child-supplied-p)))))
  `(progn
     (defun ,klass-constructor-name
            (&key ,@(loop for a in new-args collect a))
      (let ((sn (make-instance ',klass)))
       (when child-supplied-p (setf (slot-value sn 'node-parent) child))
       ,@(loop for a in args collect `(setf (slot-value sn ',a) ,a))
       sn)))))

(macroexpand '(make-constructor simple-name node-parent name-string name-binding))

(defmacro make-constructor (klass &rest args)
  (let* ((klass-constructor-name (intern (format nil "MAKE-~a" (symbol-name klass))))
	 (default-args (loop for a in args collect (list a nil)))
         (new-args (append default-args '((child nil child-supplied-p)))))
  `(progn
     (defun ,klass-constructor-name
            (&key ,@(loop for a in new-args collect a))
      (let ((sn (make-instance ',klass)))
       (when child-supplied-p (setf (slot-value child 'node-parent) sn))
       ,@(loop for a in args collect `(setf (slot-value sn ',a) ,a))
       sn)))))

(macroexpand '(make-constructor simple-name node-parent name-string name-binding))
