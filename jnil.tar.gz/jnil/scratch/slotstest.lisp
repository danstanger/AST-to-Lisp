(APPEND
 '((:NAME ECLIPSE-NAME :INITFORM "org.eclipse.jdt.core.dom.BreakStatement" :INITFUNCTION #<COMPILED-FUNCTION CLOS::CONSTANT-INITFUNCTION>
    :READERS (ECLIPSE-NAME))
   (:NAME BINDING-VARIABLE-VALUE :INITFORM NIL :INITFUNCTION #<COMPILED-FUNCTION CLOS::CONSTANT-INITFUNCTION> :READERS
    (BINDING-VARIABLE-VALUE))
   (:NAME METHODS :INITFORM 'NIL :INITFUNCTION #<COMPILED-FUNCTION CLOS::CONSTANT-INITFUNCTION> :READERS (METHODS)))
 '(STATEMENT-LABEL))
1. Trace: APPEND ==> 
((:NAME ECLIPSE-NAME :INITFORM "org.eclipse.jdt.core.dom.BreakStatement" :INITFUNCTION #<COMPILED-FUNCTION CLOS::CONSTANT-INITFUNCTION>
  :READERS (ECLIPSE-NAME))
 (:NAME BINDING-VARIABLE-VALUE :INITFORM NIL :INITFUNCTION #<COMPILED-FUNCTION CLOS::CONSTANT-INITFUNCTION> :READERS
  (BINDING-VARIABLE-VALUE))
 (:NAME METHODS :INITFORM 'NIL :INITFUNCTION #<COMPILED-FUNCTION CLOS::CONSTANT-INITFUNCTION> :READERS (METHODS)) STATEMENT-LABEL)

(defmethod (object statement-label)
  (function-name object))

(in-package :jnil.ast)
(load "~/slots2.lisp")
(expand-and-add-slot break-statement statement-label)

(defvar x (make-instance (find-class 'break-statement)))
(print-object x t)
(slot-value x 'eclipse-name)

(closer-mop:class-direct-slots (find-class 'break-statement))
(closer-mop:class-direct-slots (find-class 'binding))
