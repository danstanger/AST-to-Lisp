;(in-package #:javatools.jlinker)
(in-package #:jnil.ast)
(defvar *parser*)
(defun set-java-parser (parser) (setf *parser* parser))
(defparameter *jlinker-run-java* t)

(defmacro expand-and-add-slot (java-class new-slot-1)
  (let ((class-sym (gensym "CLASS")))
    `(let* ((,class-sym (find-class ',java-class))
	   ; (ds (c2mop:class-direct-superclasses ,class-sym))
	    (ds (butlast (rest (c2mop:class-precedence-list ,class-sym))))
            (current-slots (closer-mop:class-direct-slots ,class-sym))
            (canonical-slots (mapcar (lambda (slot)
                                       (list :name (closer-mop:slot-definition-name slot)
                                             :initform (closer-mop:slot-definition-initform slot)
                                             :initfunction (closer-mop:slot-definition-initfunction slot)
                                             :readers (list (closer-mop:slot-definition-name slot))))
                                     current-slots)))
       (c2mop:ensure-class ',java-class
			   :direct-superclasses ds
                           :direct-slots (append canonical-slots
                                                 (list (list :name ',new-slot-1)))))))

(defmacro def-java-class (arg1 arg2 arg3 arg4 &rest rest)
  (declare (ignorable rest))
  (let* ((klass-name (first arg1))
         (java-class-string (second arg1))
         (java-class-name (last (uiop:split-string java-class-string :separator ".")))
         (fields (first (first arg4)))
         (field-name (if (first fields) (first fields) 'binding-variable-value))
         (field-val-string (second fields)))

    `(progn
       (defclass ,klass-name ,arg2
         ((eclipse-name :initform ,java-class-string
          ;              :initfunction (lambda () ,java-class-string)
          )
          (,field-name :initform ,field-val-string
          ;             :initfunction (lambda () ,field-val-string)
          )))

       (defmethod print-object ((obj ,klass-name) stream)
         (let ((*print-readably* nil) (*print-circle* t))
           ;(print-unreadable-object (obj t :type t :identity t)
           (print-unreadable-object (obj t)
            (format t "class-of ~a~%" (class-of obj))
            (format t "class precedence list ~a~%"
		    (c2mop:class-precedence-list (class-of obj)))
            (format t "eclipse-name ~a~%" (slot-value obj 'eclipse-name))
;            (format t "methods ~a~%" (slot-value obj 'methods))
	     ))))))

(defun jcall (arg1 arg2 &rest arg3) t)

(defmacro def-java-method (arg1 arg2)
  (let ((function-name (first arg1))
	(java-function-name (second arg1))
	(klass-arg (first arg2)))
  `(progn
     (expand-and-add-slot ,klass-arg ,function-name)
     (defmethod ,function-name ((obj ,klass-arg) &rest arg)
       (slot-value obj ',function-name)))))

(defun jlinker-query () t)
(defun jlinker-init (&optional o) t)
(defun process-java-ast (arg1 arg2)
  (let ((java-ast (read-java-ast arg1 arg2)))
    (apply *parser* nil java-ast)))

(defun jstatic (eclipse-func eclipse-package arg1 &optional arg2)
  (cond ((string= eclipse-func "parseProjectUnit") (process-java-ast arg1 arg2))
	(t t) ; for now
  ))
(defun jlinker-end () t)
