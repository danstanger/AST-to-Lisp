(defmacro expand-and-add-slot (java-class new-slot-1)
  (let ((class-sym (gensym "CLASS")))
    `(let* ((,class-sym (find-class ',java-class))
            (current-slots (closer-mop:class-direct-slots ,class-sym))
            (canonical-slots (mapcar (lambda (slot)
                                       (list :name (closer-mop:slot-definition-name slot)
                                             :initform (closer-mop:slot-definition-initform slot)
                                             :initfunction (closer-mop:slot-definition-initfunction slot)
                                             :readers (list (closer-mop:slot-definition-name slot))))
                                     current-slots)))
       (c2mop:ensure-class ',java-class
                           :direct-slots (append canonical-slots
                                                 (list (list :name ',new-slot-1)))))))

; (load "~/slots2.lisp")
; (expand-and-add-slot break-statement statement-label)
