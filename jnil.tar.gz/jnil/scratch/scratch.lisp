(defmacro my-dolist-macro ((var list-form) &body body)
  `(dolist (,var ,list-form)
     ,@body))
(macroexpand-1 '(my-dolist-macro (x '(1 2 3)) (print x)))

(defmacro my-dolist-macro ((var list-form) &body body)
 (let (var (list-form '(1 2 3)))
  `(dolist (,var ,list-form)
     ,@body)))


(defmacro myloop ()
(loop for item in '(1 2 3 4 5)
      do (print item)))

(defmacro myloop1 ()
(loop for item in (getf *jlinker-data* :fn) do (print item)))

(mapc #'(lambda (key) (setf (getf *jlinker-data* key) nil))
  (loop :for (key nil) :on  *jlinker-data* :by #'cddr
      :collect key))

(defun find-classes-in-package (package-designator)
  "Returns a list of all class objects defined by symbols in the given package."
  (let ((package (find-package package-designator))
        (classes '()))
    (when package
      (do-symbols (sym package)
        ;; Ensure the symbol belongs to this package and names a class
        (when (and (eq (symbol-package sym) package)
                   (find-class sym nil))
          (pushnew (find-class sym) classes))))
    classes))
(find-classes-in-package *package*)
