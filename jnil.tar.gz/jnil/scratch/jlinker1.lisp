;(in-package #:javatools.jlinker)
(in-package #:jnil.ast)
(defvar *parser*)
(defun set-java-parser (parser) (setf *parser* parser))
(defparameter *jlinker-run-java* t)
(defmacro def-java-class (arg1 arg2 arg3 arg4 &rest rest)
  (declare (ignorable rest))
  (let* ((klass-name (first arg1))
         (java-class-string (second arg1))
         (fields (first (first arg4)))
         (field-name (if (first fields) (first fields) 'binding-variable-value))
         (field-val-string (second fields)))

    `(progn
       (defclass ,klass-name ,arg2
         ((eclipse-name :initform ,java-class-string
                        :initfunction (lambda () ,java-class-string))
          (,field-name :initform ,field-val-string
                       :initfunction (lambda () ,field-val-string))))

       (defmethod print-object ((obj ,klass-name) stream)
	 (let ((*print-readably* nil) (*print-circle* t))
           ;(print-unreadable-object (obj t :type t :identity t)
           (print-unreadable-object (obj t)
            (format t "eclipse-name ~a~%" (slot-value obj 'eclipse-name))
            (format t "methods ~a~%" (slot-value obj 'methods)))))

  ;     (defmethod ,klass-name (&optional a) t)
)))

(defun jcall (arg1 arg2 &rest arg3) t)

(defmacro def-java-method (arg1 arg2)
  (let ((function-name (first arg1))
	(java-function-name (second arg1))
	(klass-arg (first arg2)))
  `(progn
     (defun ,function-name (,klass-arg)
       (with-slots (methods) ,klass-arg
	 (acons ,function-name (intern ,java-function-name) methods))))))

;(defgeneric binding-variable-value (v))
;(defgeneric binding-modifiers (binding))
;(defun binding-kind (binding) t)
;(defun binding-name (binding) t)
(defun jlinker-query () t)
(defun jlinker-init (&optional o) t)
(defun process-java-ast (arg1 arg2)
  (let ((java-ast (read-java-ast arg1 arg2)))
    (apply *parser* nil java-ast)))

(defun jstatic (eclipse-func eclipse-package arg1 &optional arg2)
  (cond ((string= eclipse-func "parseProjectUnit") (process-java-ast arg1 arg2))
	(t t) ; for now
  ))
(defun jlinker-end () t)
