(defun add-two-slots (class-name)
  "Adds two slots to the direct-slots of an existing class using the MOP."
  (let* ((class (find-class class-name))
         ;; 1. Retrieve the existing direct slots
         (existing-slots (c2mop:class-direct-slots class))
         ;; 2. Construct metaobjects for the two new slots
         (new-slot-1 (c2mop:make-direct-slot-definition
                      class
                      :name 'new-slot-1
                      :initargs '(:new-slot-1)
                      :initform nil))
         (new-slot-2 (c2mop:make-direct-slot-definition
                      class
                      :name 'new-slot-2
                      :initargs '(:new-slot-2)
                      :initform nil))
         ;; 3. Combine old and new direct slots
         (updated-slots (append existing-slots (list new-slot-1 new-slot-2))))
    
    ;; 4. Update the class metaobject with the new direct slots
    (setf (c2mop:class-direct-slots class) updated-slots)
    
    ;; 5. Re-finalize the class so CLOS updates the instances and effective slots
    (c2mop:finalize-inheritance class)
    class))

(defmacro expand-and-add-slots (class-name new-slot-1 new-slot-2)
  "Retrieves the slots of CLASS-NAME, appends NEW-SLOT-1 and NEW-SLOT-2, 
and updates the class using the MOP."
  (let ((class-sym (gensym "CLASS")))
    `(let* ((,class-sym (find-class ',class-name))
            ;; Get the current direct slots
            (current-slots (closer-mop:class-direct-slots ,class-sym))
            ;; Convert slot metaobjects into canonical slot specifications (plist format)
            (canonical-slots (mapcar (lambda (slot)
                                       (list (closer-mop:slot-definition-name slot)
                                             :initarg (intern (symbol-name (closer-mop:slot-definition-name slot)) "KEYWORD")
                                             :initform (closer-mop:slot-definition-initform slot)
                                             :accessor (closer-mop:slot-definition-name slot)))
                                     current-slots)))
       ;; Redefine the class with the original slots + the 2 new ones
       (c2mop:ensure-class ',class-name
                           :direct-slots (append canonical-slots
                                                 (list ',new-slot-1 ',new-slot-2))))))

