         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPUTE-ACTION-STAMP>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-OPERATION-TIME)>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION CALL-WITH-AROUND-COMPILE-HOOK>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS TEST-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS TEST-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-DEPENDENCY :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-COMPONENT-OF-VERSION :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PARENT-COMPONENT :VERSION 1> #<BUILT-IN-CLASS STRING>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS CONS>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :FEATURE) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :VERSION) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-VISITING-ACTION-LIST)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITING-ACTION-LIST>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITING-ACTION-SET>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITED-ACTIONS>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-PLANNED-ACTION-COUNT)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-PLANNED-ACTION-COUNT>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-TOTAL-ACTION-COUNT)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-TOTAL-ACTION-COUNT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-FORCED-NOT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-FORCED>
WARNING: DEFCLASS: Class SEQUENTIAL-PLAN (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS LIST>)> in #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SEQUENTIAL-PLAN :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS ACTION-STATUS>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION ASDF/ACTION::ACTION-DONE-P>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS ACTION-STATUS>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION ASDF/ACTION::ACTION-STAMP>
WARNING: DEFCLASS: Class ACTION-STATUS (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class PLANNED-ACTION-STATUS (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS ACTION-STATUS :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION NEEDED-IN-IMAGE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION NEEDED-IN-IMAGE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPUTE-ACTION-STAMP>
WARNING: DEFUN/DEFMACRO: redefining function TRAVERSE-ACTION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS FILTERED-SEQUENTIAL-PLAN :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FILTERED-SEQUENTIAL-PLAN :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BUILD-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS REQUIRE-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS REQUIRE-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :REQUIRE) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SYSTEM-DEFINITION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NON-SYSTEM-SYSTEM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NON-TOPLEVEL-SYSTEM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BAD-SYSTEM-NAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: DEFGENERIC: redefining function BUNDLE-TYPE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION PROLOGUE-CODE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EPILOGUE-CODE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION NO-UIOP>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PREFIX-LISP-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION POSTFIX-LISP-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EXTRA-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EXTRA-BUILD-ARGS>
WARNING: DEFGENERIC: redefining function GATHER-OPERATION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: DEFGENERIC: redefining function GATHER-TYPE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BUNDLE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS IMAGE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS PROGRAM-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION TRIVIAL-SYSTEM-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION TRIVIAL-SYSTEM-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LINK-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-BUNDLE-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LIB-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DLL-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LIB-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DELIVER-ASD-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DELIVER-ASD-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-BUNDLE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)>
         in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-CONCATENATE-SOURCE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-CONCATENATE-SOURCE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-LOAD-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)>
         in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-LOAD-COMPILED-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS PACKAGE-INFERRED-SYSTEM-MISSING-PACKAGE-ERROR :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION OPERATION-ON-WARNINGS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION OPERATION-ON-FAILURE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF OPERATION-ON-WARNINGS)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF OPERATION-ON-FAILURE)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-PROPERTY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-PROPERTY)>
;; Loaded file /home/dxs/lisp/asdf/asdf.fas
0 errors, 0 warnings
;; Loading file /home/dxs/common-lisp/jnil/jnil.asd ...
;; Loaded file /home/dxs/common-lisp/jnil/jnil.asd
0 errors, 0 warnings
;; Loading file /home/dxs/common-lisp/jnil/cl-utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/cl-utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/jlinkerpackage.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/jlinkerpackage.lisp
;; Loading file /home/dxs/common-lisp/jnil/readfile.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/readfile.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package.lisp ...
;;  Loading file /home/dxs/common-lisp/jnil/excl.lisp ...
;;  Loaded file /home/dxs/common-lisp/jnil/excl.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jlinker.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jlinker.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/modifier.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/modifier.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/binding.lisp ...
;;  Loading file /home/dxs/common-lisp/jnil/jlinker.lisp ...
;;  Loaded file /home/dxs/common-lisp/jnil/jlinker.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-NAME in /home/dxs/common-lisp/jnil/ast/type-binding.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/binding.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-DECLARING-CLASS in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/type-binding.lisp
WARNING: DEFUN/DEFMACRO: redefining function BINDING-TYPE-BINDING in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp, was defined
         in top-level
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package-binding.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/package-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-DECLARING-CLASS in /home/dxs/common-lisp/jnil/ast/method-binding.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/node.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/node.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/anonymous-class-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/anonymous-class-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/body-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/body-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/type-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/field-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/field-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/initializer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/initializer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-BINDING in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/catch-clause.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/catch-clause.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/compilation-unit.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/compilation-unit.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/expression-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/expression-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-access.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-creation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-creation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-initializer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-initializer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/assignment.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/assignment.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/cast-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/cast-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/character-literal.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function LITERAL-VALUE in /home/dxs/common-lisp/jnil/ast/character-literal.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/character-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/class-instance-creation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/class-instance-creation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/conditional-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/conditional-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/field-access.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/field-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/infix-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-LEFT-OPERAND in /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-RIGHT-OPERAND in /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-invocation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/simple-name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/simple-name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/qualified-name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/qualified-name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/null-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/null-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/number-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/number-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/parenthesized-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/parenthesized-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-OPERAND in /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/string-literal.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function LITERAL-VALUE in /home/dxs/common-lisp/jnil/ast/string-literal.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/character-literal.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/string-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-field-access.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function FIELD-ACCESS-NAME in /home/dxs/common-lisp/jnil/ast/super-field-access.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/field-access.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-field-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function INVOCATION-NAME in /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/method-invocation.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/this-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/this-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/body-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/import-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/import-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/import-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/package-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/import-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/package-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-constructor-invocation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-constructor-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jblock.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jblock.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/ifstatement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/ifstatement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/return-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/return-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/while-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/while-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/return-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/while-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/for-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/for-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/while-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/for-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/while-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/for-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/do-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/do-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/for-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/do-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/for-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/do-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/empty-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/empty-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/switch-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/switch-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/do-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/continue-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-LABEL in /home/dxs/common-lisp/jnil/ast/continue-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/continue-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/break-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-LABEL in /home/dxs/common-lisp/jnil/ast/break-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/continue-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/break-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/try-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/try-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/throw-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/throw-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/switch-case.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/switch-case.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-TYPE in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/field-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/package-declaration.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-BINDING in /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-fragment.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-fragment.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp,
         was defined in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-TYPE in /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jtype.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jtype.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/primitive-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/primitive-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/simple-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/simple-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/visitor.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/visitor.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/caching-layer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/caching-layer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/process.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/process.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/package.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/lisp-format.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/lisp-format.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/linj-format.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/linj-format.lisp
;; Loading file /home/dxs/common-lisp/jnil/package.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/jnil-utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/jnil-utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/addit-knowledge/addit-knowledge-framework.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/addit-knowledge/addit-knowledge-framework.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/annotator.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/annotator.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-knowledge.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-knowledge.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/basic-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/basic-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-typer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-typer.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/linj-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/linj-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/linj-typer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/linj-typer.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/lisp-guru.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/lisp-guru.lisp
;; Loading file /home/dxs/common-lisp/jnil/main.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/main.lisp
0 errors, 32 warnings
#<ASDF/LISP-ACTION:LOAD-SOURCE-OP> ;
#<ASDF/PLAN:SEQUENTIAL-PLAN #x1A665E26>
[1]> (jnil::jnil-generate-code (make-instance 'jnil.ast::empty-statement) :common-lisp t nil)
; Compilation switches: NIL
;;; Running visitor: #<JNIL::ANNOTATOR #x1A75646E>
visit :before 
 vis #<ANNOTATOR #x1A75646E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>

** - Continuable Error
Break
If you continue (by typing 'continue'): Return from BREAK loop
The following restarts are also available:
ABORT          :R1      Abort main loop
Break 1 [2]> continue
defgeneric visit vis #<ANNOTATOR #x1A75646E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::ANNOTATOR #x1A75646E>
;;; Running visitor: #<JNIL::BASIC-CODER #x1A756A7E>
visit :before 
 vis #<BASIC-CODER #x1A756A7E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>

** - Continuable Error
Break
If you continue (by typing 'continue'): Return from BREAK loop
The following restarts are also available:
ABORT          :R1      Abort main loop
Break 1 [3]> continue
;;; After running visitor: #<JNIL::BASIC-CODER #x1A756A7E>
;;; Running visitor: #<JNIL::COMMON-CODER #x1A756B8E>
visit :before 
 vis #<COMMON-CODER #x1A756B8E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>

** - Continuable Error
Break
If you continue (by typing 'continue'): Return from BREAK loop
The following restarts are also available:
ABORT          :R1      Abort main loop
Break 1 [4]> continue
defgeneric visit vis #<COMMON-CODER #x1A756B8E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::COMMON-CODER #x1A756B8E>
;;; Running visitor: #<JNIL::LISP-GURU #x1A756C9E>
visit :before 
 vis #<LISP-GURU #x1A756C9E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>

** - Continuable Error
Break
If you continue (by typing 'continue'): Return from BREAK loop
The following restarts are also available:
ABORT          :R1      Abort main loop
Break 1 [5]> continue
defgeneric visit vis #<LISP-GURU #x1A756C9E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::LISP-GURU #x1A756C9E>
T
[6]> 
dxs@kitchen:~/common-lisp/jnil$ clisp -q -repl -i asdf -x "(asdf:operate 'asdf:load-source-op \"jnil\")" 
;; Loading file /home/dxs/.clisprc ...
;;  Loading file /home/dxs/quicklisp/setup.lisp ...
;;   Loading file /home/dxs/quicklisp/asdf.lisp ...
;;   Loaded file /home/dxs/quicklisp/asdf.lisp
;;  Loaded file /home/dxs/quicklisp/setup.lisp
To load "closer-mop":
  Load 1 ASDF system:
    closer-mop
; Loading "closer-mop"

;; Loaded file /home/dxs/.clisprc
;; Loading file /home/dxs/lisp/asdf/asdf.fas ...
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NOT-IMPLEMENTED-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PARAMETER-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DEPRECATED-FUNCTION-CONDITION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-CONDITION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS FUNCTION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STREAM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL STRING) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :STRING) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :LINES) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :LINE) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :FORMS) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :FORM) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL T) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS FUNCTION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STREAM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL T) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SUBPROCESS-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS INVALID-CONFIGURATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
; Upgrading ASDF from version 3.2.1 to version 3.3.7
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FORMATTED-SYSTEM-DEFINITION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-NAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DUPLICATE-NAMES> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIMES>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-INLINE-METHODS>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-IN-ORDER-TO>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-IF-FEATURE>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT>)> from an already called generic
         function #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-SIDEWAY-DEPENDENCIES)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-SIDEWAY-DEPENDENCIES>
WARNING: DEFCLASS: Class ASDF/LISP-ACTION:CL-SOURCE-FILE (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class ASDF/SYSTEM:SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS PARENT-COMPONENT :VERSION 1> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FILE-COMPONENT :VERSION 1> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-ENCODING>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-EXTERNAL-FORMAT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION AROUND-COMPILE-HOOK>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS NULL>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS STRING>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-ENTRY-POINT>
WARNING: DEFCLASS: Class PROTO-SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS SYSTEM :VERSION 2>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF SYSTEM-SOURCE-FILE)>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS SYSTEM :VERSION 2>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF BUILTIN-SYSTEM-P)>
WARNING: DEFCLASS: Class SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFUN/DEFMACRO: redefining function SYSTEM-LICENSE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-BUILD-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: DEFUN/DEFMACRO: redefining function ACTION-VALID-P in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS CIRCULAR-DEPENDENCY :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: DEFUN/DEFMACRO: redefining function CALL-WHILE-VISITING-ACTION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DOWNWARD-OPERATION> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS UPWARD-OPERATION> #<STANDARD-CLASS CHILD-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SIDEWAY-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SELFWARD-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS NON-PROPAGATING-OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Adding method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> to an already called generic function
         #<STANDARD-GENERIC-FUNCTION DOWNWARD-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION DOWNWARD-OPERATION>
WARNING: Adding method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> to an already called generic function
         #<STANDARD-GENERIC-FUNCTION SIDEWAY-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION SIDEWAY-OPERATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SELFWARD-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-OPERATION-TIME)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPUTE-ACTION-STAMP>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-OPERATION-TIME)>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION CALL-WITH-AROUND-COMPILE-HOOK>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS TEST-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS TEST-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-DEPENDENCY :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-COMPONENT-OF-VERSION :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PARENT-COMPONENT :VERSION 1> #<BUILT-IN-CLASS STRING>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS CONS>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :FEATURE) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :VERSION) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-VISITING-ACTION-LIST)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITING-ACTION-LIST>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITING-ACTION-SET>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITED-ACTIONS>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-PLANNED-ACTION-COUNT)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-PLANNED-ACTION-COUNT>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-TOTAL-ACTION-COUNT)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-TOTAL-ACTION-COUNT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-FORCED-NOT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-FORCED>
WARNING: DEFCLASS: Class SEQUENTIAL-PLAN (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS LIST>)> in #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SEQUENTIAL-PLAN :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS ACTION-STATUS>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION ASDF/ACTION::ACTION-DONE-P>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS ACTION-STATUS>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION ASDF/ACTION::ACTION-STAMP>
WARNING: DEFCLASS: Class ACTION-STATUS (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class PLANNED-ACTION-STATUS (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS ACTION-STATUS :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION NEEDED-IN-IMAGE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION NEEDED-IN-IMAGE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPUTE-ACTION-STAMP>
WARNING: DEFUN/DEFMACRO: redefining function TRAVERSE-ACTION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS FILTERED-SEQUENTIAL-PLAN :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FILTERED-SEQUENTIAL-PLAN :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BUILD-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS REQUIRE-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS REQUIRE-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :REQUIRE) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SYSTEM-DEFINITION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NON-SYSTEM-SYSTEM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NON-TOPLEVEL-SYSTEM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BAD-SYSTEM-NAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: DEFGENERIC: redefining function BUNDLE-TYPE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION PROLOGUE-CODE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EPILOGUE-CODE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION NO-UIOP>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PREFIX-LISP-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION POSTFIX-LISP-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EXTRA-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EXTRA-BUILD-ARGS>
WARNING: DEFGENERIC: redefining function GATHER-OPERATION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: DEFGENERIC: redefining function GATHER-TYPE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BUNDLE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS IMAGE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS PROGRAM-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION TRIVIAL-SYSTEM-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION TRIVIAL-SYSTEM-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LINK-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-BUNDLE-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LIB-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DLL-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LIB-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DELIVER-ASD-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DELIVER-ASD-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-BUNDLE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)>
         in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-CONCATENATE-SOURCE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-CONCATENATE-SOURCE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-LOAD-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)>
         in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-LOAD-COMPILED-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS PACKAGE-INFERRED-SYSTEM-MISSING-PACKAGE-ERROR :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION OPERATION-ON-WARNINGS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION OPERATION-ON-FAILURE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF OPERATION-ON-WARNINGS)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF OPERATION-ON-FAILURE)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-PROPERTY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-PROPERTY)>
;; Loaded file /home/dxs/lisp/asdf/asdf.fas
0 errors, 0 warnings
;; Loading file /home/dxs/common-lisp/jnil/jnil.asd ...
;; Loaded file /home/dxs/common-lisp/jnil/jnil.asd
0 errors, 0 warnings
;; Loading file /home/dxs/common-lisp/jnil/cl-utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/cl-utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/jlinkerpackage.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/jlinkerpackage.lisp
;; Loading file /home/dxs/common-lisp/jnil/readfile.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/readfile.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package.lisp ...
;;  Loading file /home/dxs/common-lisp/jnil/excl.lisp ...
;;  Loaded file /home/dxs/common-lisp/jnil/excl.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jlinker.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jlinker.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/modifier.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/modifier.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/binding.lisp ...
;;  Loading file /home/dxs/common-lisp/jnil/jlinker.lisp ...
;;  Loaded file /home/dxs/common-lisp/jnil/jlinker.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-NAME in /home/dxs/common-lisp/jnil/ast/type-binding.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/binding.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-DECLARING-CLASS in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/type-binding.lisp
WARNING: DEFUN/DEFMACRO: redefining function BINDING-TYPE-BINDING in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp, was defined
         in top-level
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package-binding.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/package-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-DECLARING-CLASS in /home/dxs/common-lisp/jnil/ast/method-binding.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/node.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/node.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/anonymous-class-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/anonymous-class-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/body-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/body-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/type-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/field-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/field-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/initializer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/initializer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-BINDING in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/catch-clause.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/catch-clause.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/compilation-unit.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/compilation-unit.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/expression-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/expression-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-access.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-creation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-creation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-initializer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-initializer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/assignment.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/assignment.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/cast-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/cast-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/character-literal.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function LITERAL-VALUE in /home/dxs/common-lisp/jnil/ast/character-literal.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/character-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/class-instance-creation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/class-instance-creation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/conditional-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/conditional-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/field-access.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/field-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/infix-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-LEFT-OPERAND in /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-RIGHT-OPERAND in /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-invocation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/simple-name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/simple-name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/qualified-name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/qualified-name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/null-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/null-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/number-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/number-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/parenthesized-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/parenthesized-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-OPERAND in /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/string-literal.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function LITERAL-VALUE in /home/dxs/common-lisp/jnil/ast/string-literal.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/character-literal.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/string-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-field-access.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function FIELD-ACCESS-NAME in /home/dxs/common-lisp/jnil/ast/super-field-access.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/field-access.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-field-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function INVOCATION-NAME in /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/method-invocation.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/this-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/this-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/body-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/import-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/import-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/import-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/package-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/import-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/package-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-constructor-invocation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-constructor-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jblock.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jblock.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/ifstatement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/ifstatement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/return-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/return-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/while-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/while-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/return-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/while-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/for-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/for-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/while-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/for-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/while-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/for-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/do-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/do-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/for-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/do-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/for-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/do-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/empty-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/empty-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/switch-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/switch-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/do-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/continue-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-LABEL in /home/dxs/common-lisp/jnil/ast/continue-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/continue-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/break-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-LABEL in /home/dxs/common-lisp/jnil/ast/break-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/continue-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/break-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/try-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/try-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/throw-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/throw-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/switch-case.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/switch-case.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-TYPE in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/field-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/package-declaration.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-BINDING in /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-fragment.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-fragment.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp,
         was defined in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-TYPE in /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jtype.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jtype.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/primitive-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/primitive-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/simple-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/simple-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/visitor.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/visitor.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/caching-layer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/caching-layer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/process.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/process.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/package.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/lisp-format.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/lisp-format.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/linj-format.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/linj-format.lisp
;; Loading file /home/dxs/common-lisp/jnil/package.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/jnil-utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/jnil-utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/addit-knowledge/addit-knowledge-framework.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/addit-knowledge/addit-knowledge-framework.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/annotator.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/annotator.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-knowledge.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-knowledge.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/basic-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/basic-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-typer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-typer.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/linj-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/linj-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/linj-typer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/linj-typer.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/lisp-guru.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/lisp-guru.lisp
;; Loading file /home/dxs/common-lisp/jnil/main.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/main.lisp
0 errors, 32 warnings
#<ASDF/LISP-ACTION:LOAD-SOURCE-OP> ;
#<ASDF/PLAN:SEQUENTIAL-PLAN #x1A733E26>
[1]> (jnil::jnil-generate-code (make-instance 'jnil.ast::empty-statement) :common-lisp t nil)
; Compilation switches: NIL
;;; Running visitor: #<JNIL::ANNOTATOR #x1A82446E>
visit :before 
 vis #<ANNOTATOR #x1A82446E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
defgeneric visit vis #<ANNOTATOR #x1A82446E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::ANNOTATOR #x1A82446E>
;;; Running visitor: #<JNIL::BASIC-CODER #x1A824A7E>
visit :before 
 vis #<BASIC-CODER #x1A824A7E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::BASIC-CODER #x1A824A7E>
;;; Running visitor: #<JNIL::COMMON-CODER #x1A824B8E>
visit :before 
 vis #<COMMON-CODER #x1A824B8E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
defgeneric visit vis #<COMMON-CODER #x1A824B8E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::COMMON-CODER #x1A824B8E>
;;; Running visitor: #<JNIL::LISP-GURU #x1A824C9E>
visit :before 
 vis #<LISP-GURU #x1A824C9E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
defgeneric visit vis #<LISP-GURU #x1A824C9E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::LISP-GURU #x1A824C9E>
T
[2]> 
dxs@kitchen:~/common-lisp/jnil$ clisp -q -repl -i asdf -x "(asdf:operate 'asdf:load-source-op \"jnil\")" 
;; Loading file /home/dxs/.clisprc ...
;;  Loading file /home/dxs/quicklisp/setup.lisp ...
;;   Loading file /home/dxs/quicklisp/asdf.lisp ...
;;   Loaded file /home/dxs/quicklisp/asdf.lisp
;;  Loaded file /home/dxs/quicklisp/setup.lisp
To load "closer-mop":
  Load 1 ASDF system:
    closer-mop
; Loading "closer-mop"

;; Loaded file /home/dxs/.clisprc
;; Loading file /home/dxs/lisp/asdf/asdf.fas ...
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NOT-IMPLEMENTED-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PARAMETER-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DEPRECATED-FUNCTION-CONDITION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-CONDITION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS FUNCTION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STREAM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL STRING) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :STRING) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :LINES) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :LINE) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :FORMS) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :FORM) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL T) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS FUNCTION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STREAM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL T) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SUBPROCESS-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS INVALID-CONFIGURATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
; Upgrading ASDF from version 3.2.1 to version 3.3.7
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FORMATTED-SYSTEM-DEFINITION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-NAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DUPLICATE-NAMES> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIMES>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-INLINE-METHODS>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-IN-ORDER-TO>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-IF-FEATURE>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT>)> from an already called generic
         function #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-SIDEWAY-DEPENDENCIES)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-SIDEWAY-DEPENDENCIES>
WARNING: DEFCLASS: Class ASDF/LISP-ACTION:CL-SOURCE-FILE (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class ASDF/SYSTEM:SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS PARENT-COMPONENT :VERSION 1> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FILE-COMPONENT :VERSION 1> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-ENCODING>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-EXTERNAL-FORMAT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION AROUND-COMPILE-HOOK>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS NULL>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS STRING>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-ENTRY-POINT>
WARNING: DEFCLASS: Class PROTO-SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS SYSTEM :VERSION 2>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF SYSTEM-SOURCE-FILE)>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS SYSTEM :VERSION 2>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF BUILTIN-SYSTEM-P)>
WARNING: DEFCLASS: Class SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFUN/DEFMACRO: redefining function SYSTEM-LICENSE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-BUILD-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: DEFUN/DEFMACRO: redefining function ACTION-VALID-P in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS CIRCULAR-DEPENDENCY :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: DEFUN/DEFMACRO: redefining function CALL-WHILE-VISITING-ACTION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DOWNWARD-OPERATION> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS UPWARD-OPERATION> #<STANDARD-CLASS CHILD-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SIDEWAY-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SELFWARD-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS NON-PROPAGATING-OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Adding method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> to an already called generic function
         #<STANDARD-GENERIC-FUNCTION DOWNWARD-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION DOWNWARD-OPERATION>
WARNING: Adding method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> to an already called generic function
         #<STANDARD-GENERIC-FUNCTION SIDEWAY-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION SIDEWAY-OPERATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SELFWARD-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-OPERATION-TIME)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPUTE-ACTION-STAMP>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-OPERATION-TIME)>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION CALL-WITH-AROUND-COMPILE-HOOK>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS TEST-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS TEST-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-DEPENDENCY :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-COMPONENT-OF-VERSION :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PARENT-COMPONENT :VERSION 1> #<BUILT-IN-CLASS STRING>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS CONS>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :FEATURE) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :VERSION) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-VISITING-ACTION-LIST)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITING-ACTION-LIST>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITING-ACTION-SET>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITED-ACTIONS>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-PLANNED-ACTION-COUNT)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-PLANNED-ACTION-COUNT>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-TOTAL-ACTION-COUNT)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-TOTAL-ACTION-COUNT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-FORCED-NOT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-FORCED>
WARNING: DEFCLASS: Class SEQUENTIAL-PLAN (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS LIST>)> in #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SEQUENTIAL-PLAN :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS ACTION-STATUS>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION ASDF/ACTION::ACTION-DONE-P>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS ACTION-STATUS>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION ASDF/ACTION::ACTION-STAMP>
WARNING: DEFCLASS: Class ACTION-STATUS (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class PLANNED-ACTION-STATUS (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS ACTION-STATUS :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION NEEDED-IN-IMAGE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION NEEDED-IN-IMAGE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPUTE-ACTION-STAMP>
WARNING: DEFUN/DEFMACRO: redefining function TRAVERSE-ACTION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS FILTERED-SEQUENTIAL-PLAN :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FILTERED-SEQUENTIAL-PLAN :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BUILD-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS REQUIRE-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS REQUIRE-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :REQUIRE) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SYSTEM-DEFINITION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NON-SYSTEM-SYSTEM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NON-TOPLEVEL-SYSTEM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BAD-SYSTEM-NAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: DEFGENERIC: redefining function BUNDLE-TYPE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION PROLOGUE-CODE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EPILOGUE-CODE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION NO-UIOP>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PREFIX-LISP-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION POSTFIX-LISP-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EXTRA-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EXTRA-BUILD-ARGS>
WARNING: DEFGENERIC: redefining function GATHER-OPERATION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: DEFGENERIC: redefining function GATHER-TYPE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BUNDLE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS IMAGE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS PROGRAM-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION TRIVIAL-SYSTEM-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION TRIVIAL-SYSTEM-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LINK-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-BUNDLE-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LIB-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DLL-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LIB-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DELIVER-ASD-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DELIVER-ASD-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-BUNDLE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)>
         in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-CONCATENATE-SOURCE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-CONCATENATE-SOURCE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-LOAD-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)>
         in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-LOAD-COMPILED-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS PACKAGE-INFERRED-SYSTEM-MISSING-PACKAGE-ERROR :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION OPERATION-ON-WARNINGS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION OPERATION-ON-FAILURE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF OPERATION-ON-WARNINGS)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF OPERATION-ON-FAILURE)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-PROPERTY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-PROPERTY)>
;; Loaded file /home/dxs/lisp/asdf/asdf.fas
0 errors, 0 warnings
;; Loading file /home/dxs/common-lisp/jnil/jnil.asd ...
;; Loaded file /home/dxs/common-lisp/jnil/jnil.asd
0 errors, 0 warnings
;; Loading file /home/dxs/common-lisp/jnil/cl-utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/cl-utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/jlinkerpackage.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/jlinkerpackage.lisp
;; Loading file /home/dxs/common-lisp/jnil/readfile.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/readfile.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package.lisp ...
;;  Loading file /home/dxs/common-lisp/jnil/excl.lisp ...
;;  Loaded file /home/dxs/common-lisp/jnil/excl.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jlinker.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jlinker.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/modifier.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/modifier.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/binding.lisp ...
;;  Loading file /home/dxs/common-lisp/jnil/jlinker.lisp ...
;;  Loaded file /home/dxs/common-lisp/jnil/jlinker.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-NAME in /home/dxs/common-lisp/jnil/ast/type-binding.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/binding.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-DECLARING-CLASS in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/type-binding.lisp
WARNING: DEFUN/DEFMACRO: redefining function BINDING-TYPE-BINDING in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp, was defined
         in top-level
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package-binding.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/package-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-DECLARING-CLASS in /home/dxs/common-lisp/jnil/ast/method-binding.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/node.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/node.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/anonymous-class-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/anonymous-class-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/body-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/body-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/type-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/field-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/field-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/initializer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/initializer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-BINDING in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/catch-clause.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/catch-clause.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/compilation-unit.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/compilation-unit.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/expression-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/expression-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-access.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-creation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-creation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-initializer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-initializer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/assignment.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/assignment.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/cast-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/cast-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/character-literal.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function LITERAL-VALUE in /home/dxs/common-lisp/jnil/ast/character-literal.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/character-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/class-instance-creation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/class-instance-creation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/conditional-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/conditional-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/field-access.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/field-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/infix-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-LEFT-OPERAND in /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-RIGHT-OPERAND in /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-invocation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/simple-name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/simple-name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/qualified-name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/qualified-name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/null-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/null-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/number-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/number-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/parenthesized-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/parenthesized-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-OPERAND in /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/string-literal.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function LITERAL-VALUE in /home/dxs/common-lisp/jnil/ast/string-literal.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/character-literal.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/string-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-field-access.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function FIELD-ACCESS-NAME in /home/dxs/common-lisp/jnil/ast/super-field-access.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/field-access.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-field-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function INVOCATION-NAME in /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/method-invocation.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/this-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/this-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/body-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/import-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/import-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/import-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/package-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/import-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/package-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-constructor-invocation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-constructor-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jblock.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jblock.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/ifstatement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/ifstatement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/return-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/return-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/while-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/while-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/return-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/while-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/for-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/for-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/while-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/for-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/while-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/for-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/do-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/do-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/for-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/do-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/for-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/do-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/empty-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/empty-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/switch-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/switch-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/do-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/continue-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-LABEL in /home/dxs/common-lisp/jnil/ast/continue-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/continue-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/break-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-LABEL in /home/dxs/common-lisp/jnil/ast/break-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/continue-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/break-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/try-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/try-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/throw-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/throw-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/switch-case.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/switch-case.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-TYPE in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/field-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/package-declaration.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-BINDING in /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-fragment.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-fragment.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp,
         was defined in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-TYPE in /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jtype.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jtype.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/primitive-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/primitive-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/simple-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/simple-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/visitor.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/visitor.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/caching-layer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/caching-layer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/process.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/process.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/package.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/lisp-format.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/lisp-format.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/linj-format.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/linj-format.lisp
;; Loading file /home/dxs/common-lisp/jnil/package.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/jnil-utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/jnil-utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/addit-knowledge/addit-knowledge-framework.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/addit-knowledge/addit-knowledge-framework.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/annotator.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/annotator.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-knowledge.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-knowledge.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/basic-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/basic-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-typer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-typer.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/linj-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/linj-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/linj-typer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/linj-typer.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/lisp-guru.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/lisp-guru.lisp
;; Loading file /home/dxs/common-lisp/jnil/main.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/main.lisp
0 errors, 32 warnings
#<ASDF/LISP-ACTION:LOAD-SOURCE-OP> ;
#<ASDF/PLAN:SEQUENTIAL-PLAN #x1B616E26>
[1]> (jnil::jnil-generate-code (make-instance 'jnil.ast::empty-statement) :common-lisp t nil)
; Compilation switches: NIL
;;; Running visitor: #<JNIL::ANNOTATOR #x1B7072FE>
visit :before 
 vis #<ANNOTATOR #x1B7072FE> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
defgeneric visit vis #<ANNOTATOR #x1B7072FE> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::ANNOTATOR #x1B7072FE>
;;; Running visitor: #<JNIL::BASIC-CODER #x1B70790E>
visit :before 
 vis #<BASIC-CODER #x1B70790E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::BASIC-CODER #x1B70790E>
;;; Running visitor: #<JNIL::COMMON-CODER #x1B707A1E>
visit :before 
 vis #<COMMON-CODER #x1B707A1E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
defgeneric visit vis #<COMMON-CODER #x1B707A1E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::COMMON-CODER #x1B707A1E>
;;; Running visitor: #<JNIL::LISP-GURU #x1B707B2E>
visit :before 
 vis #<LISP-GURU #x1B707B2E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
defgeneric visit vis #<LISP-GURU #x1B707B2E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::LISP-GURU #x1B707B2E>
T
[2]> 
dxs@kitchen:~/common-lisp/jnil$ clisp -q -repl -i asdf -x "(asdf:operate 'asdf:load-source-op \"jnil\")" 
;; Loading file /home/dxs/.clisprc ...
;;  Loading file /home/dxs/quicklisp/setup.lisp ...
;;   Loading file /home/dxs/quicklisp/asdf.lisp ...
;;   Loaded file /home/dxs/quicklisp/asdf.lisp
;;  Loaded file /home/dxs/quicklisp/setup.lisp
To load "closer-mop":
  Load 1 ASDF system:
    closer-mop
; Loading "closer-mop"

;; Loaded file /home/dxs/.clisprc
;; Loading file /home/dxs/lisp/asdf/asdf.fas ...
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NOT-IMPLEMENTED-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PARAMETER-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DEPRECATED-FUNCTION-CONDITION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-CONDITION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS FUNCTION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STREAM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL STRING) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :STRING) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :LINES) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :LINE) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :FORMS) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :FORM) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL T) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS FUNCTION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STREAM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL T) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SUBPROCESS-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS INVALID-CONFIGURATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
; Upgrading ASDF from version 3.2.1 to version 3.3.7
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FORMATTED-SYSTEM-DEFINITION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-NAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DUPLICATE-NAMES> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIMES>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-INLINE-METHODS>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-IN-ORDER-TO>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-IF-FEATURE>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT>)> from an already called generic
         function #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-SIDEWAY-DEPENDENCIES)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-SIDEWAY-DEPENDENCIES>
WARNING: DEFCLASS: Class ASDF/LISP-ACTION:CL-SOURCE-FILE (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class ASDF/SYSTEM:SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS PARENT-COMPONENT :VERSION 1> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FILE-COMPONENT :VERSION 1> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-ENCODING>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-EXTERNAL-FORMAT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION AROUND-COMPILE-HOOK>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS NULL>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS STRING>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-ENTRY-POINT>
WARNING: DEFCLASS: Class PROTO-SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS SYSTEM :VERSION 2>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF SYSTEM-SOURCE-FILE)>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS SYSTEM :VERSION 2>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF BUILTIN-SYSTEM-P)>
WARNING: DEFCLASS: Class SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFUN/DEFMACRO: redefining function SYSTEM-LICENSE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-BUILD-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: DEFUN/DEFMACRO: redefining function ACTION-VALID-P in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS CIRCULAR-DEPENDENCY :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: DEFUN/DEFMACRO: redefining function CALL-WHILE-VISITING-ACTION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DOWNWARD-OPERATION> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS UPWARD-OPERATION> #<STANDARD-CLASS CHILD-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SIDEWAY-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SELFWARD-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS NON-PROPAGATING-OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Adding method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> to an already called generic function
         #<STANDARD-GENERIC-FUNCTION DOWNWARD-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION DOWNWARD-OPERATION>
WARNING: Adding method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> to an already called generic function
         #<STANDARD-GENERIC-FUNCTION SIDEWAY-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION SIDEWAY-OPERATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SELFWARD-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-OPERATION-TIME)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPUTE-ACTION-STAMP>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-OPERATION-TIME)>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION CALL-WITH-AROUND-COMPILE-HOOK>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS TEST-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS TEST-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-DEPENDENCY :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-COMPONENT-OF-VERSION :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PARENT-COMPONENT :VERSION 1> #<BUILT-IN-CLASS STRING>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS CONS>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :FEATURE) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :VERSION) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-VISITING-ACTION-LIST)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITING-ACTION-LIST>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITING-ACTION-SET>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITED-ACTIONS>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-PLANNED-ACTION-COUNT)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-PLANNED-ACTION-COUNT>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-TOTAL-ACTION-COUNT)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-TOTAL-ACTION-COUNT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-FORCED-NOT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-FORCED>
WARNING: DEFCLASS: Class SEQUENTIAL-PLAN (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS LIST>)> in #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SEQUENTIAL-PLAN :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS ACTION-STATUS>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION ASDF/ACTION::ACTION-DONE-P>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS ACTION-STATUS>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION ASDF/ACTION::ACTION-STAMP>
WARNING: DEFCLASS: Class ACTION-STATUS (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class PLANNED-ACTION-STATUS (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS ACTION-STATUS :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION NEEDED-IN-IMAGE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION NEEDED-IN-IMAGE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPUTE-ACTION-STAMP>
WARNING: DEFUN/DEFMACRO: redefining function TRAVERSE-ACTION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS FILTERED-SEQUENTIAL-PLAN :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FILTERED-SEQUENTIAL-PLAN :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BUILD-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS REQUIRE-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS REQUIRE-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :REQUIRE) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SYSTEM-DEFINITION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NON-SYSTEM-SYSTEM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NON-TOPLEVEL-SYSTEM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BAD-SYSTEM-NAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: DEFGENERIC: redefining function BUNDLE-TYPE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION PROLOGUE-CODE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EPILOGUE-CODE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION NO-UIOP>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PREFIX-LISP-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION POSTFIX-LISP-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EXTRA-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EXTRA-BUILD-ARGS>
WARNING: DEFGENERIC: redefining function GATHER-OPERATION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: DEFGENERIC: redefining function GATHER-TYPE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BUNDLE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS IMAGE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS PROGRAM-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION TRIVIAL-SYSTEM-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION TRIVIAL-SYSTEM-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LINK-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-BUNDLE-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LIB-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DLL-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LIB-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DELIVER-ASD-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DELIVER-ASD-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-BUNDLE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)>
         in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-CONCATENATE-SOURCE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-CONCATENATE-SOURCE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-LOAD-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)>
         in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-LOAD-COMPILED-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS PACKAGE-INFERRED-SYSTEM-MISSING-PACKAGE-ERROR :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION OPERATION-ON-WARNINGS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION OPERATION-ON-FAILURE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF OPERATION-ON-WARNINGS)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF OPERATION-ON-FAILURE)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-PROPERTY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-PROPERTY)>
;; Loaded file /home/dxs/lisp/asdf/asdf.fas
0 errors, 0 warnings
;; Loading file /home/dxs/common-lisp/jnil/jnil.asd ...
;; Loaded file /home/dxs/common-lisp/jnil/jnil.asd
0 errors, 0 warnings
;; Loading file /home/dxs/common-lisp/jnil/cl-utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/cl-utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/jlinkerpackage.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/jlinkerpackage.lisp
;; Loading file /home/dxs/common-lisp/jnil/readfile.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/readfile.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package.lisp ...
;;  Loading file /home/dxs/common-lisp/jnil/excl.lisp ...
;;  Loaded file /home/dxs/common-lisp/jnil/excl.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jlinker.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jlinker.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/modifier.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/modifier.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/binding.lisp ...
;;  Loading file /home/dxs/common-lisp/jnil/jlinker.lisp ...
;;  Loaded file /home/dxs/common-lisp/jnil/jlinker.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-NAME in /home/dxs/common-lisp/jnil/ast/type-binding.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/binding.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-DECLARING-CLASS in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/type-binding.lisp
WARNING: DEFUN/DEFMACRO: redefining function BINDING-TYPE-BINDING in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp, was defined
         in top-level
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package-binding.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/package-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-DECLARING-CLASS in /home/dxs/common-lisp/jnil/ast/method-binding.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/node.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/node.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/anonymous-class-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/anonymous-class-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/body-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/body-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/type-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/field-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/field-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/initializer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/initializer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-BINDING in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/catch-clause.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/catch-clause.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/compilation-unit.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/compilation-unit.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/expression-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/expression-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-access.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-creation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-creation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-initializer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-initializer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/assignment.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/assignment.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/cast-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/cast-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/character-literal.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function LITERAL-VALUE in /home/dxs/common-lisp/jnil/ast/character-literal.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/character-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/class-instance-creation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/class-instance-creation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/conditional-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/conditional-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/field-access.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/field-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/infix-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-LEFT-OPERAND in /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-RIGHT-OPERAND in /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-invocation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/simple-name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/simple-name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/qualified-name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/qualified-name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/null-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/null-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/number-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/number-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/parenthesized-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/parenthesized-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-OPERAND in /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/string-literal.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function LITERAL-VALUE in /home/dxs/common-lisp/jnil/ast/string-literal.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/character-literal.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/string-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-field-access.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function FIELD-ACCESS-NAME in /home/dxs/common-lisp/jnil/ast/super-field-access.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/field-access.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-field-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function INVOCATION-NAME in /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/method-invocation.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/this-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/this-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/body-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/import-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/import-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/import-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/package-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/import-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/package-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-constructor-invocation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-constructor-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jblock.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jblock.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/ifstatement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/ifstatement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/return-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/return-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/while-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/while-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/return-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/while-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/for-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/for-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/while-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/for-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/while-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/for-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/do-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/do-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/for-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/do-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/for-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/do-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/empty-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/empty-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/switch-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/switch-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/do-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/continue-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-LABEL in /home/dxs/common-lisp/jnil/ast/continue-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/continue-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/break-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-LABEL in /home/dxs/common-lisp/jnil/ast/break-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/continue-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/break-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/try-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/try-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/throw-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/throw-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/switch-case.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/switch-case.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-TYPE in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/field-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/package-declaration.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-BINDING in /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-fragment.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-fragment.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp,
         was defined in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-TYPE in /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jtype.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jtype.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/primitive-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/primitive-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/simple-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/simple-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/visitor.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/visitor.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/caching-layer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/caching-layer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/process.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/process.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/package.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/lisp-format.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/lisp-format.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/linj-format.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/linj-format.lisp
;; Loading file /home/dxs/common-lisp/jnil/package.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/jnil-utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/jnil-utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/addit-knowledge/addit-knowledge-framework.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/addit-knowledge/addit-knowledge-framework.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/annotator.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/annotator.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-knowledge.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-knowledge.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/basic-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/basic-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-typer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-typer.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/linj-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/linj-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/linj-typer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/linj-typer.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/lisp-guru.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/lisp-guru.lisp
;; Loading file /home/dxs/common-lisp/jnil/main.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/main.lisp
0 errors, 32 warnings
#<ASDF/LISP-ACTION:LOAD-SOURCE-OP> ;
#<ASDF/PLAN:SEQUENTIAL-PLAN #x1ADDFE26>
[1]> (jnil::jnil-generate-code (make-instance 'jnil.ast::empty-statement) :common-lisp t nil)
; Compilation switches: NIL
;;; Running visitor: #<JNIL::ANNOTATOR #x1AED042E>
visit :before 
 vis #<ANNOTATOR #x1AED042E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
defgeneric visit vis #<ANNOTATOR #x1AED042E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::ANNOTATOR #x1AED042E>
;;; Running visitor: #<JNIL::BASIC-CODER #x1AED0A3E>
visit :before 
 vis #<BASIC-CODER #x1AED0A3E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::BASIC-CODER #x1AED0A3E>
;;; Running visitor: #<JNIL::COMMON-CODER #x1AED0B4E>
visit :before 
 vis #<COMMON-CODER #x1AED0B4E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
defgeneric visit vis #<COMMON-CODER #x1AED0B4E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::COMMON-CODER #x1AED0B4E>
;;; Running visitor: #<JNIL::LISP-GURU #x1AED0C5E>
visit :before 
 vis #<LISP-GURU #x1AED0C5E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
defgeneric visit vis #<LISP-GURU #x1AED0C5E> node #<eclipse-name-of org.eclipse.jdt.core.dom.EmptyStatement
methods NIL
>
;;; After running visitor: #<JNIL::LISP-GURU #x1AED0C5E>
T
[2]> (load "~/slots2.lisp")
;; Loading file /home/dxs/slots2.lisp ...
;; Loaded file /home/dxs/slots2.lisp
#P"/home/dxs/slots2.lisp"
[3]> (macroexpand '(expand-and-add-slot break-statement statement-label))
(LET*
 ((#:CLASS29004 (FIND-CLASS 'BREAK-STATEMENT)) (CURRENT-SLOTS (CLASS-DIRECT-SLOTS #:CLASS29004))
  (CANONICAL-SLOTS
   (MAPCAR
    (LAMBDA (SLOT)
     (LIST :NAME (SLOT-DEFINITION-NAME SLOT) :INITFORM (SLOT-DEFINITION-INITFORM SLOT) :INITFUNCTION (SLOT-DEFINITION-INITFUNCTION SLOT)
      :READER (SLOT-DEFINITION-NAME SLOT)))
    CURRENT-SLOTS)))
 (ENSURE-CLASS 'BREAK-STATEMENT :DIRECT-SLOTS (APPEND CANONICAL-SLOTS (LIST 'STATEMENT-LABEL)))) ;
T
[4]> (find-class 'break-statement)

*** - FIND-CLASS: BREAK-STATEMENT does not name a class
The following restarts are available:
ABORT          :R1      Abort main loop
Break 1 [5]> 
[6]> (find-class 'jnil.ast::break-statement)
#<STANDARD-CLASS JNIL.AST:BREAK-STATEMENT>
[7]> (expand-and-add-slot jnil.ast::break-statement jnil.ast::statement-label)

*** - MAKE-INSTANCE: illegal keyword/value pair :READER, JNIL.AST::ECLIPSE-NAME in argument list.
      The allowed keywords are
       (:NAME :INITARGS :TYPE :ALLOCATION CLOS::INHERITABLE-INITER CLOS::INHERITABLE-DOC :READERS :WRITERS :INITFORM :INITFUNCTION
        :DOCUMENTATION CLOS::DEFCLASS-FORM)

The following restarts are available:
ABORT          :R1      Abort main loop
Break 1 [8]> 
[9]> (load "~/slots2.lisp")
;; Loading file /home/dxs/slots2.lisp ...
;; Loaded file /home/dxs/slots2.lisp
#P"/home/dxs/slots2.lisp"
[10]> (expand-and-add-slot jnil.ast::break-statement jnil.ast::statement-label)

*** - (INITIALIZE-INSTANCE SLOT-DEFINITION) for slot JNIL.AST::ECLIPSE-NAME: The :READERS argument should be a proper list of function
      names, not JNIL.AST::ECLIPSE-NAME
The following restarts are available:
ABORT          :R1      Abort main loop
Break 1 [11]> 
[12]> (load "~/slots2.lisp")
;; Loading file /home/dxs/slots2.lisp ...
;; Loaded file /home/dxs/slots2.lisp
#P"/home/dxs/slots2.lisp"
[13]> (expand-and-add-slot jnil.ast::break-statement jnil.ast::statement-label)

*** - LET: variable SLOT has no value
The following restarts are available:
USE-VALUE      :R1      Input a value to be used instead of SLOT.
STORE-VALUE    :R2      Input a new value for SLOT.
ABORT          :R3      Abort main loop
Break 1 [14]> 
[15]> (expand-and-add-slot jnil.ast::break-statement jnil.ast::statement-label)

*** - LET: variable SLOT has no value
The following restarts are available:
USE-VALUE      :R1      Input a value to be used instead of SLOT.
STORE-VALUE    :R2      Input a new value for SLOT.
ABORT          :R3      Abort main loop
Break 1 [16]> 
[17]> (load "~/slots2.lisp")
;; Loading file /home/dxs/slots2.lisp ...
;; Loaded file /home/dxs/slots2.lisp
#P"/home/dxs/slots2.lisp"
[18]> (macroexpand '(expand-and-add-slot break-statement statement-label))     
(LET*
 ((#:CLASS29044 (FIND-CLASS 'BREAK-STATEMENT)) (CURRENT-SLOTS (CLASS-DIRECT-SLOTS #:CLASS29044))
  (CANONICAL-SLOTS
   (MAPCAR
    (LAMBDA (SLOT)
     (LIST :NAME (SLOT-DEFINITION-NAME SLOT) :INITFORM (SLOT-DEFINITION-INITFORM SLOT) :INITFUNCTION (SLOT-DEFINITION-INITFUNCTION SLOT)
      :READERS (SLOT-DEFINITION-NAME SLOT)))
    CURRENT-SLOTS)))
 (ENSURE-CLASS 'BREAK-STATEMENT :DIRECT-SLOTS (APPEND CANONICAL-SLOTS (LIST 'STATEMENT-LABEL)))) ;
T
[19]> (load "~/slots2.lisp")
;; Loading file /home/dxs/slots2.lisp ...
;; Loaded file /home/dxs/slots2.lisp
#P"/home/dxs/slots2.lisp"
[20]> (macroexpand '(expand-and-add-slot break-statement statement-label))
(LET*
 ((#:CLASS29045 (FIND-CLASS 'BREAK-STATEMENT)) (CURRENT-SLOTS (CLASS-DIRECT-SLOTS #:CLASS29045))
  (CANONICAL-SLOTS
   (MAPCAR
    (LAMBDA (SLOT)
     (LIST :NAME (SLOT-DEFINITION-NAME SLOT) :INITFORM (SLOT-DEFINITION-INITFORM SLOT) :INITFUNCTION (SLOT-DEFINITION-INITFUNCTION SLOT)
      :READERS (LIST (SLOT-DEFINITION-NAME SLOT))))
    CURRENT-SLOTS)))
 (ENSURE-CLASS 'BREAK-STATEMENT :DIRECT-SLOTS (APPEND CANONICAL-SLOTS (LIST 'STATEMENT-LABEL)))) ;
T
[21]> (expand-and-add-slot jnil.ast::break-statement jnil.ast::statement-label)
; (expand-and-add-slot break-statement statement-label)

*** - APPLY: dotted argument list given to #<STANDARD-GENERIC-FUNCTION COMPUTE-DIRECT-SLOT-DEFINITION-INITARGS> :
      JNIL.AST:STATEMENT-LABEL
The following restarts are available:
ABORT          :R1      Abort main loop
Break 1 [22]> 
[23]> (in-package "jnil.ast")

*** - SYSTEM::%FIND-PACKAGE: There is no package with name "jnil.ast"
The following restarts are available:
USE-VALUE      :R1      Input a value to be used instead.
ABORT          :R2      Abort main loop
Break 1 [24]> 
[25]> 
dxs@kitchen:~/common-lisp/jnil$ clisp -q -repl -i asdf -x "(asdf:operate 'asdf:load-source-op \"jnil\")" 
;; Loading file /home/dxs/.clisprc ...
;;  Loading file /home/dxs/quicklisp/setup.lisp ...
;;   Loading file /home/dxs/quicklisp/asdf.lisp ...
;;   Loaded file /home/dxs/quicklisp/asdf.lisp
;;  Loaded file /home/dxs/quicklisp/setup.lisp
To load "closer-mop":
  Load 1 ASDF system:
    closer-mop
; Loading "closer-mop"

;; Loaded file /home/dxs/.clisprc
;; Loading file /home/dxs/lisp/asdf/asdf.fas ...
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NOT-IMPLEMENTED-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PARAMETER-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DEPRECATED-FUNCTION-CONDITION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-CONDITION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS FUNCTION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STREAM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL STRING) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :STRING) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :LINES) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :LINE) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :FORMS) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL :FORM) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL T) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION SLURP-INPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS FUNCTION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STREAM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD ((EQL T) #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VOMIT-OUTPUT-STREAM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SUBPROCESS-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS INVALID-CONFIGURATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
; Upgrading ASDF from version 3.2.1 to version 3.3.7
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FORMATTED-SYSTEM-DEFINITION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-NAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DUPLICATE-NAMES> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIMES>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-INLINE-METHODS>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-IN-ORDER-TO>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-IF-FEATURE>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT>)> from an already called generic
         function #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-SIDEWAY-DEPENDENCIES)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS COMPONENT>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION COMPONENT-SIDEWAY-DEPENDENCIES>
WARNING: DEFCLASS: Class ASDF/LISP-ACTION:CL-SOURCE-FILE (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class ASDF/SYSTEM:SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS PARENT-COMPONENT :VERSION 1> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FILE-COMPONENT :VERSION 1> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION SOURCE-FILE-TYPE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-ENCODING>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-EXTERNAL-FORMAT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION AROUND-COMPILE-HOOK>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS NULL>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION VERSION-SATISFIES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS STRING>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-OPERATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-ENTRY-POINT>
WARNING: DEFCLASS: Class PROTO-SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS SYSTEM :VERSION 2>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF SYSTEM-SOURCE-FILE)>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS SYSTEM :VERSION 2>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF BUILTIN-SYSTEM-P)>
WARNING: DEFCLASS: Class SYSTEM (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFUN/DEFMACRO: redefining function SYSTEM-LICENSE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION SYSTEM-SOURCE-FILE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION COMPONENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-RELATIVE-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-PARENT-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-BUILD-PATHNAME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: DEFUN/DEFMACRO: redefining function ACTION-VALID-P in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS CIRCULAR-DEPENDENCY :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: DEFUN/DEFMACRO: redefining function CALL-WHILE-VISITING-ACTION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DOWNWARD-OPERATION> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS UPWARD-OPERATION> #<STANDARD-CLASS CHILD-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SIDEWAY-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SELFWARD-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS NON-PROPAGATING-OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Adding method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> to an already called generic function
         #<STANDARD-GENERIC-FUNCTION DOWNWARD-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION DOWNWARD-OPERATION>
WARNING: Adding method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> to an already called generic function
         #<STANDARD-GENERIC-FUNCTION SIDEWAY-OPERATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION SIDEWAY-OPERATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SELFWARD-OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-OPERATION-TIME)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION COMPUTE-ACTION-STAMP>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-OPERATION-TIME>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-OPERATION-TIME)>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION CALL-WITH-AROUND-COMPILE-HOOK>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM-WITH-RESTARTS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREPARE-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS PARENT-COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-DESCRIPTION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS CL-SOURCE-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS STATIC-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS TEST-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS TEST-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATION-DONE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-DEPENDENCY :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS MISSING-COMPONENT-OF-VERSION :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PARENT-COMPONENT :VERSION 1> #<BUILT-IN-CLASS STRING>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS CONS>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION FIND-COMPONENT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :FEATURE) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :VERSION) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)>
         in #<STANDARD-GENERIC-FUNCTION ACTION-FORCED-NOT-P>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-VISITING-ACTION-LIST)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITING-ACTION-LIST>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITING-ACTION-SET>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-VISITED-ACTIONS>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-PLANNED-ACTION-COUNT)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-PLANNED-ACTION-COUNT>
WARNING: Removing method #<CLOS:STANDARD-WRITER-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called
         generic function #<STANDARD-GENERIC-FUNCTION (SETF PLAN-TOTAL-ACTION-COUNT)>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-TOTAL-ACTION-COUNT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-FORCED-NOT>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS PLAN-TRAVERSAL>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION PLAN-FORCED>
WARNING: DEFCLASS: Class SEQUENTIAL-PLAN (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS LIST>)> in #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SEQUENTIAL-PLAN :VERSION 1>)> in #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS ACTION-STATUS>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION ASDF/ACTION::ACTION-DONE-P>
WARNING: Removing method #<CLOS:STANDARD-READER-METHOD (#<STANDARD-CLASS ACTION-STATUS>)> from an already called generic function
         #<STANDARD-GENERIC-FUNCTION ASDF/ACTION::ACTION-STAMP>
WARNING: DEFCLASS: Class ACTION-STATUS (or one of its ancestors) is being redefined, instances are obsolete
WARNING: DEFCLASS: Class PLANNED-ACTION-STATUS (or one of its ancestors) is being redefined, instances are obsolete
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS ACTION-STATUS :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION NEEDED-IN-IMAGE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION NEEDED-IN-IMAGE-P>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPUTE-ACTION-STAMP>
WARNING: DEFUN/DEFMACRO: redefining function TRAVERSE-ACTION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS FILTERED-SEQUENTIAL-PLAN :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INITIALIZE-INSTANCE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS FILTERED-SEQUENTIAL-PLAN :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PLAN-ACTIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION MAKE-PLAN>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION PERFORM-PLAN>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD :AROUND (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BUILD-OP> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPILE-OP> #<STANDARD-CLASS REQUIRE-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS REQUIRE-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> (EQL :REQUIRE) #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION RESOLVE-DEPENDENCY-COMBINATION>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SYSTEM-DEFINITION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION FIND-SYSTEM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NON-SYSTEM-SYSTEM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS NON-TOPLEVEL-SYSTEM> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BAD-SYSTEM-NAME> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: DEFGENERIC: redefining function BUNDLE-TYPE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION PROLOGUE-CODE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EPILOGUE-CODE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION NO-UIOP>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PREFIX-LISP-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION POSTFIX-LISP-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EXTRA-OBJECT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION EXTRA-BUILD-ARGS>
WARNING: DEFGENERIC: redefining function GATHER-OPERATION in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: DEFGENERIC: redefining function GATHER-TYPE in /home/dxs/lisp/asdf/asdf.fas, was defined in top-level
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BUNDLE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS IMAGE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<STANDARD-CLASS PROGRAM-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD :AFTER (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION MARK-OPERATION-DONE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS SYSTEM :VERSION 3>)> in #<STANDARD-GENERIC-FUNCTION TRIVIAL-SYSTEM-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-SOURCE-OP> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPILED-FILE :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION TRIVIAL-SYSTEM-P>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LINK-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-BUNDLE-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LIB-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DLL-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS GATHER-OPERATION :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LIB-OP :VERSION 1> #<STANDARD-CLASS PREBUILT-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DELIVER-ASD-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS DELIVER-ASD-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-BUNDLE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)>
         in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS LOAD-BUNDLE-OP> #<STANDARD-CLASS PRECOMPILED-SYSTEM :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-DEPENDS-ON>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-CONCATENATE-SOURCE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION INPUT-FILES>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION OUTPUT-FILES>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-CONCATENATE-SOURCE-OP :VERSION 1> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-LOAD-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)>
         in #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-COMPILE-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS BASIC-LOAD-COMPILED-CONCATENATED-SOURCE-OP> #<STANDARD-CLASS SYSTEM :VERSION 3>)> in
         #<STANDARD-GENERIC-FUNCTION PERFORM>
WARNING: Replacing method
         #<STANDARD-METHOD (#<STANDARD-CLASS PACKAGE-INFERRED-SYSTEM-MISSING-PACKAGE-ERROR :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-OUTPUT-TRANSLATIONS>
WARNING: Redefining an already called generic function #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS PATHNAME>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS NULL>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS CONS>)> in #<STANDARD-GENERIC-FUNCTION PROCESS-SOURCE-REGISTRY>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION-ERROR> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION PRINT-OBJECT>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION OPERATION-ON-WARNINGS>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION>)> in #<STANDARD-GENERIC-FUNCTION OPERATION-ON-FAILURE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF OPERATION-ON-WARNINGS)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS OPERATION>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF OPERATION-ON-FAILURE)>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS STRING> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS SYMBOL> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS OPERATION> #<STANDARD-CLASS COMPONENT :VERSION 1>)> in
         #<STANDARD-GENERIC-FUNCTION TRAVERSE>
WARNING: Replacing method #<STANDARD-METHOD :BEFORE (#<BUILT-IN-CLASS T> #<BUILT-IN-CLASS T>)> in #<STANDARD-GENERIC-FUNCTION OPERATE>
WARNING: Replacing method #<STANDARD-METHOD (#<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION COMPONENT-PROPERTY>
WARNING: Replacing method #<STANDARD-METHOD (#<BUILT-IN-CLASS T> #<STANDARD-CLASS COMPONENT :VERSION 1> #<BUILT-IN-CLASS T>)> in
         #<STANDARD-GENERIC-FUNCTION (SETF COMPONENT-PROPERTY)>
;; Loaded file /home/dxs/lisp/asdf/asdf.fas
0 errors, 0 warnings
;; Loading file /home/dxs/common-lisp/jnil/jnil.asd ...
;; Loaded file /home/dxs/common-lisp/jnil/jnil.asd
0 errors, 0 warnings
;; Loading file /home/dxs/common-lisp/jnil/cl-utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/cl-utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/jlinkerpackage.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/jlinkerpackage.lisp
;; Loading file /home/dxs/common-lisp/jnil/readfile.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/readfile.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package.lisp ...
;;  Loading file /home/dxs/common-lisp/jnil/excl.lisp ...
;;  Loaded file /home/dxs/common-lisp/jnil/excl.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jlinker.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jlinker.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/modifier.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/modifier.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/binding.lisp ...
;;  Loading file /home/dxs/common-lisp/jnil/jlinker.lisp ...
;;  Loaded file /home/dxs/common-lisp/jnil/jlinker.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-NAME in /home/dxs/common-lisp/jnil/ast/type-binding.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/binding.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-DECLARING-CLASS in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/type-binding.lisp
WARNING: DEFUN/DEFMACRO: redefining function BINDING-TYPE-BINDING in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp, was defined
         in top-level
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package-binding.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/package-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-binding.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function BINDING-DECLARING-CLASS in /home/dxs/common-lisp/jnil/ast/method-binding.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/variable-binding.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-binding.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/node.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/node.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/anonymous-class-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/anonymous-class-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/body-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/body-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/type-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/abstract-type-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/field-declaration.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/field-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/initializer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/initializer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-BINDING in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/type-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/catch-clause.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/catch-clause.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/compilation-unit.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/compilation-unit.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/expression-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/expression-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-access.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-creation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-creation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-initializer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-initializer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/assignment.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/assignment.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/cast-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/cast-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/character-literal.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function LITERAL-VALUE in /home/dxs/common-lisp/jnil/ast/character-literal.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/boolean-literal.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/character-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/class-instance-creation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/class-instance-creation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/conditional-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/conditional-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/field-access.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/field-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/infix-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-LEFT-OPERAND in /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-RIGHT-OPERAND in /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/infix-expression.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/instanceof-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/method-invocation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/method-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/simple-name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/simple-name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/qualified-name.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/qualified-name.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/null-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/null-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/number-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/number-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/parenthesized-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/parenthesized-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function EXPRESSION-OPERAND in /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/postfix-expression.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/prefix-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/string-literal.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function LITERAL-VALUE in /home/dxs/common-lisp/jnil/ast/string-literal.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/character-literal.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/string-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-field-access.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function FIELD-ACCESS-NAME in /home/dxs/common-lisp/jnil/ast/super-field-access.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/field-access.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-field-access.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function INVOCATION-NAME in /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/method-invocation.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-method-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/this-expression.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/this-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/type-literal.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/type-literal.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/body-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/import-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/import-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/import-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/package-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/package-declaration.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/import-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/package-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/super-constructor-invocation.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/super-constructor-invocation.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jblock.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jblock.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/ifstatement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/ifstatement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/return-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/return-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/while-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/while-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/return-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/while-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/for-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/for-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/while-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/for-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/while-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/for-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/do-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/do-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/for-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-EXPRESSION in /home/dxs/common-lisp/jnil/ast/do-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/for-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/do-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/empty-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/empty-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/switch-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/switch-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-BODY in /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/do-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/continue-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-LABEL in /home/dxs/common-lisp/jnil/ast/continue-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/labeled-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/continue-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/break-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function STATEMENT-LABEL in /home/dxs/common-lisp/jnil/ast/break-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/continue-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/break-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/try-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/try-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/throw-statement.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/throw-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/switch-case.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/switch-case.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp, was defined in
         /home/dxs/common-lisp/jnil/ast/variable-declaration-expression.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-TYPE in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/field-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-NAME in /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp, was defined
         in /home/dxs/common-lisp/jnil/ast/package-declaration.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-BINDING in /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/method-declaration.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/variable-declaration-fragment.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/variable-declaration-fragment.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp ...
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-MODIFIERS in /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp,
         was defined in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
WARNING: DEFUN/DEFMACRO: redefining function DECLARATION-TYPE in /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp, was
         defined in /home/dxs/common-lisp/jnil/ast/variable-declaration-statement.lisp
;; Loaded file /home/dxs/common-lisp/jnil/ast/single-variable-declaration.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/jtype.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/jtype.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/primitive-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/primitive-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/simple-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/simple-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/array-type.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/array-type.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/visitor.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/visitor.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/caching-layer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/caching-layer.lisp
;; Loading file /home/dxs/common-lisp/jnil/ast/utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/ast/utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/process.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/process.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/package.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/lisp-format.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/lisp-format.lisp
;; Loading file /home/dxs/common-lisp/jnil/format/linj-format.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/format/linj-format.lisp
;; Loading file /home/dxs/common-lisp/jnil/package.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/package.lisp
;; Loading file /home/dxs/common-lisp/jnil/jnil-utils.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/jnil-utils.lisp
;; Loading file /home/dxs/common-lisp/jnil/addit-knowledge/addit-knowledge-framework.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/addit-knowledge/addit-knowledge-framework.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/annotator.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/annotator.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-knowledge.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-knowledge.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/basic-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/basic-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/common-typer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/common-typer.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/linj-coder.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/linj-coder.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/linj-typer.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/linj-typer.lisp
;; Loading file /home/dxs/common-lisp/jnil/coders/lisp-guru.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/coders/lisp-guru.lisp
;; Loading file /home/dxs/common-lisp/jnil/main.lisp ...
;; Loaded file /home/dxs/common-lisp/jnil/main.lisp
0 errors, 32 warnings
#<ASDF/LISP-ACTION:LOAD-SOURCE-OP> ;
#<ASDF/PLAN:SEQUENTIAL-PLAN #x1B428E26>
[1]> (in-package :jnil.ast)
#<PACKAGE JNIL.AST>
JNIL.AST[2]> (load 


