class HelloWorld2 {
    public static void main(java.lang.String[] args, int[] iargs) {
        System.out.println("Hello, World!");
    }
}
