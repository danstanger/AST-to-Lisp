package com.example.myapp;
import java.lang.System;
class HelloWorld3 {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
