// $ANTLR 3.5.3 Java.g 2026-08-18 22:10:38

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;


/**
 * An ANTLRv3 capable Java 1.5 grammar for building ASTs.
 * BSD licence
 *
 * Copyright (c) 2007-2008 by HABELITZ Software Developments
 *
 * All rights reserved.
 *
 * http://www.habelitz.com
 *
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY HABELITZ SOFTWARE DEVELOPMENTS ('HSD') ``AS IS''
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL 'HSD' BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
@SuppressWarnings("all")
public class JavaParser extends Parser {
	public static final String[] tokenNames = new String[] {
		"<invalid>", "<EOR>", "<DOWN>", "<UP>", "ABSTRACT", "AND", "AND_ASSIGN", 
		"ANNOTATION_INIT_ARRAY_ELEMENT", "ANNOTATION_INIT_BLOCK", "ANNOTATION_INIT_DEFAULT_KEY", 
		"ANNOTATION_INIT_KEY_LIST", "ANNOTATION_LIST", "ANNOTATION_METHOD_DECL", 
		"ANNOTATION_SCOPE", "ANNOTATION_TOP_LEVEL_SCOPE", "ARGUMENT_LIST", "ARRAY_DECLARATOR", 
		"ARRAY_DECLARATOR_LIST", "ARRAY_ELEMENT_ACCESS", "ARRAY_INITIALIZER", 
		"ASSERT", "ASSIGN", "AT", "BIT_SHIFT_RIGHT", "BIT_SHIFT_RIGHT_ASSIGN", 
		"BLOCK_SCOPE", "BOOLEAN", "BREAK", "BYTE", "CASE", "CAST_EXPR", "CATCH", 
		"CATCH_CLAUSE_LIST", "CHAR", "CHARACTER_LITERAL", "CLASS", "CLASS_CONSTRUCTOR_CALL", 
		"CLASS_INSTANCE_INITIALIZER", "CLASS_STATIC_INITIALIZER", "CLASS_TOP_LEVEL_SCOPE", 
		"COLON", "COMMA", "COMMENT", "CONSTRUCTOR_DECL", "CONTINUE", "DEC", "DECIMAL_LITERAL", 
		"DEFAULT", "DIV", "DIV_ASSIGN", "DO", "DOT", "DOTSTAR", "DOUBLE", "ELLIPSIS", 
		"ELSE", "ENUM", "ENUM_TOP_LEVEL_SCOPE", "EQUAL", "ESCAPE_SEQUENCE", "EXPONENT", 
		"EXPR", "EXTENDS", "EXTENDS_BOUND_LIST", "EXTENDS_CLAUSE", "FALSE", "FINAL", 
		"FINALLY", "FLOAT", "FLOATING_POINT_LITERAL", "FLOAT_TYPE_SUFFIX", "FOR", 
		"FORMAL_PARAM_LIST", "FORMAL_PARAM_STD_DECL", "FORMAL_PARAM_VARARG_DECL", 
		"FOR_CONDITION", "FOR_EACH", "FOR_INIT", "FOR_UPDATE", "FUNCTION_METHOD_DECL", 
		"GENERIC_TYPE_ARG_LIST", "GENERIC_TYPE_PARAM_LIST", "GREATER_OR_EQUAL", 
		"GREATER_THAN", "HEX_DIGIT", "HEX_LITERAL", "IDENT", "IF", "IMPLEMENTS", 
		"IMPLEMENTS_CLAUSE", "IMPORT", "INC", "INSTANCEOF", "INT", "INTEGER_TYPE_SUFFIX", 
		"INTERFACE", "INTERFACE_TOP_LEVEL_SCOPE", "JAVADOC_COMMENT", "JAVA_ID_PART", 
		"JAVA_ID_START", "JAVA_SOURCE", "LABELED_STATEMENT", "LBRACK", "LCURLY", 
		"LESS_OR_EQUAL", "LESS_THAN", "LINE_COMMENT", "LOCAL_MODIFIER_LIST", "LOGICAL_AND", 
		"LOGICAL_NOT", "LOGICAL_OR", "LONG", "LPAREN", "METHOD_CALL", "MINUS", 
		"MINUS_ASSIGN", "MOD", "MODIFIER_LIST", "MOD_ASSIGN", "NATIVE", "NEW", 
		"NIL", "NOT", "NOT_EQUAL", "NULL", "OCTAL_ESCAPE", "OCTAL_LITERAL", "OR", 
		"OR_ASSIGN", "PACKAGE", "PARENTESIZED_EXPR", "PLUS", "PLUS_ASSIGN", "POST_DEC", 
		"POST_INC", "PRE_DEC", "PRE_INC", "PRIVATE", "PROTECTED", "PUBLIC", "QUALIFIED_TYPE_IDENT", 
		"QUESTION", "RBRACK", "RCURLY", "RETURN", "RPAREN", "SEMI", "SHIFT_LEFT", 
		"SHIFT_LEFT_ASSIGN", "SHIFT_RIGHT", "SHIFT_RIGHT_ASSIGN", "SHORT", "STAR", 
		"STAR_ASSIGN", "STATIC", "STATIC_ARRAY_CREATOR", "STRICTFP", "STRING_LITERAL", 
		"SUPER", "SUPER_CONSTRUCTOR_CALL", "SWITCH", "SWITCH_BLOCK_LABEL_LIST", 
		"SYNCHRONIZED", "THIS", "THIS_CONSTRUCTOR_CALL", "THROW", "THROWS", "THROWS_CLAUSE", 
		"TRANSIENT", "TRUE", "TRY", "TYPE", "UNARY_MINUS", "UNARY_PLUS", "UNICODE_ESCAPE", 
		"VAR_DECLARATION", "VAR_DECLARATOR", "VAR_DECLARATOR_LIST", "VOID", "VOID_METHOD_DECL", 
		"VOLATILE", "WHILE", "WS", "XOR", "XOR_ASSIGN"
	};
	public static final int EOF=-1;
	public static final int ABSTRACT=4;
	public static final int AND=5;
	public static final int AND_ASSIGN=6;
	public static final int ANNOTATION_INIT_ARRAY_ELEMENT=7;
	public static final int ANNOTATION_INIT_BLOCK=8;
	public static final int ANNOTATION_INIT_DEFAULT_KEY=9;
	public static final int ANNOTATION_INIT_KEY_LIST=10;
	public static final int ANNOTATION_LIST=11;
	public static final int ANNOTATION_METHOD_DECL=12;
	public static final int ANNOTATION_SCOPE=13;
	public static final int ANNOTATION_TOP_LEVEL_SCOPE=14;
	public static final int ARGUMENT_LIST=15;
	public static final int ARRAY_DECLARATOR=16;
	public static final int ARRAY_DECLARATOR_LIST=17;
	public static final int ARRAY_ELEMENT_ACCESS=18;
	public static final int ARRAY_INITIALIZER=19;
	public static final int ASSERT=20;
	public static final int ASSIGN=21;
	public static final int AT=22;
	public static final int BIT_SHIFT_RIGHT=23;
	public static final int BIT_SHIFT_RIGHT_ASSIGN=24;
	public static final int BLOCK_SCOPE=25;
	public static final int BOOLEAN=26;
	public static final int BREAK=27;
	public static final int BYTE=28;
	public static final int CASE=29;
	public static final int CAST_EXPR=30;
	public static final int CATCH=31;
	public static final int CATCH_CLAUSE_LIST=32;
	public static final int CHAR=33;
	public static final int CHARACTER_LITERAL=34;
	public static final int CLASS=35;
	public static final int CLASS_CONSTRUCTOR_CALL=36;
	public static final int CLASS_INSTANCE_INITIALIZER=37;
	public static final int CLASS_STATIC_INITIALIZER=38;
	public static final int CLASS_TOP_LEVEL_SCOPE=39;
	public static final int COLON=40;
	public static final int COMMA=41;
	public static final int COMMENT=42;
	public static final int CONSTRUCTOR_DECL=43;
	public static final int CONTINUE=44;
	public static final int DEC=45;
	public static final int DECIMAL_LITERAL=46;
	public static final int DEFAULT=47;
	public static final int DIV=48;
	public static final int DIV_ASSIGN=49;
	public static final int DO=50;
	public static final int DOT=51;
	public static final int DOTSTAR=52;
	public static final int DOUBLE=53;
	public static final int ELLIPSIS=54;
	public static final int ELSE=55;
	public static final int ENUM=56;
	public static final int ENUM_TOP_LEVEL_SCOPE=57;
	public static final int EQUAL=58;
	public static final int ESCAPE_SEQUENCE=59;
	public static final int EXPONENT=60;
	public static final int EXPR=61;
	public static final int EXTENDS=62;
	public static final int EXTENDS_BOUND_LIST=63;
	public static final int EXTENDS_CLAUSE=64;
	public static final int FALSE=65;
	public static final int FINAL=66;
	public static final int FINALLY=67;
	public static final int FLOAT=68;
	public static final int FLOATING_POINT_LITERAL=69;
	public static final int FLOAT_TYPE_SUFFIX=70;
	public static final int FOR=71;
	public static final int FORMAL_PARAM_LIST=72;
	public static final int FORMAL_PARAM_STD_DECL=73;
	public static final int FORMAL_PARAM_VARARG_DECL=74;
	public static final int FOR_CONDITION=75;
	public static final int FOR_EACH=76;
	public static final int FOR_INIT=77;
	public static final int FOR_UPDATE=78;
	public static final int FUNCTION_METHOD_DECL=79;
	public static final int GENERIC_TYPE_ARG_LIST=80;
	public static final int GENERIC_TYPE_PARAM_LIST=81;
	public static final int GREATER_OR_EQUAL=82;
	public static final int GREATER_THAN=83;
	public static final int HEX_DIGIT=84;
	public static final int HEX_LITERAL=85;
	public static final int IDENT=86;
	public static final int IF=87;
	public static final int IMPLEMENTS=88;
	public static final int IMPLEMENTS_CLAUSE=89;
	public static final int IMPORT=90;
	public static final int INC=91;
	public static final int INSTANCEOF=92;
	public static final int INT=93;
	public static final int INTEGER_TYPE_SUFFIX=94;
	public static final int INTERFACE=95;
	public static final int INTERFACE_TOP_LEVEL_SCOPE=96;
	public static final int JAVADOC_COMMENT=97;
	public static final int JAVA_ID_PART=98;
	public static final int JAVA_ID_START=99;
	public static final int JAVA_SOURCE=100;
	public static final int LABELED_STATEMENT=101;
	public static final int LBRACK=102;
	public static final int LCURLY=103;
	public static final int LESS_OR_EQUAL=104;
	public static final int LESS_THAN=105;
	public static final int LINE_COMMENT=106;
	public static final int LOCAL_MODIFIER_LIST=107;
	public static final int LOGICAL_AND=108;
	public static final int LOGICAL_NOT=109;
	public static final int LOGICAL_OR=110;
	public static final int LONG=111;
	public static final int LPAREN=112;
	public static final int METHOD_CALL=113;
	public static final int MINUS=114;
	public static final int MINUS_ASSIGN=115;
	public static final int MOD=116;
	public static final int MODIFIER_LIST=117;
	public static final int MOD_ASSIGN=118;
	public static final int NATIVE=119;
	public static final int NEW=120;
	public static final int NIL=121;
	public static final int NOT=122;
	public static final int NOT_EQUAL=123;
	public static final int NULL=124;
	public static final int OCTAL_ESCAPE=125;
	public static final int OCTAL_LITERAL=126;
	public static final int OR=127;
	public static final int OR_ASSIGN=128;
	public static final int PACKAGE=129;
	public static final int PARENTESIZED_EXPR=130;
	public static final int PLUS=131;
	public static final int PLUS_ASSIGN=132;
	public static final int POST_DEC=133;
	public static final int POST_INC=134;
	public static final int PRE_DEC=135;
	public static final int PRE_INC=136;
	public static final int PRIVATE=137;
	public static final int PROTECTED=138;
	public static final int PUBLIC=139;
	public static final int QUALIFIED_TYPE_IDENT=140;
	public static final int QUESTION=141;
	public static final int RBRACK=142;
	public static final int RCURLY=143;
	public static final int RETURN=144;
	public static final int RPAREN=145;
	public static final int SEMI=146;
	public static final int SHIFT_LEFT=147;
	public static final int SHIFT_LEFT_ASSIGN=148;
	public static final int SHIFT_RIGHT=149;
	public static final int SHIFT_RIGHT_ASSIGN=150;
	public static final int SHORT=151;
	public static final int STAR=152;
	public static final int STAR_ASSIGN=153;
	public static final int STATIC=154;
	public static final int STATIC_ARRAY_CREATOR=155;
	public static final int STRICTFP=156;
	public static final int STRING_LITERAL=157;
	public static final int SUPER=158;
	public static final int SUPER_CONSTRUCTOR_CALL=159;
	public static final int SWITCH=160;
	public static final int SWITCH_BLOCK_LABEL_LIST=161;
	public static final int SYNCHRONIZED=162;
	public static final int THIS=163;
	public static final int THIS_CONSTRUCTOR_CALL=164;
	public static final int THROW=165;
	public static final int THROWS=166;
	public static final int THROWS_CLAUSE=167;
	public static final int TRANSIENT=168;
	public static final int TRUE=169;
	public static final int TRY=170;
	public static final int TYPE=171;
	public static final int UNARY_MINUS=172;
	public static final int UNARY_PLUS=173;
	public static final int UNICODE_ESCAPE=174;
	public static final int VAR_DECLARATION=175;
	public static final int VAR_DECLARATOR=176;
	public static final int VAR_DECLARATOR_LIST=177;
	public static final int VOID=178;
	public static final int VOID_METHOD_DECL=179;
	public static final int VOLATILE=180;
	public static final int WHILE=181;
	public static final int WS=182;
	public static final int XOR=183;
	public static final int XOR_ASSIGN=184;

	// delegates
	public Parser[] getDelegates() {
		return new Parser[] {};
	}

	// delegators


	public JavaParser(TokenStream input) {
		this(input, new RecognizerSharedState());
	}
	public JavaParser(TokenStream input, RecognizerSharedState state) {
		super(input, state);
		this.state.ruleMemo = new HashMap[358+1];


	}

	protected TreeAdaptor adaptor = new CommonTreeAdaptor();

	public void setTreeAdaptor(TreeAdaptor adaptor) {
		this.adaptor = adaptor;
	}
	public TreeAdaptor getTreeAdaptor() {
		return adaptor;
	}
	@Override public String[] getTokenNames() { return JavaParser.tokenNames; }
	@Override public String getGrammarFileName() { return "Java.g"; }


	public static class javaSource_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "javaSource"
	// Java.g:223:1: javaSource : compilationUnit -> ^( JAVA_SOURCE[\"COMPILATION-UNIT\"] compilationUnit ) ;
	public final JavaParser.javaSource_return javaSource() throws RecognitionException {
		JavaParser.javaSource_return retval = new JavaParser.javaSource_return();
		retval.start = input.LT(1);
		int javaSource_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope compilationUnit1 =null;

		RewriteRuleSubtreeStream stream_compilationUnit=new RewriteRuleSubtreeStream(adaptor,"rule compilationUnit");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 1) ) { return retval; }

			// Java.g:224:5: ( compilationUnit -> ^( JAVA_SOURCE[\"COMPILATION-UNIT\"] compilationUnit ) )
			// Java.g:224:9: compilationUnit
			{
			pushFollow(FOLLOW_compilationUnit_in_javaSource4468);
			compilationUnit1=compilationUnit();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_compilationUnit.add(compilationUnit1.getTree());

			// AST REWRITE
			// elements: compilationUnit
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 225:9: -> ^( JAVA_SOURCE[\"COMPILATION-UNIT\"] compilationUnit )
			{
				// Java.g:225:13: ^( JAVA_SOURCE[\"COMPILATION-UNIT\"] compilationUnit )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(JAVA_SOURCE, "COMPILATION-UNIT"), root_1);
				adaptor.addChild(root_1, stream_compilationUnit.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 1, javaSource_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "javaSource"


	public static class compilationUnit_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "compilationUnit"
	// Java.g:228:1: compilationUnit : annotationList ( packageDeclaration )? ( importDeclaration )* ( typeDecls )* ;
	public final JavaParser.compilationUnit_return compilationUnit() throws RecognitionException {
		JavaParser.compilationUnit_return retval = new JavaParser.compilationUnit_return();
		retval.start = input.LT(1);
		int compilationUnit_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope annotationList2 =null;
		ParserRuleReturnScope packageDeclaration3 =null;
		ParserRuleReturnScope importDeclaration4 =null;
		ParserRuleReturnScope typeDecls5 =null;


		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 2) ) { return retval; }

			// Java.g:229:5: ( annotationList ( packageDeclaration )? ( importDeclaration )* ( typeDecls )* )
			// Java.g:229:9: annotationList ( packageDeclaration )? ( importDeclaration )* ( typeDecls )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_annotationList_in_compilationUnit4505);
			annotationList2=annotationList();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, annotationList2.getTree());

			// Java.g:230:9: ( packageDeclaration )?
			int alt1=2;
			int LA1_0 = input.LA(1);
			if ( (LA1_0==PACKAGE) ) {
				alt1=1;
			}
			switch (alt1) {
				case 1 :
					// Java.g:230:9: packageDeclaration
					{
					pushFollow(FOLLOW_packageDeclaration_in_compilationUnit4515);
					packageDeclaration3=packageDeclaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, packageDeclaration3.getTree());

					}
					break;

			}

			// Java.g:231:9: ( importDeclaration )*
			loop2:
			while (true) {
				int alt2=2;
				int LA2_0 = input.LA(1);
				if ( (LA2_0==IMPORT) ) {
					alt2=1;
				}

				switch (alt2) {
				case 1 :
					// Java.g:231:9: importDeclaration
					{
					pushFollow(FOLLOW_importDeclaration_in_compilationUnit4526);
					importDeclaration4=importDeclaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, importDeclaration4.getTree());

					}
					break;

				default :
					break loop2;
				}
			}

			// Java.g:232:9: ( typeDecls )*
			loop3:
			while (true) {
				int alt3=2;
				int LA3_0 = input.LA(1);
				if ( (LA3_0==ABSTRACT||LA3_0==AT||LA3_0==BOOLEAN||LA3_0==BYTE||LA3_0==CHAR||LA3_0==CLASS||LA3_0==DOUBLE||LA3_0==ENUM||LA3_0==FINAL||LA3_0==FLOAT||LA3_0==IDENT||LA3_0==INT||LA3_0==INTERFACE||LA3_0==LESS_THAN||LA3_0==LONG||LA3_0==NATIVE||(LA3_0 >= PRIVATE && LA3_0 <= PUBLIC)||LA3_0==SEMI||LA3_0==SHORT||LA3_0==STATIC||LA3_0==STRICTFP||LA3_0==SYNCHRONIZED||LA3_0==TRANSIENT||LA3_0==VOID||LA3_0==VOLATILE) ) {
					alt3=1;
				}

				switch (alt3) {
				case 1 :
					// Java.g:232:9: typeDecls
					{
					pushFollow(FOLLOW_typeDecls_in_compilationUnit4537);
					typeDecls5=typeDecls();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, typeDecls5.getTree());

					}
					break;

				default :
					break loop3;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 2, compilationUnit_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "compilationUnit"


	public static class typeDecls_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "typeDecls"
	// Java.g:235:1: typeDecls : ( typeDeclaration | SEMI !);
	public final JavaParser.typeDecls_return typeDecls() throws RecognitionException {
		JavaParser.typeDecls_return retval = new JavaParser.typeDecls_return();
		retval.start = input.LT(1);
		int typeDecls_StartIndex = input.index();

		CommonTree root_0 = null;

		Token SEMI7=null;
		ParserRuleReturnScope typeDeclaration6 =null;

		CommonTree SEMI7_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 3) ) { return retval; }

			// Java.g:236:5: ( typeDeclaration | SEMI !)
			int alt4=2;
			int LA4_0 = input.LA(1);
			if ( (LA4_0==ABSTRACT||LA4_0==AT||LA4_0==BOOLEAN||LA4_0==BYTE||LA4_0==CHAR||LA4_0==CLASS||LA4_0==DOUBLE||LA4_0==ENUM||LA4_0==FINAL||LA4_0==FLOAT||LA4_0==IDENT||LA4_0==INT||LA4_0==INTERFACE||LA4_0==LESS_THAN||LA4_0==LONG||LA4_0==NATIVE||(LA4_0 >= PRIVATE && LA4_0 <= PUBLIC)||LA4_0==SHORT||LA4_0==STATIC||LA4_0==STRICTFP||LA4_0==SYNCHRONIZED||LA4_0==TRANSIENT||LA4_0==VOID||LA4_0==VOLATILE) ) {
				alt4=1;
			}
			else if ( (LA4_0==SEMI) ) {
				alt4=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 4, 0, input);
				throw nvae;
			}

			switch (alt4) {
				case 1 :
					// Java.g:236:9: typeDeclaration
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_typeDeclaration_in_typeDecls4557);
					typeDeclaration6=typeDeclaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, typeDeclaration6.getTree());

					}
					break;
				case 2 :
					// Java.g:237:9: SEMI !
					{
					root_0 = (CommonTree)adaptor.nil();


					SEMI7=(Token)match(input,SEMI,FOLLOW_SEMI_in_typeDecls4567); if (state.failed) return retval;
					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 3, typeDecls_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "typeDecls"


	public static class packageDeclaration_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "packageDeclaration"
	// Java.g:240:1: packageDeclaration : PACKAGE qualifiedIdentifier SEMI -> ^( PACKAGE[\"PACKAGE-DECLARATION\"] qualifiedIdentifier ) ;
	public final JavaParser.packageDeclaration_return packageDeclaration() throws RecognitionException {
		JavaParser.packageDeclaration_return retval = new JavaParser.packageDeclaration_return();
		retval.start = input.LT(1);
		int packageDeclaration_StartIndex = input.index();

		CommonTree root_0 = null;

		Token PACKAGE8=null;
		Token SEMI10=null;
		ParserRuleReturnScope qualifiedIdentifier9 =null;

		CommonTree PACKAGE8_tree=null;
		CommonTree SEMI10_tree=null;
		RewriteRuleTokenStream stream_PACKAGE=new RewriteRuleTokenStream(adaptor,"token PACKAGE");
		RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
		RewriteRuleSubtreeStream stream_qualifiedIdentifier=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedIdentifier");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 4) ) { return retval; }

			// Java.g:241:5: ( PACKAGE qualifiedIdentifier SEMI -> ^( PACKAGE[\"PACKAGE-DECLARATION\"] qualifiedIdentifier ) )
			// Java.g:241:9: PACKAGE qualifiedIdentifier SEMI
			{
			PACKAGE8=(Token)match(input,PACKAGE,FOLLOW_PACKAGE_in_packageDeclaration4587); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_PACKAGE.add(PACKAGE8);

			pushFollow(FOLLOW_qualifiedIdentifier_in_packageDeclaration4589);
			qualifiedIdentifier9=qualifiedIdentifier();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_qualifiedIdentifier.add(qualifiedIdentifier9.getTree());
			SEMI10=(Token)match(input,SEMI,FOLLOW_SEMI_in_packageDeclaration4591); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_SEMI.add(SEMI10);


			// AST REWRITE
			// elements: qualifiedIdentifier, PACKAGE
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 242:2: -> ^( PACKAGE[\"PACKAGE-DECLARATION\"] qualifiedIdentifier )
			{
				// Java.g:242:5: ^( PACKAGE[\"PACKAGE-DECLARATION\"] qualifiedIdentifier )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(PACKAGE, "PACKAGE-DECLARATION"), root_1);
				adaptor.addChild(root_1, stream_qualifiedIdentifier.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 4, packageDeclaration_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "packageDeclaration"


	public static class importDeclaration_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "importDeclaration"
	// Java.g:251:1: importDeclaration : IMPORT ( STATIC )? qualifiedIdentifier ( DOTSTAR )? SEMI -> ^( IMPORT[\"IMPORT-DECLARATION\"] ( STATIC )? qualifiedIdentifier ( DOTSTAR )? ) ;
	public final JavaParser.importDeclaration_return importDeclaration() throws RecognitionException {
		JavaParser.importDeclaration_return retval = new JavaParser.importDeclaration_return();
		retval.start = input.LT(1);
		int importDeclaration_StartIndex = input.index();

		CommonTree root_0 = null;

		Token IMPORT11=null;
		Token STATIC12=null;
		Token DOTSTAR14=null;
		Token SEMI15=null;
		ParserRuleReturnScope qualifiedIdentifier13 =null;

		CommonTree IMPORT11_tree=null;
		CommonTree STATIC12_tree=null;
		CommonTree DOTSTAR14_tree=null;
		CommonTree SEMI15_tree=null;
		RewriteRuleTokenStream stream_IMPORT=new RewriteRuleTokenStream(adaptor,"token IMPORT");
		RewriteRuleTokenStream stream_DOTSTAR=new RewriteRuleTokenStream(adaptor,"token DOTSTAR");
		RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
		RewriteRuleTokenStream stream_STATIC=new RewriteRuleTokenStream(adaptor,"token STATIC");
		RewriteRuleSubtreeStream stream_qualifiedIdentifier=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedIdentifier");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 5) ) { return retval; }

			// Java.g:252:5: ( IMPORT ( STATIC )? qualifiedIdentifier ( DOTSTAR )? SEMI -> ^( IMPORT[\"IMPORT-DECLARATION\"] ( STATIC )? qualifiedIdentifier ( DOTSTAR )? ) )
			// Java.g:252:9: IMPORT ( STATIC )? qualifiedIdentifier ( DOTSTAR )? SEMI
			{
			IMPORT11=(Token)match(input,IMPORT,FOLLOW_IMPORT_in_importDeclaration4623); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_IMPORT.add(IMPORT11);

			// Java.g:252:16: ( STATIC )?
			int alt5=2;
			int LA5_0 = input.LA(1);
			if ( (LA5_0==STATIC) ) {
				alt5=1;
			}
			switch (alt5) {
				case 1 :
					// Java.g:252:16: STATIC
					{
					STATIC12=(Token)match(input,STATIC,FOLLOW_STATIC_in_importDeclaration4625); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_STATIC.add(STATIC12);

					}
					break;

			}

			pushFollow(FOLLOW_qualifiedIdentifier_in_importDeclaration4628);
			qualifiedIdentifier13=qualifiedIdentifier();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_qualifiedIdentifier.add(qualifiedIdentifier13.getTree());
			// Java.g:252:44: ( DOTSTAR )?
			int alt6=2;
			int LA6_0 = input.LA(1);
			if ( (LA6_0==DOTSTAR) ) {
				alt6=1;
			}
			switch (alt6) {
				case 1 :
					// Java.g:252:44: DOTSTAR
					{
					DOTSTAR14=(Token)match(input,DOTSTAR,FOLLOW_DOTSTAR_in_importDeclaration4630); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DOTSTAR.add(DOTSTAR14);

					}
					break;

			}

			SEMI15=(Token)match(input,SEMI,FOLLOW_SEMI_in_importDeclaration4633); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_SEMI.add(SEMI15);


			// AST REWRITE
			// elements: STATIC, IMPORT, qualifiedIdentifier, DOTSTAR
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 253:2: -> ^( IMPORT[\"IMPORT-DECLARATION\"] ( STATIC )? qualifiedIdentifier ( DOTSTAR )? )
			{
				// Java.g:253:5: ^( IMPORT[\"IMPORT-DECLARATION\"] ( STATIC )? qualifiedIdentifier ( DOTSTAR )? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(IMPORT, "IMPORT-DECLARATION"), root_1);
				// Java.g:253:36: ( STATIC )?
				if ( stream_STATIC.hasNext() ) {
					adaptor.addChild(root_1, stream_STATIC.nextNode());
				}
				stream_STATIC.reset();

				adaptor.addChild(root_1, stream_qualifiedIdentifier.nextTree());
				// Java.g:253:64: ( DOTSTAR )?
				if ( stream_DOTSTAR.hasNext() ) {
					adaptor.addChild(root_1, stream_DOTSTAR.nextNode());
				}
				stream_DOTSTAR.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 5, importDeclaration_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "importDeclaration"


	public static class typeDeclaration_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "typeDeclaration"
	// Java.g:256:1: typeDeclaration : modifierList ! ( classTypeDeclaration[$modifierList.tree] | interfaceTypeDeclaration[$modifierList.tree] | enumTypeDeclaration[$modifierList.tree] | annotationTypeDeclaration[$modifierList.tree] ) ;
	public final JavaParser.typeDeclaration_return typeDeclaration() throws RecognitionException {
		JavaParser.typeDeclaration_return retval = new JavaParser.typeDeclaration_return();
		retval.start = input.LT(1);
		int typeDeclaration_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope modifierList16 =null;
		ParserRuleReturnScope classTypeDeclaration17 =null;
		ParserRuleReturnScope interfaceTypeDeclaration18 =null;
		ParserRuleReturnScope enumTypeDeclaration19 =null;
		ParserRuleReturnScope annotationTypeDeclaration20 =null;


		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 6) ) { return retval; }

			// Java.g:257:5: ( modifierList ! ( classTypeDeclaration[$modifierList.tree] | interfaceTypeDeclaration[$modifierList.tree] | enumTypeDeclaration[$modifierList.tree] | annotationTypeDeclaration[$modifierList.tree] ) )
			// Java.g:257:9: modifierList ! ( classTypeDeclaration[$modifierList.tree] | interfaceTypeDeclaration[$modifierList.tree] | enumTypeDeclaration[$modifierList.tree] | annotationTypeDeclaration[$modifierList.tree] )
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_modifierList_in_typeDeclaration4668);
			modifierList16=modifierList();
			state._fsp--;
			if (state.failed) return retval;
			// Java.g:258:9: ( classTypeDeclaration[$modifierList.tree] | interfaceTypeDeclaration[$modifierList.tree] | enumTypeDeclaration[$modifierList.tree] | annotationTypeDeclaration[$modifierList.tree] )
			int alt7=4;
			switch ( input.LA(1) ) {
			case CLASS:
				{
				alt7=1;
				}
				break;
			case INTERFACE:
				{
				alt7=2;
				}
				break;
			case ENUM:
				{
				alt7=3;
				}
				break;
			case AT:
				{
				alt7=4;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 7, 0, input);
				throw nvae;
			}
			switch (alt7) {
				case 1 :
					// Java.g:258:13: classTypeDeclaration[$modifierList.tree]
					{
					pushFollow(FOLLOW_classTypeDeclaration_in_typeDeclaration4683);
					classTypeDeclaration17=classTypeDeclaration((modifierList16!=null?((CommonTree)modifierList16.getTree()):null));
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, classTypeDeclaration17.getTree());

					}
					break;
				case 2 :
					// Java.g:259:13: interfaceTypeDeclaration[$modifierList.tree]
					{
					pushFollow(FOLLOW_interfaceTypeDeclaration_in_typeDeclaration4698);
					interfaceTypeDeclaration18=interfaceTypeDeclaration((modifierList16!=null?((CommonTree)modifierList16.getTree()):null));
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, interfaceTypeDeclaration18.getTree());

					}
					break;
				case 3 :
					// Java.g:260:13: enumTypeDeclaration[$modifierList.tree]
					{
					pushFollow(FOLLOW_enumTypeDeclaration_in_typeDeclaration4713);
					enumTypeDeclaration19=enumTypeDeclaration((modifierList16!=null?((CommonTree)modifierList16.getTree()):null));
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, enumTypeDeclaration19.getTree());

					}
					break;
				case 4 :
					// Java.g:261:13: annotationTypeDeclaration[$modifierList.tree]
					{
					pushFollow(FOLLOW_annotationTypeDeclaration_in_typeDeclaration4728);
					annotationTypeDeclaration20=annotationTypeDeclaration((modifierList16!=null?((CommonTree)modifierList16.getTree()):null));
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, annotationTypeDeclaration20.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 6, typeDeclaration_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "typeDeclaration"


	public static class classTypeDeclaration_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "classTypeDeclaration"
	// Java.g:265:1: classTypeDeclaration[CommonTree modifiers] : CLASS IDENT ( genericTypeParameterList )? ( classExtendsClause )? ( implementsClause )? classBody -> ^( CLASS IDENT ( genericTypeParameterList )? ( classExtendsClause )? ( implementsClause )? classBody ) ;
	public final JavaParser.classTypeDeclaration_return classTypeDeclaration(CommonTree modifiers) throws RecognitionException {
		JavaParser.classTypeDeclaration_return retval = new JavaParser.classTypeDeclaration_return();
		retval.start = input.LT(1);
		int classTypeDeclaration_StartIndex = input.index();

		CommonTree root_0 = null;

		Token CLASS21=null;
		Token IDENT22=null;
		ParserRuleReturnScope genericTypeParameterList23 =null;
		ParserRuleReturnScope classExtendsClause24 =null;
		ParserRuleReturnScope implementsClause25 =null;
		ParserRuleReturnScope classBody26 =null;

		CommonTree CLASS21_tree=null;
		CommonTree IDENT22_tree=null;
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleTokenStream stream_CLASS=new RewriteRuleTokenStream(adaptor,"token CLASS");
		RewriteRuleSubtreeStream stream_classBody=new RewriteRuleSubtreeStream(adaptor,"rule classBody");
		RewriteRuleSubtreeStream stream_classExtendsClause=new RewriteRuleSubtreeStream(adaptor,"rule classExtendsClause");
		RewriteRuleSubtreeStream stream_genericTypeParameterList=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeParameterList");
		RewriteRuleSubtreeStream stream_implementsClause=new RewriteRuleSubtreeStream(adaptor,"rule implementsClause");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 7) ) { return retval; }

			// Java.g:266:5: ( CLASS IDENT ( genericTypeParameterList )? ( classExtendsClause )? ( implementsClause )? classBody -> ^( CLASS IDENT ( genericTypeParameterList )? ( classExtendsClause )? ( implementsClause )? classBody ) )
			// Java.g:266:9: CLASS IDENT ( genericTypeParameterList )? ( classExtendsClause )? ( implementsClause )? classBody
			{
			CLASS21=(Token)match(input,CLASS,FOLLOW_CLASS_in_classTypeDeclaration4759); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_CLASS.add(CLASS21);

			IDENT22=(Token)match(input,IDENT,FOLLOW_IDENT_in_classTypeDeclaration4761); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_IDENT.add(IDENT22);

			// Java.g:266:21: ( genericTypeParameterList )?
			int alt8=2;
			int LA8_0 = input.LA(1);
			if ( (LA8_0==LESS_THAN) ) {
				alt8=1;
			}
			switch (alt8) {
				case 1 :
					// Java.g:266:21: genericTypeParameterList
					{
					pushFollow(FOLLOW_genericTypeParameterList_in_classTypeDeclaration4763);
					genericTypeParameterList23=genericTypeParameterList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_genericTypeParameterList.add(genericTypeParameterList23.getTree());
					}
					break;

			}

			// Java.g:266:47: ( classExtendsClause )?
			int alt9=2;
			int LA9_0 = input.LA(1);
			if ( (LA9_0==EXTENDS) ) {
				alt9=1;
			}
			switch (alt9) {
				case 1 :
					// Java.g:266:47: classExtendsClause
					{
					pushFollow(FOLLOW_classExtendsClause_in_classTypeDeclaration4766);
					classExtendsClause24=classExtendsClause();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_classExtendsClause.add(classExtendsClause24.getTree());
					}
					break;

			}

			// Java.g:266:67: ( implementsClause )?
			int alt10=2;
			int LA10_0 = input.LA(1);
			if ( (LA10_0==IMPLEMENTS) ) {
				alt10=1;
			}
			switch (alt10) {
				case 1 :
					// Java.g:266:67: implementsClause
					{
					pushFollow(FOLLOW_implementsClause_in_classTypeDeclaration4769);
					implementsClause25=implementsClause();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_implementsClause.add(implementsClause25.getTree());
					}
					break;

			}

			pushFollow(FOLLOW_classBody_in_classTypeDeclaration4772);
			classBody26=classBody();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_classBody.add(classBody26.getTree());

			// AST REWRITE
			// elements: CLASS, IDENT, classBody, implementsClause, classExtendsClause, genericTypeParameterList
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 267:9: -> ^( CLASS IDENT ( genericTypeParameterList )? ( classExtendsClause )? ( implementsClause )? classBody )
			{
				// Java.g:267:13: ^( CLASS IDENT ( genericTypeParameterList )? ( classExtendsClause )? ( implementsClause )? classBody )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot(stream_CLASS.nextNode(), root_1);
				adaptor.addChild(root_1, modifiers);
				adaptor.addChild(root_1, stream_IDENT.nextNode());
				// Java.g:267:40: ( genericTypeParameterList )?
				if ( stream_genericTypeParameterList.hasNext() ) {
					adaptor.addChild(root_1, stream_genericTypeParameterList.nextTree());
				}
				stream_genericTypeParameterList.reset();

				// Java.g:267:66: ( classExtendsClause )?
				if ( stream_classExtendsClause.hasNext() ) {
					adaptor.addChild(root_1, stream_classExtendsClause.nextTree());
				}
				stream_classExtendsClause.reset();

				// Java.g:268:15: ( implementsClause )?
				if ( stream_implementsClause.hasNext() ) {
					adaptor.addChild(root_1, stream_implementsClause.nextTree());
				}
				stream_implementsClause.reset();

				adaptor.addChild(root_1, stream_classBody.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 7, classTypeDeclaration_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "classTypeDeclaration"


	public static class classExtendsClause_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "classExtendsClause"
	// Java.g:271:1: classExtendsClause : EXTENDS type -> ^( EXTENDS_CLAUSE[$EXTENDS, \"EXTENDS_CLAUSE\"] type ) ;
	public final JavaParser.classExtendsClause_return classExtendsClause() throws RecognitionException {
		JavaParser.classExtendsClause_return retval = new JavaParser.classExtendsClause_return();
		retval.start = input.LT(1);
		int classExtendsClause_StartIndex = input.index();

		CommonTree root_0 = null;

		Token EXTENDS27=null;
		ParserRuleReturnScope type28 =null;

		CommonTree EXTENDS27_tree=null;
		RewriteRuleTokenStream stream_EXTENDS=new RewriteRuleTokenStream(adaptor,"token EXTENDS");
		RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 8) ) { return retval; }

			// Java.g:272:5: ( EXTENDS type -> ^( EXTENDS_CLAUSE[$EXTENDS, \"EXTENDS_CLAUSE\"] type ) )
			// Java.g:272:9: EXTENDS type
			{
			EXTENDS27=(Token)match(input,EXTENDS,FOLLOW_EXTENDS_in_classExtendsClause4835); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_EXTENDS.add(EXTENDS27);

			pushFollow(FOLLOW_type_in_classExtendsClause4837);
			type28=type();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_type.add(type28.getTree());

			// AST REWRITE
			// elements: type
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 273:9: -> ^( EXTENDS_CLAUSE[$EXTENDS, \"EXTENDS_CLAUSE\"] type )
			{
				// Java.g:273:13: ^( EXTENDS_CLAUSE[$EXTENDS, \"EXTENDS_CLAUSE\"] type )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EXTENDS_CLAUSE, EXTENDS27, "EXTENDS_CLAUSE"), root_1);
				adaptor.addChild(root_1, stream_type.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 8, classExtendsClause_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "classExtendsClause"


	public static class interfaceExtendsClause_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "interfaceExtendsClause"
	// Java.g:276:1: interfaceExtendsClause : EXTENDS typeList -> ^( EXTENDS_CLAUSE[$EXTENDS, \"EXTENDS_CLAUSE\"] typeList ) ;
	public final JavaParser.interfaceExtendsClause_return interfaceExtendsClause() throws RecognitionException {
		JavaParser.interfaceExtendsClause_return retval = new JavaParser.interfaceExtendsClause_return();
		retval.start = input.LT(1);
		int interfaceExtendsClause_StartIndex = input.index();

		CommonTree root_0 = null;

		Token EXTENDS29=null;
		ParserRuleReturnScope typeList30 =null;

		CommonTree EXTENDS29_tree=null;
		RewriteRuleTokenStream stream_EXTENDS=new RewriteRuleTokenStream(adaptor,"token EXTENDS");
		RewriteRuleSubtreeStream stream_typeList=new RewriteRuleSubtreeStream(adaptor,"rule typeList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 9) ) { return retval; }

			// Java.g:277:5: ( EXTENDS typeList -> ^( EXTENDS_CLAUSE[$EXTENDS, \"EXTENDS_CLAUSE\"] typeList ) )
			// Java.g:277:9: EXTENDS typeList
			{
			EXTENDS29=(Token)match(input,EXTENDS,FOLLOW_EXTENDS_in_interfaceExtendsClause4874); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_EXTENDS.add(EXTENDS29);

			pushFollow(FOLLOW_typeList_in_interfaceExtendsClause4876);
			typeList30=typeList();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_typeList.add(typeList30.getTree());

			// AST REWRITE
			// elements: typeList
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 278:9: -> ^( EXTENDS_CLAUSE[$EXTENDS, \"EXTENDS_CLAUSE\"] typeList )
			{
				// Java.g:278:13: ^( EXTENDS_CLAUSE[$EXTENDS, \"EXTENDS_CLAUSE\"] typeList )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EXTENDS_CLAUSE, EXTENDS29, "EXTENDS_CLAUSE"), root_1);
				adaptor.addChild(root_1, stream_typeList.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 9, interfaceExtendsClause_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "interfaceExtendsClause"


	public static class implementsClause_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "implementsClause"
	// Java.g:281:1: implementsClause : IMPLEMENTS typeList -> ^( IMPLEMENTS_CLAUSE[$IMPLEMENTS, \"IMPLEMENTS_CLAUSE\"] typeList ) ;
	public final JavaParser.implementsClause_return implementsClause() throws RecognitionException {
		JavaParser.implementsClause_return retval = new JavaParser.implementsClause_return();
		retval.start = input.LT(1);
		int implementsClause_StartIndex = input.index();

		CommonTree root_0 = null;

		Token IMPLEMENTS31=null;
		ParserRuleReturnScope typeList32 =null;

		CommonTree IMPLEMENTS31_tree=null;
		RewriteRuleTokenStream stream_IMPLEMENTS=new RewriteRuleTokenStream(adaptor,"token IMPLEMENTS");
		RewriteRuleSubtreeStream stream_typeList=new RewriteRuleSubtreeStream(adaptor,"rule typeList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 10) ) { return retval; }

			// Java.g:282:5: ( IMPLEMENTS typeList -> ^( IMPLEMENTS_CLAUSE[$IMPLEMENTS, \"IMPLEMENTS_CLAUSE\"] typeList ) )
			// Java.g:282:9: IMPLEMENTS typeList
			{
			IMPLEMENTS31=(Token)match(input,IMPLEMENTS,FOLLOW_IMPLEMENTS_in_implementsClause4913); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_IMPLEMENTS.add(IMPLEMENTS31);

			pushFollow(FOLLOW_typeList_in_implementsClause4915);
			typeList32=typeList();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_typeList.add(typeList32.getTree());

			// AST REWRITE
			// elements: typeList
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 283:9: -> ^( IMPLEMENTS_CLAUSE[$IMPLEMENTS, \"IMPLEMENTS_CLAUSE\"] typeList )
			{
				// Java.g:283:13: ^( IMPLEMENTS_CLAUSE[$IMPLEMENTS, \"IMPLEMENTS_CLAUSE\"] typeList )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(IMPLEMENTS_CLAUSE, IMPLEMENTS31, "IMPLEMENTS_CLAUSE"), root_1);
				adaptor.addChild(root_1, stream_typeList.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 10, implementsClause_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "implementsClause"


	public static class genericTypeParameterList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "genericTypeParameterList"
	// Java.g:286:1: genericTypeParameterList : LESS_THAN genericTypeParameter ( COMMA genericTypeParameter )* genericTypeListClosing -> ^( GENERIC_TYPE_PARAM_LIST[$LESS_THAN, \"GENERIC_TYPE_PARAM_LIST\"] ( genericTypeParameter )+ ) ;
	public final JavaParser.genericTypeParameterList_return genericTypeParameterList() throws RecognitionException {
		JavaParser.genericTypeParameterList_return retval = new JavaParser.genericTypeParameterList_return();
		retval.start = input.LT(1);
		int genericTypeParameterList_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LESS_THAN33=null;
		Token COMMA35=null;
		ParserRuleReturnScope genericTypeParameter34 =null;
		ParserRuleReturnScope genericTypeParameter36 =null;
		ParserRuleReturnScope genericTypeListClosing37 =null;

		CommonTree LESS_THAN33_tree=null;
		CommonTree COMMA35_tree=null;
		RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
		RewriteRuleTokenStream stream_LESS_THAN=new RewriteRuleTokenStream(adaptor,"token LESS_THAN");
		RewriteRuleSubtreeStream stream_genericTypeParameter=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeParameter");
		RewriteRuleSubtreeStream stream_genericTypeListClosing=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeListClosing");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 11) ) { return retval; }

			// Java.g:287:5: ( LESS_THAN genericTypeParameter ( COMMA genericTypeParameter )* genericTypeListClosing -> ^( GENERIC_TYPE_PARAM_LIST[$LESS_THAN, \"GENERIC_TYPE_PARAM_LIST\"] ( genericTypeParameter )+ ) )
			// Java.g:287:9: LESS_THAN genericTypeParameter ( COMMA genericTypeParameter )* genericTypeListClosing
			{
			LESS_THAN33=(Token)match(input,LESS_THAN,FOLLOW_LESS_THAN_in_genericTypeParameterList4952); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LESS_THAN.add(LESS_THAN33);

			pushFollow(FOLLOW_genericTypeParameter_in_genericTypeParameterList4954);
			genericTypeParameter34=genericTypeParameter();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_genericTypeParameter.add(genericTypeParameter34.getTree());
			// Java.g:287:40: ( COMMA genericTypeParameter )*
			loop11:
			while (true) {
				int alt11=2;
				int LA11_0 = input.LA(1);
				if ( (LA11_0==COMMA) ) {
					alt11=1;
				}

				switch (alt11) {
				case 1 :
					// Java.g:287:41: COMMA genericTypeParameter
					{
					COMMA35=(Token)match(input,COMMA,FOLLOW_COMMA_in_genericTypeParameterList4957); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_COMMA.add(COMMA35);

					pushFollow(FOLLOW_genericTypeParameter_in_genericTypeParameterList4959);
					genericTypeParameter36=genericTypeParameter();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_genericTypeParameter.add(genericTypeParameter36.getTree());
					}
					break;

				default :
					break loop11;
				}
			}

			pushFollow(FOLLOW_genericTypeListClosing_in_genericTypeParameterList4963);
			genericTypeListClosing37=genericTypeListClosing();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_genericTypeListClosing.add(genericTypeListClosing37.getTree());

			// AST REWRITE
			// elements: genericTypeParameter
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 288:9: -> ^( GENERIC_TYPE_PARAM_LIST[$LESS_THAN, \"GENERIC_TYPE_PARAM_LIST\"] ( genericTypeParameter )+ )
			{
				// Java.g:288:13: ^( GENERIC_TYPE_PARAM_LIST[$LESS_THAN, \"GENERIC_TYPE_PARAM_LIST\"] ( genericTypeParameter )+ )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(GENERIC_TYPE_PARAM_LIST, LESS_THAN33, "GENERIC_TYPE_PARAM_LIST"), root_1);
				if ( !(stream_genericTypeParameter.hasNext()) ) {
					throw new RewriteEarlyExitException();
				}
				while ( stream_genericTypeParameter.hasNext() ) {
					adaptor.addChild(root_1, stream_genericTypeParameter.nextTree());
				}
				stream_genericTypeParameter.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 11, genericTypeParameterList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "genericTypeParameterList"


	public static class genericTypeListClosing_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "genericTypeListClosing"
	// Java.g:291:1: genericTypeListClosing : ( GREATER_THAN | SHIFT_RIGHT | BIT_SHIFT_RIGHT |);
	public final JavaParser.genericTypeListClosing_return genericTypeListClosing() throws RecognitionException {
		JavaParser.genericTypeListClosing_return retval = new JavaParser.genericTypeListClosing_return();
		retval.start = input.LT(1);
		int genericTypeListClosing_StartIndex = input.index();

		CommonTree root_0 = null;

		Token GREATER_THAN38=null;
		Token SHIFT_RIGHT39=null;
		Token BIT_SHIFT_RIGHT40=null;

		CommonTree GREATER_THAN38_tree=null;
		CommonTree SHIFT_RIGHT39_tree=null;
		CommonTree BIT_SHIFT_RIGHT40_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 12) ) { return retval; }

			// Java.g:295:5: ( GREATER_THAN | SHIFT_RIGHT | BIT_SHIFT_RIGHT |)
			int alt12=4;
			switch ( input.LA(1) ) {
			case GREATER_THAN:
				{
				int LA12_1 = input.LA(2);
				if ( (synpred14_Java()) ) {
					alt12=1;
				}
				else if ( (true) ) {
					alt12=4;
				}

				}
				break;
			case SHIFT_RIGHT:
				{
				int LA12_2 = input.LA(2);
				if ( (synpred15_Java()) ) {
					alt12=2;
				}
				else if ( (true) ) {
					alt12=4;
				}

				}
				break;
			case BIT_SHIFT_RIGHT:
				{
				int LA12_3 = input.LA(2);
				if ( (synpred16_Java()) ) {
					alt12=3;
				}
				else if ( (true) ) {
					alt12=4;
				}

				}
				break;
			case EOF:
			case AND:
			case AND_ASSIGN:
			case ASSIGN:
			case BIT_SHIFT_RIGHT_ASSIGN:
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case COLON:
			case COMMA:
			case DIV_ASSIGN:
			case DOT:
			case DOUBLE:
			case ELLIPSIS:
			case EQUAL:
			case EXTENDS:
			case FLOAT:
			case IDENT:
			case IMPLEMENTS:
			case INT:
			case LBRACK:
			case LCURLY:
			case LOGICAL_AND:
			case LOGICAL_OR:
			case LONG:
			case LPAREN:
			case MINUS_ASSIGN:
			case MOD_ASSIGN:
			case NOT_EQUAL:
			case OR:
			case OR_ASSIGN:
			case PLUS_ASSIGN:
			case QUESTION:
			case RBRACK:
			case RCURLY:
			case RPAREN:
			case SEMI:
			case SHIFT_LEFT_ASSIGN:
			case SHIFT_RIGHT_ASSIGN:
			case SHORT:
			case STAR_ASSIGN:
			case SUPER:
			case THIS:
			case VOID:
			case XOR:
			case XOR_ASSIGN:
				{
				alt12=4;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 12, 0, input);
				throw nvae;
			}
			switch (alt12) {
				case 1 :
					// Java.g:295:9: GREATER_THAN
					{
					root_0 = (CommonTree)adaptor.nil();


					GREATER_THAN38=(Token)match(input,GREATER_THAN,FOLLOW_GREATER_THAN_in_genericTypeListClosing5078); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					GREATER_THAN38_tree = (CommonTree)adaptor.create(GREATER_THAN38);
					adaptor.addChild(root_0, GREATER_THAN38_tree);
					}

					}
					break;
				case 2 :
					// Java.g:296:9: SHIFT_RIGHT
					{
					root_0 = (CommonTree)adaptor.nil();


					SHIFT_RIGHT39=(Token)match(input,SHIFT_RIGHT,FOLLOW_SHIFT_RIGHT_in_genericTypeListClosing5088); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					SHIFT_RIGHT39_tree = (CommonTree)adaptor.create(SHIFT_RIGHT39);
					adaptor.addChild(root_0, SHIFT_RIGHT39_tree);
					}

					}
					break;
				case 3 :
					// Java.g:297:9: BIT_SHIFT_RIGHT
					{
					root_0 = (CommonTree)adaptor.nil();


					BIT_SHIFT_RIGHT40=(Token)match(input,BIT_SHIFT_RIGHT,FOLLOW_BIT_SHIFT_RIGHT_in_genericTypeListClosing5098); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					BIT_SHIFT_RIGHT40_tree = (CommonTree)adaptor.create(BIT_SHIFT_RIGHT40);
					adaptor.addChild(root_0, BIT_SHIFT_RIGHT40_tree);
					}

					}
					break;
				case 4 :
					// Java.g:299:5: 
					{
					root_0 = (CommonTree)adaptor.nil();


					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 12, genericTypeListClosing_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "genericTypeListClosing"


	public static class genericTypeParameter_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "genericTypeParameter"
	// Java.g:301:1: genericTypeParameter : IDENT ( bound )? -> ^( IDENT ( bound )? ) ;
	public final JavaParser.genericTypeParameter_return genericTypeParameter() throws RecognitionException {
		JavaParser.genericTypeParameter_return retval = new JavaParser.genericTypeParameter_return();
		retval.start = input.LT(1);
		int genericTypeParameter_StartIndex = input.index();

		CommonTree root_0 = null;

		Token IDENT41=null;
		ParserRuleReturnScope bound42 =null;

		CommonTree IDENT41_tree=null;
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleSubtreeStream stream_bound=new RewriteRuleSubtreeStream(adaptor,"rule bound");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 13) ) { return retval; }

			// Java.g:302:5: ( IDENT ( bound )? -> ^( IDENT ( bound )? ) )
			// Java.g:302:9: IDENT ( bound )?
			{
			IDENT41=(Token)match(input,IDENT,FOLLOW_IDENT_in_genericTypeParameter5126); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_IDENT.add(IDENT41);

			// Java.g:302:15: ( bound )?
			int alt13=2;
			int LA13_0 = input.LA(1);
			if ( (LA13_0==EXTENDS) ) {
				int LA13_1 = input.LA(2);
				if ( (LA13_1==BOOLEAN||LA13_1==BYTE||LA13_1==CHAR||LA13_1==DOUBLE||LA13_1==FLOAT||LA13_1==INT||LA13_1==LONG||LA13_1==SHORT) ) {
					int LA13_3 = input.LA(3);
					if ( (synpred17_Java()) ) {
						alt13=1;
					}
				}
				else if ( (LA13_1==IDENT) ) {
					int LA13_4 = input.LA(3);
					if ( (synpred17_Java()) ) {
						alt13=1;
					}
				}
			}
			switch (alt13) {
				case 1 :
					// Java.g:302:15: bound
					{
					pushFollow(FOLLOW_bound_in_genericTypeParameter5128);
					bound42=bound();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_bound.add(bound42.getTree());
					}
					break;

			}


			// AST REWRITE
			// elements: IDENT, bound
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 303:9: -> ^( IDENT ( bound )? )
			{
				// Java.g:303:13: ^( IDENT ( bound )? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot(stream_IDENT.nextNode(), root_1);
				// Java.g:303:21: ( bound )?
				if ( stream_bound.hasNext() ) {
					adaptor.addChild(root_1, stream_bound.nextTree());
				}
				stream_bound.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 13, genericTypeParameter_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "genericTypeParameter"


	public static class bound_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "bound"
	// Java.g:306:1: bound : EXTENDS type ( AND type )* -> ^( EXTENDS_BOUND_LIST[$EXTENDS, \"EXTENDS_BOUND_LIST\"] ( type )+ ) ;
	public final JavaParser.bound_return bound() throws RecognitionException {
		JavaParser.bound_return retval = new JavaParser.bound_return();
		retval.start = input.LT(1);
		int bound_StartIndex = input.index();

		CommonTree root_0 = null;

		Token EXTENDS43=null;
		Token AND45=null;
		ParserRuleReturnScope type44 =null;
		ParserRuleReturnScope type46 =null;

		CommonTree EXTENDS43_tree=null;
		CommonTree AND45_tree=null;
		RewriteRuleTokenStream stream_EXTENDS=new RewriteRuleTokenStream(adaptor,"token EXTENDS");
		RewriteRuleTokenStream stream_AND=new RewriteRuleTokenStream(adaptor,"token AND");
		RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 14) ) { return retval; }

			// Java.g:307:5: ( EXTENDS type ( AND type )* -> ^( EXTENDS_BOUND_LIST[$EXTENDS, \"EXTENDS_BOUND_LIST\"] ( type )+ ) )
			// Java.g:307:9: EXTENDS type ( AND type )*
			{
			EXTENDS43=(Token)match(input,EXTENDS,FOLLOW_EXTENDS_in_bound5166); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_EXTENDS.add(EXTENDS43);

			pushFollow(FOLLOW_type_in_bound5168);
			type44=type();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_type.add(type44.getTree());
			// Java.g:307:22: ( AND type )*
			loop14:
			while (true) {
				int alt14=2;
				int LA14_0 = input.LA(1);
				if ( (LA14_0==AND) ) {
					alt14=1;
				}

				switch (alt14) {
				case 1 :
					// Java.g:307:23: AND type
					{
					AND45=(Token)match(input,AND,FOLLOW_AND_in_bound5171); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_AND.add(AND45);

					pushFollow(FOLLOW_type_in_bound5173);
					type46=type();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_type.add(type46.getTree());
					}
					break;

				default :
					break loop14;
				}
			}


			// AST REWRITE
			// elements: type
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 308:9: -> ^( EXTENDS_BOUND_LIST[$EXTENDS, \"EXTENDS_BOUND_LIST\"] ( type )+ )
			{
				// Java.g:308:13: ^( EXTENDS_BOUND_LIST[$EXTENDS, \"EXTENDS_BOUND_LIST\"] ( type )+ )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EXTENDS_BOUND_LIST, EXTENDS43, "EXTENDS_BOUND_LIST"), root_1);
				if ( !(stream_type.hasNext()) ) {
					throw new RewriteEarlyExitException();
				}
				while ( stream_type.hasNext() ) {
					adaptor.addChild(root_1, stream_type.nextTree());
				}
				stream_type.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 14, bound_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "bound"


	public static class enumTypeDeclaration_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "enumTypeDeclaration"
	// Java.g:311:1: enumTypeDeclaration[CommonTree modifiers] : ENUM IDENT ( implementsClause )? enumBody -> ^( ENUM IDENT ( implementsClause )? enumBody ) ;
	public final JavaParser.enumTypeDeclaration_return enumTypeDeclaration(CommonTree modifiers) throws RecognitionException {
		JavaParser.enumTypeDeclaration_return retval = new JavaParser.enumTypeDeclaration_return();
		retval.start = input.LT(1);
		int enumTypeDeclaration_StartIndex = input.index();

		CommonTree root_0 = null;

		Token ENUM47=null;
		Token IDENT48=null;
		ParserRuleReturnScope implementsClause49 =null;
		ParserRuleReturnScope enumBody50 =null;

		CommonTree ENUM47_tree=null;
		CommonTree IDENT48_tree=null;
		RewriteRuleTokenStream stream_ENUM=new RewriteRuleTokenStream(adaptor,"token ENUM");
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleSubtreeStream stream_enumBody=new RewriteRuleSubtreeStream(adaptor,"rule enumBody");
		RewriteRuleSubtreeStream stream_implementsClause=new RewriteRuleSubtreeStream(adaptor,"rule implementsClause");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 15) ) { return retval; }

			// Java.g:312:5: ( ENUM IDENT ( implementsClause )? enumBody -> ^( ENUM IDENT ( implementsClause )? enumBody ) )
			// Java.g:312:9: ENUM IDENT ( implementsClause )? enumBody
			{
			ENUM47=(Token)match(input,ENUM,FOLLOW_ENUM_in_enumTypeDeclaration5214); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_ENUM.add(ENUM47);

			IDENT48=(Token)match(input,IDENT,FOLLOW_IDENT_in_enumTypeDeclaration5216); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_IDENT.add(IDENT48);

			// Java.g:312:20: ( implementsClause )?
			int alt15=2;
			int LA15_0 = input.LA(1);
			if ( (LA15_0==IMPLEMENTS) ) {
				alt15=1;
			}
			switch (alt15) {
				case 1 :
					// Java.g:312:20: implementsClause
					{
					pushFollow(FOLLOW_implementsClause_in_enumTypeDeclaration5218);
					implementsClause49=implementsClause();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_implementsClause.add(implementsClause49.getTree());
					}
					break;

			}

			pushFollow(FOLLOW_enumBody_in_enumTypeDeclaration5221);
			enumBody50=enumBody();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_enumBody.add(enumBody50.getTree());

			// AST REWRITE
			// elements: implementsClause, enumBody, IDENT, ENUM
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 313:9: -> ^( ENUM IDENT ( implementsClause )? enumBody )
			{
				// Java.g:313:13: ^( ENUM IDENT ( implementsClause )? enumBody )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot(stream_ENUM.nextNode(), root_1);
				adaptor.addChild(root_1, modifiers);
				adaptor.addChild(root_1, stream_IDENT.nextNode());
				// Java.g:313:39: ( implementsClause )?
				if ( stream_implementsClause.hasNext() ) {
					adaptor.addChild(root_1, stream_implementsClause.nextTree());
				}
				stream_implementsClause.reset();

				adaptor.addChild(root_1, stream_enumBody.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 15, enumTypeDeclaration_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "enumTypeDeclaration"


	public static class enumBody_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "enumBody"
	// Java.g:316:1: enumBody : LCURLY enumScopeDeclarations RCURLY -> ^( ENUM_TOP_LEVEL_SCOPE[$LCURLY, \"ENUM_TOP_LEVEL_SCOPE\"] enumScopeDeclarations ) ;
	public final JavaParser.enumBody_return enumBody() throws RecognitionException {
		JavaParser.enumBody_return retval = new JavaParser.enumBody_return();
		retval.start = input.LT(1);
		int enumBody_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LCURLY51=null;
		Token RCURLY53=null;
		ParserRuleReturnScope enumScopeDeclarations52 =null;

		CommonTree LCURLY51_tree=null;
		CommonTree RCURLY53_tree=null;
		RewriteRuleTokenStream stream_LCURLY=new RewriteRuleTokenStream(adaptor,"token LCURLY");
		RewriteRuleTokenStream stream_RCURLY=new RewriteRuleTokenStream(adaptor,"token RCURLY");
		RewriteRuleSubtreeStream stream_enumScopeDeclarations=new RewriteRuleSubtreeStream(adaptor,"rule enumScopeDeclarations");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 16) ) { return retval; }

			// Java.g:317:5: ( LCURLY enumScopeDeclarations RCURLY -> ^( ENUM_TOP_LEVEL_SCOPE[$LCURLY, \"ENUM_TOP_LEVEL_SCOPE\"] enumScopeDeclarations ) )
			// Java.g:317:9: LCURLY enumScopeDeclarations RCURLY
			{
			LCURLY51=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_enumBody5264); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LCURLY.add(LCURLY51);

			pushFollow(FOLLOW_enumScopeDeclarations_in_enumBody5266);
			enumScopeDeclarations52=enumScopeDeclarations();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_enumScopeDeclarations.add(enumScopeDeclarations52.getTree());
			RCURLY53=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_enumBody5268); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RCURLY.add(RCURLY53);


			// AST REWRITE
			// elements: enumScopeDeclarations
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 318:9: -> ^( ENUM_TOP_LEVEL_SCOPE[$LCURLY, \"ENUM_TOP_LEVEL_SCOPE\"] enumScopeDeclarations )
			{
				// Java.g:318:13: ^( ENUM_TOP_LEVEL_SCOPE[$LCURLY, \"ENUM_TOP_LEVEL_SCOPE\"] enumScopeDeclarations )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ENUM_TOP_LEVEL_SCOPE, LCURLY51, "ENUM_TOP_LEVEL_SCOPE"), root_1);
				adaptor.addChild(root_1, stream_enumScopeDeclarations.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 16, enumBody_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "enumBody"


	public static class enumScopeDeclarations_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "enumScopeDeclarations"
	// Java.g:321:1: enumScopeDeclarations : enumConstants ( COMMA !)? ( enumClassScopeDeclarations )? ;
	public final JavaParser.enumScopeDeclarations_return enumScopeDeclarations() throws RecognitionException {
		JavaParser.enumScopeDeclarations_return retval = new JavaParser.enumScopeDeclarations_return();
		retval.start = input.LT(1);
		int enumScopeDeclarations_StartIndex = input.index();

		CommonTree root_0 = null;

		Token COMMA55=null;
		ParserRuleReturnScope enumConstants54 =null;
		ParserRuleReturnScope enumClassScopeDeclarations56 =null;

		CommonTree COMMA55_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 17) ) { return retval; }

			// Java.g:322:5: ( enumConstants ( COMMA !)? ( enumClassScopeDeclarations )? )
			// Java.g:322:9: enumConstants ( COMMA !)? ( enumClassScopeDeclarations )?
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_enumConstants_in_enumScopeDeclarations5305);
			enumConstants54=enumConstants();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, enumConstants54.getTree());

			// Java.g:322:23: ( COMMA !)?
			int alt16=2;
			int LA16_0 = input.LA(1);
			if ( (LA16_0==COMMA) ) {
				alt16=1;
			}
			switch (alt16) {
				case 1 :
					// Java.g:322:24: COMMA !
					{
					COMMA55=(Token)match(input,COMMA,FOLLOW_COMMA_in_enumScopeDeclarations5308); if (state.failed) return retval;
					}
					break;

			}

			// Java.g:322:33: ( enumClassScopeDeclarations )?
			int alt17=2;
			int LA17_0 = input.LA(1);
			if ( (LA17_0==SEMI) ) {
				alt17=1;
			}
			switch (alt17) {
				case 1 :
					// Java.g:322:33: enumClassScopeDeclarations
					{
					pushFollow(FOLLOW_enumClassScopeDeclarations_in_enumScopeDeclarations5313);
					enumClassScopeDeclarations56=enumClassScopeDeclarations();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, enumClassScopeDeclarations56.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 17, enumScopeDeclarations_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "enumScopeDeclarations"


	public static class enumClassScopeDeclarations_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "enumClassScopeDeclarations"
	// Java.g:325:1: enumClassScopeDeclarations : SEMI ( classScopeDeclarations )* -> ^( CLASS_TOP_LEVEL_SCOPE[$SEMI, \"CLASS_TOP_LEVEL_SCOPE\"] ( classScopeDeclarations )* ) ;
	public final JavaParser.enumClassScopeDeclarations_return enumClassScopeDeclarations() throws RecognitionException {
		JavaParser.enumClassScopeDeclarations_return retval = new JavaParser.enumClassScopeDeclarations_return();
		retval.start = input.LT(1);
		int enumClassScopeDeclarations_StartIndex = input.index();

		CommonTree root_0 = null;

		Token SEMI57=null;
		ParserRuleReturnScope classScopeDeclarations58 =null;

		CommonTree SEMI57_tree=null;
		RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
		RewriteRuleSubtreeStream stream_classScopeDeclarations=new RewriteRuleSubtreeStream(adaptor,"rule classScopeDeclarations");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 18) ) { return retval; }

			// Java.g:326:5: ( SEMI ( classScopeDeclarations )* -> ^( CLASS_TOP_LEVEL_SCOPE[$SEMI, \"CLASS_TOP_LEVEL_SCOPE\"] ( classScopeDeclarations )* ) )
			// Java.g:326:9: SEMI ( classScopeDeclarations )*
			{
			SEMI57=(Token)match(input,SEMI,FOLLOW_SEMI_in_enumClassScopeDeclarations5333); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_SEMI.add(SEMI57);

			// Java.g:326:14: ( classScopeDeclarations )*
			loop18:
			while (true) {
				int alt18=2;
				int LA18_0 = input.LA(1);
				if ( (LA18_0==ABSTRACT||LA18_0==AT||LA18_0==BOOLEAN||LA18_0==BYTE||LA18_0==CHAR||LA18_0==CLASS||LA18_0==DOUBLE||LA18_0==ENUM||LA18_0==FINAL||LA18_0==FLOAT||LA18_0==IDENT||LA18_0==INT||LA18_0==INTERFACE||LA18_0==LCURLY||LA18_0==LESS_THAN||LA18_0==LONG||LA18_0==NATIVE||(LA18_0 >= PRIVATE && LA18_0 <= PUBLIC)||LA18_0==SEMI||LA18_0==SHORT||LA18_0==STATIC||LA18_0==STRICTFP||LA18_0==SYNCHRONIZED||LA18_0==TRANSIENT||LA18_0==VOID||LA18_0==VOLATILE) ) {
					alt18=1;
				}

				switch (alt18) {
				case 1 :
					// Java.g:326:14: classScopeDeclarations
					{
					pushFollow(FOLLOW_classScopeDeclarations_in_enumClassScopeDeclarations5335);
					classScopeDeclarations58=classScopeDeclarations();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_classScopeDeclarations.add(classScopeDeclarations58.getTree());
					}
					break;

				default :
					break loop18;
				}
			}


			// AST REWRITE
			// elements: classScopeDeclarations
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 327:9: -> ^( CLASS_TOP_LEVEL_SCOPE[$SEMI, \"CLASS_TOP_LEVEL_SCOPE\"] ( classScopeDeclarations )* )
			{
				// Java.g:327:13: ^( CLASS_TOP_LEVEL_SCOPE[$SEMI, \"CLASS_TOP_LEVEL_SCOPE\"] ( classScopeDeclarations )* )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CLASS_TOP_LEVEL_SCOPE, SEMI57, "CLASS_TOP_LEVEL_SCOPE"), root_1);
				// Java.g:327:69: ( classScopeDeclarations )*
				while ( stream_classScopeDeclarations.hasNext() ) {
					adaptor.addChild(root_1, stream_classScopeDeclarations.nextTree());
				}
				stream_classScopeDeclarations.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 18, enumClassScopeDeclarations_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "enumClassScopeDeclarations"


	public static class enumConstants_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "enumConstants"
	// Java.g:330:1: enumConstants : enumConstant ( COMMA ! enumConstant )* ;
	public final JavaParser.enumConstants_return enumConstants() throws RecognitionException {
		JavaParser.enumConstants_return retval = new JavaParser.enumConstants_return();
		retval.start = input.LT(1);
		int enumConstants_StartIndex = input.index();

		CommonTree root_0 = null;

		Token COMMA60=null;
		ParserRuleReturnScope enumConstant59 =null;
		ParserRuleReturnScope enumConstant61 =null;

		CommonTree COMMA60_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 19) ) { return retval; }

			// Java.g:331:5: ( enumConstant ( COMMA ! enumConstant )* )
			// Java.g:331:9: enumConstant ( COMMA ! enumConstant )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_enumConstant_in_enumConstants5374);
			enumConstant59=enumConstant();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, enumConstant59.getTree());

			// Java.g:331:22: ( COMMA ! enumConstant )*
			loop19:
			while (true) {
				int alt19=2;
				int LA19_0 = input.LA(1);
				if ( (LA19_0==COMMA) ) {
					int LA19_1 = input.LA(2);
					if ( (LA19_1==AT||LA19_1==IDENT) ) {
						alt19=1;
					}

				}

				switch (alt19) {
				case 1 :
					// Java.g:331:23: COMMA ! enumConstant
					{
					COMMA60=(Token)match(input,COMMA,FOLLOW_COMMA_in_enumConstants5377); if (state.failed) return retval;
					pushFollow(FOLLOW_enumConstant_in_enumConstants5380);
					enumConstant61=enumConstant();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, enumConstant61.getTree());

					}
					break;

				default :
					break loop19;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 19, enumConstants_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "enumConstants"


	public static class enumConstant_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "enumConstant"
	// Java.g:334:1: enumConstant : annotationList IDENT ^ ( arguments )? ( classBody )? ;
	public final JavaParser.enumConstant_return enumConstant() throws RecognitionException {
		JavaParser.enumConstant_return retval = new JavaParser.enumConstant_return();
		retval.start = input.LT(1);
		int enumConstant_StartIndex = input.index();

		CommonTree root_0 = null;

		Token IDENT63=null;
		ParserRuleReturnScope annotationList62 =null;
		ParserRuleReturnScope arguments64 =null;
		ParserRuleReturnScope classBody65 =null;

		CommonTree IDENT63_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 20) ) { return retval; }

			// Java.g:335:5: ( annotationList IDENT ^ ( arguments )? ( classBody )? )
			// Java.g:335:9: annotationList IDENT ^ ( arguments )? ( classBody )?
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_annotationList_in_enumConstant5401);
			annotationList62=annotationList();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, annotationList62.getTree());

			IDENT63=(Token)match(input,IDENT,FOLLOW_IDENT_in_enumConstant5403); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			IDENT63_tree = (CommonTree)adaptor.create(IDENT63);
			root_0 = (CommonTree)adaptor.becomeRoot(IDENT63_tree, root_0);
			}

			// Java.g:335:31: ( arguments )?
			int alt20=2;
			int LA20_0 = input.LA(1);
			if ( (LA20_0==LPAREN) ) {
				alt20=1;
			}
			switch (alt20) {
				case 1 :
					// Java.g:335:31: arguments
					{
					pushFollow(FOLLOW_arguments_in_enumConstant5406);
					arguments64=arguments();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arguments64.getTree());

					}
					break;

			}

			// Java.g:335:42: ( classBody )?
			int alt21=2;
			int LA21_0 = input.LA(1);
			if ( (LA21_0==LCURLY) ) {
				alt21=1;
			}
			switch (alt21) {
				case 1 :
					// Java.g:335:42: classBody
					{
					pushFollow(FOLLOW_classBody_in_enumConstant5409);
					classBody65=classBody();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, classBody65.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 20, enumConstant_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "enumConstant"


	public static class interfaceTypeDeclaration_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "interfaceTypeDeclaration"
	// Java.g:338:1: interfaceTypeDeclaration[CommonTree modifiers] : INTERFACE IDENT ( genericTypeParameterList )? ( interfaceExtendsClause )? interfaceBody -> ^( INTERFACE IDENT ( genericTypeParameterList )? ( interfaceExtendsClause )? interfaceBody ) ;
	public final JavaParser.interfaceTypeDeclaration_return interfaceTypeDeclaration(CommonTree modifiers) throws RecognitionException {
		JavaParser.interfaceTypeDeclaration_return retval = new JavaParser.interfaceTypeDeclaration_return();
		retval.start = input.LT(1);
		int interfaceTypeDeclaration_StartIndex = input.index();

		CommonTree root_0 = null;

		Token INTERFACE66=null;
		Token IDENT67=null;
		ParserRuleReturnScope genericTypeParameterList68 =null;
		ParserRuleReturnScope interfaceExtendsClause69 =null;
		ParserRuleReturnScope interfaceBody70 =null;

		CommonTree INTERFACE66_tree=null;
		CommonTree IDENT67_tree=null;
		RewriteRuleTokenStream stream_INTERFACE=new RewriteRuleTokenStream(adaptor,"token INTERFACE");
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleSubtreeStream stream_interfaceBody=new RewriteRuleSubtreeStream(adaptor,"rule interfaceBody");
		RewriteRuleSubtreeStream stream_interfaceExtendsClause=new RewriteRuleSubtreeStream(adaptor,"rule interfaceExtendsClause");
		RewriteRuleSubtreeStream stream_genericTypeParameterList=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeParameterList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 21) ) { return retval; }

			// Java.g:339:5: ( INTERFACE IDENT ( genericTypeParameterList )? ( interfaceExtendsClause )? interfaceBody -> ^( INTERFACE IDENT ( genericTypeParameterList )? ( interfaceExtendsClause )? interfaceBody ) )
			// Java.g:339:9: INTERFACE IDENT ( genericTypeParameterList )? ( interfaceExtendsClause )? interfaceBody
			{
			INTERFACE66=(Token)match(input,INTERFACE,FOLLOW_INTERFACE_in_interfaceTypeDeclaration5430); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_INTERFACE.add(INTERFACE66);

			IDENT67=(Token)match(input,IDENT,FOLLOW_IDENT_in_interfaceTypeDeclaration5432); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_IDENT.add(IDENT67);

			// Java.g:339:25: ( genericTypeParameterList )?
			int alt22=2;
			int LA22_0 = input.LA(1);
			if ( (LA22_0==LESS_THAN) ) {
				alt22=1;
			}
			switch (alt22) {
				case 1 :
					// Java.g:339:25: genericTypeParameterList
					{
					pushFollow(FOLLOW_genericTypeParameterList_in_interfaceTypeDeclaration5434);
					genericTypeParameterList68=genericTypeParameterList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_genericTypeParameterList.add(genericTypeParameterList68.getTree());
					}
					break;

			}

			// Java.g:339:51: ( interfaceExtendsClause )?
			int alt23=2;
			int LA23_0 = input.LA(1);
			if ( (LA23_0==EXTENDS) ) {
				alt23=1;
			}
			switch (alt23) {
				case 1 :
					// Java.g:339:51: interfaceExtendsClause
					{
					pushFollow(FOLLOW_interfaceExtendsClause_in_interfaceTypeDeclaration5437);
					interfaceExtendsClause69=interfaceExtendsClause();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_interfaceExtendsClause.add(interfaceExtendsClause69.getTree());
					}
					break;

			}

			pushFollow(FOLLOW_interfaceBody_in_interfaceTypeDeclaration5440);
			interfaceBody70=interfaceBody();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_interfaceBody.add(interfaceBody70.getTree());

			// AST REWRITE
			// elements: interfaceBody, INTERFACE, genericTypeParameterList, IDENT, interfaceExtendsClause
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 340:9: -> ^( INTERFACE IDENT ( genericTypeParameterList )? ( interfaceExtendsClause )? interfaceBody )
			{
				// Java.g:340:13: ^( INTERFACE IDENT ( genericTypeParameterList )? ( interfaceExtendsClause )? interfaceBody )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot(stream_INTERFACE.nextNode(), root_1);
				adaptor.addChild(root_1, modifiers);
				adaptor.addChild(root_1, stream_IDENT.nextNode());
				// Java.g:340:44: ( genericTypeParameterList )?
				if ( stream_genericTypeParameterList.hasNext() ) {
					adaptor.addChild(root_1, stream_genericTypeParameterList.nextTree());
				}
				stream_genericTypeParameterList.reset();

				// Java.g:340:70: ( interfaceExtendsClause )?
				if ( stream_interfaceExtendsClause.hasNext() ) {
					adaptor.addChild(root_1, stream_interfaceExtendsClause.nextTree());
				}
				stream_interfaceExtendsClause.reset();

				adaptor.addChild(root_1, stream_interfaceBody.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 21, interfaceTypeDeclaration_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "interfaceTypeDeclaration"


	public static class typeList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "typeList"
	// Java.g:343:1: typeList : type ( COMMA ! type )* ;
	public final JavaParser.typeList_return typeList() throws RecognitionException {
		JavaParser.typeList_return retval = new JavaParser.typeList_return();
		retval.start = input.LT(1);
		int typeList_StartIndex = input.index();

		CommonTree root_0 = null;

		Token COMMA72=null;
		ParserRuleReturnScope type71 =null;
		ParserRuleReturnScope type73 =null;

		CommonTree COMMA72_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 22) ) { return retval; }

			// Java.g:344:5: ( type ( COMMA ! type )* )
			// Java.g:344:9: type ( COMMA ! type )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_type_in_typeList5486);
			type71=type();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, type71.getTree());

			// Java.g:344:14: ( COMMA ! type )*
			loop24:
			while (true) {
				int alt24=2;
				int LA24_0 = input.LA(1);
				if ( (LA24_0==COMMA) ) {
					alt24=1;
				}

				switch (alt24) {
				case 1 :
					// Java.g:344:15: COMMA ! type
					{
					COMMA72=(Token)match(input,COMMA,FOLLOW_COMMA_in_typeList5489); if (state.failed) return retval;
					pushFollow(FOLLOW_type_in_typeList5492);
					type73=type();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, type73.getTree());

					}
					break;

				default :
					break loop24;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 22, typeList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "typeList"


	public static class classBody_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "classBody"
	// Java.g:347:1: classBody : LCURLY ( classScopeDeclarations )* RCURLY -> ^( CLASS_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( classScopeDeclarations )* ) ;
	public final JavaParser.classBody_return classBody() throws RecognitionException {
		JavaParser.classBody_return retval = new JavaParser.classBody_return();
		retval.start = input.LT(1);
		int classBody_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LCURLY74=null;
		Token RCURLY76=null;
		ParserRuleReturnScope classScopeDeclarations75 =null;

		CommonTree LCURLY74_tree=null;
		CommonTree RCURLY76_tree=null;
		RewriteRuleTokenStream stream_LCURLY=new RewriteRuleTokenStream(adaptor,"token LCURLY");
		RewriteRuleTokenStream stream_RCURLY=new RewriteRuleTokenStream(adaptor,"token RCURLY");
		RewriteRuleSubtreeStream stream_classScopeDeclarations=new RewriteRuleSubtreeStream(adaptor,"rule classScopeDeclarations");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 23) ) { return retval; }

			// Java.g:348:5: ( LCURLY ( classScopeDeclarations )* RCURLY -> ^( CLASS_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( classScopeDeclarations )* ) )
			// Java.g:348:9: LCURLY ( classScopeDeclarations )* RCURLY
			{
			LCURLY74=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_classBody5513); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LCURLY.add(LCURLY74);

			// Java.g:348:16: ( classScopeDeclarations )*
			loop25:
			while (true) {
				int alt25=2;
				int LA25_0 = input.LA(1);
				if ( (LA25_0==ABSTRACT||LA25_0==AT||LA25_0==BOOLEAN||LA25_0==BYTE||LA25_0==CHAR||LA25_0==CLASS||LA25_0==DOUBLE||LA25_0==ENUM||LA25_0==FINAL||LA25_0==FLOAT||LA25_0==IDENT||LA25_0==INT||LA25_0==INTERFACE||LA25_0==LCURLY||LA25_0==LESS_THAN||LA25_0==LONG||LA25_0==NATIVE||(LA25_0 >= PRIVATE && LA25_0 <= PUBLIC)||LA25_0==SEMI||LA25_0==SHORT||LA25_0==STATIC||LA25_0==STRICTFP||LA25_0==SYNCHRONIZED||LA25_0==TRANSIENT||LA25_0==VOID||LA25_0==VOLATILE) ) {
					alt25=1;
				}

				switch (alt25) {
				case 1 :
					// Java.g:348:16: classScopeDeclarations
					{
					pushFollow(FOLLOW_classScopeDeclarations_in_classBody5515);
					classScopeDeclarations75=classScopeDeclarations();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_classScopeDeclarations.add(classScopeDeclarations75.getTree());
					}
					break;

				default :
					break loop25;
				}
			}

			RCURLY76=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_classBody5518); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RCURLY.add(RCURLY76);


			// AST REWRITE
			// elements: classScopeDeclarations
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 349:9: -> ^( CLASS_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( classScopeDeclarations )* )
			{
				// Java.g:349:13: ^( CLASS_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( classScopeDeclarations )* )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CLASS_TOP_LEVEL_SCOPE, LCURLY74, "CLASS_TOP_LEVEL_SCOPE"), root_1);
				// Java.g:349:71: ( classScopeDeclarations )*
				while ( stream_classScopeDeclarations.hasNext() ) {
					adaptor.addChild(root_1, stream_classScopeDeclarations.nextTree());
				}
				stream_classScopeDeclarations.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 23, classBody_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "classBody"


	public static class interfaceBody_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "interfaceBody"
	// Java.g:352:1: interfaceBody : LCURLY ( interfaceScopeDeclarations )* RCURLY -> ^( INTERFACE_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( interfaceScopeDeclarations )* ) ;
	public final JavaParser.interfaceBody_return interfaceBody() throws RecognitionException {
		JavaParser.interfaceBody_return retval = new JavaParser.interfaceBody_return();
		retval.start = input.LT(1);
		int interfaceBody_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LCURLY77=null;
		Token RCURLY79=null;
		ParserRuleReturnScope interfaceScopeDeclarations78 =null;

		CommonTree LCURLY77_tree=null;
		CommonTree RCURLY79_tree=null;
		RewriteRuleTokenStream stream_LCURLY=new RewriteRuleTokenStream(adaptor,"token LCURLY");
		RewriteRuleTokenStream stream_RCURLY=new RewriteRuleTokenStream(adaptor,"token RCURLY");
		RewriteRuleSubtreeStream stream_interfaceScopeDeclarations=new RewriteRuleSubtreeStream(adaptor,"rule interfaceScopeDeclarations");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 24) ) { return retval; }

			// Java.g:353:5: ( LCURLY ( interfaceScopeDeclarations )* RCURLY -> ^( INTERFACE_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( interfaceScopeDeclarations )* ) )
			// Java.g:353:9: LCURLY ( interfaceScopeDeclarations )* RCURLY
			{
			LCURLY77=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_interfaceBody5556); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LCURLY.add(LCURLY77);

			// Java.g:353:16: ( interfaceScopeDeclarations )*
			loop26:
			while (true) {
				int alt26=2;
				int LA26_0 = input.LA(1);
				if ( (LA26_0==ABSTRACT||LA26_0==AT||LA26_0==BOOLEAN||LA26_0==BYTE||LA26_0==CHAR||LA26_0==CLASS||LA26_0==DOUBLE||LA26_0==ENUM||LA26_0==FINAL||LA26_0==FLOAT||LA26_0==IDENT||LA26_0==INT||LA26_0==INTERFACE||LA26_0==LESS_THAN||LA26_0==LONG||LA26_0==NATIVE||(LA26_0 >= PRIVATE && LA26_0 <= PUBLIC)||LA26_0==SEMI||LA26_0==SHORT||LA26_0==STATIC||LA26_0==STRICTFP||LA26_0==SYNCHRONIZED||LA26_0==TRANSIENT||LA26_0==VOID||LA26_0==VOLATILE) ) {
					alt26=1;
				}

				switch (alt26) {
				case 1 :
					// Java.g:353:16: interfaceScopeDeclarations
					{
					pushFollow(FOLLOW_interfaceScopeDeclarations_in_interfaceBody5558);
					interfaceScopeDeclarations78=interfaceScopeDeclarations();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_interfaceScopeDeclarations.add(interfaceScopeDeclarations78.getTree());
					}
					break;

				default :
					break loop26;
				}
			}

			RCURLY79=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_interfaceBody5561); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RCURLY.add(RCURLY79);


			// AST REWRITE
			// elements: interfaceScopeDeclarations
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 354:9: -> ^( INTERFACE_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( interfaceScopeDeclarations )* )
			{
				// Java.g:354:13: ^( INTERFACE_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( interfaceScopeDeclarations )* )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(INTERFACE_TOP_LEVEL_SCOPE, LCURLY77, "CLASS_TOP_LEVEL_SCOPE"), root_1);
				// Java.g:354:75: ( interfaceScopeDeclarations )*
				while ( stream_interfaceScopeDeclarations.hasNext() ) {
					adaptor.addChild(root_1, stream_interfaceScopeDeclarations.nextTree());
				}
				stream_interfaceScopeDeclarations.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 24, interfaceBody_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "interfaceBody"


	public static class classScopeDeclarations_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "classScopeDeclarations"
	// Java.g:357:1: classScopeDeclarations : ( block -> ^( CLASS_INSTANCE_INITIALIZER block ) | STATIC block -> ^( CLASS_STATIC_INITIALIZER[$STATIC, \"CLASS_STATIC_INITIALIZER\"] block ) | modifierList ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block )? ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ( block )? ) |ident= IDENT formalParameterList ( throwsClause )? block -> ^( CONSTRUCTOR_DECL[$ident, \"CONSTRUCTOR_DECL\"] modifierList ( genericTypeParameterList )? formalParameterList ( throwsClause )? block ) ) | type classFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type classFieldDeclaratorList ) ) | typeDeclaration | SEMI !);
	public final JavaParser.classScopeDeclarations_return classScopeDeclarations() throws RecognitionException {
		JavaParser.classScopeDeclarations_return retval = new JavaParser.classScopeDeclarations_return();
		retval.start = input.LT(1);
		int classScopeDeclarations_StartIndex = input.index();

		CommonTree root_0 = null;

		Token ident=null;
		Token STATIC81=null;
		Token IDENT86=null;
		Token SEMI91=null;
		Token VOID92=null;
		Token IDENT93=null;
		Token SEMI97=null;
		Token SEMI103=null;
		Token SEMI105=null;
		ParserRuleReturnScope block80 =null;
		ParserRuleReturnScope block82 =null;
		ParserRuleReturnScope modifierList83 =null;
		ParserRuleReturnScope genericTypeParameterList84 =null;
		ParserRuleReturnScope type85 =null;
		ParserRuleReturnScope formalParameterList87 =null;
		ParserRuleReturnScope arrayDeclaratorList88 =null;
		ParserRuleReturnScope throwsClause89 =null;
		ParserRuleReturnScope block90 =null;
		ParserRuleReturnScope formalParameterList94 =null;
		ParserRuleReturnScope throwsClause95 =null;
		ParserRuleReturnScope block96 =null;
		ParserRuleReturnScope formalParameterList98 =null;
		ParserRuleReturnScope throwsClause99 =null;
		ParserRuleReturnScope block100 =null;
		ParserRuleReturnScope type101 =null;
		ParserRuleReturnScope classFieldDeclaratorList102 =null;
		ParserRuleReturnScope typeDeclaration104 =null;

		CommonTree ident_tree=null;
		CommonTree STATIC81_tree=null;
		CommonTree IDENT86_tree=null;
		CommonTree SEMI91_tree=null;
		CommonTree VOID92_tree=null;
		CommonTree IDENT93_tree=null;
		CommonTree SEMI97_tree=null;
		CommonTree SEMI103_tree=null;
		CommonTree SEMI105_tree=null;
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
		RewriteRuleTokenStream stream_VOID=new RewriteRuleTokenStream(adaptor,"token VOID");
		RewriteRuleTokenStream stream_STATIC=new RewriteRuleTokenStream(adaptor,"token STATIC");
		RewriteRuleSubtreeStream stream_throwsClause=new RewriteRuleSubtreeStream(adaptor,"rule throwsClause");
		RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
		RewriteRuleSubtreeStream stream_genericTypeParameterList=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeParameterList");
		RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
		RewriteRuleSubtreeStream stream_modifierList=new RewriteRuleSubtreeStream(adaptor,"rule modifierList");
		RewriteRuleSubtreeStream stream_arrayDeclaratorList=new RewriteRuleSubtreeStream(adaptor,"rule arrayDeclaratorList");
		RewriteRuleSubtreeStream stream_classFieldDeclaratorList=new RewriteRuleSubtreeStream(adaptor,"rule classFieldDeclaratorList");
		RewriteRuleSubtreeStream stream_formalParameterList=new RewriteRuleSubtreeStream(adaptor,"rule formalParameterList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 25) ) { return retval; }

			// Java.g:358:5: ( block -> ^( CLASS_INSTANCE_INITIALIZER block ) | STATIC block -> ^( CLASS_STATIC_INITIALIZER[$STATIC, \"CLASS_STATIC_INITIALIZER\"] block ) | modifierList ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block )? ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ( block )? ) |ident= IDENT formalParameterList ( throwsClause )? block -> ^( CONSTRUCTOR_DECL[$ident, \"CONSTRUCTOR_DECL\"] modifierList ( genericTypeParameterList )? formalParameterList ( throwsClause )? block ) ) | type classFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type classFieldDeclaratorList ) ) | typeDeclaration | SEMI !)
			int alt36=5;
			switch ( input.LA(1) ) {
			case LCURLY:
				{
				alt36=1;
				}
				break;
			case STATIC:
				{
				int LA36_2 = input.LA(2);
				if ( (synpred32_Java()) ) {
					alt36=2;
				}
				else if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 2, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case PUBLIC:
				{
				int LA36_3 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 3, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case PROTECTED:
				{
				int LA36_4 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 4, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case PRIVATE:
				{
				int LA36_5 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 5, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case ABSTRACT:
				{
				int LA36_6 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 6, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case NATIVE:
				{
				int LA36_7 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 7, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case SYNCHRONIZED:
				{
				int LA36_8 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 8, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case TRANSIENT:
				{
				int LA36_9 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 9, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case VOLATILE:
				{
				int LA36_10 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 10, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case STRICTFP:
				{
				int LA36_11 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 11, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case FINAL:
				{
				int LA36_12 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 12, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case AT:
				{
				int LA36_13 = input.LA(2);
				if ( (synpred43_Java()) ) {
					alt36=3;
				}
				else if ( (synpred44_Java()) ) {
					alt36=4;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 36, 13, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case DOUBLE:
			case FLOAT:
			case IDENT:
			case INT:
			case LESS_THAN:
			case LONG:
			case SHORT:
			case VOID:
				{
				alt36=3;
				}
				break;
			case CLASS:
			case ENUM:
			case INTERFACE:
				{
				alt36=4;
				}
				break;
			case SEMI:
				{
				alt36=5;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 36, 0, input);
				throw nvae;
			}
			switch (alt36) {
				case 1 :
					// Java.g:358:9: block
					{
					pushFollow(FOLLOW_block_in_classScopeDeclarations5599);
					block80=block();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_block.add(block80.getTree());

					// AST REWRITE
					// elements: block
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 358:25: -> ^( CLASS_INSTANCE_INITIALIZER block )
					{
						// Java.g:358:29: ^( CLASS_INSTANCE_INITIALIZER block )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CLASS_INSTANCE_INITIALIZER, "CLASS_INSTANCE_INITIALIZER"), root_1);
						adaptor.addChild(root_1, stream_block.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 2 :
					// Java.g:359:9: STATIC block
					{
					STATIC81=(Token)match(input,STATIC,FOLLOW_STATIC_in_classScopeDeclarations5628); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_STATIC.add(STATIC81);

					pushFollow(FOLLOW_block_in_classScopeDeclarations5630);
					block82=block();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_block.add(block82.getTree());

					// AST REWRITE
					// elements: block
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 359:25: -> ^( CLASS_STATIC_INITIALIZER[$STATIC, \"CLASS_STATIC_INITIALIZER\"] block )
					{
						// Java.g:359:29: ^( CLASS_STATIC_INITIALIZER[$STATIC, \"CLASS_STATIC_INITIALIZER\"] block )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CLASS_STATIC_INITIALIZER, STATIC81, "CLASS_STATIC_INITIALIZER"), root_1);
						adaptor.addChild(root_1, stream_block.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 3 :
					// Java.g:360:9: modifierList ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block )? ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ( block )? ) |ident= IDENT formalParameterList ( throwsClause )? block -> ^( CONSTRUCTOR_DECL[$ident, \"CONSTRUCTOR_DECL\"] modifierList ( genericTypeParameterList )? formalParameterList ( throwsClause )? block ) ) | type classFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type classFieldDeclaratorList ) )
					{
					pushFollow(FOLLOW_modifierList_in_classScopeDeclarations5653);
					modifierList83=modifierList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_modifierList.add(modifierList83.getTree());
					// Java.g:361:9: ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block )? ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ( block )? ) |ident= IDENT formalParameterList ( throwsClause )? block -> ^( CONSTRUCTOR_DECL[$ident, \"CONSTRUCTOR_DECL\"] modifierList ( genericTypeParameterList )? formalParameterList ( throwsClause )? block ) ) | type classFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type classFieldDeclaratorList ) )
					int alt35=2;
					switch ( input.LA(1) ) {
					case LESS_THAN:
					case VOID:
						{
						alt35=1;
						}
						break;
					case BOOLEAN:
					case BYTE:
					case CHAR:
					case DOUBLE:
					case FLOAT:
					case INT:
					case LONG:
					case SHORT:
						{
						int LA35_2 = input.LA(2);
						if ( (synpred42_Java()) ) {
							alt35=1;
						}
						else if ( (true) ) {
							alt35=2;
						}

						}
						break;
					case IDENT:
						{
						int LA35_3 = input.LA(2);
						if ( (synpred42_Java()) ) {
							alt35=1;
						}
						else if ( (true) ) {
							alt35=2;
						}

						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 35, 0, input);
						throw nvae;
					}
					switch (alt35) {
						case 1 :
							// Java.g:361:13: ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block )? ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ( block )? ) |ident= IDENT formalParameterList ( throwsClause )? block -> ^( CONSTRUCTOR_DECL[$ident, \"CONSTRUCTOR_DECL\"] modifierList ( genericTypeParameterList )? formalParameterList ( throwsClause )? block ) )
							{
							// Java.g:361:13: ( genericTypeParameterList )?
							int alt27=2;
							int LA27_0 = input.LA(1);
							if ( (LA27_0==LESS_THAN) ) {
								alt27=1;
							}
							switch (alt27) {
								case 1 :
									// Java.g:361:13: genericTypeParameterList
									{
									pushFollow(FOLLOW_genericTypeParameterList_in_classScopeDeclarations5667);
									genericTypeParameterList84=genericTypeParameterList();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_genericTypeParameterList.add(genericTypeParameterList84.getTree());
									}
									break;

							}

							// Java.g:362:13: ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block )? ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ( block )? ) |ident= IDENT formalParameterList ( throwsClause )? block -> ^( CONSTRUCTOR_DECL[$ident, \"CONSTRUCTOR_DECL\"] modifierList ( genericTypeParameterList )? formalParameterList ( throwsClause )? block ) )
							int alt34=3;
							switch ( input.LA(1) ) {
							case BOOLEAN:
							case BYTE:
							case CHAR:
							case DOUBLE:
							case FLOAT:
							case INT:
							case LONG:
							case SHORT:
								{
								alt34=1;
								}
								break;
							case IDENT:
								{
								int LA34_2 = input.LA(2);
								if ( (LA34_2==DOT||LA34_2==IDENT||LA34_2==LBRACK||LA34_2==LESS_THAN) ) {
									alt34=1;
								}
								else if ( (LA34_2==LPAREN) ) {
									alt34=3;
								}

								else {
									if (state.backtracking>0) {state.failed=true; return retval;}
									int nvaeMark = input.mark();
									try {
										input.consume();
										NoViableAltException nvae =
											new NoViableAltException("", 34, 2, input);
										throw nvae;
									} finally {
										input.rewind(nvaeMark);
									}
								}

								}
								break;
							case VOID:
								{
								alt34=2;
								}
								break;
							default:
								if (state.backtracking>0) {state.failed=true; return retval;}
								NoViableAltException nvae =
									new NoViableAltException("", 34, 0, input);
								throw nvae;
							}
							switch (alt34) {
								case 1 :
									// Java.g:362:17: type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI )
									{
									pushFollow(FOLLOW_type_in_classScopeDeclarations5686);
									type85=type();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_type.add(type85.getTree());
									IDENT86=(Token)match(input,IDENT,FOLLOW_IDENT_in_classScopeDeclarations5688); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_IDENT.add(IDENT86);

									pushFollow(FOLLOW_formalParameterList_in_classScopeDeclarations5690);
									formalParameterList87=formalParameterList();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_formalParameterList.add(formalParameterList87.getTree());
									// Java.g:362:48: ( arrayDeclaratorList )?
									int alt28=2;
									int LA28_0 = input.LA(1);
									if ( (LA28_0==LBRACK) ) {
										alt28=1;
									}
									switch (alt28) {
										case 1 :
											// Java.g:362:48: arrayDeclaratorList
											{
											pushFollow(FOLLOW_arrayDeclaratorList_in_classScopeDeclarations5692);
											arrayDeclaratorList88=arrayDeclaratorList();
											state._fsp--;
											if (state.failed) return retval;
											if ( state.backtracking==0 ) stream_arrayDeclaratorList.add(arrayDeclaratorList88.getTree());
											}
											break;

									}

									// Java.g:362:69: ( throwsClause )?
									int alt29=2;
									int LA29_0 = input.LA(1);
									if ( (LA29_0==THROWS) ) {
										alt29=1;
									}
									switch (alt29) {
										case 1 :
											// Java.g:362:69: throwsClause
											{
											pushFollow(FOLLOW_throwsClause_in_classScopeDeclarations5695);
											throwsClause89=throwsClause();
											state._fsp--;
											if (state.failed) return retval;
											if ( state.backtracking==0 ) stream_throwsClause.add(throwsClause89.getTree());
											}
											break;

									}

									// Java.g:362:83: ( block | SEMI )
									int alt30=2;
									int LA30_0 = input.LA(1);
									if ( (LA30_0==LCURLY) ) {
										alt30=1;
									}
									else if ( (LA30_0==SEMI) ) {
										alt30=2;
									}

									else {
										if (state.backtracking>0) {state.failed=true; return retval;}
										NoViableAltException nvae =
											new NoViableAltException("", 30, 0, input);
										throw nvae;
									}

									switch (alt30) {
										case 1 :
											// Java.g:362:84: block
											{
											pushFollow(FOLLOW_block_in_classScopeDeclarations5699);
											block90=block();
											state._fsp--;
											if (state.failed) return retval;
											if ( state.backtracking==0 ) stream_block.add(block90.getTree());
											}
											break;
										case 2 :
											// Java.g:362:92: SEMI
											{
											SEMI91=(Token)match(input,SEMI,FOLLOW_SEMI_in_classScopeDeclarations5703); if (state.failed) return retval; 
											if ( state.backtracking==0 ) stream_SEMI.add(SEMI91);

											}
											break;

									}


									// AST REWRITE
									// elements: type, modifierList, throwsClause, formalParameterList, IDENT, arrayDeclaratorList, block, genericTypeParameterList
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 363:17: -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block )? )
									{
										// Java.g:363:21: ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block )? )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FUNCTION_METHOD_DECL, "FUNCTION_METHOD_DECL"), root_1);
										adaptor.addChild(root_1, stream_modifierList.nextTree());
										// Java.g:363:57: ( genericTypeParameterList )?
										if ( stream_genericTypeParameterList.hasNext() ) {
											adaptor.addChild(root_1, stream_genericTypeParameterList.nextTree());
										}
										stream_genericTypeParameterList.reset();

										adaptor.addChild(root_1, stream_type.nextTree());
										adaptor.addChild(root_1, stream_IDENT.nextNode());
										adaptor.addChild(root_1, stream_formalParameterList.nextTree());
										// Java.g:363:114: ( arrayDeclaratorList )?
										if ( stream_arrayDeclaratorList.hasNext() ) {
											adaptor.addChild(root_1, stream_arrayDeclaratorList.nextTree());
										}
										stream_arrayDeclaratorList.reset();

										// Java.g:363:135: ( throwsClause )?
										if ( stream_throwsClause.hasNext() ) {
											adaptor.addChild(root_1, stream_throwsClause.nextTree());
										}
										stream_throwsClause.reset();

										// Java.g:363:149: ( block )?
										if ( stream_block.hasNext() ) {
											adaptor.addChild(root_1, stream_block.nextTree());
										}
										stream_block.reset();

										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;
								case 2 :
									// Java.g:364:17: VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI )
									{
									VOID92=(Token)match(input,VOID,FOLLOW_VOID_in_classScopeDeclarations5765); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_VOID.add(VOID92);

									IDENT93=(Token)match(input,IDENT,FOLLOW_IDENT_in_classScopeDeclarations5767); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_IDENT.add(IDENT93);

									pushFollow(FOLLOW_formalParameterList_in_classScopeDeclarations5769);
									formalParameterList94=formalParameterList();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_formalParameterList.add(formalParameterList94.getTree());
									// Java.g:364:48: ( throwsClause )?
									int alt31=2;
									int LA31_0 = input.LA(1);
									if ( (LA31_0==THROWS) ) {
										alt31=1;
									}
									switch (alt31) {
										case 1 :
											// Java.g:364:48: throwsClause
											{
											pushFollow(FOLLOW_throwsClause_in_classScopeDeclarations5771);
											throwsClause95=throwsClause();
											state._fsp--;
											if (state.failed) return retval;
											if ( state.backtracking==0 ) stream_throwsClause.add(throwsClause95.getTree());
											}
											break;

									}

									// Java.g:364:62: ( block | SEMI )
									int alt32=2;
									int LA32_0 = input.LA(1);
									if ( (LA32_0==LCURLY) ) {
										alt32=1;
									}
									else if ( (LA32_0==SEMI) ) {
										alt32=2;
									}

									else {
										if (state.backtracking>0) {state.failed=true; return retval;}
										NoViableAltException nvae =
											new NoViableAltException("", 32, 0, input);
										throw nvae;
									}

									switch (alt32) {
										case 1 :
											// Java.g:364:63: block
											{
											pushFollow(FOLLOW_block_in_classScopeDeclarations5775);
											block96=block();
											state._fsp--;
											if (state.failed) return retval;
											if ( state.backtracking==0 ) stream_block.add(block96.getTree());
											}
											break;
										case 2 :
											// Java.g:364:71: SEMI
											{
											SEMI97=(Token)match(input,SEMI,FOLLOW_SEMI_in_classScopeDeclarations5779); if (state.failed) return retval; 
											if ( state.backtracking==0 ) stream_SEMI.add(SEMI97);

											}
											break;

									}


									// AST REWRITE
									// elements: genericTypeParameterList, throwsClause, formalParameterList, IDENT, block, modifierList
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 365:17: -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ( block )? )
									{
										// Java.g:365:21: ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ( block )? )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VOID_METHOD_DECL, "VOID_METHOD_DECL"), root_1);
										adaptor.addChild(root_1, stream_modifierList.nextTree());
										// Java.g:365:53: ( genericTypeParameterList )?
										if ( stream_genericTypeParameterList.hasNext() ) {
											adaptor.addChild(root_1, stream_genericTypeParameterList.nextTree());
										}
										stream_genericTypeParameterList.reset();

										adaptor.addChild(root_1, stream_IDENT.nextNode());
										adaptor.addChild(root_1, stream_formalParameterList.nextTree());
										// Java.g:365:105: ( throwsClause )?
										if ( stream_throwsClause.hasNext() ) {
											adaptor.addChild(root_1, stream_throwsClause.nextTree());
										}
										stream_throwsClause.reset();

										// Java.g:365:119: ( block )?
										if ( stream_block.hasNext() ) {
											adaptor.addChild(root_1, stream_block.nextTree());
										}
										stream_block.reset();

										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;
								case 3 :
									// Java.g:366:17: ident= IDENT formalParameterList ( throwsClause )? block
									{
									ident=(Token)match(input,IDENT,FOLLOW_IDENT_in_classScopeDeclarations5838); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_IDENT.add(ident);

									pushFollow(FOLLOW_formalParameterList_in_classScopeDeclarations5840);
									formalParameterList98=formalParameterList();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_formalParameterList.add(formalParameterList98.getTree());
									// Java.g:366:49: ( throwsClause )?
									int alt33=2;
									int LA33_0 = input.LA(1);
									if ( (LA33_0==THROWS) ) {
										alt33=1;
									}
									switch (alt33) {
										case 1 :
											// Java.g:366:49: throwsClause
											{
											pushFollow(FOLLOW_throwsClause_in_classScopeDeclarations5842);
											throwsClause99=throwsClause();
											state._fsp--;
											if (state.failed) return retval;
											if ( state.backtracking==0 ) stream_throwsClause.add(throwsClause99.getTree());
											}
											break;

									}

									pushFollow(FOLLOW_block_in_classScopeDeclarations5845);
									block100=block();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_block.add(block100.getTree());

									// AST REWRITE
									// elements: block, genericTypeParameterList, throwsClause, modifierList, formalParameterList
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 367:17: -> ^( CONSTRUCTOR_DECL[$ident, \"CONSTRUCTOR_DECL\"] modifierList ( genericTypeParameterList )? formalParameterList ( throwsClause )? block )
									{
										// Java.g:367:21: ^( CONSTRUCTOR_DECL[$ident, \"CONSTRUCTOR_DECL\"] modifierList ( genericTypeParameterList )? formalParameterList ( throwsClause )? block )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CONSTRUCTOR_DECL, ident, "CONSTRUCTOR_DECL"), root_1);
										adaptor.addChild(root_1, stream_modifierList.nextTree());
										// Java.g:367:81: ( genericTypeParameterList )?
										if ( stream_genericTypeParameterList.hasNext() ) {
											adaptor.addChild(root_1, stream_genericTypeParameterList.nextTree());
										}
										stream_genericTypeParameterList.reset();

										adaptor.addChild(root_1, stream_formalParameterList.nextTree());
										// Java.g:367:127: ( throwsClause )?
										if ( stream_throwsClause.hasNext() ) {
											adaptor.addChild(root_1, stream_throwsClause.nextTree());
										}
										stream_throwsClause.reset();

										adaptor.addChild(root_1, stream_block.nextTree());
										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;

							}

							}
							break;
						case 2 :
							// Java.g:369:13: type classFieldDeclaratorList SEMI
							{
							pushFollow(FOLLOW_type_in_classScopeDeclarations5909);
							type101=type();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_type.add(type101.getTree());
							pushFollow(FOLLOW_classFieldDeclaratorList_in_classScopeDeclarations5911);
							classFieldDeclaratorList102=classFieldDeclaratorList();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_classFieldDeclaratorList.add(classFieldDeclaratorList102.getTree());
							SEMI103=(Token)match(input,SEMI,FOLLOW_SEMI_in_classScopeDeclarations5913); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SEMI.add(SEMI103);


							// AST REWRITE
							// elements: type, classFieldDeclaratorList, modifierList
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 370:13: -> ^( VAR_DECLARATION modifierList type classFieldDeclaratorList )
							{
								// Java.g:370:17: ^( VAR_DECLARATION modifierList type classFieldDeclaratorList )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECLARATION, "VAR_DECLARATION"), root_1);
								adaptor.addChild(root_1, stream_modifierList.nextTree());
								adaptor.addChild(root_1, stream_type.nextTree());
								adaptor.addChild(root_1, stream_classFieldDeclaratorList.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;
				case 4 :
					// Java.g:372:9: typeDeclaration
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_typeDeclaration_in_classScopeDeclarations5958);
					typeDeclaration104=typeDeclaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, typeDeclaration104.getTree());

					}
					break;
				case 5 :
					// Java.g:373:9: SEMI !
					{
					root_0 = (CommonTree)adaptor.nil();


					SEMI105=(Token)match(input,SEMI,FOLLOW_SEMI_in_classScopeDeclarations5968); if (state.failed) return retval;
					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 25, classScopeDeclarations_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "classScopeDeclarations"


	public static class interfaceScopeDeclarations_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "interfaceScopeDeclarations"
	// Java.g:376:1: interfaceScopeDeclarations : ( modifierList ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ) | VOID IDENT formalParameterList ( throwsClause )? SEMI -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ) ) | type interfaceFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type interfaceFieldDeclaratorList ) ) | typeDeclaration | SEMI !);
	public final JavaParser.interfaceScopeDeclarations_return interfaceScopeDeclarations() throws RecognitionException {
		JavaParser.interfaceScopeDeclarations_return retval = new JavaParser.interfaceScopeDeclarations_return();
		retval.start = input.LT(1);
		int interfaceScopeDeclarations_StartIndex = input.index();

		CommonTree root_0 = null;

		Token IDENT109=null;
		Token SEMI113=null;
		Token VOID114=null;
		Token IDENT115=null;
		Token SEMI118=null;
		Token SEMI121=null;
		Token SEMI123=null;
		ParserRuleReturnScope modifierList106 =null;
		ParserRuleReturnScope genericTypeParameterList107 =null;
		ParserRuleReturnScope type108 =null;
		ParserRuleReturnScope formalParameterList110 =null;
		ParserRuleReturnScope arrayDeclaratorList111 =null;
		ParserRuleReturnScope throwsClause112 =null;
		ParserRuleReturnScope formalParameterList116 =null;
		ParserRuleReturnScope throwsClause117 =null;
		ParserRuleReturnScope type119 =null;
		ParserRuleReturnScope interfaceFieldDeclaratorList120 =null;
		ParserRuleReturnScope typeDeclaration122 =null;

		CommonTree IDENT109_tree=null;
		CommonTree SEMI113_tree=null;
		CommonTree VOID114_tree=null;
		CommonTree IDENT115_tree=null;
		CommonTree SEMI118_tree=null;
		CommonTree SEMI121_tree=null;
		CommonTree SEMI123_tree=null;
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
		RewriteRuleTokenStream stream_VOID=new RewriteRuleTokenStream(adaptor,"token VOID");
		RewriteRuleSubtreeStream stream_throwsClause=new RewriteRuleSubtreeStream(adaptor,"rule throwsClause");
		RewriteRuleSubtreeStream stream_interfaceFieldDeclaratorList=new RewriteRuleSubtreeStream(adaptor,"rule interfaceFieldDeclaratorList");
		RewriteRuleSubtreeStream stream_genericTypeParameterList=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeParameterList");
		RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
		RewriteRuleSubtreeStream stream_modifierList=new RewriteRuleSubtreeStream(adaptor,"rule modifierList");
		RewriteRuleSubtreeStream stream_arrayDeclaratorList=new RewriteRuleSubtreeStream(adaptor,"rule arrayDeclaratorList");
		RewriteRuleSubtreeStream stream_formalParameterList=new RewriteRuleSubtreeStream(adaptor,"rule formalParameterList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 26) ) { return retval; }

			// Java.g:377:5: ( modifierList ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ) | VOID IDENT formalParameterList ( throwsClause )? SEMI -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ) ) | type interfaceFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type interfaceFieldDeclaratorList ) ) | typeDeclaration | SEMI !)
			int alt43=3;
			switch ( input.LA(1) ) {
			case PUBLIC:
				{
				int LA43_1 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 1, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case PROTECTED:
				{
				int LA43_2 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 2, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case PRIVATE:
				{
				int LA43_3 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 3, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case STATIC:
				{
				int LA43_4 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 4, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case ABSTRACT:
				{
				int LA43_5 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 5, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case NATIVE:
				{
				int LA43_6 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 6, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case SYNCHRONIZED:
				{
				int LA43_7 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 7, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case TRANSIENT:
				{
				int LA43_8 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 8, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case VOLATILE:
				{
				int LA43_9 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 9, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case STRICTFP:
				{
				int LA43_10 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 10, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case FINAL:
				{
				int LA43_11 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 11, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case AT:
				{
				int LA43_12 = input.LA(2);
				if ( (synpred51_Java()) ) {
					alt43=1;
				}
				else if ( (synpred52_Java()) ) {
					alt43=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 43, 12, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case DOUBLE:
			case FLOAT:
			case IDENT:
			case INT:
			case LESS_THAN:
			case LONG:
			case SHORT:
			case VOID:
				{
				alt43=1;
				}
				break;
			case CLASS:
			case ENUM:
			case INTERFACE:
				{
				alt43=2;
				}
				break;
			case SEMI:
				{
				alt43=3;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 43, 0, input);
				throw nvae;
			}
			switch (alt43) {
				case 1 :
					// Java.g:377:9: modifierList ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ) | VOID IDENT formalParameterList ( throwsClause )? SEMI -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ) ) | type interfaceFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type interfaceFieldDeclaratorList ) )
					{
					pushFollow(FOLLOW_modifierList_in_interfaceScopeDeclarations5988);
					modifierList106=modifierList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_modifierList.add(modifierList106.getTree());
					// Java.g:378:9: ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ) | VOID IDENT formalParameterList ( throwsClause )? SEMI -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ) ) | type interfaceFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type interfaceFieldDeclaratorList ) )
					int alt42=2;
					switch ( input.LA(1) ) {
					case LESS_THAN:
					case VOID:
						{
						alt42=1;
						}
						break;
					case BOOLEAN:
					case BYTE:
					case CHAR:
					case DOUBLE:
					case FLOAT:
					case INT:
					case LONG:
					case SHORT:
						{
						int LA42_2 = input.LA(2);
						if ( (synpred50_Java()) ) {
							alt42=1;
						}
						else if ( (true) ) {
							alt42=2;
						}

						}
						break;
					case IDENT:
						{
						int LA42_3 = input.LA(2);
						if ( (synpred50_Java()) ) {
							alt42=1;
						}
						else if ( (true) ) {
							alt42=2;
						}

						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 42, 0, input);
						throw nvae;
					}
					switch (alt42) {
						case 1 :
							// Java.g:378:13: ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ) | VOID IDENT formalParameterList ( throwsClause )? SEMI -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ) )
							{
							// Java.g:378:13: ( genericTypeParameterList )?
							int alt37=2;
							int LA37_0 = input.LA(1);
							if ( (LA37_0==LESS_THAN) ) {
								alt37=1;
							}
							switch (alt37) {
								case 1 :
									// Java.g:378:13: genericTypeParameterList
									{
									pushFollow(FOLLOW_genericTypeParameterList_in_interfaceScopeDeclarations6002);
									genericTypeParameterList107=genericTypeParameterList();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_genericTypeParameterList.add(genericTypeParameterList107.getTree());
									}
									break;

							}

							// Java.g:379:13: ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ) | VOID IDENT formalParameterList ( throwsClause )? SEMI -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? ) )
							int alt41=2;
							int LA41_0 = input.LA(1);
							if ( (LA41_0==BOOLEAN||LA41_0==BYTE||LA41_0==CHAR||LA41_0==DOUBLE||LA41_0==FLOAT||LA41_0==IDENT||LA41_0==INT||LA41_0==LONG||LA41_0==SHORT) ) {
								alt41=1;
							}
							else if ( (LA41_0==VOID) ) {
								alt41=2;
							}

							else {
								if (state.backtracking>0) {state.failed=true; return retval;}
								NoViableAltException nvae =
									new NoViableAltException("", 41, 0, input);
								throw nvae;
							}

							switch (alt41) {
								case 1 :
									// Java.g:379:17: type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI
									{
									pushFollow(FOLLOW_type_in_interfaceScopeDeclarations6021);
									type108=type();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_type.add(type108.getTree());
									IDENT109=(Token)match(input,IDENT,FOLLOW_IDENT_in_interfaceScopeDeclarations6023); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_IDENT.add(IDENT109);

									pushFollow(FOLLOW_formalParameterList_in_interfaceScopeDeclarations6025);
									formalParameterList110=formalParameterList();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_formalParameterList.add(formalParameterList110.getTree());
									// Java.g:379:48: ( arrayDeclaratorList )?
									int alt38=2;
									int LA38_0 = input.LA(1);
									if ( (LA38_0==LBRACK) ) {
										alt38=1;
									}
									switch (alt38) {
										case 1 :
											// Java.g:379:48: arrayDeclaratorList
											{
											pushFollow(FOLLOW_arrayDeclaratorList_in_interfaceScopeDeclarations6027);
											arrayDeclaratorList111=arrayDeclaratorList();
											state._fsp--;
											if (state.failed) return retval;
											if ( state.backtracking==0 ) stream_arrayDeclaratorList.add(arrayDeclaratorList111.getTree());
											}
											break;

									}

									// Java.g:379:69: ( throwsClause )?
									int alt39=2;
									int LA39_0 = input.LA(1);
									if ( (LA39_0==THROWS) ) {
										alt39=1;
									}
									switch (alt39) {
										case 1 :
											// Java.g:379:69: throwsClause
											{
											pushFollow(FOLLOW_throwsClause_in_interfaceScopeDeclarations6030);
											throwsClause112=throwsClause();
											state._fsp--;
											if (state.failed) return retval;
											if ( state.backtracking==0 ) stream_throwsClause.add(throwsClause112.getTree());
											}
											break;

									}

									SEMI113=(Token)match(input,SEMI,FOLLOW_SEMI_in_interfaceScopeDeclarations6033); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_SEMI.add(SEMI113);


									// AST REWRITE
									// elements: genericTypeParameterList, type, arrayDeclaratorList, modifierList, throwsClause, IDENT, formalParameterList
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 380:17: -> ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? )
									{
										// Java.g:380:21: ^( FUNCTION_METHOD_DECL modifierList ( genericTypeParameterList )? type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FUNCTION_METHOD_DECL, "FUNCTION_METHOD_DECL"), root_1);
										adaptor.addChild(root_1, stream_modifierList.nextTree());
										// Java.g:380:57: ( genericTypeParameterList )?
										if ( stream_genericTypeParameterList.hasNext() ) {
											adaptor.addChild(root_1, stream_genericTypeParameterList.nextTree());
										}
										stream_genericTypeParameterList.reset();

										adaptor.addChild(root_1, stream_type.nextTree());
										adaptor.addChild(root_1, stream_IDENT.nextNode());
										adaptor.addChild(root_1, stream_formalParameterList.nextTree());
										// Java.g:380:114: ( arrayDeclaratorList )?
										if ( stream_arrayDeclaratorList.hasNext() ) {
											adaptor.addChild(root_1, stream_arrayDeclaratorList.nextTree());
										}
										stream_arrayDeclaratorList.reset();

										// Java.g:380:135: ( throwsClause )?
										if ( stream_throwsClause.hasNext() ) {
											adaptor.addChild(root_1, stream_throwsClause.nextTree());
										}
										stream_throwsClause.reset();

										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;
								case 2 :
									// Java.g:381:17: VOID IDENT formalParameterList ( throwsClause )? SEMI
									{
									VOID114=(Token)match(input,VOID,FOLLOW_VOID_in_interfaceScopeDeclarations6091); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_VOID.add(VOID114);

									IDENT115=(Token)match(input,IDENT,FOLLOW_IDENT_in_interfaceScopeDeclarations6093); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_IDENT.add(IDENT115);

									pushFollow(FOLLOW_formalParameterList_in_interfaceScopeDeclarations6095);
									formalParameterList116=formalParameterList();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_formalParameterList.add(formalParameterList116.getTree());
									// Java.g:381:48: ( throwsClause )?
									int alt40=2;
									int LA40_0 = input.LA(1);
									if ( (LA40_0==THROWS) ) {
										alt40=1;
									}
									switch (alt40) {
										case 1 :
											// Java.g:381:48: throwsClause
											{
											pushFollow(FOLLOW_throwsClause_in_interfaceScopeDeclarations6097);
											throwsClause117=throwsClause();
											state._fsp--;
											if (state.failed) return retval;
											if ( state.backtracking==0 ) stream_throwsClause.add(throwsClause117.getTree());
											}
											break;

									}

									SEMI118=(Token)match(input,SEMI,FOLLOW_SEMI_in_interfaceScopeDeclarations6100); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_SEMI.add(SEMI118);


									// AST REWRITE
									// elements: IDENT, modifierList, throwsClause, genericTypeParameterList, formalParameterList
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 382:17: -> ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? )
									{
										// Java.g:382:21: ^( VOID_METHOD_DECL modifierList ( genericTypeParameterList )? IDENT formalParameterList ( throwsClause )? )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VOID_METHOD_DECL, "VOID_METHOD_DECL"), root_1);
										adaptor.addChild(root_1, stream_modifierList.nextTree());
										// Java.g:382:53: ( genericTypeParameterList )?
										if ( stream_genericTypeParameterList.hasNext() ) {
											adaptor.addChild(root_1, stream_genericTypeParameterList.nextTree());
										}
										stream_genericTypeParameterList.reset();

										adaptor.addChild(root_1, stream_IDENT.nextNode());
										adaptor.addChild(root_1, stream_formalParameterList.nextTree());
										// Java.g:382:105: ( throwsClause )?
										if ( stream_throwsClause.hasNext() ) {
											adaptor.addChild(root_1, stream_throwsClause.nextTree());
										}
										stream_throwsClause.reset();

										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;

							}

							}
							break;
						case 2 :
							// Java.g:384:13: type interfaceFieldDeclaratorList SEMI
							{
							pushFollow(FOLLOW_type_in_interfaceScopeDeclarations6163);
							type119=type();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_type.add(type119.getTree());
							pushFollow(FOLLOW_interfaceFieldDeclaratorList_in_interfaceScopeDeclarations6165);
							interfaceFieldDeclaratorList120=interfaceFieldDeclaratorList();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_interfaceFieldDeclaratorList.add(interfaceFieldDeclaratorList120.getTree());
							SEMI121=(Token)match(input,SEMI,FOLLOW_SEMI_in_interfaceScopeDeclarations6167); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SEMI.add(SEMI121);


							// AST REWRITE
							// elements: interfaceFieldDeclaratorList, type, modifierList
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 385:13: -> ^( VAR_DECLARATION modifierList type interfaceFieldDeclaratorList )
							{
								// Java.g:385:17: ^( VAR_DECLARATION modifierList type interfaceFieldDeclaratorList )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECLARATION, "VAR_DECLARATION"), root_1);
								adaptor.addChild(root_1, stream_modifierList.nextTree());
								adaptor.addChild(root_1, stream_type.nextTree());
								adaptor.addChild(root_1, stream_interfaceFieldDeclaratorList.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;
				case 2 :
					// Java.g:387:9: typeDeclaration
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_typeDeclaration_in_interfaceScopeDeclarations6212);
					typeDeclaration122=typeDeclaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, typeDeclaration122.getTree());

					}
					break;
				case 3 :
					// Java.g:388:9: SEMI !
					{
					root_0 = (CommonTree)adaptor.nil();


					SEMI123=(Token)match(input,SEMI,FOLLOW_SEMI_in_interfaceScopeDeclarations6222); if (state.failed) return retval;
					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 26, interfaceScopeDeclarations_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "interfaceScopeDeclarations"


	public static class classFieldDeclaratorList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "classFieldDeclaratorList"
	// Java.g:391:1: classFieldDeclaratorList : classFieldDeclarator ( COMMA classFieldDeclarator )* -> ^( VAR_DECLARATOR_LIST ( classFieldDeclarator )+ ) ;
	public final JavaParser.classFieldDeclaratorList_return classFieldDeclaratorList() throws RecognitionException {
		JavaParser.classFieldDeclaratorList_return retval = new JavaParser.classFieldDeclaratorList_return();
		retval.start = input.LT(1);
		int classFieldDeclaratorList_StartIndex = input.index();

		CommonTree root_0 = null;

		Token COMMA125=null;
		ParserRuleReturnScope classFieldDeclarator124 =null;
		ParserRuleReturnScope classFieldDeclarator126 =null;

		CommonTree COMMA125_tree=null;
		RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
		RewriteRuleSubtreeStream stream_classFieldDeclarator=new RewriteRuleSubtreeStream(adaptor,"rule classFieldDeclarator");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 27) ) { return retval; }

			// Java.g:392:5: ( classFieldDeclarator ( COMMA classFieldDeclarator )* -> ^( VAR_DECLARATOR_LIST ( classFieldDeclarator )+ ) )
			// Java.g:392:9: classFieldDeclarator ( COMMA classFieldDeclarator )*
			{
			pushFollow(FOLLOW_classFieldDeclarator_in_classFieldDeclaratorList6242);
			classFieldDeclarator124=classFieldDeclarator();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_classFieldDeclarator.add(classFieldDeclarator124.getTree());
			// Java.g:392:30: ( COMMA classFieldDeclarator )*
			loop44:
			while (true) {
				int alt44=2;
				int LA44_0 = input.LA(1);
				if ( (LA44_0==COMMA) ) {
					alt44=1;
				}

				switch (alt44) {
				case 1 :
					// Java.g:392:31: COMMA classFieldDeclarator
					{
					COMMA125=(Token)match(input,COMMA,FOLLOW_COMMA_in_classFieldDeclaratorList6245); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_COMMA.add(COMMA125);

					pushFollow(FOLLOW_classFieldDeclarator_in_classFieldDeclaratorList6247);
					classFieldDeclarator126=classFieldDeclarator();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_classFieldDeclarator.add(classFieldDeclarator126.getTree());
					}
					break;

				default :
					break loop44;
				}
			}


			// AST REWRITE
			// elements: classFieldDeclarator
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 393:9: -> ^( VAR_DECLARATOR_LIST ( classFieldDeclarator )+ )
			{
				// Java.g:393:13: ^( VAR_DECLARATOR_LIST ( classFieldDeclarator )+ )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECLARATOR_LIST, "VAR_DECLARATOR_LIST"), root_1);
				if ( !(stream_classFieldDeclarator.hasNext()) ) {
					throw new RewriteEarlyExitException();
				}
				while ( stream_classFieldDeclarator.hasNext() ) {
					adaptor.addChild(root_1, stream_classFieldDeclarator.nextTree());
				}
				stream_classFieldDeclarator.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 27, classFieldDeclaratorList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "classFieldDeclaratorList"


	public static class classFieldDeclarator_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "classFieldDeclarator"
	// Java.g:396:1: classFieldDeclarator : variableDeclaratorId ( ASSIGN variableInitializer )? -> ^( VAR_DECLARATOR variableDeclaratorId ( variableInitializer )? ) ;
	public final JavaParser.classFieldDeclarator_return classFieldDeclarator() throws RecognitionException {
		JavaParser.classFieldDeclarator_return retval = new JavaParser.classFieldDeclarator_return();
		retval.start = input.LT(1);
		int classFieldDeclarator_StartIndex = input.index();

		CommonTree root_0 = null;

		Token ASSIGN128=null;
		ParserRuleReturnScope variableDeclaratorId127 =null;
		ParserRuleReturnScope variableInitializer129 =null;

		CommonTree ASSIGN128_tree=null;
		RewriteRuleTokenStream stream_ASSIGN=new RewriteRuleTokenStream(adaptor,"token ASSIGN");
		RewriteRuleSubtreeStream stream_variableInitializer=new RewriteRuleSubtreeStream(adaptor,"rule variableInitializer");
		RewriteRuleSubtreeStream stream_variableDeclaratorId=new RewriteRuleSubtreeStream(adaptor,"rule variableDeclaratorId");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 28) ) { return retval; }

			// Java.g:397:5: ( variableDeclaratorId ( ASSIGN variableInitializer )? -> ^( VAR_DECLARATOR variableDeclaratorId ( variableInitializer )? ) )
			// Java.g:397:9: variableDeclaratorId ( ASSIGN variableInitializer )?
			{
			pushFollow(FOLLOW_variableDeclaratorId_in_classFieldDeclarator6286);
			variableDeclaratorId127=variableDeclaratorId();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_variableDeclaratorId.add(variableDeclaratorId127.getTree());
			// Java.g:397:30: ( ASSIGN variableInitializer )?
			int alt45=2;
			int LA45_0 = input.LA(1);
			if ( (LA45_0==ASSIGN) ) {
				alt45=1;
			}
			switch (alt45) {
				case 1 :
					// Java.g:397:31: ASSIGN variableInitializer
					{
					ASSIGN128=(Token)match(input,ASSIGN,FOLLOW_ASSIGN_in_classFieldDeclarator6289); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_ASSIGN.add(ASSIGN128);

					pushFollow(FOLLOW_variableInitializer_in_classFieldDeclarator6291);
					variableInitializer129=variableInitializer();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_variableInitializer.add(variableInitializer129.getTree());
					}
					break;

			}


			// AST REWRITE
			// elements: variableInitializer, variableDeclaratorId
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 398:9: -> ^( VAR_DECLARATOR variableDeclaratorId ( variableInitializer )? )
			{
				// Java.g:398:13: ^( VAR_DECLARATOR variableDeclaratorId ( variableInitializer )? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECLARATOR, "VAR_DECLARATOR"), root_1);
				adaptor.addChild(root_1, stream_variableDeclaratorId.nextTree());
				// Java.g:398:51: ( variableInitializer )?
				if ( stream_variableInitializer.hasNext() ) {
					adaptor.addChild(root_1, stream_variableInitializer.nextTree());
				}
				stream_variableInitializer.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 28, classFieldDeclarator_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "classFieldDeclarator"


	public static class interfaceFieldDeclaratorList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "interfaceFieldDeclaratorList"
	// Java.g:401:1: interfaceFieldDeclaratorList : interfaceFieldDeclarator ( COMMA interfaceFieldDeclarator )* -> ^( VAR_DECLARATOR_LIST ( interfaceFieldDeclarator )+ ) ;
	public final JavaParser.interfaceFieldDeclaratorList_return interfaceFieldDeclaratorList() throws RecognitionException {
		JavaParser.interfaceFieldDeclaratorList_return retval = new JavaParser.interfaceFieldDeclaratorList_return();
		retval.start = input.LT(1);
		int interfaceFieldDeclaratorList_StartIndex = input.index();

		CommonTree root_0 = null;

		Token COMMA131=null;
		ParserRuleReturnScope interfaceFieldDeclarator130 =null;
		ParserRuleReturnScope interfaceFieldDeclarator132 =null;

		CommonTree COMMA131_tree=null;
		RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
		RewriteRuleSubtreeStream stream_interfaceFieldDeclarator=new RewriteRuleSubtreeStream(adaptor,"rule interfaceFieldDeclarator");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 29) ) { return retval; }

			// Java.g:402:5: ( interfaceFieldDeclarator ( COMMA interfaceFieldDeclarator )* -> ^( VAR_DECLARATOR_LIST ( interfaceFieldDeclarator )+ ) )
			// Java.g:402:9: interfaceFieldDeclarator ( COMMA interfaceFieldDeclarator )*
			{
			pushFollow(FOLLOW_interfaceFieldDeclarator_in_interfaceFieldDeclaratorList6332);
			interfaceFieldDeclarator130=interfaceFieldDeclarator();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_interfaceFieldDeclarator.add(interfaceFieldDeclarator130.getTree());
			// Java.g:402:34: ( COMMA interfaceFieldDeclarator )*
			loop46:
			while (true) {
				int alt46=2;
				int LA46_0 = input.LA(1);
				if ( (LA46_0==COMMA) ) {
					alt46=1;
				}

				switch (alt46) {
				case 1 :
					// Java.g:402:35: COMMA interfaceFieldDeclarator
					{
					COMMA131=(Token)match(input,COMMA,FOLLOW_COMMA_in_interfaceFieldDeclaratorList6335); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_COMMA.add(COMMA131);

					pushFollow(FOLLOW_interfaceFieldDeclarator_in_interfaceFieldDeclaratorList6337);
					interfaceFieldDeclarator132=interfaceFieldDeclarator();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_interfaceFieldDeclarator.add(interfaceFieldDeclarator132.getTree());
					}
					break;

				default :
					break loop46;
				}
			}


			// AST REWRITE
			// elements: interfaceFieldDeclarator
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 403:9: -> ^( VAR_DECLARATOR_LIST ( interfaceFieldDeclarator )+ )
			{
				// Java.g:403:13: ^( VAR_DECLARATOR_LIST ( interfaceFieldDeclarator )+ )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECLARATOR_LIST, "VAR_DECLARATOR_LIST"), root_1);
				if ( !(stream_interfaceFieldDeclarator.hasNext()) ) {
					throw new RewriteEarlyExitException();
				}
				while ( stream_interfaceFieldDeclarator.hasNext() ) {
					adaptor.addChild(root_1, stream_interfaceFieldDeclarator.nextTree());
				}
				stream_interfaceFieldDeclarator.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 29, interfaceFieldDeclaratorList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "interfaceFieldDeclaratorList"


	public static class interfaceFieldDeclarator_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "interfaceFieldDeclarator"
	// Java.g:406:1: interfaceFieldDeclarator : variableDeclaratorId ASSIGN variableInitializer -> ^( VAR_DECLARATOR variableDeclaratorId variableInitializer ) ;
	public final JavaParser.interfaceFieldDeclarator_return interfaceFieldDeclarator() throws RecognitionException {
		JavaParser.interfaceFieldDeclarator_return retval = new JavaParser.interfaceFieldDeclarator_return();
		retval.start = input.LT(1);
		int interfaceFieldDeclarator_StartIndex = input.index();

		CommonTree root_0 = null;

		Token ASSIGN134=null;
		ParserRuleReturnScope variableDeclaratorId133 =null;
		ParserRuleReturnScope variableInitializer135 =null;

		CommonTree ASSIGN134_tree=null;
		RewriteRuleTokenStream stream_ASSIGN=new RewriteRuleTokenStream(adaptor,"token ASSIGN");
		RewriteRuleSubtreeStream stream_variableInitializer=new RewriteRuleSubtreeStream(adaptor,"rule variableInitializer");
		RewriteRuleSubtreeStream stream_variableDeclaratorId=new RewriteRuleSubtreeStream(adaptor,"rule variableDeclaratorId");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 30) ) { return retval; }

			// Java.g:407:5: ( variableDeclaratorId ASSIGN variableInitializer -> ^( VAR_DECLARATOR variableDeclaratorId variableInitializer ) )
			// Java.g:407:9: variableDeclaratorId ASSIGN variableInitializer
			{
			pushFollow(FOLLOW_variableDeclaratorId_in_interfaceFieldDeclarator6376);
			variableDeclaratorId133=variableDeclaratorId();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_variableDeclaratorId.add(variableDeclaratorId133.getTree());
			ASSIGN134=(Token)match(input,ASSIGN,FOLLOW_ASSIGN_in_interfaceFieldDeclarator6378); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_ASSIGN.add(ASSIGN134);

			pushFollow(FOLLOW_variableInitializer_in_interfaceFieldDeclarator6380);
			variableInitializer135=variableInitializer();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_variableInitializer.add(variableInitializer135.getTree());

			// AST REWRITE
			// elements: variableDeclaratorId, variableInitializer
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 408:9: -> ^( VAR_DECLARATOR variableDeclaratorId variableInitializer )
			{
				// Java.g:408:13: ^( VAR_DECLARATOR variableDeclaratorId variableInitializer )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECLARATOR, "VAR_DECLARATOR"), root_1);
				adaptor.addChild(root_1, stream_variableDeclaratorId.nextTree());
				adaptor.addChild(root_1, stream_variableInitializer.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 30, interfaceFieldDeclarator_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "interfaceFieldDeclarator"


	public static class variableDeclaratorId_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "variableDeclaratorId"
	// Java.g:411:1: variableDeclaratorId : IDENT ^ ( arrayDeclaratorList )? ;
	public final JavaParser.variableDeclaratorId_return variableDeclaratorId() throws RecognitionException {
		JavaParser.variableDeclaratorId_return retval = new JavaParser.variableDeclaratorId_return();
		retval.start = input.LT(1);
		int variableDeclaratorId_StartIndex = input.index();

		CommonTree root_0 = null;

		Token IDENT136=null;
		ParserRuleReturnScope arrayDeclaratorList137 =null;

		CommonTree IDENT136_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 31) ) { return retval; }

			// Java.g:412:5: ( IDENT ^ ( arrayDeclaratorList )? )
			// Java.g:412:9: IDENT ^ ( arrayDeclaratorList )?
			{
			root_0 = (CommonTree)adaptor.nil();


			IDENT136=(Token)match(input,IDENT,FOLLOW_IDENT_in_variableDeclaratorId6418); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			IDENT136_tree = (CommonTree)adaptor.create(IDENT136);
			root_0 = (CommonTree)adaptor.becomeRoot(IDENT136_tree, root_0);
			}

			// Java.g:412:16: ( arrayDeclaratorList )?
			int alt47=2;
			int LA47_0 = input.LA(1);
			if ( (LA47_0==LBRACK) ) {
				alt47=1;
			}
			switch (alt47) {
				case 1 :
					// Java.g:412:16: arrayDeclaratorList
					{
					pushFollow(FOLLOW_arrayDeclaratorList_in_variableDeclaratorId6421);
					arrayDeclaratorList137=arrayDeclaratorList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arrayDeclaratorList137.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 31, variableDeclaratorId_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "variableDeclaratorId"


	public static class variableInitializer_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "variableInitializer"
	// Java.g:415:1: variableInitializer : ( arrayInitializer | expression );
	public final JavaParser.variableInitializer_return variableInitializer() throws RecognitionException {
		JavaParser.variableInitializer_return retval = new JavaParser.variableInitializer_return();
		retval.start = input.LT(1);
		int variableInitializer_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope arrayInitializer138 =null;
		ParserRuleReturnScope expression139 =null;


		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 32) ) { return retval; }

			// Java.g:416:5: ( arrayInitializer | expression )
			int alt48=2;
			int LA48_0 = input.LA(1);
			if ( (LA48_0==LCURLY) ) {
				alt48=1;
			}
			else if ( (LA48_0==BOOLEAN||LA48_0==BYTE||(LA48_0 >= CHAR && LA48_0 <= CHARACTER_LITERAL)||(LA48_0 >= DEC && LA48_0 <= DECIMAL_LITERAL)||LA48_0==DOUBLE||LA48_0==FALSE||(LA48_0 >= FLOAT && LA48_0 <= FLOATING_POINT_LITERAL)||(LA48_0 >= HEX_LITERAL && LA48_0 <= IDENT)||LA48_0==INC||LA48_0==INT||LA48_0==LESS_THAN||LA48_0==LOGICAL_NOT||(LA48_0 >= LONG && LA48_0 <= LPAREN)||LA48_0==MINUS||LA48_0==NEW||LA48_0==NOT||LA48_0==NULL||LA48_0==OCTAL_LITERAL||LA48_0==PLUS||LA48_0==SHORT||(LA48_0 >= STRING_LITERAL && LA48_0 <= SUPER)||LA48_0==THIS||LA48_0==TRUE||LA48_0==VOID) ) {
				alt48=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 48, 0, input);
				throw nvae;
			}

			switch (alt48) {
				case 1 :
					// Java.g:416:9: arrayInitializer
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_arrayInitializer_in_variableInitializer6441);
					arrayInitializer138=arrayInitializer();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arrayInitializer138.getTree());

					}
					break;
				case 2 :
					// Java.g:417:9: expression
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_expression_in_variableInitializer6451);
					expression139=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, expression139.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 32, variableInitializer_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "variableInitializer"


	public static class arrayDeclarator_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "arrayDeclarator"
	// Java.g:420:1: arrayDeclarator : LBRACK RBRACK -> ^( ARRAY_DECLARATOR ) ;
	public final JavaParser.arrayDeclarator_return arrayDeclarator() throws RecognitionException {
		JavaParser.arrayDeclarator_return retval = new JavaParser.arrayDeclarator_return();
		retval.start = input.LT(1);
		int arrayDeclarator_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LBRACK140=null;
		Token RBRACK141=null;

		CommonTree LBRACK140_tree=null;
		CommonTree RBRACK141_tree=null;
		RewriteRuleTokenStream stream_RBRACK=new RewriteRuleTokenStream(adaptor,"token RBRACK");
		RewriteRuleTokenStream stream_LBRACK=new RewriteRuleTokenStream(adaptor,"token LBRACK");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 33) ) { return retval; }

			// Java.g:421:5: ( LBRACK RBRACK -> ^( ARRAY_DECLARATOR ) )
			// Java.g:421:9: LBRACK RBRACK
			{
			LBRACK140=(Token)match(input,LBRACK,FOLLOW_LBRACK_in_arrayDeclarator6470); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LBRACK.add(LBRACK140);

			RBRACK141=(Token)match(input,RBRACK,FOLLOW_RBRACK_in_arrayDeclarator6472); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RBRACK.add(RBRACK141);


			// AST REWRITE
			// elements: 
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 422:9: -> ^( ARRAY_DECLARATOR )
			{
				// Java.g:422:13: ^( ARRAY_DECLARATOR )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ARRAY_DECLARATOR, "ARRAY_DECLARATOR"), root_1);
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 33, arrayDeclarator_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "arrayDeclarator"


	public static class arrayDeclaratorList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "arrayDeclaratorList"
	// Java.g:425:1: arrayDeclaratorList : ( arrayDeclarator )+ -> ^( ARRAY_DECLARATOR_LIST ( arrayDeclarator )+ ) ;
	public final JavaParser.arrayDeclaratorList_return arrayDeclaratorList() throws RecognitionException {
		JavaParser.arrayDeclaratorList_return retval = new JavaParser.arrayDeclaratorList_return();
		retval.start = input.LT(1);
		int arrayDeclaratorList_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope arrayDeclarator142 =null;

		RewriteRuleSubtreeStream stream_arrayDeclarator=new RewriteRuleSubtreeStream(adaptor,"rule arrayDeclarator");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 34) ) { return retval; }

			// Java.g:426:5: ( ( arrayDeclarator )+ -> ^( ARRAY_DECLARATOR_LIST ( arrayDeclarator )+ ) )
			// Java.g:426:9: ( arrayDeclarator )+
			{
			// Java.g:426:9: ( arrayDeclarator )+
			int cnt49=0;
			loop49:
			while (true) {
				int alt49=2;
				int LA49_0 = input.LA(1);
				if ( (LA49_0==LBRACK) ) {
					int LA49_2 = input.LA(2);
					if ( (synpred58_Java()) ) {
						alt49=1;
					}

				}

				switch (alt49) {
				case 1 :
					// Java.g:426:9: arrayDeclarator
					{
					pushFollow(FOLLOW_arrayDeclarator_in_arrayDeclaratorList6506);
					arrayDeclarator142=arrayDeclarator();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_arrayDeclarator.add(arrayDeclarator142.getTree());
					}
					break;

				default :
					if ( cnt49 >= 1 ) break loop49;
					if (state.backtracking>0) {state.failed=true; return retval;}
					EarlyExitException eee = new EarlyExitException(49, input);
					throw eee;
				}
				cnt49++;
			}


			// AST REWRITE
			// elements: arrayDeclarator
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 427:9: -> ^( ARRAY_DECLARATOR_LIST ( arrayDeclarator )+ )
			{
				// Java.g:427:13: ^( ARRAY_DECLARATOR_LIST ( arrayDeclarator )+ )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ARRAY_DECLARATOR_LIST, "ARRAY_DECLARATOR_LIST"), root_1);
				if ( !(stream_arrayDeclarator.hasNext()) ) {
					throw new RewriteEarlyExitException();
				}
				while ( stream_arrayDeclarator.hasNext() ) {
					adaptor.addChild(root_1, stream_arrayDeclarator.nextTree());
				}
				stream_arrayDeclarator.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 34, arrayDeclaratorList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "arrayDeclaratorList"


	public static class arrayInitializer_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "arrayInitializer"
	// Java.g:430:1: arrayInitializer : LCURLY ( variableInitializer ( COMMA variableInitializer )* ( COMMA )? )? RCURLY -> ^( ARRAY_INITIALIZER[$LCURLY, \"ARRAY_INITIALIZER\"] ( variableInitializer )* ) ;
	public final JavaParser.arrayInitializer_return arrayInitializer() throws RecognitionException {
		JavaParser.arrayInitializer_return retval = new JavaParser.arrayInitializer_return();
		retval.start = input.LT(1);
		int arrayInitializer_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LCURLY143=null;
		Token COMMA145=null;
		Token COMMA147=null;
		Token RCURLY148=null;
		ParserRuleReturnScope variableInitializer144 =null;
		ParserRuleReturnScope variableInitializer146 =null;

		CommonTree LCURLY143_tree=null;
		CommonTree COMMA145_tree=null;
		CommonTree COMMA147_tree=null;
		CommonTree RCURLY148_tree=null;
		RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
		RewriteRuleTokenStream stream_LCURLY=new RewriteRuleTokenStream(adaptor,"token LCURLY");
		RewriteRuleTokenStream stream_RCURLY=new RewriteRuleTokenStream(adaptor,"token RCURLY");
		RewriteRuleSubtreeStream stream_variableInitializer=new RewriteRuleSubtreeStream(adaptor,"rule variableInitializer");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 35) ) { return retval; }

			// Java.g:431:5: ( LCURLY ( variableInitializer ( COMMA variableInitializer )* ( COMMA )? )? RCURLY -> ^( ARRAY_INITIALIZER[$LCURLY, \"ARRAY_INITIALIZER\"] ( variableInitializer )* ) )
			// Java.g:431:9: LCURLY ( variableInitializer ( COMMA variableInitializer )* ( COMMA )? )? RCURLY
			{
			LCURLY143=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_arrayInitializer6544); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LCURLY.add(LCURLY143);

			// Java.g:431:16: ( variableInitializer ( COMMA variableInitializer )* ( COMMA )? )?
			int alt52=2;
			int LA52_0 = input.LA(1);
			if ( (LA52_0==BOOLEAN||LA52_0==BYTE||(LA52_0 >= CHAR && LA52_0 <= CHARACTER_LITERAL)||(LA52_0 >= DEC && LA52_0 <= DECIMAL_LITERAL)||LA52_0==DOUBLE||LA52_0==FALSE||(LA52_0 >= FLOAT && LA52_0 <= FLOATING_POINT_LITERAL)||(LA52_0 >= HEX_LITERAL && LA52_0 <= IDENT)||LA52_0==INC||LA52_0==INT||LA52_0==LCURLY||LA52_0==LESS_THAN||LA52_0==LOGICAL_NOT||(LA52_0 >= LONG && LA52_0 <= LPAREN)||LA52_0==MINUS||LA52_0==NEW||LA52_0==NOT||LA52_0==NULL||LA52_0==OCTAL_LITERAL||LA52_0==PLUS||LA52_0==SHORT||(LA52_0 >= STRING_LITERAL && LA52_0 <= SUPER)||LA52_0==THIS||LA52_0==TRUE||LA52_0==VOID) ) {
				alt52=1;
			}
			switch (alt52) {
				case 1 :
					// Java.g:431:17: variableInitializer ( COMMA variableInitializer )* ( COMMA )?
					{
					pushFollow(FOLLOW_variableInitializer_in_arrayInitializer6547);
					variableInitializer144=variableInitializer();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_variableInitializer.add(variableInitializer144.getTree());
					// Java.g:431:37: ( COMMA variableInitializer )*
					loop50:
					while (true) {
						int alt50=2;
						int LA50_0 = input.LA(1);
						if ( (LA50_0==COMMA) ) {
							int LA50_1 = input.LA(2);
							if ( (LA50_1==BOOLEAN||LA50_1==BYTE||(LA50_1 >= CHAR && LA50_1 <= CHARACTER_LITERAL)||(LA50_1 >= DEC && LA50_1 <= DECIMAL_LITERAL)||LA50_1==DOUBLE||LA50_1==FALSE||(LA50_1 >= FLOAT && LA50_1 <= FLOATING_POINT_LITERAL)||(LA50_1 >= HEX_LITERAL && LA50_1 <= IDENT)||LA50_1==INC||LA50_1==INT||LA50_1==LCURLY||LA50_1==LESS_THAN||LA50_1==LOGICAL_NOT||(LA50_1 >= LONG && LA50_1 <= LPAREN)||LA50_1==MINUS||LA50_1==NEW||LA50_1==NOT||LA50_1==NULL||LA50_1==OCTAL_LITERAL||LA50_1==PLUS||LA50_1==SHORT||(LA50_1 >= STRING_LITERAL && LA50_1 <= SUPER)||LA50_1==THIS||LA50_1==TRUE||LA50_1==VOID) ) {
								alt50=1;
							}

						}

						switch (alt50) {
						case 1 :
							// Java.g:431:38: COMMA variableInitializer
							{
							COMMA145=(Token)match(input,COMMA,FOLLOW_COMMA_in_arrayInitializer6550); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_COMMA.add(COMMA145);

							pushFollow(FOLLOW_variableInitializer_in_arrayInitializer6552);
							variableInitializer146=variableInitializer();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_variableInitializer.add(variableInitializer146.getTree());
							}
							break;

						default :
							break loop50;
						}
					}

					// Java.g:431:66: ( COMMA )?
					int alt51=2;
					int LA51_0 = input.LA(1);
					if ( (LA51_0==COMMA) ) {
						alt51=1;
					}
					switch (alt51) {
						case 1 :
							// Java.g:431:66: COMMA
							{
							COMMA147=(Token)match(input,COMMA,FOLLOW_COMMA_in_arrayInitializer6556); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_COMMA.add(COMMA147);

							}
							break;

					}

					}
					break;

			}

			RCURLY148=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_arrayInitializer6561); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RCURLY.add(RCURLY148);


			// AST REWRITE
			// elements: variableInitializer
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 432:9: -> ^( ARRAY_INITIALIZER[$LCURLY, \"ARRAY_INITIALIZER\"] ( variableInitializer )* )
			{
				// Java.g:432:13: ^( ARRAY_INITIALIZER[$LCURLY, \"ARRAY_INITIALIZER\"] ( variableInitializer )* )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ARRAY_INITIALIZER, LCURLY143, "ARRAY_INITIALIZER"), root_1);
				// Java.g:432:63: ( variableInitializer )*
				while ( stream_variableInitializer.hasNext() ) {
					adaptor.addChild(root_1, stream_variableInitializer.nextTree());
				}
				stream_variableInitializer.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 35, arrayInitializer_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "arrayInitializer"


	public static class throwsClause_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "throwsClause"
	// Java.g:435:1: throwsClause : THROWS qualifiedIdentList -> ^( THROWS_CLAUSE[$THROWS, \"THROWS_CLAUSE\"] qualifiedIdentList ) ;
	public final JavaParser.throwsClause_return throwsClause() throws RecognitionException {
		JavaParser.throwsClause_return retval = new JavaParser.throwsClause_return();
		retval.start = input.LT(1);
		int throwsClause_StartIndex = input.index();

		CommonTree root_0 = null;

		Token THROWS149=null;
		ParserRuleReturnScope qualifiedIdentList150 =null;

		CommonTree THROWS149_tree=null;
		RewriteRuleTokenStream stream_THROWS=new RewriteRuleTokenStream(adaptor,"token THROWS");
		RewriteRuleSubtreeStream stream_qualifiedIdentList=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedIdentList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 36) ) { return retval; }

			// Java.g:436:5: ( THROWS qualifiedIdentList -> ^( THROWS_CLAUSE[$THROWS, \"THROWS_CLAUSE\"] qualifiedIdentList ) )
			// Java.g:436:9: THROWS qualifiedIdentList
			{
			THROWS149=(Token)match(input,THROWS,FOLLOW_THROWS_in_throwsClause6599); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_THROWS.add(THROWS149);

			pushFollow(FOLLOW_qualifiedIdentList_in_throwsClause6601);
			qualifiedIdentList150=qualifiedIdentList();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_qualifiedIdentList.add(qualifiedIdentList150.getTree());

			// AST REWRITE
			// elements: qualifiedIdentList
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 437:9: -> ^( THROWS_CLAUSE[$THROWS, \"THROWS_CLAUSE\"] qualifiedIdentList )
			{
				// Java.g:437:13: ^( THROWS_CLAUSE[$THROWS, \"THROWS_CLAUSE\"] qualifiedIdentList )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(THROWS_CLAUSE, THROWS149, "THROWS_CLAUSE"), root_1);
				adaptor.addChild(root_1, stream_qualifiedIdentList.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 36, throwsClause_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "throwsClause"


	public static class modifierList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "modifierList"
	// Java.g:440:1: modifierList : ( modifier )* -> ^( MODIFIER_LIST NIL ( modifier )* ) ;
	public final JavaParser.modifierList_return modifierList() throws RecognitionException {
		JavaParser.modifierList_return retval = new JavaParser.modifierList_return();
		retval.start = input.LT(1);
		int modifierList_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope modifier151 =null;

		RewriteRuleSubtreeStream stream_modifier=new RewriteRuleSubtreeStream(adaptor,"rule modifier");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 37) ) { return retval; }

			// Java.g:441:5: ( ( modifier )* -> ^( MODIFIER_LIST NIL ( modifier )* ) )
			// Java.g:441:9: ( modifier )*
			{
			// Java.g:441:9: ( modifier )*
			loop53:
			while (true) {
				int alt53=2;
				int LA53_0 = input.LA(1);
				if ( (LA53_0==AT) ) {
					int LA53_2 = input.LA(2);
					if ( (LA53_2==IDENT) ) {
						alt53=1;
					}

				}
				else if ( (LA53_0==ABSTRACT||LA53_0==FINAL||LA53_0==NATIVE||(LA53_0 >= PRIVATE && LA53_0 <= PUBLIC)||LA53_0==STATIC||LA53_0==STRICTFP||LA53_0==SYNCHRONIZED||LA53_0==TRANSIENT||LA53_0==VOLATILE) ) {
					alt53=1;
				}

				switch (alt53) {
				case 1 :
					// Java.g:441:9: modifier
					{
					pushFollow(FOLLOW_modifier_in_modifierList6638);
					modifier151=modifier();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_modifier.add(modifier151.getTree());
					}
					break;

				default :
					break loop53;
				}
			}


			// AST REWRITE
			// elements: modifier
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 442:9: -> ^( MODIFIER_LIST NIL ( modifier )* )
			{
				// Java.g:442:13: ^( MODIFIER_LIST NIL ( modifier )* )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(MODIFIER_LIST, "MODIFIER_LIST"), root_1);
				adaptor.addChild(root_1, (CommonTree)adaptor.create(NIL, "NIL"));
				// Java.g:442:33: ( modifier )*
				while ( stream_modifier.hasNext() ) {
					adaptor.addChild(root_1, stream_modifier.nextTree());
				}
				stream_modifier.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 37, modifierList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "modifierList"


	public static class modifier_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "modifier"
	// Java.g:445:1: modifier : ( PUBLIC | PROTECTED | PRIVATE | STATIC | ABSTRACT | NATIVE | SYNCHRONIZED | TRANSIENT | VOLATILE | STRICTFP | localModifier );
	public final JavaParser.modifier_return modifier() throws RecognitionException {
		JavaParser.modifier_return retval = new JavaParser.modifier_return();
		retval.start = input.LT(1);
		int modifier_StartIndex = input.index();

		CommonTree root_0 = null;

		Token PUBLIC152=null;
		Token PROTECTED153=null;
		Token PRIVATE154=null;
		Token STATIC155=null;
		Token ABSTRACT156=null;
		Token NATIVE157=null;
		Token SYNCHRONIZED158=null;
		Token TRANSIENT159=null;
		Token VOLATILE160=null;
		Token STRICTFP161=null;
		ParserRuleReturnScope localModifier162 =null;

		CommonTree PUBLIC152_tree=null;
		CommonTree PROTECTED153_tree=null;
		CommonTree PRIVATE154_tree=null;
		CommonTree STATIC155_tree=null;
		CommonTree ABSTRACT156_tree=null;
		CommonTree NATIVE157_tree=null;
		CommonTree SYNCHRONIZED158_tree=null;
		CommonTree TRANSIENT159_tree=null;
		CommonTree VOLATILE160_tree=null;
		CommonTree STRICTFP161_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 38) ) { return retval; }

			// Java.g:446:5: ( PUBLIC | PROTECTED | PRIVATE | STATIC | ABSTRACT | NATIVE | SYNCHRONIZED | TRANSIENT | VOLATILE | STRICTFP | localModifier )
			int alt54=11;
			switch ( input.LA(1) ) {
			case PUBLIC:
				{
				alt54=1;
				}
				break;
			case PROTECTED:
				{
				alt54=2;
				}
				break;
			case PRIVATE:
				{
				alt54=3;
				}
				break;
			case STATIC:
				{
				alt54=4;
				}
				break;
			case ABSTRACT:
				{
				alt54=5;
				}
				break;
			case NATIVE:
				{
				alt54=6;
				}
				break;
			case SYNCHRONIZED:
				{
				alt54=7;
				}
				break;
			case TRANSIENT:
				{
				alt54=8;
				}
				break;
			case VOLATILE:
				{
				alt54=9;
				}
				break;
			case STRICTFP:
				{
				alt54=10;
				}
				break;
			case AT:
			case FINAL:
				{
				alt54=11;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 54, 0, input);
				throw nvae;
			}
			switch (alt54) {
				case 1 :
					// Java.g:446:9: PUBLIC
					{
					root_0 = (CommonTree)adaptor.nil();


					PUBLIC152=(Token)match(input,PUBLIC,FOLLOW_PUBLIC_in_modifier6678); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					PUBLIC152_tree = (CommonTree)adaptor.create(PUBLIC152);
					adaptor.addChild(root_0, PUBLIC152_tree);
					}

					}
					break;
				case 2 :
					// Java.g:447:9: PROTECTED
					{
					root_0 = (CommonTree)adaptor.nil();


					PROTECTED153=(Token)match(input,PROTECTED,FOLLOW_PROTECTED_in_modifier6688); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					PROTECTED153_tree = (CommonTree)adaptor.create(PROTECTED153);
					adaptor.addChild(root_0, PROTECTED153_tree);
					}

					}
					break;
				case 3 :
					// Java.g:448:9: PRIVATE
					{
					root_0 = (CommonTree)adaptor.nil();


					PRIVATE154=(Token)match(input,PRIVATE,FOLLOW_PRIVATE_in_modifier6698); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					PRIVATE154_tree = (CommonTree)adaptor.create(PRIVATE154);
					adaptor.addChild(root_0, PRIVATE154_tree);
					}

					}
					break;
				case 4 :
					// Java.g:449:9: STATIC
					{
					root_0 = (CommonTree)adaptor.nil();


					STATIC155=(Token)match(input,STATIC,FOLLOW_STATIC_in_modifier6708); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					STATIC155_tree = (CommonTree)adaptor.create(STATIC155);
					adaptor.addChild(root_0, STATIC155_tree);
					}

					}
					break;
				case 5 :
					// Java.g:450:9: ABSTRACT
					{
					root_0 = (CommonTree)adaptor.nil();


					ABSTRACT156=(Token)match(input,ABSTRACT,FOLLOW_ABSTRACT_in_modifier6718); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					ABSTRACT156_tree = (CommonTree)adaptor.create(ABSTRACT156);
					adaptor.addChild(root_0, ABSTRACT156_tree);
					}

					}
					break;
				case 6 :
					// Java.g:451:9: NATIVE
					{
					root_0 = (CommonTree)adaptor.nil();


					NATIVE157=(Token)match(input,NATIVE,FOLLOW_NATIVE_in_modifier6728); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					NATIVE157_tree = (CommonTree)adaptor.create(NATIVE157);
					adaptor.addChild(root_0, NATIVE157_tree);
					}

					}
					break;
				case 7 :
					// Java.g:452:9: SYNCHRONIZED
					{
					root_0 = (CommonTree)adaptor.nil();


					SYNCHRONIZED158=(Token)match(input,SYNCHRONIZED,FOLLOW_SYNCHRONIZED_in_modifier6738); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					SYNCHRONIZED158_tree = (CommonTree)adaptor.create(SYNCHRONIZED158);
					adaptor.addChild(root_0, SYNCHRONIZED158_tree);
					}

					}
					break;
				case 8 :
					// Java.g:453:9: TRANSIENT
					{
					root_0 = (CommonTree)adaptor.nil();


					TRANSIENT159=(Token)match(input,TRANSIENT,FOLLOW_TRANSIENT_in_modifier6748); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					TRANSIENT159_tree = (CommonTree)adaptor.create(TRANSIENT159);
					adaptor.addChild(root_0, TRANSIENT159_tree);
					}

					}
					break;
				case 9 :
					// Java.g:454:9: VOLATILE
					{
					root_0 = (CommonTree)adaptor.nil();


					VOLATILE160=(Token)match(input,VOLATILE,FOLLOW_VOLATILE_in_modifier6758); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					VOLATILE160_tree = (CommonTree)adaptor.create(VOLATILE160);
					adaptor.addChild(root_0, VOLATILE160_tree);
					}

					}
					break;
				case 10 :
					// Java.g:455:9: STRICTFP
					{
					root_0 = (CommonTree)adaptor.nil();


					STRICTFP161=(Token)match(input,STRICTFP,FOLLOW_STRICTFP_in_modifier6768); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					STRICTFP161_tree = (CommonTree)adaptor.create(STRICTFP161);
					adaptor.addChild(root_0, STRICTFP161_tree);
					}

					}
					break;
				case 11 :
					// Java.g:456:9: localModifier
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_localModifier_in_modifier6778);
					localModifier162=localModifier();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, localModifier162.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 38, modifier_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "modifier"


	public static class localModifierList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "localModifierList"
	// Java.g:459:1: localModifierList : ( localModifier )* -> ^( LOCAL_MODIFIER_LIST ( localModifier )* ) ;
	public final JavaParser.localModifierList_return localModifierList() throws RecognitionException {
		JavaParser.localModifierList_return retval = new JavaParser.localModifierList_return();
		retval.start = input.LT(1);
		int localModifierList_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope localModifier163 =null;

		RewriteRuleSubtreeStream stream_localModifier=new RewriteRuleSubtreeStream(adaptor,"rule localModifier");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 39) ) { return retval; }

			// Java.g:460:5: ( ( localModifier )* -> ^( LOCAL_MODIFIER_LIST ( localModifier )* ) )
			// Java.g:460:9: ( localModifier )*
			{
			// Java.g:460:9: ( localModifier )*
			loop55:
			while (true) {
				int alt55=2;
				int LA55_0 = input.LA(1);
				if ( (LA55_0==AT||LA55_0==FINAL) ) {
					alt55=1;
				}

				switch (alt55) {
				case 1 :
					// Java.g:460:9: localModifier
					{
					pushFollow(FOLLOW_localModifier_in_localModifierList6797);
					localModifier163=localModifier();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_localModifier.add(localModifier163.getTree());
					}
					break;

				default :
					break loop55;
				}
			}


			// AST REWRITE
			// elements: localModifier
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 461:9: -> ^( LOCAL_MODIFIER_LIST ( localModifier )* )
			{
				// Java.g:461:12: ^( LOCAL_MODIFIER_LIST ( localModifier )* )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(LOCAL_MODIFIER_LIST, "LOCAL_MODIFIER_LIST"), root_1);
				// Java.g:461:34: ( localModifier )*
				while ( stream_localModifier.hasNext() ) {
					adaptor.addChild(root_1, stream_localModifier.nextTree());
				}
				stream_localModifier.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 39, localModifierList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "localModifierList"


	public static class localModifier_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "localModifier"
	// Java.g:464:1: localModifier : ( FINAL | annotation );
	public final JavaParser.localModifier_return localModifier() throws RecognitionException {
		JavaParser.localModifier_return retval = new JavaParser.localModifier_return();
		retval.start = input.LT(1);
		int localModifier_StartIndex = input.index();

		CommonTree root_0 = null;

		Token FINAL164=null;
		ParserRuleReturnScope annotation165 =null;

		CommonTree FINAL164_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 40) ) { return retval; }

			// Java.g:465:5: ( FINAL | annotation )
			int alt56=2;
			int LA56_0 = input.LA(1);
			if ( (LA56_0==FINAL) ) {
				alt56=1;
			}
			else if ( (LA56_0==AT) ) {
				alt56=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 56, 0, input);
				throw nvae;
			}

			switch (alt56) {
				case 1 :
					// Java.g:465:9: FINAL
					{
					root_0 = (CommonTree)adaptor.nil();


					FINAL164=(Token)match(input,FINAL,FOLLOW_FINAL_in_localModifier6834); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					FINAL164_tree = (CommonTree)adaptor.create(FINAL164);
					adaptor.addChild(root_0, FINAL164_tree);
					}

					}
					break;
				case 2 :
					// Java.g:466:9: annotation
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_annotation_in_localModifier6844);
					annotation165=annotation();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, annotation165.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 40, localModifier_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "localModifier"


	public static class type_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "type"
	// Java.g:469:1: type : ( simpleType | objectType );
	public final JavaParser.type_return type() throws RecognitionException {
		JavaParser.type_return retval = new JavaParser.type_return();
		retval.start = input.LT(1);
		int type_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope simpleType166 =null;
		ParserRuleReturnScope objectType167 =null;


		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 41) ) { return retval; }

			// Java.g:470:5: ( simpleType | objectType )
			int alt57=2;
			int LA57_0 = input.LA(1);
			if ( (LA57_0==BOOLEAN||LA57_0==BYTE||LA57_0==CHAR||LA57_0==DOUBLE||LA57_0==FLOAT||LA57_0==INT||LA57_0==LONG||LA57_0==SHORT) ) {
				alt57=1;
			}
			else if ( (LA57_0==IDENT) ) {
				alt57=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 57, 0, input);
				throw nvae;
			}

			switch (alt57) {
				case 1 :
					// Java.g:470:9: simpleType
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_simpleType_in_type6863);
					simpleType166=simpleType();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, simpleType166.getTree());

					}
					break;
				case 2 :
					// Java.g:471:9: objectType
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_objectType_in_type6873);
					objectType167=objectType();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, objectType167.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 41, type_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "type"


	public static class simpleType_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "simpleType"
	// Java.g:474:1: simpleType : primitiveType ( arrayDeclaratorList )? -> ^( TYPE[\"TIPE\"] primitiveType ( arrayDeclaratorList )? ) ;
	public final JavaParser.simpleType_return simpleType() throws RecognitionException {
		JavaParser.simpleType_return retval = new JavaParser.simpleType_return();
		retval.start = input.LT(1);
		int simpleType_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope primitiveType168 =null;
		ParserRuleReturnScope arrayDeclaratorList169 =null;

		RewriteRuleSubtreeStream stream_primitiveType=new RewriteRuleSubtreeStream(adaptor,"rule primitiveType");
		RewriteRuleSubtreeStream stream_arrayDeclaratorList=new RewriteRuleSubtreeStream(adaptor,"rule arrayDeclaratorList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 42) ) { return retval; }

			// Java.g:475:5: ( primitiveType ( arrayDeclaratorList )? -> ^( TYPE[\"TIPE\"] primitiveType ( arrayDeclaratorList )? ) )
			// Java.g:475:9: primitiveType ( arrayDeclaratorList )?
			{
			pushFollow(FOLLOW_primitiveType_in_simpleType6893);
			primitiveType168=primitiveType();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_primitiveType.add(primitiveType168.getTree());
			// Java.g:475:23: ( arrayDeclaratorList )?
			int alt58=2;
			int LA58_0 = input.LA(1);
			if ( (LA58_0==LBRACK) ) {
				int LA58_1 = input.LA(2);
				if ( (LA58_1==RBRACK) ) {
					int LA58_3 = input.LA(3);
					if ( (synpred76_Java()) ) {
						alt58=1;
					}
				}
			}
			switch (alt58) {
				case 1 :
					// Java.g:475:23: arrayDeclaratorList
					{
					pushFollow(FOLLOW_arrayDeclaratorList_in_simpleType6895);
					arrayDeclaratorList169=arrayDeclaratorList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_arrayDeclaratorList.add(arrayDeclaratorList169.getTree());
					}
					break;

			}


			// AST REWRITE
			// elements: primitiveType, arrayDeclaratorList
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 476:9: -> ^( TYPE[\"TIPE\"] primitiveType ( arrayDeclaratorList )? )
			{
				// Java.g:476:13: ^( TYPE[\"TIPE\"] primitiveType ( arrayDeclaratorList )? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(TYPE, "TIPE"), root_1);
				adaptor.addChild(root_1, stream_primitiveType.nextTree());
				// Java.g:476:42: ( arrayDeclaratorList )?
				if ( stream_arrayDeclaratorList.hasNext() ) {
					adaptor.addChild(root_1, stream_arrayDeclaratorList.nextTree());
				}
				stream_arrayDeclaratorList.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 42, simpleType_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "simpleType"


	public static class objectType_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "objectType"
	// Java.g:479:1: objectType : qualifiedTypeIdent ( arrayDeclaratorList )? -> ^( TYPE[\"TIPE\"] qualifiedTypeIdent ( arrayDeclaratorList )? ) ;
	public final JavaParser.objectType_return objectType() throws RecognitionException {
		JavaParser.objectType_return retval = new JavaParser.objectType_return();
		retval.start = input.LT(1);
		int objectType_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope qualifiedTypeIdent170 =null;
		ParserRuleReturnScope arrayDeclaratorList171 =null;

		RewriteRuleSubtreeStream stream_qualifiedTypeIdent=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedTypeIdent");
		RewriteRuleSubtreeStream stream_arrayDeclaratorList=new RewriteRuleSubtreeStream(adaptor,"rule arrayDeclaratorList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 43) ) { return retval; }

			// Java.g:480:5: ( qualifiedTypeIdent ( arrayDeclaratorList )? -> ^( TYPE[\"TIPE\"] qualifiedTypeIdent ( arrayDeclaratorList )? ) )
			// Java.g:480:9: qualifiedTypeIdent ( arrayDeclaratorList )?
			{
			pushFollow(FOLLOW_qualifiedTypeIdent_in_objectType6937);
			qualifiedTypeIdent170=qualifiedTypeIdent();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_qualifiedTypeIdent.add(qualifiedTypeIdent170.getTree());
			// Java.g:480:28: ( arrayDeclaratorList )?
			int alt59=2;
			int LA59_0 = input.LA(1);
			if ( (LA59_0==LBRACK) ) {
				int LA59_1 = input.LA(2);
				if ( (synpred77_Java()) ) {
					alt59=1;
				}
			}
			switch (alt59) {
				case 1 :
					// Java.g:480:28: arrayDeclaratorList
					{
					pushFollow(FOLLOW_arrayDeclaratorList_in_objectType6939);
					arrayDeclaratorList171=arrayDeclaratorList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_arrayDeclaratorList.add(arrayDeclaratorList171.getTree());
					}
					break;

			}


			// AST REWRITE
			// elements: arrayDeclaratorList, qualifiedTypeIdent
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 481:9: -> ^( TYPE[\"TIPE\"] qualifiedTypeIdent ( arrayDeclaratorList )? )
			{
				// Java.g:481:13: ^( TYPE[\"TIPE\"] qualifiedTypeIdent ( arrayDeclaratorList )? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(TYPE, "TIPE"), root_1);
				adaptor.addChild(root_1, stream_qualifiedTypeIdent.nextTree());
				// Java.g:481:47: ( arrayDeclaratorList )?
				if ( stream_arrayDeclaratorList.hasNext() ) {
					adaptor.addChild(root_1, stream_arrayDeclaratorList.nextTree());
				}
				stream_arrayDeclaratorList.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 43, objectType_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "objectType"


	public static class objectTypeSimplified_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "objectTypeSimplified"
	// Java.g:484:1: objectTypeSimplified : qualifiedTypeIdentSimplified ( arrayDeclaratorList )? -> ^( TYPE[\"TIPE\"] qualifiedTypeIdentSimplified ( arrayDeclaratorList )? ) ;
	public final JavaParser.objectTypeSimplified_return objectTypeSimplified() throws RecognitionException {
		JavaParser.objectTypeSimplified_return retval = new JavaParser.objectTypeSimplified_return();
		retval.start = input.LT(1);
		int objectTypeSimplified_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope qualifiedTypeIdentSimplified172 =null;
		ParserRuleReturnScope arrayDeclaratorList173 =null;

		RewriteRuleSubtreeStream stream_qualifiedTypeIdentSimplified=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedTypeIdentSimplified");
		RewriteRuleSubtreeStream stream_arrayDeclaratorList=new RewriteRuleSubtreeStream(adaptor,"rule arrayDeclaratorList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 44) ) { return retval; }

			// Java.g:485:5: ( qualifiedTypeIdentSimplified ( arrayDeclaratorList )? -> ^( TYPE[\"TIPE\"] qualifiedTypeIdentSimplified ( arrayDeclaratorList )? ) )
			// Java.g:485:9: qualifiedTypeIdentSimplified ( arrayDeclaratorList )?
			{
			pushFollow(FOLLOW_qualifiedTypeIdentSimplified_in_objectTypeSimplified6980);
			qualifiedTypeIdentSimplified172=qualifiedTypeIdentSimplified();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_qualifiedTypeIdentSimplified.add(qualifiedTypeIdentSimplified172.getTree());
			// Java.g:485:38: ( arrayDeclaratorList )?
			int alt60=2;
			int LA60_0 = input.LA(1);
			if ( (LA60_0==LBRACK) ) {
				alt60=1;
			}
			switch (alt60) {
				case 1 :
					// Java.g:485:38: arrayDeclaratorList
					{
					pushFollow(FOLLOW_arrayDeclaratorList_in_objectTypeSimplified6982);
					arrayDeclaratorList173=arrayDeclaratorList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_arrayDeclaratorList.add(arrayDeclaratorList173.getTree());
					}
					break;

			}


			// AST REWRITE
			// elements: qualifiedTypeIdentSimplified, arrayDeclaratorList
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 486:9: -> ^( TYPE[\"TIPE\"] qualifiedTypeIdentSimplified ( arrayDeclaratorList )? )
			{
				// Java.g:486:13: ^( TYPE[\"TIPE\"] qualifiedTypeIdentSimplified ( arrayDeclaratorList )? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(TYPE, "TIPE"), root_1);
				adaptor.addChild(root_1, stream_qualifiedTypeIdentSimplified.nextTree());
				// Java.g:486:57: ( arrayDeclaratorList )?
				if ( stream_arrayDeclaratorList.hasNext() ) {
					adaptor.addChild(root_1, stream_arrayDeclaratorList.nextTree());
				}
				stream_arrayDeclaratorList.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 44, objectTypeSimplified_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "objectTypeSimplified"


	public static class qualifiedTypeIdent_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "qualifiedTypeIdent"
	// Java.g:489:1: qualifiedTypeIdent : typeIdent ( DOT typeIdent )* -> ^( QUALIFIED_TYPE_IDENT ( typeIdent )+ ) ;
	public final JavaParser.qualifiedTypeIdent_return qualifiedTypeIdent() throws RecognitionException {
		JavaParser.qualifiedTypeIdent_return retval = new JavaParser.qualifiedTypeIdent_return();
		retval.start = input.LT(1);
		int qualifiedTypeIdent_StartIndex = input.index();

		CommonTree root_0 = null;

		Token DOT175=null;
		ParserRuleReturnScope typeIdent174 =null;
		ParserRuleReturnScope typeIdent176 =null;

		CommonTree DOT175_tree=null;
		RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
		RewriteRuleSubtreeStream stream_typeIdent=new RewriteRuleSubtreeStream(adaptor,"rule typeIdent");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 45) ) { return retval; }

			// Java.g:490:5: ( typeIdent ( DOT typeIdent )* -> ^( QUALIFIED_TYPE_IDENT ( typeIdent )+ ) )
			// Java.g:490:9: typeIdent ( DOT typeIdent )*
			{
			pushFollow(FOLLOW_typeIdent_in_qualifiedTypeIdent7023);
			typeIdent174=typeIdent();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_typeIdent.add(typeIdent174.getTree());
			// Java.g:490:19: ( DOT typeIdent )*
			loop61:
			while (true) {
				int alt61=2;
				int LA61_0 = input.LA(1);
				if ( (LA61_0==DOT) ) {
					int LA61_2 = input.LA(2);
					if ( (synpred79_Java()) ) {
						alt61=1;
					}

				}

				switch (alt61) {
				case 1 :
					// Java.g:490:20: DOT typeIdent
					{
					DOT175=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedTypeIdent7026); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DOT.add(DOT175);

					pushFollow(FOLLOW_typeIdent_in_qualifiedTypeIdent7028);
					typeIdent176=typeIdent();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_typeIdent.add(typeIdent176.getTree());
					}
					break;

				default :
					break loop61;
				}
			}


			// AST REWRITE
			// elements: typeIdent
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 491:9: -> ^( QUALIFIED_TYPE_IDENT ( typeIdent )+ )
			{
				// Java.g:491:13: ^( QUALIFIED_TYPE_IDENT ( typeIdent )+ )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(QUALIFIED_TYPE_IDENT, "QUALIFIED_TYPE_IDENT"), root_1);
				if ( !(stream_typeIdent.hasNext()) ) {
					throw new RewriteEarlyExitException();
				}
				while ( stream_typeIdent.hasNext() ) {
					adaptor.addChild(root_1, stream_typeIdent.nextTree());
				}
				stream_typeIdent.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 45, qualifiedTypeIdent_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "qualifiedTypeIdent"


	public static class qualifiedTypeIdentSimplified_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "qualifiedTypeIdentSimplified"
	// Java.g:494:1: qualifiedTypeIdentSimplified : typeIdentSimplified ( DOT typeIdentSimplified )* -> ^( QUALIFIED_TYPE_IDENT ( typeIdentSimplified )+ ) ;
	public final JavaParser.qualifiedTypeIdentSimplified_return qualifiedTypeIdentSimplified() throws RecognitionException {
		JavaParser.qualifiedTypeIdentSimplified_return retval = new JavaParser.qualifiedTypeIdentSimplified_return();
		retval.start = input.LT(1);
		int qualifiedTypeIdentSimplified_StartIndex = input.index();

		CommonTree root_0 = null;

		Token DOT178=null;
		ParserRuleReturnScope typeIdentSimplified177 =null;
		ParserRuleReturnScope typeIdentSimplified179 =null;

		CommonTree DOT178_tree=null;
		RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
		RewriteRuleSubtreeStream stream_typeIdentSimplified=new RewriteRuleSubtreeStream(adaptor,"rule typeIdentSimplified");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 46) ) { return retval; }

			// Java.g:495:5: ( typeIdentSimplified ( DOT typeIdentSimplified )* -> ^( QUALIFIED_TYPE_IDENT ( typeIdentSimplified )+ ) )
			// Java.g:495:9: typeIdentSimplified ( DOT typeIdentSimplified )*
			{
			pushFollow(FOLLOW_typeIdentSimplified_in_qualifiedTypeIdentSimplified7067);
			typeIdentSimplified177=typeIdentSimplified();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_typeIdentSimplified.add(typeIdentSimplified177.getTree());
			// Java.g:495:29: ( DOT typeIdentSimplified )*
			loop62:
			while (true) {
				int alt62=2;
				int LA62_0 = input.LA(1);
				if ( (LA62_0==DOT) ) {
					alt62=1;
				}

				switch (alt62) {
				case 1 :
					// Java.g:495:30: DOT typeIdentSimplified
					{
					DOT178=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedTypeIdentSimplified7070); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DOT.add(DOT178);

					pushFollow(FOLLOW_typeIdentSimplified_in_qualifiedTypeIdentSimplified7072);
					typeIdentSimplified179=typeIdentSimplified();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_typeIdentSimplified.add(typeIdentSimplified179.getTree());
					}
					break;

				default :
					break loop62;
				}
			}


			// AST REWRITE
			// elements: typeIdentSimplified
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 496:9: -> ^( QUALIFIED_TYPE_IDENT ( typeIdentSimplified )+ )
			{
				// Java.g:496:13: ^( QUALIFIED_TYPE_IDENT ( typeIdentSimplified )+ )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(QUALIFIED_TYPE_IDENT, "QUALIFIED_TYPE_IDENT"), root_1);
				if ( !(stream_typeIdentSimplified.hasNext()) ) {
					throw new RewriteEarlyExitException();
				}
				while ( stream_typeIdentSimplified.hasNext() ) {
					adaptor.addChild(root_1, stream_typeIdentSimplified.nextTree());
				}
				stream_typeIdentSimplified.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 46, qualifiedTypeIdentSimplified_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "qualifiedTypeIdentSimplified"


	public static class typeIdent_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "typeIdent"
	// Java.g:499:1: typeIdent : IDENT ^ ( genericTypeArgumentList )? ;
	public final JavaParser.typeIdent_return typeIdent() throws RecognitionException {
		JavaParser.typeIdent_return retval = new JavaParser.typeIdent_return();
		retval.start = input.LT(1);
		int typeIdent_StartIndex = input.index();

		CommonTree root_0 = null;

		Token IDENT180=null;
		ParserRuleReturnScope genericTypeArgumentList181 =null;

		CommonTree IDENT180_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 47) ) { return retval; }

			// Java.g:500:5: ( IDENT ^ ( genericTypeArgumentList )? )
			// Java.g:500:9: IDENT ^ ( genericTypeArgumentList )?
			{
			root_0 = (CommonTree)adaptor.nil();


			IDENT180=(Token)match(input,IDENT,FOLLOW_IDENT_in_typeIdent7111); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			IDENT180_tree = (CommonTree)adaptor.create(IDENT180);
			root_0 = (CommonTree)adaptor.becomeRoot(IDENT180_tree, root_0);
			}

			// Java.g:500:16: ( genericTypeArgumentList )?
			int alt63=2;
			int LA63_0 = input.LA(1);
			if ( (LA63_0==LESS_THAN) ) {
				alt63=1;
			}
			switch (alt63) {
				case 1 :
					// Java.g:500:16: genericTypeArgumentList
					{
					pushFollow(FOLLOW_genericTypeArgumentList_in_typeIdent7114);
					genericTypeArgumentList181=genericTypeArgumentList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, genericTypeArgumentList181.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 47, typeIdent_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "typeIdent"


	public static class typeIdentSimplified_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "typeIdentSimplified"
	// Java.g:503:1: typeIdentSimplified : IDENT ^ ( genericTypeArgumentListSimplified )? ;
	public final JavaParser.typeIdentSimplified_return typeIdentSimplified() throws RecognitionException {
		JavaParser.typeIdentSimplified_return retval = new JavaParser.typeIdentSimplified_return();
		retval.start = input.LT(1);
		int typeIdentSimplified_StartIndex = input.index();

		CommonTree root_0 = null;

		Token IDENT182=null;
		ParserRuleReturnScope genericTypeArgumentListSimplified183 =null;

		CommonTree IDENT182_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 48) ) { return retval; }

			// Java.g:504:5: ( IDENT ^ ( genericTypeArgumentListSimplified )? )
			// Java.g:504:9: IDENT ^ ( genericTypeArgumentListSimplified )?
			{
			root_0 = (CommonTree)adaptor.nil();


			IDENT182=(Token)match(input,IDENT,FOLLOW_IDENT_in_typeIdentSimplified7134); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			IDENT182_tree = (CommonTree)adaptor.create(IDENT182);
			root_0 = (CommonTree)adaptor.becomeRoot(IDENT182_tree, root_0);
			}

			// Java.g:504:16: ( genericTypeArgumentListSimplified )?
			int alt64=2;
			int LA64_0 = input.LA(1);
			if ( (LA64_0==LESS_THAN) ) {
				alt64=1;
			}
			switch (alt64) {
				case 1 :
					// Java.g:504:16: genericTypeArgumentListSimplified
					{
					pushFollow(FOLLOW_genericTypeArgumentListSimplified_in_typeIdentSimplified7137);
					genericTypeArgumentListSimplified183=genericTypeArgumentListSimplified();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, genericTypeArgumentListSimplified183.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 48, typeIdentSimplified_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "typeIdentSimplified"


	public static class primitiveType_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "primitiveType"
	// Java.g:507:1: primitiveType : ( BOOLEAN | CHAR | BYTE | SHORT | INT | LONG | FLOAT | DOUBLE );
	public final JavaParser.primitiveType_return primitiveType() throws RecognitionException {
		JavaParser.primitiveType_return retval = new JavaParser.primitiveType_return();
		retval.start = input.LT(1);
		int primitiveType_StartIndex = input.index();

		CommonTree root_0 = null;

		Token set184=null;

		CommonTree set184_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 49) ) { return retval; }

			// Java.g:508:5: ( BOOLEAN | CHAR | BYTE | SHORT | INT | LONG | FLOAT | DOUBLE )
			// Java.g:
			{
			root_0 = (CommonTree)adaptor.nil();


			set184=input.LT(1);
			if ( input.LA(1)==BOOLEAN||input.LA(1)==BYTE||input.LA(1)==CHAR||input.LA(1)==DOUBLE||input.LA(1)==FLOAT||input.LA(1)==INT||input.LA(1)==LONG||input.LA(1)==SHORT ) {
				input.consume();
				if ( state.backtracking==0 ) adaptor.addChild(root_0, (CommonTree)adaptor.create(set184));
				state.errorRecovery=false;
				state.failed=false;
			}
			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				MismatchedSetException mse = new MismatchedSetException(null,input);
				throw mse;
			}
			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 49, primitiveType_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "primitiveType"


	public static class genericTypeArgumentList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "genericTypeArgumentList"
	// Java.g:518:1: genericTypeArgumentList : LESS_THAN genericTypeArgument ( COMMA genericTypeArgument )* genericTypeListClosing -> ^( GENERIC_TYPE_ARG_LIST[$LESS_THAN, \"GENERIC_TYPE_ARG_LIST\"] ( genericTypeArgument )+ ) ;
	public final JavaParser.genericTypeArgumentList_return genericTypeArgumentList() throws RecognitionException {
		JavaParser.genericTypeArgumentList_return retval = new JavaParser.genericTypeArgumentList_return();
		retval.start = input.LT(1);
		int genericTypeArgumentList_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LESS_THAN185=null;
		Token COMMA187=null;
		ParserRuleReturnScope genericTypeArgument186 =null;
		ParserRuleReturnScope genericTypeArgument188 =null;
		ParserRuleReturnScope genericTypeListClosing189 =null;

		CommonTree LESS_THAN185_tree=null;
		CommonTree COMMA187_tree=null;
		RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
		RewriteRuleTokenStream stream_LESS_THAN=new RewriteRuleTokenStream(adaptor,"token LESS_THAN");
		RewriteRuleSubtreeStream stream_genericTypeArgument=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeArgument");
		RewriteRuleSubtreeStream stream_genericTypeListClosing=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeListClosing");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 50) ) { return retval; }

			// Java.g:519:5: ( LESS_THAN genericTypeArgument ( COMMA genericTypeArgument )* genericTypeListClosing -> ^( GENERIC_TYPE_ARG_LIST[$LESS_THAN, \"GENERIC_TYPE_ARG_LIST\"] ( genericTypeArgument )+ ) )
			// Java.g:519:9: LESS_THAN genericTypeArgument ( COMMA genericTypeArgument )* genericTypeListClosing
			{
			LESS_THAN185=(Token)match(input,LESS_THAN,FOLLOW_LESS_THAN_in_genericTypeArgumentList7246); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LESS_THAN.add(LESS_THAN185);

			pushFollow(FOLLOW_genericTypeArgument_in_genericTypeArgumentList7248);
			genericTypeArgument186=genericTypeArgument();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_genericTypeArgument.add(genericTypeArgument186.getTree());
			// Java.g:519:39: ( COMMA genericTypeArgument )*
			loop65:
			while (true) {
				int alt65=2;
				int LA65_0 = input.LA(1);
				if ( (LA65_0==COMMA) ) {
					int LA65_2 = input.LA(2);
					if ( (synpred90_Java()) ) {
						alt65=1;
					}

				}

				switch (alt65) {
				case 1 :
					// Java.g:519:40: COMMA genericTypeArgument
					{
					COMMA187=(Token)match(input,COMMA,FOLLOW_COMMA_in_genericTypeArgumentList7251); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_COMMA.add(COMMA187);

					pushFollow(FOLLOW_genericTypeArgument_in_genericTypeArgumentList7253);
					genericTypeArgument188=genericTypeArgument();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_genericTypeArgument.add(genericTypeArgument188.getTree());
					}
					break;

				default :
					break loop65;
				}
			}

			pushFollow(FOLLOW_genericTypeListClosing_in_genericTypeArgumentList7257);
			genericTypeListClosing189=genericTypeListClosing();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_genericTypeListClosing.add(genericTypeListClosing189.getTree());

			// AST REWRITE
			// elements: genericTypeArgument
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 520:9: -> ^( GENERIC_TYPE_ARG_LIST[$LESS_THAN, \"GENERIC_TYPE_ARG_LIST\"] ( genericTypeArgument )+ )
			{
				// Java.g:520:13: ^( GENERIC_TYPE_ARG_LIST[$LESS_THAN, \"GENERIC_TYPE_ARG_LIST\"] ( genericTypeArgument )+ )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(GENERIC_TYPE_ARG_LIST, LESS_THAN185, "GENERIC_TYPE_ARG_LIST"), root_1);
				if ( !(stream_genericTypeArgument.hasNext()) ) {
					throw new RewriteEarlyExitException();
				}
				while ( stream_genericTypeArgument.hasNext() ) {
					adaptor.addChild(root_1, stream_genericTypeArgument.nextTree());
				}
				stream_genericTypeArgument.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 50, genericTypeArgumentList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "genericTypeArgumentList"


	public static class genericTypeArgument_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "genericTypeArgument"
	// Java.g:523:1: genericTypeArgument : ( type | QUESTION ( genericWildcardBoundType )? -> ^( QUESTION ( genericWildcardBoundType )? ) );
	public final JavaParser.genericTypeArgument_return genericTypeArgument() throws RecognitionException {
		JavaParser.genericTypeArgument_return retval = new JavaParser.genericTypeArgument_return();
		retval.start = input.LT(1);
		int genericTypeArgument_StartIndex = input.index();

		CommonTree root_0 = null;

		Token QUESTION191=null;
		ParserRuleReturnScope type190 =null;
		ParserRuleReturnScope genericWildcardBoundType192 =null;

		CommonTree QUESTION191_tree=null;
		RewriteRuleTokenStream stream_QUESTION=new RewriteRuleTokenStream(adaptor,"token QUESTION");
		RewriteRuleSubtreeStream stream_genericWildcardBoundType=new RewriteRuleSubtreeStream(adaptor,"rule genericWildcardBoundType");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 51) ) { return retval; }

			// Java.g:524:5: ( type | QUESTION ( genericWildcardBoundType )? -> ^( QUESTION ( genericWildcardBoundType )? ) )
			int alt67=2;
			int LA67_0 = input.LA(1);
			if ( (LA67_0==BOOLEAN||LA67_0==BYTE||LA67_0==CHAR||LA67_0==DOUBLE||LA67_0==FLOAT||LA67_0==IDENT||LA67_0==INT||LA67_0==LONG||LA67_0==SHORT) ) {
				alt67=1;
			}
			else if ( (LA67_0==QUESTION) ) {
				alt67=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 67, 0, input);
				throw nvae;
			}

			switch (alt67) {
				case 1 :
					// Java.g:524:9: type
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_type_in_genericTypeArgument7295);
					type190=type();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, type190.getTree());

					}
					break;
				case 2 :
					// Java.g:525:9: QUESTION ( genericWildcardBoundType )?
					{
					QUESTION191=(Token)match(input,QUESTION,FOLLOW_QUESTION_in_genericTypeArgument7305); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_QUESTION.add(QUESTION191);

					// Java.g:525:18: ( genericWildcardBoundType )?
					int alt66=2;
					int LA66_0 = input.LA(1);
					if ( (LA66_0==EXTENDS) ) {
						int LA66_1 = input.LA(2);
						if ( (LA66_1==BOOLEAN||LA66_1==BYTE||LA66_1==CHAR||LA66_1==DOUBLE||LA66_1==FLOAT||LA66_1==INT||LA66_1==LONG||LA66_1==SHORT) ) {
							int LA66_4 = input.LA(3);
							if ( (synpred92_Java()) ) {
								alt66=1;
							}
						}
						else if ( (LA66_1==IDENT) ) {
							int LA66_5 = input.LA(3);
							if ( (synpred92_Java()) ) {
								alt66=1;
							}
						}
					}
					else if ( (LA66_0==SUPER) ) {
						int LA66_3 = input.LA(2);
						if ( (LA66_3==BOOLEAN||LA66_3==BYTE||LA66_3==CHAR||LA66_3==DOUBLE||LA66_3==FLOAT||LA66_3==IDENT||LA66_3==INT||LA66_3==LONG||LA66_3==SHORT) ) {
							alt66=1;
						}
					}
					switch (alt66) {
						case 1 :
							// Java.g:525:18: genericWildcardBoundType
							{
							pushFollow(FOLLOW_genericWildcardBoundType_in_genericTypeArgument7307);
							genericWildcardBoundType192=genericWildcardBoundType();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_genericWildcardBoundType.add(genericWildcardBoundType192.getTree());
							}
							break;

					}


					// AST REWRITE
					// elements: QUESTION, genericWildcardBoundType
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 526:9: -> ^( QUESTION ( genericWildcardBoundType )? )
					{
						// Java.g:526:13: ^( QUESTION ( genericWildcardBoundType )? )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_QUESTION.nextNode(), root_1);
						// Java.g:526:24: ( genericWildcardBoundType )?
						if ( stream_genericWildcardBoundType.hasNext() ) {
							adaptor.addChild(root_1, stream_genericWildcardBoundType.nextTree());
						}
						stream_genericWildcardBoundType.reset();

						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 51, genericTypeArgument_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "genericTypeArgument"


	public static class genericWildcardBoundType_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "genericWildcardBoundType"
	// Java.g:529:1: genericWildcardBoundType : ( EXTENDS | SUPER ) ^ type ;
	public final JavaParser.genericWildcardBoundType_return genericWildcardBoundType() throws RecognitionException {
		JavaParser.genericWildcardBoundType_return retval = new JavaParser.genericWildcardBoundType_return();
		retval.start = input.LT(1);
		int genericWildcardBoundType_StartIndex = input.index();

		CommonTree root_0 = null;

		Token set193=null;
		ParserRuleReturnScope type194 =null;

		CommonTree set193_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 52) ) { return retval; }

			// Java.g:530:5: ( ( EXTENDS | SUPER ) ^ type )
			// Java.g:530:9: ( EXTENDS | SUPER ) ^ type
			{
			root_0 = (CommonTree)adaptor.nil();


			set193=input.LT(1);
			set193=input.LT(1);
			if ( input.LA(1)==EXTENDS||input.LA(1)==SUPER ) {
				input.consume();
				if ( state.backtracking==0 ) root_0 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(set193), root_0);
				state.errorRecovery=false;
				state.failed=false;
			}
			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				MismatchedSetException mse = new MismatchedSetException(null,input);
				throw mse;
			}
			pushFollow(FOLLOW_type_in_genericWildcardBoundType7354);
			type194=type();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, type194.getTree());

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 52, genericWildcardBoundType_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "genericWildcardBoundType"


	public static class genericTypeArgumentListSimplified_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "genericTypeArgumentListSimplified"
	// Java.g:533:1: genericTypeArgumentListSimplified : LESS_THAN genericTypeArgumentSimplified ( COMMA genericTypeArgumentSimplified )* genericTypeListClosing -> ^( GENERIC_TYPE_ARG_LIST[$LESS_THAN, \"GENERIC_TYPE_ARG_LIST\"] ( genericTypeArgumentSimplified )+ ) ;
	public final JavaParser.genericTypeArgumentListSimplified_return genericTypeArgumentListSimplified() throws RecognitionException {
		JavaParser.genericTypeArgumentListSimplified_return retval = new JavaParser.genericTypeArgumentListSimplified_return();
		retval.start = input.LT(1);
		int genericTypeArgumentListSimplified_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LESS_THAN195=null;
		Token COMMA197=null;
		ParserRuleReturnScope genericTypeArgumentSimplified196 =null;
		ParserRuleReturnScope genericTypeArgumentSimplified198 =null;
		ParserRuleReturnScope genericTypeListClosing199 =null;

		CommonTree LESS_THAN195_tree=null;
		CommonTree COMMA197_tree=null;
		RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
		RewriteRuleTokenStream stream_LESS_THAN=new RewriteRuleTokenStream(adaptor,"token LESS_THAN");
		RewriteRuleSubtreeStream stream_genericTypeArgumentSimplified=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeArgumentSimplified");
		RewriteRuleSubtreeStream stream_genericTypeListClosing=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeListClosing");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 53) ) { return retval; }

			// Java.g:534:5: ( LESS_THAN genericTypeArgumentSimplified ( COMMA genericTypeArgumentSimplified )* genericTypeListClosing -> ^( GENERIC_TYPE_ARG_LIST[$LESS_THAN, \"GENERIC_TYPE_ARG_LIST\"] ( genericTypeArgumentSimplified )+ ) )
			// Java.g:534:9: LESS_THAN genericTypeArgumentSimplified ( COMMA genericTypeArgumentSimplified )* genericTypeListClosing
			{
			LESS_THAN195=(Token)match(input,LESS_THAN,FOLLOW_LESS_THAN_in_genericTypeArgumentListSimplified7373); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LESS_THAN.add(LESS_THAN195);

			pushFollow(FOLLOW_genericTypeArgumentSimplified_in_genericTypeArgumentListSimplified7375);
			genericTypeArgumentSimplified196=genericTypeArgumentSimplified();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_genericTypeArgumentSimplified.add(genericTypeArgumentSimplified196.getTree());
			// Java.g:534:49: ( COMMA genericTypeArgumentSimplified )*
			loop68:
			while (true) {
				int alt68=2;
				int LA68_0 = input.LA(1);
				if ( (LA68_0==COMMA) ) {
					alt68=1;
				}

				switch (alt68) {
				case 1 :
					// Java.g:534:50: COMMA genericTypeArgumentSimplified
					{
					COMMA197=(Token)match(input,COMMA,FOLLOW_COMMA_in_genericTypeArgumentListSimplified7378); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_COMMA.add(COMMA197);

					pushFollow(FOLLOW_genericTypeArgumentSimplified_in_genericTypeArgumentListSimplified7380);
					genericTypeArgumentSimplified198=genericTypeArgumentSimplified();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_genericTypeArgumentSimplified.add(genericTypeArgumentSimplified198.getTree());
					}
					break;

				default :
					break loop68;
				}
			}

			pushFollow(FOLLOW_genericTypeListClosing_in_genericTypeArgumentListSimplified7384);
			genericTypeListClosing199=genericTypeListClosing();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_genericTypeListClosing.add(genericTypeListClosing199.getTree());

			// AST REWRITE
			// elements: genericTypeArgumentSimplified
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 535:9: -> ^( GENERIC_TYPE_ARG_LIST[$LESS_THAN, \"GENERIC_TYPE_ARG_LIST\"] ( genericTypeArgumentSimplified )+ )
			{
				// Java.g:535:13: ^( GENERIC_TYPE_ARG_LIST[$LESS_THAN, \"GENERIC_TYPE_ARG_LIST\"] ( genericTypeArgumentSimplified )+ )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(GENERIC_TYPE_ARG_LIST, LESS_THAN195, "GENERIC_TYPE_ARG_LIST"), root_1);
				if ( !(stream_genericTypeArgumentSimplified.hasNext()) ) {
					throw new RewriteEarlyExitException();
				}
				while ( stream_genericTypeArgumentSimplified.hasNext() ) {
					adaptor.addChild(root_1, stream_genericTypeArgumentSimplified.nextTree());
				}
				stream_genericTypeArgumentSimplified.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 53, genericTypeArgumentListSimplified_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "genericTypeArgumentListSimplified"


	public static class genericTypeArgumentSimplified_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "genericTypeArgumentSimplified"
	// Java.g:538:1: genericTypeArgumentSimplified : ( type | QUESTION );
	public final JavaParser.genericTypeArgumentSimplified_return genericTypeArgumentSimplified() throws RecognitionException {
		JavaParser.genericTypeArgumentSimplified_return retval = new JavaParser.genericTypeArgumentSimplified_return();
		retval.start = input.LT(1);
		int genericTypeArgumentSimplified_StartIndex = input.index();

		CommonTree root_0 = null;

		Token QUESTION201=null;
		ParserRuleReturnScope type200 =null;

		CommonTree QUESTION201_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 54) ) { return retval; }

			// Java.g:539:5: ( type | QUESTION )
			int alt69=2;
			int LA69_0 = input.LA(1);
			if ( (LA69_0==BOOLEAN||LA69_0==BYTE||LA69_0==CHAR||LA69_0==DOUBLE||LA69_0==FLOAT||LA69_0==IDENT||LA69_0==INT||LA69_0==LONG||LA69_0==SHORT) ) {
				alt69=1;
			}
			else if ( (LA69_0==QUESTION) ) {
				alt69=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 69, 0, input);
				throw nvae;
			}

			switch (alt69) {
				case 1 :
					// Java.g:539:9: type
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_type_in_genericTypeArgumentSimplified7422);
					type200=type();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, type200.getTree());

					}
					break;
				case 2 :
					// Java.g:540:9: QUESTION
					{
					root_0 = (CommonTree)adaptor.nil();


					QUESTION201=(Token)match(input,QUESTION,FOLLOW_QUESTION_in_genericTypeArgumentSimplified7432); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					QUESTION201_tree = (CommonTree)adaptor.create(QUESTION201);
					adaptor.addChild(root_0, QUESTION201_tree);
					}

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 54, genericTypeArgumentSimplified_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "genericTypeArgumentSimplified"


	public static class qualifiedIdentList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "qualifiedIdentList"
	// Java.g:543:1: qualifiedIdentList : qualifiedIdentifier ( COMMA ! qualifiedIdentifier )* ;
	public final JavaParser.qualifiedIdentList_return qualifiedIdentList() throws RecognitionException {
		JavaParser.qualifiedIdentList_return retval = new JavaParser.qualifiedIdentList_return();
		retval.start = input.LT(1);
		int qualifiedIdentList_StartIndex = input.index();

		CommonTree root_0 = null;

		Token COMMA203=null;
		ParserRuleReturnScope qualifiedIdentifier202 =null;
		ParserRuleReturnScope qualifiedIdentifier204 =null;

		CommonTree COMMA203_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 55) ) { return retval; }

			// Java.g:544:5: ( qualifiedIdentifier ( COMMA ! qualifiedIdentifier )* )
			// Java.g:544:9: qualifiedIdentifier ( COMMA ! qualifiedIdentifier )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_qualifiedIdentifier_in_qualifiedIdentList7451);
			qualifiedIdentifier202=qualifiedIdentifier();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedIdentifier202.getTree());

			// Java.g:544:29: ( COMMA ! qualifiedIdentifier )*
			loop70:
			while (true) {
				int alt70=2;
				int LA70_0 = input.LA(1);
				if ( (LA70_0==COMMA) ) {
					alt70=1;
				}

				switch (alt70) {
				case 1 :
					// Java.g:544:30: COMMA ! qualifiedIdentifier
					{
					COMMA203=(Token)match(input,COMMA,FOLLOW_COMMA_in_qualifiedIdentList7454); if (state.failed) return retval;
					pushFollow(FOLLOW_qualifiedIdentifier_in_qualifiedIdentList7457);
					qualifiedIdentifier204=qualifiedIdentifier();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedIdentifier204.getTree());

					}
					break;

				default :
					break loop70;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 55, qualifiedIdentList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "qualifiedIdentList"


	public static class formalParameterList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "formalParameterList"
	// Java.g:547:1: formalParameterList : LPAREN ( formalParameterStandardDecl ( COMMA formalParameterStandardDecl )* ( COMMA formalParameterVarArgDecl )? -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] ( formalParameterStandardDecl )+ ( formalParameterVarArgDecl )? ) | formalParameterVarArgDecl -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] formalParameterVarArgDecl ) | -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] ) ) RPAREN ;
	public final JavaParser.formalParameterList_return formalParameterList() throws RecognitionException {
		JavaParser.formalParameterList_return retval = new JavaParser.formalParameterList_return();
		retval.start = input.LT(1);
		int formalParameterList_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LPAREN205=null;
		Token COMMA207=null;
		Token COMMA209=null;
		Token RPAREN212=null;
		ParserRuleReturnScope formalParameterStandardDecl206 =null;
		ParserRuleReturnScope formalParameterStandardDecl208 =null;
		ParserRuleReturnScope formalParameterVarArgDecl210 =null;
		ParserRuleReturnScope formalParameterVarArgDecl211 =null;

		CommonTree LPAREN205_tree=null;
		CommonTree COMMA207_tree=null;
		CommonTree COMMA209_tree=null;
		CommonTree RPAREN212_tree=null;
		RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
		RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
		RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
		RewriteRuleSubtreeStream stream_formalParameterStandardDecl=new RewriteRuleSubtreeStream(adaptor,"rule formalParameterStandardDecl");
		RewriteRuleSubtreeStream stream_formalParameterVarArgDecl=new RewriteRuleSubtreeStream(adaptor,"rule formalParameterVarArgDecl");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 56) ) { return retval; }

			// Java.g:548:5: ( LPAREN ( formalParameterStandardDecl ( COMMA formalParameterStandardDecl )* ( COMMA formalParameterVarArgDecl )? -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] ( formalParameterStandardDecl )+ ( formalParameterVarArgDecl )? ) | formalParameterVarArgDecl -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] formalParameterVarArgDecl ) | -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] ) ) RPAREN )
			// Java.g:548:9: LPAREN ( formalParameterStandardDecl ( COMMA formalParameterStandardDecl )* ( COMMA formalParameterVarArgDecl )? -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] ( formalParameterStandardDecl )+ ( formalParameterVarArgDecl )? ) | formalParameterVarArgDecl -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] formalParameterVarArgDecl ) | -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] ) ) RPAREN
			{
			LPAREN205=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_formalParameterList7478); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LPAREN.add(LPAREN205);

			// Java.g:549:9: ( formalParameterStandardDecl ( COMMA formalParameterStandardDecl )* ( COMMA formalParameterVarArgDecl )? -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] ( formalParameterStandardDecl )+ ( formalParameterVarArgDecl )? ) | formalParameterVarArgDecl -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] formalParameterVarArgDecl ) | -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] ) )
			int alt73=3;
			switch ( input.LA(1) ) {
			case FINAL:
				{
				int LA73_1 = input.LA(2);
				if ( (synpred99_Java()) ) {
					alt73=1;
				}
				else if ( (synpred100_Java()) ) {
					alt73=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 73, 1, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case AT:
				{
				int LA73_2 = input.LA(2);
				if ( (synpred99_Java()) ) {
					alt73=1;
				}
				else if ( (synpred100_Java()) ) {
					alt73=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 73, 2, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case DOUBLE:
			case FLOAT:
			case INT:
			case LONG:
			case SHORT:
				{
				int LA73_3 = input.LA(2);
				if ( (synpred99_Java()) ) {
					alt73=1;
				}
				else if ( (synpred100_Java()) ) {
					alt73=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 73, 3, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case IDENT:
				{
				int LA73_4 = input.LA(2);
				if ( (synpred99_Java()) ) {
					alt73=1;
				}
				else if ( (synpred100_Java()) ) {
					alt73=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 73, 4, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case RPAREN:
				{
				alt73=3;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 73, 0, input);
				throw nvae;
			}
			switch (alt73) {
				case 1 :
					// Java.g:550:13: formalParameterStandardDecl ( COMMA formalParameterStandardDecl )* ( COMMA formalParameterVarArgDecl )?
					{
					pushFollow(FOLLOW_formalParameterStandardDecl_in_formalParameterList7505);
					formalParameterStandardDecl206=formalParameterStandardDecl();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_formalParameterStandardDecl.add(formalParameterStandardDecl206.getTree());
					// Java.g:550:41: ( COMMA formalParameterStandardDecl )*
					loop71:
					while (true) {
						int alt71=2;
						int LA71_0 = input.LA(1);
						if ( (LA71_0==COMMA) ) {
							int LA71_1 = input.LA(2);
							if ( (synpred97_Java()) ) {
								alt71=1;
							}

						}

						switch (alt71) {
						case 1 :
							// Java.g:550:42: COMMA formalParameterStandardDecl
							{
							COMMA207=(Token)match(input,COMMA,FOLLOW_COMMA_in_formalParameterList7508); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_COMMA.add(COMMA207);

							pushFollow(FOLLOW_formalParameterStandardDecl_in_formalParameterList7510);
							formalParameterStandardDecl208=formalParameterStandardDecl();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_formalParameterStandardDecl.add(formalParameterStandardDecl208.getTree());
							}
							break;

						default :
							break loop71;
						}
					}

					// Java.g:550:78: ( COMMA formalParameterVarArgDecl )?
					int alt72=2;
					int LA72_0 = input.LA(1);
					if ( (LA72_0==COMMA) ) {
						alt72=1;
					}
					switch (alt72) {
						case 1 :
							// Java.g:550:79: COMMA formalParameterVarArgDecl
							{
							COMMA209=(Token)match(input,COMMA,FOLLOW_COMMA_in_formalParameterList7515); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_COMMA.add(COMMA209);

							pushFollow(FOLLOW_formalParameterVarArgDecl_in_formalParameterList7517);
							formalParameterVarArgDecl210=formalParameterVarArgDecl();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_formalParameterVarArgDecl.add(formalParameterVarArgDecl210.getTree());
							}
							break;

					}


					// AST REWRITE
					// elements: formalParameterVarArgDecl, formalParameterStandardDecl
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 551:13: -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] ( formalParameterStandardDecl )+ ( formalParameterVarArgDecl )? )
					{
						// Java.g:551:17: ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] ( formalParameterStandardDecl )+ ( formalParameterVarArgDecl )? )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FORMAL_PARAM_LIST, LPAREN205, "FORMAL_PARAM_LIST"), root_1);
						if ( !(stream_formalParameterStandardDecl.hasNext()) ) {
							throw new RewriteEarlyExitException();
						}
						while ( stream_formalParameterStandardDecl.hasNext() ) {
							adaptor.addChild(root_1, stream_formalParameterStandardDecl.nextTree());
						}
						stream_formalParameterStandardDecl.reset();

						// Java.g:551:96: ( formalParameterVarArgDecl )?
						if ( stream_formalParameterVarArgDecl.hasNext() ) {
							adaptor.addChild(root_1, stream_formalParameterVarArgDecl.nextTree());
						}
						stream_formalParameterVarArgDecl.reset();

						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 2 :
					// Java.g:553:13: formalParameterVarArgDecl
					{
					pushFollow(FOLLOW_formalParameterVarArgDecl_in_formalParameterList7572);
					formalParameterVarArgDecl211=formalParameterVarArgDecl();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_formalParameterVarArgDecl.add(formalParameterVarArgDecl211.getTree());

					// AST REWRITE
					// elements: formalParameterVarArgDecl
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 554:13: -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] formalParameterVarArgDecl )
					{
						// Java.g:554:17: ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] formalParameterVarArgDecl )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FORMAL_PARAM_LIST, LPAREN205, "FORMAL_PARAM_LIST"), root_1);
						adaptor.addChild(root_1, stream_formalParameterVarArgDecl.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 3 :
					// Java.g:556:13: 
					{

					// AST REWRITE
					// elements: 
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 556:13: -> ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] )
					{
						// Java.g:556:17: ^( FORMAL_PARAM_LIST[$LPAREN, \"FORMAL_PARAM_LIST\"] )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FORMAL_PARAM_LIST, LPAREN205, "FORMAL_PARAM_LIST"), root_1);
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;

			}

			RPAREN212=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_formalParameterList7647); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RPAREN.add(RPAREN212);

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 56, formalParameterList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "formalParameterList"


	public static class formalParameterStandardDecl_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "formalParameterStandardDecl"
	// Java.g:561:1: formalParameterStandardDecl : localModifierList type variableDeclaratorId -> ^( FORMAL_PARAM_STD_DECL localModifierList type variableDeclaratorId ) ;
	public final JavaParser.formalParameterStandardDecl_return formalParameterStandardDecl() throws RecognitionException {
		JavaParser.formalParameterStandardDecl_return retval = new JavaParser.formalParameterStandardDecl_return();
		retval.start = input.LT(1);
		int formalParameterStandardDecl_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope localModifierList213 =null;
		ParserRuleReturnScope type214 =null;
		ParserRuleReturnScope variableDeclaratorId215 =null;

		RewriteRuleSubtreeStream stream_localModifierList=new RewriteRuleSubtreeStream(adaptor,"rule localModifierList");
		RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
		RewriteRuleSubtreeStream stream_variableDeclaratorId=new RewriteRuleSubtreeStream(adaptor,"rule variableDeclaratorId");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 57) ) { return retval; }

			// Java.g:562:5: ( localModifierList type variableDeclaratorId -> ^( FORMAL_PARAM_STD_DECL localModifierList type variableDeclaratorId ) )
			// Java.g:562:9: localModifierList type variableDeclaratorId
			{
			pushFollow(FOLLOW_localModifierList_in_formalParameterStandardDecl7666);
			localModifierList213=localModifierList();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_localModifierList.add(localModifierList213.getTree());
			pushFollow(FOLLOW_type_in_formalParameterStandardDecl7668);
			type214=type();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_type.add(type214.getTree());
			pushFollow(FOLLOW_variableDeclaratorId_in_formalParameterStandardDecl7670);
			variableDeclaratorId215=variableDeclaratorId();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_variableDeclaratorId.add(variableDeclaratorId215.getTree());

			// AST REWRITE
			// elements: variableDeclaratorId, type, localModifierList
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 563:9: -> ^( FORMAL_PARAM_STD_DECL localModifierList type variableDeclaratorId )
			{
				// Java.g:563:13: ^( FORMAL_PARAM_STD_DECL localModifierList type variableDeclaratorId )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FORMAL_PARAM_STD_DECL, "FORMAL_PARAM_STD_DECL"), root_1);
				adaptor.addChild(root_1, stream_localModifierList.nextTree());
				adaptor.addChild(root_1, stream_type.nextTree());
				adaptor.addChild(root_1, stream_variableDeclaratorId.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 57, formalParameterStandardDecl_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "formalParameterStandardDecl"


	public static class formalParameterVarArgDecl_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "formalParameterVarArgDecl"
	// Java.g:566:1: formalParameterVarArgDecl : localModifierList type ELLIPSIS variableDeclaratorId -> ^( FORMAL_PARAM_VARARG_DECL localModifierList type variableDeclaratorId ) ;
	public final JavaParser.formalParameterVarArgDecl_return formalParameterVarArgDecl() throws RecognitionException {
		JavaParser.formalParameterVarArgDecl_return retval = new JavaParser.formalParameterVarArgDecl_return();
		retval.start = input.LT(1);
		int formalParameterVarArgDecl_StartIndex = input.index();

		CommonTree root_0 = null;

		Token ELLIPSIS218=null;
		ParserRuleReturnScope localModifierList216 =null;
		ParserRuleReturnScope type217 =null;
		ParserRuleReturnScope variableDeclaratorId219 =null;

		CommonTree ELLIPSIS218_tree=null;
		RewriteRuleTokenStream stream_ELLIPSIS=new RewriteRuleTokenStream(adaptor,"token ELLIPSIS");
		RewriteRuleSubtreeStream stream_localModifierList=new RewriteRuleSubtreeStream(adaptor,"rule localModifierList");
		RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
		RewriteRuleSubtreeStream stream_variableDeclaratorId=new RewriteRuleSubtreeStream(adaptor,"rule variableDeclaratorId");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 58) ) { return retval; }

			// Java.g:567:5: ( localModifierList type ELLIPSIS variableDeclaratorId -> ^( FORMAL_PARAM_VARARG_DECL localModifierList type variableDeclaratorId ) )
			// Java.g:567:9: localModifierList type ELLIPSIS variableDeclaratorId
			{
			pushFollow(FOLLOW_localModifierList_in_formalParameterVarArgDecl7710);
			localModifierList216=localModifierList();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_localModifierList.add(localModifierList216.getTree());
			pushFollow(FOLLOW_type_in_formalParameterVarArgDecl7712);
			type217=type();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_type.add(type217.getTree());
			ELLIPSIS218=(Token)match(input,ELLIPSIS,FOLLOW_ELLIPSIS_in_formalParameterVarArgDecl7714); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_ELLIPSIS.add(ELLIPSIS218);

			pushFollow(FOLLOW_variableDeclaratorId_in_formalParameterVarArgDecl7716);
			variableDeclaratorId219=variableDeclaratorId();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_variableDeclaratorId.add(variableDeclaratorId219.getTree());

			// AST REWRITE
			// elements: type, localModifierList, variableDeclaratorId
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 568:9: -> ^( FORMAL_PARAM_VARARG_DECL localModifierList type variableDeclaratorId )
			{
				// Java.g:568:13: ^( FORMAL_PARAM_VARARG_DECL localModifierList type variableDeclaratorId )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FORMAL_PARAM_VARARG_DECL, "FORMAL_PARAM_VARARG_DECL"), root_1);
				adaptor.addChild(root_1, stream_localModifierList.nextTree());
				adaptor.addChild(root_1, stream_type.nextTree());
				adaptor.addChild(root_1, stream_variableDeclaratorId.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 58, formalParameterVarArgDecl_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "formalParameterVarArgDecl"


	public static class qualifiedIdentifier_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "qualifiedIdentifier"
	// Java.g:571:1: qualifiedIdentifier : ( IDENT -> IDENT ) ( DOT ident= IDENT -> ^( DOT $qualifiedIdentifier $ident) )* ;
	public final JavaParser.qualifiedIdentifier_return qualifiedIdentifier() throws RecognitionException {
		JavaParser.qualifiedIdentifier_return retval = new JavaParser.qualifiedIdentifier_return();
		retval.start = input.LT(1);
		int qualifiedIdentifier_StartIndex = input.index();

		CommonTree root_0 = null;

		Token ident=null;
		Token IDENT220=null;
		Token DOT221=null;

		CommonTree ident_tree=null;
		CommonTree IDENT220_tree=null;
		CommonTree DOT221_tree=null;
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 59) ) { return retval; }

			// Java.g:572:5: ( ( IDENT -> IDENT ) ( DOT ident= IDENT -> ^( DOT $qualifiedIdentifier $ident) )* )
			// Java.g:572:9: ( IDENT -> IDENT ) ( DOT ident= IDENT -> ^( DOT $qualifiedIdentifier $ident) )*
			{
			// Java.g:572:9: ( IDENT -> IDENT )
			// Java.g:572:13: IDENT
			{
			IDENT220=(Token)match(input,IDENT,FOLLOW_IDENT_in_qualifiedIdentifier7760); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_IDENT.add(IDENT220);


			// AST REWRITE
			// elements: IDENT
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 572:33: -> IDENT
			{
				adaptor.addChild(root_0, stream_IDENT.nextNode());
			}


			retval.tree = root_0;
			}

			}

			// Java.g:574:9: ( DOT ident= IDENT -> ^( DOT $qualifiedIdentifier $ident) )*
			loop74:
			while (true) {
				int alt74=2;
				int LA74_0 = input.LA(1);
				if ( (LA74_0==DOT) ) {
					int LA74_2 = input.LA(2);
					if ( (LA74_2==IDENT) ) {
						int LA74_3 = input.LA(3);
						if ( (synpred101_Java()) ) {
							alt74=1;
						}

					}

				}

				switch (alt74) {
				case 1 :
					// Java.g:574:13: DOT ident= IDENT
					{
					DOT221=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedIdentifier7803); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DOT.add(DOT221);

					ident=(Token)match(input,IDENT,FOLLOW_IDENT_in_qualifiedIdentifier7807); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_IDENT.add(ident);


					// AST REWRITE
					// elements: DOT, qualifiedIdentifier, ident
					// token labels: ident
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleTokenStream stream_ident=new RewriteRuleTokenStream(adaptor,"token ident",ident);
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 574:33: -> ^( DOT $qualifiedIdentifier $ident)
					{
						// Java.g:574:37: ^( DOT $qualifiedIdentifier $ident)
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
						adaptor.addChild(root_1, stream_retval.nextTree());
						adaptor.addChild(root_1, stream_ident.nextNode());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;

				default :
					break loop74;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 59, qualifiedIdentifier_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "qualifiedIdentifier"


	public static class annotationList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationList"
	// Java.g:580:1: annotationList : ( annotation )* ;
	public final JavaParser.annotationList_return annotationList() throws RecognitionException {
		JavaParser.annotationList_return retval = new JavaParser.annotationList_return();
		retval.start = input.LT(1);
		int annotationList_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope annotation222 =null;


		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 60) ) { return retval; }

			// Java.g:581:5: ( ( annotation )* )
			// Java.g:581:9: ( annotation )*
			{
			root_0 = (CommonTree)adaptor.nil();


			// Java.g:581:9: ( annotation )*
			loop75:
			while (true) {
				int alt75=2;
				int LA75_0 = input.LA(1);
				if ( (LA75_0==AT) ) {
					int LA75_2 = input.LA(2);
					if ( (LA75_2==IDENT) ) {
						int LA75_3 = input.LA(3);
						if ( (synpred102_Java()) ) {
							alt75=1;
						}

					}

				}

				switch (alt75) {
				case 1 :
					// Java.g:581:9: annotation
					{
					pushFollow(FOLLOW_annotation_in_annotationList7856);
					annotation222=annotation();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, annotation222.getTree());

					}
					break;

				default :
					break loop75;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 60, annotationList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationList"


	public static class annotation_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotation"
	// Java.g:586:1: annotation : AT ^ qualifiedIdentifier ( annotationInit )? ;
	public final JavaParser.annotation_return annotation() throws RecognitionException {
		JavaParser.annotation_return retval = new JavaParser.annotation_return();
		retval.start = input.LT(1);
		int annotation_StartIndex = input.index();

		CommonTree root_0 = null;

		Token AT223=null;
		ParserRuleReturnScope qualifiedIdentifier224 =null;
		ParserRuleReturnScope annotationInit225 =null;

		CommonTree AT223_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 61) ) { return retval; }

			// Java.g:587:5: ( AT ^ qualifiedIdentifier ( annotationInit )? )
			// Java.g:587:9: AT ^ qualifiedIdentifier ( annotationInit )?
			{
			root_0 = (CommonTree)adaptor.nil();


			AT223=(Token)match(input,AT,FOLLOW_AT_in_annotation7890); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			AT223_tree = (CommonTree)adaptor.create(AT223);
			root_0 = (CommonTree)adaptor.becomeRoot(AT223_tree, root_0);
			}

			pushFollow(FOLLOW_qualifiedIdentifier_in_annotation7893);
			qualifiedIdentifier224=qualifiedIdentifier();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedIdentifier224.getTree());

			// Java.g:587:33: ( annotationInit )?
			int alt76=2;
			int LA76_0 = input.LA(1);
			if ( (LA76_0==LPAREN) ) {
				alt76=1;
			}
			switch (alt76) {
				case 1 :
					// Java.g:587:33: annotationInit
					{
					pushFollow(FOLLOW_annotationInit_in_annotation7895);
					annotationInit225=annotationInit();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, annotationInit225.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 61, annotation_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotation"


	public static class annotationInit_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationInit"
	// Java.g:590:1: annotationInit : LPAREN annotationInitializers RPAREN -> ^( ANNOTATION_INIT_BLOCK[$LPAREN, \"ANNOTATION_INIT_BLOCK\"] annotationInitializers ) ;
	public final JavaParser.annotationInit_return annotationInit() throws RecognitionException {
		JavaParser.annotationInit_return retval = new JavaParser.annotationInit_return();
		retval.start = input.LT(1);
		int annotationInit_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LPAREN226=null;
		Token RPAREN228=null;
		ParserRuleReturnScope annotationInitializers227 =null;

		CommonTree LPAREN226_tree=null;
		CommonTree RPAREN228_tree=null;
		RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
		RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
		RewriteRuleSubtreeStream stream_annotationInitializers=new RewriteRuleSubtreeStream(adaptor,"rule annotationInitializers");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 62) ) { return retval; }

			// Java.g:591:5: ( LPAREN annotationInitializers RPAREN -> ^( ANNOTATION_INIT_BLOCK[$LPAREN, \"ANNOTATION_INIT_BLOCK\"] annotationInitializers ) )
			// Java.g:591:9: LPAREN annotationInitializers RPAREN
			{
			LPAREN226=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_annotationInit7915); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LPAREN.add(LPAREN226);

			pushFollow(FOLLOW_annotationInitializers_in_annotationInit7917);
			annotationInitializers227=annotationInitializers();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_annotationInitializers.add(annotationInitializers227.getTree());
			RPAREN228=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_annotationInit7919); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RPAREN.add(RPAREN228);


			// AST REWRITE
			// elements: annotationInitializers
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 592:9: -> ^( ANNOTATION_INIT_BLOCK[$LPAREN, \"ANNOTATION_INIT_BLOCK\"] annotationInitializers )
			{
				// Java.g:592:13: ^( ANNOTATION_INIT_BLOCK[$LPAREN, \"ANNOTATION_INIT_BLOCK\"] annotationInitializers )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ANNOTATION_INIT_BLOCK, LPAREN226, "ANNOTATION_INIT_BLOCK"), root_1);
				adaptor.addChild(root_1, stream_annotationInitializers.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 62, annotationInit_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationInit"


	public static class annotationInitializers_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationInitializers"
	// Java.g:595:1: annotationInitializers : ( annotationInitializer ( COMMA annotationInitializer )* -> ^( ANNOTATION_INIT_KEY_LIST ( annotationInitializer )+ ) | annotationElementValue -> ^( ANNOTATION_INIT_DEFAULT_KEY annotationElementValue ) );
	public final JavaParser.annotationInitializers_return annotationInitializers() throws RecognitionException {
		JavaParser.annotationInitializers_return retval = new JavaParser.annotationInitializers_return();
		retval.start = input.LT(1);
		int annotationInitializers_StartIndex = input.index();

		CommonTree root_0 = null;

		Token COMMA230=null;
		ParserRuleReturnScope annotationInitializer229 =null;
		ParserRuleReturnScope annotationInitializer231 =null;
		ParserRuleReturnScope annotationElementValue232 =null;

		CommonTree COMMA230_tree=null;
		RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
		RewriteRuleSubtreeStream stream_annotationInitializer=new RewriteRuleSubtreeStream(adaptor,"rule annotationInitializer");
		RewriteRuleSubtreeStream stream_annotationElementValue=new RewriteRuleSubtreeStream(adaptor,"rule annotationElementValue");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 63) ) { return retval; }

			// Java.g:596:5: ( annotationInitializer ( COMMA annotationInitializer )* -> ^( ANNOTATION_INIT_KEY_LIST ( annotationInitializer )+ ) | annotationElementValue -> ^( ANNOTATION_INIT_DEFAULT_KEY annotationElementValue ) )
			int alt78=2;
			int LA78_0 = input.LA(1);
			if ( (LA78_0==IDENT) ) {
				int LA78_1 = input.LA(2);
				if ( (LA78_1==ASSIGN) ) {
					alt78=1;
				}
				else if ( (LA78_1==AND||LA78_1==BIT_SHIFT_RIGHT||LA78_1==DEC||LA78_1==DIV||LA78_1==DOT||LA78_1==EQUAL||(LA78_1 >= GREATER_OR_EQUAL && LA78_1 <= GREATER_THAN)||(LA78_1 >= INC && LA78_1 <= INSTANCEOF)||LA78_1==LBRACK||(LA78_1 >= LESS_OR_EQUAL && LA78_1 <= LESS_THAN)||LA78_1==LOGICAL_AND||LA78_1==LOGICAL_OR||LA78_1==LPAREN||LA78_1==MINUS||LA78_1==MOD||LA78_1==NOT_EQUAL||LA78_1==OR||LA78_1==PLUS||LA78_1==QUESTION||LA78_1==RPAREN||LA78_1==SHIFT_LEFT||LA78_1==SHIFT_RIGHT||LA78_1==STAR||LA78_1==XOR) ) {
					alt78=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 78, 1, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

			}
			else if ( (LA78_0==AT||LA78_0==BOOLEAN||LA78_0==BYTE||(LA78_0 >= CHAR && LA78_0 <= CHARACTER_LITERAL)||(LA78_0 >= DEC && LA78_0 <= DECIMAL_LITERAL)||LA78_0==DOUBLE||LA78_0==FALSE||(LA78_0 >= FLOAT && LA78_0 <= FLOATING_POINT_LITERAL)||LA78_0==HEX_LITERAL||LA78_0==INC||LA78_0==INT||LA78_0==LCURLY||LA78_0==LESS_THAN||LA78_0==LOGICAL_NOT||(LA78_0 >= LONG && LA78_0 <= LPAREN)||LA78_0==MINUS||LA78_0==NEW||LA78_0==NOT||LA78_0==NULL||LA78_0==OCTAL_LITERAL||LA78_0==PLUS||LA78_0==SHORT||(LA78_0 >= STRING_LITERAL && LA78_0 <= SUPER)||LA78_0==THIS||LA78_0==TRUE||LA78_0==VOID) ) {
				alt78=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 78, 0, input);
				throw nvae;
			}

			switch (alt78) {
				case 1 :
					// Java.g:596:9: annotationInitializer ( COMMA annotationInitializer )*
					{
					pushFollow(FOLLOW_annotationInitializer_in_annotationInitializers7956);
					annotationInitializer229=annotationInitializer();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_annotationInitializer.add(annotationInitializer229.getTree());
					// Java.g:596:31: ( COMMA annotationInitializer )*
					loop77:
					while (true) {
						int alt77=2;
						int LA77_0 = input.LA(1);
						if ( (LA77_0==COMMA) ) {
							alt77=1;
						}

						switch (alt77) {
						case 1 :
							// Java.g:596:32: COMMA annotationInitializer
							{
							COMMA230=(Token)match(input,COMMA,FOLLOW_COMMA_in_annotationInitializers7959); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_COMMA.add(COMMA230);

							pushFollow(FOLLOW_annotationInitializer_in_annotationInitializers7961);
							annotationInitializer231=annotationInitializer();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_annotationInitializer.add(annotationInitializer231.getTree());
							}
							break;

						default :
							break loop77;
						}
					}


					// AST REWRITE
					// elements: annotationInitializer
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 597:9: -> ^( ANNOTATION_INIT_KEY_LIST ( annotationInitializer )+ )
					{
						// Java.g:597:13: ^( ANNOTATION_INIT_KEY_LIST ( annotationInitializer )+ )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ANNOTATION_INIT_KEY_LIST, "ANNOTATION_INIT_KEY_LIST"), root_1);
						if ( !(stream_annotationInitializer.hasNext()) ) {
							throw new RewriteEarlyExitException();
						}
						while ( stream_annotationInitializer.hasNext() ) {
							adaptor.addChild(root_1, stream_annotationInitializer.nextTree());
						}
						stream_annotationInitializer.reset();

						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 2 :
					// Java.g:598:9: annotationElementValue
					{
					pushFollow(FOLLOW_annotationElementValue_in_annotationInitializers7991);
					annotationElementValue232=annotationElementValue();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_annotationElementValue.add(annotationElementValue232.getTree());

					// AST REWRITE
					// elements: annotationElementValue
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 599:9: -> ^( ANNOTATION_INIT_DEFAULT_KEY annotationElementValue )
					{
						// Java.g:599:13: ^( ANNOTATION_INIT_DEFAULT_KEY annotationElementValue )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ANNOTATION_INIT_DEFAULT_KEY, "ANNOTATION_INIT_DEFAULT_KEY"), root_1);
						adaptor.addChild(root_1, stream_annotationElementValue.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 63, annotationInitializers_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationInitializers"


	public static class annotationInitializer_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationInitializer"
	// Java.g:602:1: annotationInitializer : IDENT ^ ASSIGN ! annotationElementValue ;
	public final JavaParser.annotationInitializer_return annotationInitializer() throws RecognitionException {
		JavaParser.annotationInitializer_return retval = new JavaParser.annotationInitializer_return();
		retval.start = input.LT(1);
		int annotationInitializer_StartIndex = input.index();

		CommonTree root_0 = null;

		Token IDENT233=null;
		Token ASSIGN234=null;
		ParserRuleReturnScope annotationElementValue235 =null;

		CommonTree IDENT233_tree=null;
		CommonTree ASSIGN234_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 64) ) { return retval; }

			// Java.g:603:5: ( IDENT ^ ASSIGN ! annotationElementValue )
			// Java.g:603:9: IDENT ^ ASSIGN ! annotationElementValue
			{
			root_0 = (CommonTree)adaptor.nil();


			IDENT233=(Token)match(input,IDENT,FOLLOW_IDENT_in_annotationInitializer8028); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			IDENT233_tree = (CommonTree)adaptor.create(IDENT233);
			root_0 = (CommonTree)adaptor.becomeRoot(IDENT233_tree, root_0);
			}

			ASSIGN234=(Token)match(input,ASSIGN,FOLLOW_ASSIGN_in_annotationInitializer8031); if (state.failed) return retval;
			pushFollow(FOLLOW_annotationElementValue_in_annotationInitializer8034);
			annotationElementValue235=annotationElementValue();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, annotationElementValue235.getTree());

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 64, annotationInitializer_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationInitializer"


	public static class annotationElementValue_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationElementValue"
	// Java.g:606:1: annotationElementValue : ( annotationElementValueExpression | annotation | annotationElementValueArrayInitializer );
	public final JavaParser.annotationElementValue_return annotationElementValue() throws RecognitionException {
		JavaParser.annotationElementValue_return retval = new JavaParser.annotationElementValue_return();
		retval.start = input.LT(1);
		int annotationElementValue_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope annotationElementValueExpression236 =null;
		ParserRuleReturnScope annotation237 =null;
		ParserRuleReturnScope annotationElementValueArrayInitializer238 =null;


		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 65) ) { return retval; }

			// Java.g:607:5: ( annotationElementValueExpression | annotation | annotationElementValueArrayInitializer )
			int alt79=3;
			switch ( input.LA(1) ) {
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case CHARACTER_LITERAL:
			case DEC:
			case DECIMAL_LITERAL:
			case DOUBLE:
			case FALSE:
			case FLOAT:
			case FLOATING_POINT_LITERAL:
			case HEX_LITERAL:
			case IDENT:
			case INC:
			case INT:
			case LESS_THAN:
			case LOGICAL_NOT:
			case LONG:
			case LPAREN:
			case MINUS:
			case NEW:
			case NOT:
			case NULL:
			case OCTAL_LITERAL:
			case PLUS:
			case SHORT:
			case STRING_LITERAL:
			case SUPER:
			case THIS:
			case TRUE:
			case VOID:
				{
				alt79=1;
				}
				break;
			case AT:
				{
				alt79=2;
				}
				break;
			case LCURLY:
				{
				alt79=3;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 79, 0, input);
				throw nvae;
			}
			switch (alt79) {
				case 1 :
					// Java.g:607:9: annotationElementValueExpression
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_annotationElementValueExpression_in_annotationElementValue8053);
					annotationElementValueExpression236=annotationElementValueExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, annotationElementValueExpression236.getTree());

					}
					break;
				case 2 :
					// Java.g:608:9: annotation
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_annotation_in_annotationElementValue8063);
					annotation237=annotation();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, annotation237.getTree());

					}
					break;
				case 3 :
					// Java.g:609:9: annotationElementValueArrayInitializer
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_annotationElementValueArrayInitializer_in_annotationElementValue8073);
					annotationElementValueArrayInitializer238=annotationElementValueArrayInitializer();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, annotationElementValueArrayInitializer238.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 65, annotationElementValue_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationElementValue"


	public static class annotationElementValueExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationElementValueExpression"
	// Java.g:612:1: annotationElementValueExpression : conditionalExpression -> ^( EXPR conditionalExpression ) ;
	public final JavaParser.annotationElementValueExpression_return annotationElementValueExpression() throws RecognitionException {
		JavaParser.annotationElementValueExpression_return retval = new JavaParser.annotationElementValueExpression_return();
		retval.start = input.LT(1);
		int annotationElementValueExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope conditionalExpression239 =null;

		RewriteRuleSubtreeStream stream_conditionalExpression=new RewriteRuleSubtreeStream(adaptor,"rule conditionalExpression");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 66) ) { return retval; }

			// Java.g:613:5: ( conditionalExpression -> ^( EXPR conditionalExpression ) )
			// Java.g:613:9: conditionalExpression
			{
			pushFollow(FOLLOW_conditionalExpression_in_annotationElementValueExpression8092);
			conditionalExpression239=conditionalExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_conditionalExpression.add(conditionalExpression239.getTree());

			// AST REWRITE
			// elements: conditionalExpression
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 614:9: -> ^( EXPR conditionalExpression )
			{
				// Java.g:614:13: ^( EXPR conditionalExpression )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EXPR, "EXPR"), root_1);
				adaptor.addChild(root_1, stream_conditionalExpression.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 66, annotationElementValueExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationElementValueExpression"


	public static class annotationElementValueArrayInitializer_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationElementValueArrayInitializer"
	// Java.g:617:1: annotationElementValueArrayInitializer : LCURLY ( annotationElementValue ( COMMA annotationElementValue )* )? ( COMMA )? RCURLY -> ^( ANNOTATION_INIT_ARRAY_ELEMENT[$LCURLY, \"ANNOTATION_ELEM_VALUE_ARRAY_INIT\"] ( annotationElementValue )* ) ;
	public final JavaParser.annotationElementValueArrayInitializer_return annotationElementValueArrayInitializer() throws RecognitionException {
		JavaParser.annotationElementValueArrayInitializer_return retval = new JavaParser.annotationElementValueArrayInitializer_return();
		retval.start = input.LT(1);
		int annotationElementValueArrayInitializer_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LCURLY240=null;
		Token COMMA242=null;
		Token COMMA244=null;
		Token RCURLY245=null;
		ParserRuleReturnScope annotationElementValue241 =null;
		ParserRuleReturnScope annotationElementValue243 =null;

		CommonTree LCURLY240_tree=null;
		CommonTree COMMA242_tree=null;
		CommonTree COMMA244_tree=null;
		CommonTree RCURLY245_tree=null;
		RewriteRuleTokenStream stream_COMMA=new RewriteRuleTokenStream(adaptor,"token COMMA");
		RewriteRuleTokenStream stream_LCURLY=new RewriteRuleTokenStream(adaptor,"token LCURLY");
		RewriteRuleTokenStream stream_RCURLY=new RewriteRuleTokenStream(adaptor,"token RCURLY");
		RewriteRuleSubtreeStream stream_annotationElementValue=new RewriteRuleSubtreeStream(adaptor,"rule annotationElementValue");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 67) ) { return retval; }

			// Java.g:618:5: ( LCURLY ( annotationElementValue ( COMMA annotationElementValue )* )? ( COMMA )? RCURLY -> ^( ANNOTATION_INIT_ARRAY_ELEMENT[$LCURLY, \"ANNOTATION_ELEM_VALUE_ARRAY_INIT\"] ( annotationElementValue )* ) )
			// Java.g:618:9: LCURLY ( annotationElementValue ( COMMA annotationElementValue )* )? ( COMMA )? RCURLY
			{
			LCURLY240=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_annotationElementValueArrayInitializer8128); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LCURLY.add(LCURLY240);

			// Java.g:618:16: ( annotationElementValue ( COMMA annotationElementValue )* )?
			int alt81=2;
			int LA81_0 = input.LA(1);
			if ( (LA81_0==AT||LA81_0==BOOLEAN||LA81_0==BYTE||(LA81_0 >= CHAR && LA81_0 <= CHARACTER_LITERAL)||(LA81_0 >= DEC && LA81_0 <= DECIMAL_LITERAL)||LA81_0==DOUBLE||LA81_0==FALSE||(LA81_0 >= FLOAT && LA81_0 <= FLOATING_POINT_LITERAL)||(LA81_0 >= HEX_LITERAL && LA81_0 <= IDENT)||LA81_0==INC||LA81_0==INT||LA81_0==LCURLY||LA81_0==LESS_THAN||LA81_0==LOGICAL_NOT||(LA81_0 >= LONG && LA81_0 <= LPAREN)||LA81_0==MINUS||LA81_0==NEW||LA81_0==NOT||LA81_0==NULL||LA81_0==OCTAL_LITERAL||LA81_0==PLUS||LA81_0==SHORT||(LA81_0 >= STRING_LITERAL && LA81_0 <= SUPER)||LA81_0==THIS||LA81_0==TRUE||LA81_0==VOID) ) {
				alt81=1;
			}
			switch (alt81) {
				case 1 :
					// Java.g:618:17: annotationElementValue ( COMMA annotationElementValue )*
					{
					pushFollow(FOLLOW_annotationElementValue_in_annotationElementValueArrayInitializer8131);
					annotationElementValue241=annotationElementValue();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_annotationElementValue.add(annotationElementValue241.getTree());
					// Java.g:618:40: ( COMMA annotationElementValue )*
					loop80:
					while (true) {
						int alt80=2;
						int LA80_0 = input.LA(1);
						if ( (LA80_0==COMMA) ) {
							int LA80_1 = input.LA(2);
							if ( (LA80_1==AT||LA80_1==BOOLEAN||LA80_1==BYTE||(LA80_1 >= CHAR && LA80_1 <= CHARACTER_LITERAL)||(LA80_1 >= DEC && LA80_1 <= DECIMAL_LITERAL)||LA80_1==DOUBLE||LA80_1==FALSE||(LA80_1 >= FLOAT && LA80_1 <= FLOATING_POINT_LITERAL)||(LA80_1 >= HEX_LITERAL && LA80_1 <= IDENT)||LA80_1==INC||LA80_1==INT||LA80_1==LCURLY||LA80_1==LESS_THAN||LA80_1==LOGICAL_NOT||(LA80_1 >= LONG && LA80_1 <= LPAREN)||LA80_1==MINUS||LA80_1==NEW||LA80_1==NOT||LA80_1==NULL||LA80_1==OCTAL_LITERAL||LA80_1==PLUS||LA80_1==SHORT||(LA80_1 >= STRING_LITERAL && LA80_1 <= SUPER)||LA80_1==THIS||LA80_1==TRUE||LA80_1==VOID) ) {
								alt80=1;
							}

						}

						switch (alt80) {
						case 1 :
							// Java.g:618:41: COMMA annotationElementValue
							{
							COMMA242=(Token)match(input,COMMA,FOLLOW_COMMA_in_annotationElementValueArrayInitializer8134); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_COMMA.add(COMMA242);

							pushFollow(FOLLOW_annotationElementValue_in_annotationElementValueArrayInitializer8136);
							annotationElementValue243=annotationElementValue();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_annotationElementValue.add(annotationElementValue243.getTree());
							}
							break;

						default :
							break loop80;
						}
					}

					}
					break;

			}

			// Java.g:618:74: ( COMMA )?
			int alt82=2;
			int LA82_0 = input.LA(1);
			if ( (LA82_0==COMMA) ) {
				alt82=1;
			}
			switch (alt82) {
				case 1 :
					// Java.g:618:75: COMMA
					{
					COMMA244=(Token)match(input,COMMA,FOLLOW_COMMA_in_annotationElementValueArrayInitializer8143); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_COMMA.add(COMMA244);

					}
					break;

			}

			RCURLY245=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_annotationElementValueArrayInitializer8147); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RCURLY.add(RCURLY245);


			// AST REWRITE
			// elements: annotationElementValue
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 619:9: -> ^( ANNOTATION_INIT_ARRAY_ELEMENT[$LCURLY, \"ANNOTATION_ELEM_VALUE_ARRAY_INIT\"] ( annotationElementValue )* )
			{
				// Java.g:619:13: ^( ANNOTATION_INIT_ARRAY_ELEMENT[$LCURLY, \"ANNOTATION_ELEM_VALUE_ARRAY_INIT\"] ( annotationElementValue )* )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ANNOTATION_INIT_ARRAY_ELEMENT, LCURLY240, "ANNOTATION_ELEM_VALUE_ARRAY_INIT"), root_1);
				// Java.g:619:90: ( annotationElementValue )*
				while ( stream_annotationElementValue.hasNext() ) {
					adaptor.addChild(root_1, stream_annotationElementValue.nextTree());
				}
				stream_annotationElementValue.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 67, annotationElementValueArrayInitializer_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationElementValueArrayInitializer"


	public static class annotationTypeDeclaration_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationTypeDeclaration"
	// Java.g:622:1: annotationTypeDeclaration[CommonTree modifiers] : AT INTERFACE IDENT annotationBody -> ^( AT IDENT annotationBody ) ;
	public final JavaParser.annotationTypeDeclaration_return annotationTypeDeclaration(CommonTree modifiers) throws RecognitionException {
		JavaParser.annotationTypeDeclaration_return retval = new JavaParser.annotationTypeDeclaration_return();
		retval.start = input.LT(1);
		int annotationTypeDeclaration_StartIndex = input.index();

		CommonTree root_0 = null;

		Token AT246=null;
		Token INTERFACE247=null;
		Token IDENT248=null;
		ParserRuleReturnScope annotationBody249 =null;

		CommonTree AT246_tree=null;
		CommonTree INTERFACE247_tree=null;
		CommonTree IDENT248_tree=null;
		RewriteRuleTokenStream stream_AT=new RewriteRuleTokenStream(adaptor,"token AT");
		RewriteRuleTokenStream stream_INTERFACE=new RewriteRuleTokenStream(adaptor,"token INTERFACE");
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleSubtreeStream stream_annotationBody=new RewriteRuleSubtreeStream(adaptor,"rule annotationBody");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 68) ) { return retval; }

			// Java.g:623:5: ( AT INTERFACE IDENT annotationBody -> ^( AT IDENT annotationBody ) )
			// Java.g:623:9: AT INTERFACE IDENT annotationBody
			{
			AT246=(Token)match(input,AT,FOLLOW_AT_in_annotationTypeDeclaration8186); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_AT.add(AT246);

			INTERFACE247=(Token)match(input,INTERFACE,FOLLOW_INTERFACE_in_annotationTypeDeclaration8188); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_INTERFACE.add(INTERFACE247);

			IDENT248=(Token)match(input,IDENT,FOLLOW_IDENT_in_annotationTypeDeclaration8190); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_IDENT.add(IDENT248);

			pushFollow(FOLLOW_annotationBody_in_annotationTypeDeclaration8192);
			annotationBody249=annotationBody();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_annotationBody.add(annotationBody249.getTree());

			// AST REWRITE
			// elements: AT, annotationBody, IDENT
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 624:9: -> ^( AT IDENT annotationBody )
			{
				// Java.g:624:12: ^( AT IDENT annotationBody )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot(stream_AT.nextNode(), root_1);
				adaptor.addChild(root_1, modifiers);
				adaptor.addChild(root_1, stream_IDENT.nextNode());
				adaptor.addChild(root_1, stream_annotationBody.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 68, annotationTypeDeclaration_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationTypeDeclaration"


	public static class annotationBody_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationBody"
	// Java.g:627:1: annotationBody : LCURLY ( annotationScopeDeclarations )* RCURLY -> ^( ANNOTATION_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( annotationScopeDeclarations )* ) ;
	public final JavaParser.annotationBody_return annotationBody() throws RecognitionException {
		JavaParser.annotationBody_return retval = new JavaParser.annotationBody_return();
		retval.start = input.LT(1);
		int annotationBody_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LCURLY250=null;
		Token RCURLY252=null;
		ParserRuleReturnScope annotationScopeDeclarations251 =null;

		CommonTree LCURLY250_tree=null;
		CommonTree RCURLY252_tree=null;
		RewriteRuleTokenStream stream_LCURLY=new RewriteRuleTokenStream(adaptor,"token LCURLY");
		RewriteRuleTokenStream stream_RCURLY=new RewriteRuleTokenStream(adaptor,"token RCURLY");
		RewriteRuleSubtreeStream stream_annotationScopeDeclarations=new RewriteRuleSubtreeStream(adaptor,"rule annotationScopeDeclarations");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 69) ) { return retval; }

			// Java.g:628:5: ( LCURLY ( annotationScopeDeclarations )* RCURLY -> ^( ANNOTATION_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( annotationScopeDeclarations )* ) )
			// Java.g:628:9: LCURLY ( annotationScopeDeclarations )* RCURLY
			{
			LCURLY250=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_annotationBody8231); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LCURLY.add(LCURLY250);

			// Java.g:628:16: ( annotationScopeDeclarations )*
			loop83:
			while (true) {
				int alt83=2;
				int LA83_0 = input.LA(1);
				if ( (LA83_0==ABSTRACT||LA83_0==AT||LA83_0==BOOLEAN||LA83_0==BYTE||LA83_0==CHAR||LA83_0==CLASS||LA83_0==DOUBLE||LA83_0==ENUM||LA83_0==FINAL||LA83_0==FLOAT||LA83_0==IDENT||LA83_0==INT||LA83_0==INTERFACE||LA83_0==LESS_THAN||LA83_0==LONG||LA83_0==NATIVE||(LA83_0 >= PRIVATE && LA83_0 <= PUBLIC)||LA83_0==SHORT||LA83_0==STATIC||LA83_0==STRICTFP||LA83_0==SYNCHRONIZED||LA83_0==TRANSIENT||LA83_0==VOID||LA83_0==VOLATILE) ) {
					alt83=1;
				}

				switch (alt83) {
				case 1 :
					// Java.g:628:16: annotationScopeDeclarations
					{
					pushFollow(FOLLOW_annotationScopeDeclarations_in_annotationBody8233);
					annotationScopeDeclarations251=annotationScopeDeclarations();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_annotationScopeDeclarations.add(annotationScopeDeclarations251.getTree());
					}
					break;

				default :
					break loop83;
				}
			}

			RCURLY252=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_annotationBody8236); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RCURLY.add(RCURLY252);


			// AST REWRITE
			// elements: annotationScopeDeclarations
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 629:9: -> ^( ANNOTATION_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( annotationScopeDeclarations )* )
			{
				// Java.g:629:13: ^( ANNOTATION_TOP_LEVEL_SCOPE[$LCURLY, \"CLASS_TOP_LEVEL_SCOPE\"] ( annotationScopeDeclarations )* )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ANNOTATION_TOP_LEVEL_SCOPE, LCURLY250, "CLASS_TOP_LEVEL_SCOPE"), root_1);
				// Java.g:629:76: ( annotationScopeDeclarations )*
				while ( stream_annotationScopeDeclarations.hasNext() ) {
					adaptor.addChild(root_1, stream_annotationScopeDeclarations.nextTree());
				}
				stream_annotationScopeDeclarations.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 69, annotationBody_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationBody"


	public static class annotationScopeDeclarations_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationScopeDeclarations"
	// Java.g:632:1: annotationScopeDeclarations : ( modifierList type ( IDENT LPAREN RPAREN ( annotationDefaultValue )? SEMI -> ^( ANNOTATION_METHOD_DECL modifierList type IDENT ( annotationDefaultValue )? ) | classFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type classFieldDeclaratorList ) ) | typeDeclaration );
	public final JavaParser.annotationScopeDeclarations_return annotationScopeDeclarations() throws RecognitionException {
		JavaParser.annotationScopeDeclarations_return retval = new JavaParser.annotationScopeDeclarations_return();
		retval.start = input.LT(1);
		int annotationScopeDeclarations_StartIndex = input.index();

		CommonTree root_0 = null;

		Token IDENT255=null;
		Token LPAREN256=null;
		Token RPAREN257=null;
		Token SEMI259=null;
		Token SEMI261=null;
		ParserRuleReturnScope modifierList253 =null;
		ParserRuleReturnScope type254 =null;
		ParserRuleReturnScope annotationDefaultValue258 =null;
		ParserRuleReturnScope classFieldDeclaratorList260 =null;
		ParserRuleReturnScope typeDeclaration262 =null;

		CommonTree IDENT255_tree=null;
		CommonTree LPAREN256_tree=null;
		CommonTree RPAREN257_tree=null;
		CommonTree SEMI259_tree=null;
		CommonTree SEMI261_tree=null;
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
		RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
		RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
		RewriteRuleSubtreeStream stream_annotationDefaultValue=new RewriteRuleSubtreeStream(adaptor,"rule annotationDefaultValue");
		RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
		RewriteRuleSubtreeStream stream_modifierList=new RewriteRuleSubtreeStream(adaptor,"rule modifierList");
		RewriteRuleSubtreeStream stream_classFieldDeclaratorList=new RewriteRuleSubtreeStream(adaptor,"rule classFieldDeclaratorList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 70) ) { return retval; }

			// Java.g:633:5: ( modifierList type ( IDENT LPAREN RPAREN ( annotationDefaultValue )? SEMI -> ^( ANNOTATION_METHOD_DECL modifierList type IDENT ( annotationDefaultValue )? ) | classFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type classFieldDeclaratorList ) ) | typeDeclaration )
			int alt86=2;
			switch ( input.LA(1) ) {
			case PUBLIC:
				{
				int LA86_1 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case PROTECTED:
				{
				int LA86_2 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case PRIVATE:
				{
				int LA86_3 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case STATIC:
				{
				int LA86_4 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case ABSTRACT:
				{
				int LA86_5 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case NATIVE:
				{
				int LA86_6 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case SYNCHRONIZED:
				{
				int LA86_7 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case TRANSIENT:
				{
				int LA86_8 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case VOLATILE:
				{
				int LA86_9 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case STRICTFP:
				{
				int LA86_10 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case FINAL:
				{
				int LA86_11 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case AT:
				{
				int LA86_12 = input.LA(2);
				if ( (synpred114_Java()) ) {
					alt86=1;
				}
				else if ( (true) ) {
					alt86=2;
				}

				}
				break;
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case DOUBLE:
			case FLOAT:
			case IDENT:
			case INT:
			case LONG:
			case SHORT:
				{
				alt86=1;
				}
				break;
			case CLASS:
			case ENUM:
			case INTERFACE:
				{
				alt86=2;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 86, 0, input);
				throw nvae;
			}
			switch (alt86) {
				case 1 :
					// Java.g:633:9: modifierList type ( IDENT LPAREN RPAREN ( annotationDefaultValue )? SEMI -> ^( ANNOTATION_METHOD_DECL modifierList type IDENT ( annotationDefaultValue )? ) | classFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type classFieldDeclaratorList ) )
					{
					pushFollow(FOLLOW_modifierList_in_annotationScopeDeclarations8274);
					modifierList253=modifierList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_modifierList.add(modifierList253.getTree());
					pushFollow(FOLLOW_type_in_annotationScopeDeclarations8276);
					type254=type();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_type.add(type254.getTree());
					// Java.g:634:9: ( IDENT LPAREN RPAREN ( annotationDefaultValue )? SEMI -> ^( ANNOTATION_METHOD_DECL modifierList type IDENT ( annotationDefaultValue )? ) | classFieldDeclaratorList SEMI -> ^( VAR_DECLARATION modifierList type classFieldDeclaratorList ) )
					int alt85=2;
					int LA85_0 = input.LA(1);
					if ( (LA85_0==IDENT) ) {
						int LA85_1 = input.LA(2);
						if ( (LA85_1==LPAREN) ) {
							alt85=1;
						}
						else if ( (LA85_1==ASSIGN||LA85_1==COMMA||LA85_1==LBRACK||LA85_1==SEMI) ) {
							alt85=2;
						}

						else {
							if (state.backtracking>0) {state.failed=true; return retval;}
							int nvaeMark = input.mark();
							try {
								input.consume();
								NoViableAltException nvae =
									new NoViableAltException("", 85, 1, input);
								throw nvae;
							} finally {
								input.rewind(nvaeMark);
							}
						}

					}

					else {
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 85, 0, input);
						throw nvae;
					}

					switch (alt85) {
						case 1 :
							// Java.g:634:13: IDENT LPAREN RPAREN ( annotationDefaultValue )? SEMI
							{
							IDENT255=(Token)match(input,IDENT,FOLLOW_IDENT_in_annotationScopeDeclarations8290); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_IDENT.add(IDENT255);

							LPAREN256=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_annotationScopeDeclarations8292); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_LPAREN.add(LPAREN256);

							RPAREN257=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_annotationScopeDeclarations8294); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_RPAREN.add(RPAREN257);

							// Java.g:634:33: ( annotationDefaultValue )?
							int alt84=2;
							int LA84_0 = input.LA(1);
							if ( (LA84_0==DEFAULT) ) {
								alt84=1;
							}
							switch (alt84) {
								case 1 :
									// Java.g:634:33: annotationDefaultValue
									{
									pushFollow(FOLLOW_annotationDefaultValue_in_annotationScopeDeclarations8296);
									annotationDefaultValue258=annotationDefaultValue();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_annotationDefaultValue.add(annotationDefaultValue258.getTree());
									}
									break;

							}

							SEMI259=(Token)match(input,SEMI,FOLLOW_SEMI_in_annotationScopeDeclarations8299); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SEMI.add(SEMI259);


							// AST REWRITE
							// elements: IDENT, modifierList, annotationDefaultValue, type
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 635:13: -> ^( ANNOTATION_METHOD_DECL modifierList type IDENT ( annotationDefaultValue )? )
							{
								// Java.g:635:17: ^( ANNOTATION_METHOD_DECL modifierList type IDENT ( annotationDefaultValue )? )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ANNOTATION_METHOD_DECL, "ANNOTATION_METHOD_DECL"), root_1);
								adaptor.addChild(root_1, stream_modifierList.nextTree());
								adaptor.addChild(root_1, stream_type.nextTree());
								adaptor.addChild(root_1, stream_IDENT.nextNode());
								// Java.g:635:66: ( annotationDefaultValue )?
								if ( stream_annotationDefaultValue.hasNext() ) {
									adaptor.addChild(root_1, stream_annotationDefaultValue.nextTree());
								}
								stream_annotationDefaultValue.reset();

								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 2 :
							// Java.g:636:13: classFieldDeclaratorList SEMI
							{
							pushFollow(FOLLOW_classFieldDeclaratorList_in_annotationScopeDeclarations8341);
							classFieldDeclaratorList260=classFieldDeclaratorList();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_classFieldDeclaratorList.add(classFieldDeclaratorList260.getTree());
							SEMI261=(Token)match(input,SEMI,FOLLOW_SEMI_in_annotationScopeDeclarations8343); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SEMI.add(SEMI261);


							// AST REWRITE
							// elements: classFieldDeclaratorList, modifierList, type
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 637:13: -> ^( VAR_DECLARATION modifierList type classFieldDeclaratorList )
							{
								// Java.g:637:17: ^( VAR_DECLARATION modifierList type classFieldDeclaratorList )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECLARATION, "VAR_DECLARATION"), root_1);
								adaptor.addChild(root_1, stream_modifierList.nextTree());
								adaptor.addChild(root_1, stream_type.nextTree());
								adaptor.addChild(root_1, stream_classFieldDeclaratorList.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;
				case 2 :
					// Java.g:639:9: typeDeclaration
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_typeDeclaration_in_annotationScopeDeclarations8388);
					typeDeclaration262=typeDeclaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, typeDeclaration262.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 70, annotationScopeDeclarations_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationScopeDeclarations"


	public static class annotationDefaultValue_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "annotationDefaultValue"
	// Java.g:642:1: annotationDefaultValue : DEFAULT ^ annotationElementValue ;
	public final JavaParser.annotationDefaultValue_return annotationDefaultValue() throws RecognitionException {
		JavaParser.annotationDefaultValue_return retval = new JavaParser.annotationDefaultValue_return();
		retval.start = input.LT(1);
		int annotationDefaultValue_StartIndex = input.index();

		CommonTree root_0 = null;

		Token DEFAULT263=null;
		ParserRuleReturnScope annotationElementValue264 =null;

		CommonTree DEFAULT263_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 71) ) { return retval; }

			// Java.g:643:5: ( DEFAULT ^ annotationElementValue )
			// Java.g:643:9: DEFAULT ^ annotationElementValue
			{
			root_0 = (CommonTree)adaptor.nil();


			DEFAULT263=(Token)match(input,DEFAULT,FOLLOW_DEFAULT_in_annotationDefaultValue8407); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			DEFAULT263_tree = (CommonTree)adaptor.create(DEFAULT263);
			root_0 = (CommonTree)adaptor.becomeRoot(DEFAULT263_tree, root_0);
			}

			pushFollow(FOLLOW_annotationElementValue_in_annotationDefaultValue8410);
			annotationElementValue264=annotationElementValue();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, annotationElementValue264.getTree());

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 71, annotationDefaultValue_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "annotationDefaultValue"


	public static class block_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "block"
	// Java.g:648:1: block : LCURLY ( blockStatement )* RCURLY -> ^( BLOCK_SCOPE[$LCURLY, \"JBLOCK\"] ( blockStatement )* ) ;
	public final JavaParser.block_return block() throws RecognitionException {
		JavaParser.block_return retval = new JavaParser.block_return();
		retval.start = input.LT(1);
		int block_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LCURLY265=null;
		Token RCURLY267=null;
		ParserRuleReturnScope blockStatement266 =null;

		CommonTree LCURLY265_tree=null;
		CommonTree RCURLY267_tree=null;
		RewriteRuleTokenStream stream_LCURLY=new RewriteRuleTokenStream(adaptor,"token LCURLY");
		RewriteRuleTokenStream stream_RCURLY=new RewriteRuleTokenStream(adaptor,"token RCURLY");
		RewriteRuleSubtreeStream stream_blockStatement=new RewriteRuleSubtreeStream(adaptor,"rule blockStatement");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 72) ) { return retval; }

			// Java.g:649:5: ( LCURLY ( blockStatement )* RCURLY -> ^( BLOCK_SCOPE[$LCURLY, \"JBLOCK\"] ( blockStatement )* ) )
			// Java.g:649:9: LCURLY ( blockStatement )* RCURLY
			{
			LCURLY265=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_block8431); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LCURLY.add(LCURLY265);

			// Java.g:649:16: ( blockStatement )*
			loop87:
			while (true) {
				int alt87=2;
				int LA87_0 = input.LA(1);
				if ( (LA87_0==ABSTRACT||LA87_0==ASSERT||LA87_0==AT||(LA87_0 >= BOOLEAN && LA87_0 <= BYTE)||(LA87_0 >= CHAR && LA87_0 <= CLASS)||(LA87_0 >= CONTINUE && LA87_0 <= DECIMAL_LITERAL)||LA87_0==DO||LA87_0==DOUBLE||LA87_0==ENUM||(LA87_0 >= FALSE && LA87_0 <= FINAL)||(LA87_0 >= FLOAT && LA87_0 <= FLOATING_POINT_LITERAL)||LA87_0==FOR||(LA87_0 >= HEX_LITERAL && LA87_0 <= IF)||LA87_0==INC||LA87_0==INT||LA87_0==INTERFACE||LA87_0==LCURLY||LA87_0==LESS_THAN||LA87_0==LOGICAL_NOT||(LA87_0 >= LONG && LA87_0 <= LPAREN)||LA87_0==MINUS||(LA87_0 >= NATIVE && LA87_0 <= NEW)||LA87_0==NOT||LA87_0==NULL||LA87_0==OCTAL_LITERAL||LA87_0==PLUS||(LA87_0 >= PRIVATE && LA87_0 <= PUBLIC)||LA87_0==RETURN||LA87_0==SEMI||LA87_0==SHORT||LA87_0==STATIC||(LA87_0 >= STRICTFP && LA87_0 <= SUPER)||LA87_0==SWITCH||(LA87_0 >= SYNCHRONIZED && LA87_0 <= THIS)||LA87_0==THROW||(LA87_0 >= TRANSIENT && LA87_0 <= TRY)||LA87_0==VOID||(LA87_0 >= VOLATILE && LA87_0 <= WHILE)) ) {
					alt87=1;
				}

				switch (alt87) {
				case 1 :
					// Java.g:649:16: blockStatement
					{
					pushFollow(FOLLOW_blockStatement_in_block8433);
					blockStatement266=blockStatement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_blockStatement.add(blockStatement266.getTree());
					}
					break;

				default :
					break loop87;
				}
			}

			RCURLY267=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_block8436); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RCURLY.add(RCURLY267);


			// AST REWRITE
			// elements: blockStatement
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 650:9: -> ^( BLOCK_SCOPE[$LCURLY, \"JBLOCK\"] ( blockStatement )* )
			{
				// Java.g:650:13: ^( BLOCK_SCOPE[$LCURLY, \"JBLOCK\"] ( blockStatement )* )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(BLOCK_SCOPE, LCURLY265, "JBLOCK"), root_1);
				// Java.g:650:46: ( blockStatement )*
				while ( stream_blockStatement.hasNext() ) {
					adaptor.addChild(root_1, stream_blockStatement.nextTree());
				}
				stream_blockStatement.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 72, block_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "block"


	public static class blockStatement_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "blockStatement"
	// Java.g:653:1: blockStatement : ( localVariableDeclaration SEMI !| typeDeclaration | statement );
	public final JavaParser.blockStatement_return blockStatement() throws RecognitionException {
		JavaParser.blockStatement_return retval = new JavaParser.blockStatement_return();
		retval.start = input.LT(1);
		int blockStatement_StartIndex = input.index();

		CommonTree root_0 = null;

		Token SEMI269=null;
		ParserRuleReturnScope localVariableDeclaration268 =null;
		ParserRuleReturnScope typeDeclaration270 =null;
		ParserRuleReturnScope statement271 =null;

		CommonTree SEMI269_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 73) ) { return retval; }

			// Java.g:654:5: ( localVariableDeclaration SEMI !| typeDeclaration | statement )
			int alt88=3;
			switch ( input.LA(1) ) {
			case FINAL:
				{
				int LA88_1 = input.LA(2);
				if ( (synpred116_Java()) ) {
					alt88=1;
				}
				else if ( (synpred117_Java()) ) {
					alt88=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 88, 1, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case AT:
				{
				int LA88_2 = input.LA(2);
				if ( (synpred116_Java()) ) {
					alt88=1;
				}
				else if ( (synpred117_Java()) ) {
					alt88=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 88, 2, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case DOUBLE:
			case FLOAT:
			case INT:
			case LONG:
			case SHORT:
				{
				int LA88_3 = input.LA(2);
				if ( (synpred116_Java()) ) {
					alt88=1;
				}
				else if ( (true) ) {
					alt88=3;
				}

				}
				break;
			case IDENT:
				{
				int LA88_4 = input.LA(2);
				if ( (synpred116_Java()) ) {
					alt88=1;
				}
				else if ( (true) ) {
					alt88=3;
				}

				}
				break;
			case ABSTRACT:
			case CLASS:
			case ENUM:
			case INTERFACE:
			case NATIVE:
			case PRIVATE:
			case PROTECTED:
			case PUBLIC:
			case STATIC:
			case STRICTFP:
			case TRANSIENT:
			case VOLATILE:
				{
				alt88=2;
				}
				break;
			case SYNCHRONIZED:
				{
				int LA88_11 = input.LA(2);
				if ( (synpred117_Java()) ) {
					alt88=2;
				}
				else if ( (true) ) {
					alt88=3;
				}

				}
				break;
			case ASSERT:
			case BREAK:
			case CHARACTER_LITERAL:
			case CONTINUE:
			case DEC:
			case DECIMAL_LITERAL:
			case DO:
			case FALSE:
			case FLOATING_POINT_LITERAL:
			case FOR:
			case HEX_LITERAL:
			case IF:
			case INC:
			case LCURLY:
			case LESS_THAN:
			case LOGICAL_NOT:
			case LPAREN:
			case MINUS:
			case NEW:
			case NOT:
			case NULL:
			case OCTAL_LITERAL:
			case PLUS:
			case RETURN:
			case SEMI:
			case STRING_LITERAL:
			case SUPER:
			case SWITCH:
			case THIS:
			case THROW:
			case TRUE:
			case TRY:
			case VOID:
			case WHILE:
				{
				alt88=3;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 88, 0, input);
				throw nvae;
			}
			switch (alt88) {
				case 1 :
					// Java.g:654:9: localVariableDeclaration SEMI !
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_localVariableDeclaration_in_blockStatement8474);
					localVariableDeclaration268=localVariableDeclaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, localVariableDeclaration268.getTree());

					SEMI269=(Token)match(input,SEMI,FOLLOW_SEMI_in_blockStatement8476); if (state.failed) return retval;
					}
					break;
				case 2 :
					// Java.g:655:9: typeDeclaration
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_typeDeclaration_in_blockStatement8487);
					typeDeclaration270=typeDeclaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, typeDeclaration270.getTree());

					}
					break;
				case 3 :
					// Java.g:656:9: statement
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_statement_in_blockStatement8497);
					statement271=statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, statement271.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 73, blockStatement_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "blockStatement"


	public static class localVariableDeclaration_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "localVariableDeclaration"
	// Java.g:659:1: localVariableDeclaration : localModifierList type classFieldDeclaratorList -> ^( VAR_DECLARATION localModifierList type classFieldDeclaratorList ) ;
	public final JavaParser.localVariableDeclaration_return localVariableDeclaration() throws RecognitionException {
		JavaParser.localVariableDeclaration_return retval = new JavaParser.localVariableDeclaration_return();
		retval.start = input.LT(1);
		int localVariableDeclaration_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope localModifierList272 =null;
		ParserRuleReturnScope type273 =null;
		ParserRuleReturnScope classFieldDeclaratorList274 =null;

		RewriteRuleSubtreeStream stream_localModifierList=new RewriteRuleSubtreeStream(adaptor,"rule localModifierList");
		RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
		RewriteRuleSubtreeStream stream_classFieldDeclaratorList=new RewriteRuleSubtreeStream(adaptor,"rule classFieldDeclaratorList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 74) ) { return retval; }

			// Java.g:660:5: ( localModifierList type classFieldDeclaratorList -> ^( VAR_DECLARATION localModifierList type classFieldDeclaratorList ) )
			// Java.g:660:9: localModifierList type classFieldDeclaratorList
			{
			pushFollow(FOLLOW_localModifierList_in_localVariableDeclaration8516);
			localModifierList272=localModifierList();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_localModifierList.add(localModifierList272.getTree());
			pushFollow(FOLLOW_type_in_localVariableDeclaration8518);
			type273=type();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_type.add(type273.getTree());
			pushFollow(FOLLOW_classFieldDeclaratorList_in_localVariableDeclaration8520);
			classFieldDeclaratorList274=classFieldDeclaratorList();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_classFieldDeclaratorList.add(classFieldDeclaratorList274.getTree());

			// AST REWRITE
			// elements: classFieldDeclaratorList, localModifierList, type
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 661:9: -> ^( VAR_DECLARATION localModifierList type classFieldDeclaratorList )
			{
				// Java.g:661:13: ^( VAR_DECLARATION localModifierList type classFieldDeclaratorList )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(VAR_DECLARATION, "VAR_DECLARATION"), root_1);
				adaptor.addChild(root_1, stream_localModifierList.nextTree());
				adaptor.addChild(root_1, stream_type.nextTree());
				adaptor.addChild(root_1, stream_classFieldDeclaratorList.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 74, localVariableDeclaration_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "localVariableDeclaration"


	public static class statement_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "statement"
	// Java.g:665:1: statement : ( block | ASSERT expr1= expression ( COLON expr2= expression SEMI -> ^( ASSERT $expr1 $expr2) | SEMI -> ^( ASSERT $expr1) ) | IF parenthesizedExpression ifStat= statement ( ELSE elseStat= statement -> ^( IF parenthesizedExpression $ifStat $elseStat) | -> ^( IF parenthesizedExpression $ifStat) ) | FOR LPAREN ( forInit SEMI forCondition SEMI forUpdater RPAREN statement -> ^( FOR forInit forCondition forUpdater statement ) | localModifierList type IDENT COLON expression RPAREN statement -> ^( FOR_EACH[$FOR, \"FOR_EACH\"] localModifierList type IDENT expression statement ) ) | WHILE parenthesizedExpression statement -> ^( WHILE parenthesizedExpression statement ) | DO statement WHILE parenthesizedExpression SEMI -> ^( DO statement parenthesizedExpression ) | TRY block ( catches ( finallyClause )? | finallyClause ) -> ^( TRY block ( catches )? ( finallyClause )? ) | SWITCH parenthesizedExpression LCURLY ( switchBlockLabels )? RCURLY -> ^( SWITCH parenthesizedExpression ( switchBlockLabels )? ) | SYNCHRONIZED parenthesizedExpression block -> ^( SYNCHRONIZED parenthesizedExpression block ) | RETURN ( expression )? SEMI -> ^( RETURN[\"RETURN-STATEMENT\"] ( expression )? ) | THROW expression SEMI -> ^( THROW expression ) | BREAK ( IDENT )? SEMI -> ^( BREAK ( IDENT )? ) | CONTINUE ( IDENT )? SEMI -> ^( CONTINUE ( IDENT )? ) | IDENT COLON statement -> ^( LABELED_STATEMENT IDENT statement ) | expression SEMI !| SEMI );
	public final JavaParser.statement_return statement() throws RecognitionException {
		JavaParser.statement_return retval = new JavaParser.statement_return();
		retval.start = input.LT(1);
		int statement_StartIndex = input.index();

		CommonTree root_0 = null;

		Token ASSERT276=null;
		Token COLON277=null;
		Token SEMI278=null;
		Token SEMI279=null;
		Token IF280=null;
		Token ELSE282=null;
		Token FOR283=null;
		Token LPAREN284=null;
		Token SEMI286=null;
		Token SEMI288=null;
		Token RPAREN290=null;
		Token IDENT294=null;
		Token COLON295=null;
		Token RPAREN297=null;
		Token WHILE299=null;
		Token DO302=null;
		Token WHILE304=null;
		Token SEMI306=null;
		Token TRY307=null;
		Token SWITCH312=null;
		Token LCURLY314=null;
		Token RCURLY316=null;
		Token SYNCHRONIZED317=null;
		Token RETURN320=null;
		Token SEMI322=null;
		Token THROW323=null;
		Token SEMI325=null;
		Token BREAK326=null;
		Token IDENT327=null;
		Token SEMI328=null;
		Token CONTINUE329=null;
		Token IDENT330=null;
		Token SEMI331=null;
		Token IDENT332=null;
		Token COLON333=null;
		Token SEMI336=null;
		Token SEMI337=null;
		ParserRuleReturnScope expr1 =null;
		ParserRuleReturnScope expr2 =null;
		ParserRuleReturnScope ifStat =null;
		ParserRuleReturnScope elseStat =null;
		ParserRuleReturnScope block275 =null;
		ParserRuleReturnScope parenthesizedExpression281 =null;
		ParserRuleReturnScope forInit285 =null;
		ParserRuleReturnScope forCondition287 =null;
		ParserRuleReturnScope forUpdater289 =null;
		ParserRuleReturnScope statement291 =null;
		ParserRuleReturnScope localModifierList292 =null;
		ParserRuleReturnScope type293 =null;
		ParserRuleReturnScope expression296 =null;
		ParserRuleReturnScope statement298 =null;
		ParserRuleReturnScope parenthesizedExpression300 =null;
		ParserRuleReturnScope statement301 =null;
		ParserRuleReturnScope statement303 =null;
		ParserRuleReturnScope parenthesizedExpression305 =null;
		ParserRuleReturnScope block308 =null;
		ParserRuleReturnScope catches309 =null;
		ParserRuleReturnScope finallyClause310 =null;
		ParserRuleReturnScope finallyClause311 =null;
		ParserRuleReturnScope parenthesizedExpression313 =null;
		ParserRuleReturnScope switchBlockLabels315 =null;
		ParserRuleReturnScope parenthesizedExpression318 =null;
		ParserRuleReturnScope block319 =null;
		ParserRuleReturnScope expression321 =null;
		ParserRuleReturnScope expression324 =null;
		ParserRuleReturnScope statement334 =null;
		ParserRuleReturnScope expression335 =null;

		CommonTree ASSERT276_tree=null;
		CommonTree COLON277_tree=null;
		CommonTree SEMI278_tree=null;
		CommonTree SEMI279_tree=null;
		CommonTree IF280_tree=null;
		CommonTree ELSE282_tree=null;
		CommonTree FOR283_tree=null;
		CommonTree LPAREN284_tree=null;
		CommonTree SEMI286_tree=null;
		CommonTree SEMI288_tree=null;
		CommonTree RPAREN290_tree=null;
		CommonTree IDENT294_tree=null;
		CommonTree COLON295_tree=null;
		CommonTree RPAREN297_tree=null;
		CommonTree WHILE299_tree=null;
		CommonTree DO302_tree=null;
		CommonTree WHILE304_tree=null;
		CommonTree SEMI306_tree=null;
		CommonTree TRY307_tree=null;
		CommonTree SWITCH312_tree=null;
		CommonTree LCURLY314_tree=null;
		CommonTree RCURLY316_tree=null;
		CommonTree SYNCHRONIZED317_tree=null;
		CommonTree RETURN320_tree=null;
		CommonTree SEMI322_tree=null;
		CommonTree THROW323_tree=null;
		CommonTree SEMI325_tree=null;
		CommonTree BREAK326_tree=null;
		CommonTree IDENT327_tree=null;
		CommonTree SEMI328_tree=null;
		CommonTree CONTINUE329_tree=null;
		CommonTree IDENT330_tree=null;
		CommonTree SEMI331_tree=null;
		CommonTree IDENT332_tree=null;
		CommonTree COLON333_tree=null;
		CommonTree SEMI336_tree=null;
		CommonTree SEMI337_tree=null;
		RewriteRuleTokenStream stream_SYNCHRONIZED=new RewriteRuleTokenStream(adaptor,"token SYNCHRONIZED");
		RewriteRuleTokenStream stream_ASSERT=new RewriteRuleTokenStream(adaptor,"token ASSERT");
		RewriteRuleTokenStream stream_THROW=new RewriteRuleTokenStream(adaptor,"token THROW");
		RewriteRuleTokenStream stream_SEMI=new RewriteRuleTokenStream(adaptor,"token SEMI");
		RewriteRuleTokenStream stream_FOR=new RewriteRuleTokenStream(adaptor,"token FOR");
		RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
		RewriteRuleTokenStream stream_LCURLY=new RewriteRuleTokenStream(adaptor,"token LCURLY");
		RewriteRuleTokenStream stream_COLON=new RewriteRuleTokenStream(adaptor,"token COLON");
		RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
		RewriteRuleTokenStream stream_DO=new RewriteRuleTokenStream(adaptor,"token DO");
		RewriteRuleTokenStream stream_CONTINUE=new RewriteRuleTokenStream(adaptor,"token CONTINUE");
		RewriteRuleTokenStream stream_RETURN=new RewriteRuleTokenStream(adaptor,"token RETURN");
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleTokenStream stream_BREAK=new RewriteRuleTokenStream(adaptor,"token BREAK");
		RewriteRuleTokenStream stream_ELSE=new RewriteRuleTokenStream(adaptor,"token ELSE");
		RewriteRuleTokenStream stream_WHILE=new RewriteRuleTokenStream(adaptor,"token WHILE");
		RewriteRuleTokenStream stream_TRY=new RewriteRuleTokenStream(adaptor,"token TRY");
		RewriteRuleTokenStream stream_SWITCH=new RewriteRuleTokenStream(adaptor,"token SWITCH");
		RewriteRuleTokenStream stream_IF=new RewriteRuleTokenStream(adaptor,"token IF");
		RewriteRuleTokenStream stream_RCURLY=new RewriteRuleTokenStream(adaptor,"token RCURLY");
		RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
		RewriteRuleSubtreeStream stream_parenthesizedExpression=new RewriteRuleSubtreeStream(adaptor,"rule parenthesizedExpression");
		RewriteRuleSubtreeStream stream_forCondition=new RewriteRuleSubtreeStream(adaptor,"rule forCondition");
		RewriteRuleSubtreeStream stream_forUpdater=new RewriteRuleSubtreeStream(adaptor,"rule forUpdater");
		RewriteRuleSubtreeStream stream_forInit=new RewriteRuleSubtreeStream(adaptor,"rule forInit");
		RewriteRuleSubtreeStream stream_localModifierList=new RewriteRuleSubtreeStream(adaptor,"rule localModifierList");
		RewriteRuleSubtreeStream stream_statement=new RewriteRuleSubtreeStream(adaptor,"rule statement");
		RewriteRuleSubtreeStream stream_catches=new RewriteRuleSubtreeStream(adaptor,"rule catches");
		RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");
		RewriteRuleSubtreeStream stream_switchBlockLabels=new RewriteRuleSubtreeStream(adaptor,"rule switchBlockLabels");
		RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
		RewriteRuleSubtreeStream stream_finallyClause=new RewriteRuleSubtreeStream(adaptor,"rule finallyClause");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 75) ) { return retval; }

			// Java.g:666:5: ( block | ASSERT expr1= expression ( COLON expr2= expression SEMI -> ^( ASSERT $expr1 $expr2) | SEMI -> ^( ASSERT $expr1) ) | IF parenthesizedExpression ifStat= statement ( ELSE elseStat= statement -> ^( IF parenthesizedExpression $ifStat $elseStat) | -> ^( IF parenthesizedExpression $ifStat) ) | FOR LPAREN ( forInit SEMI forCondition SEMI forUpdater RPAREN statement -> ^( FOR forInit forCondition forUpdater statement ) | localModifierList type IDENT COLON expression RPAREN statement -> ^( FOR_EACH[$FOR, \"FOR_EACH\"] localModifierList type IDENT expression statement ) ) | WHILE parenthesizedExpression statement -> ^( WHILE parenthesizedExpression statement ) | DO statement WHILE parenthesizedExpression SEMI -> ^( DO statement parenthesizedExpression ) | TRY block ( catches ( finallyClause )? | finallyClause ) -> ^( TRY block ( catches )? ( finallyClause )? ) | SWITCH parenthesizedExpression LCURLY ( switchBlockLabels )? RCURLY -> ^( SWITCH parenthesizedExpression ( switchBlockLabels )? ) | SYNCHRONIZED parenthesizedExpression block -> ^( SYNCHRONIZED parenthesizedExpression block ) | RETURN ( expression )? SEMI -> ^( RETURN[\"RETURN-STATEMENT\"] ( expression )? ) | THROW expression SEMI -> ^( THROW expression ) | BREAK ( IDENT )? SEMI -> ^( BREAK ( IDENT )? ) | CONTINUE ( IDENT )? SEMI -> ^( CONTINUE ( IDENT )? ) | IDENT COLON statement -> ^( LABELED_STATEMENT IDENT statement ) | expression SEMI !| SEMI )
			int alt98=16;
			switch ( input.LA(1) ) {
			case LCURLY:
				{
				alt98=1;
				}
				break;
			case ASSERT:
				{
				alt98=2;
				}
				break;
			case IF:
				{
				alt98=3;
				}
				break;
			case FOR:
				{
				alt98=4;
				}
				break;
			case WHILE:
				{
				alt98=5;
				}
				break;
			case DO:
				{
				alt98=6;
				}
				break;
			case TRY:
				{
				alt98=7;
				}
				break;
			case SWITCH:
				{
				alt98=8;
				}
				break;
			case SYNCHRONIZED:
				{
				alt98=9;
				}
				break;
			case RETURN:
				{
				alt98=10;
				}
				break;
			case THROW:
				{
				alt98=11;
				}
				break;
			case BREAK:
				{
				alt98=12;
				}
				break;
			case CONTINUE:
				{
				alt98=13;
				}
				break;
			case IDENT:
				{
				int LA98_14 = input.LA(2);
				if ( (LA98_14==COLON) ) {
					alt98=14;
				}
				else if ( ((LA98_14 >= AND && LA98_14 <= AND_ASSIGN)||LA98_14==ASSIGN||(LA98_14 >= BIT_SHIFT_RIGHT && LA98_14 <= BIT_SHIFT_RIGHT_ASSIGN)||LA98_14==DEC||(LA98_14 >= DIV && LA98_14 <= DIV_ASSIGN)||LA98_14==DOT||LA98_14==EQUAL||(LA98_14 >= GREATER_OR_EQUAL && LA98_14 <= GREATER_THAN)||(LA98_14 >= INC && LA98_14 <= INSTANCEOF)||LA98_14==LBRACK||(LA98_14 >= LESS_OR_EQUAL && LA98_14 <= LESS_THAN)||LA98_14==LOGICAL_AND||LA98_14==LOGICAL_OR||LA98_14==LPAREN||(LA98_14 >= MINUS && LA98_14 <= MOD)||LA98_14==MOD_ASSIGN||LA98_14==NOT_EQUAL||(LA98_14 >= OR && LA98_14 <= OR_ASSIGN)||(LA98_14 >= PLUS && LA98_14 <= PLUS_ASSIGN)||LA98_14==QUESTION||(LA98_14 >= SEMI && LA98_14 <= SHIFT_RIGHT_ASSIGN)||(LA98_14 >= STAR && LA98_14 <= STAR_ASSIGN)||(LA98_14 >= XOR && LA98_14 <= XOR_ASSIGN)) ) {
					alt98=15;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 98, 14, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case CHARACTER_LITERAL:
			case DEC:
			case DECIMAL_LITERAL:
			case DOUBLE:
			case FALSE:
			case FLOAT:
			case FLOATING_POINT_LITERAL:
			case HEX_LITERAL:
			case INC:
			case INT:
			case LESS_THAN:
			case LOGICAL_NOT:
			case LONG:
			case LPAREN:
			case MINUS:
			case NEW:
			case NOT:
			case NULL:
			case OCTAL_LITERAL:
			case PLUS:
			case SHORT:
			case STRING_LITERAL:
			case SUPER:
			case THIS:
			case TRUE:
			case VOID:
				{
				alt98=15;
				}
				break;
			case SEMI:
				{
				alt98=16;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 98, 0, input);
				throw nvae;
			}
			switch (alt98) {
				case 1 :
					// Java.g:666:9: block
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_block_in_statement8561);
					block275=block();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, block275.getTree());

					}
					break;
				case 2 :
					// Java.g:667:9: ASSERT expr1= expression ( COLON expr2= expression SEMI -> ^( ASSERT $expr1 $expr2) | SEMI -> ^( ASSERT $expr1) )
					{
					ASSERT276=(Token)match(input,ASSERT,FOLLOW_ASSERT_in_statement8571); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_ASSERT.add(ASSERT276);

					pushFollow(FOLLOW_expression_in_statement8575);
					expr1=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_expression.add(expr1.getTree());
					// Java.g:668:9: ( COLON expr2= expression SEMI -> ^( ASSERT $expr1 $expr2) | SEMI -> ^( ASSERT $expr1) )
					int alt89=2;
					int LA89_0 = input.LA(1);
					if ( (LA89_0==COLON) ) {
						alt89=1;
					}
					else if ( (LA89_0==SEMI) ) {
						alt89=2;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 89, 0, input);
						throw nvae;
					}

					switch (alt89) {
						case 1 :
							// Java.g:668:13: COLON expr2= expression SEMI
							{
							COLON277=(Token)match(input,COLON,FOLLOW_COLON_in_statement8589); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_COLON.add(COLON277);

							pushFollow(FOLLOW_expression_in_statement8593);
							expr2=expression();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_expression.add(expr2.getTree());
							SEMI278=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement8595); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SEMI.add(SEMI278);


							// AST REWRITE
							// elements: ASSERT, expr2, expr1
							// token labels: 
							// rule labels: expr2, expr1, retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_expr2=new RewriteRuleSubtreeStream(adaptor,"rule expr2",expr2!=null?expr2.getTree():null);
							RewriteRuleSubtreeStream stream_expr1=new RewriteRuleSubtreeStream(adaptor,"rule expr1",expr1!=null?expr1.getTree():null);
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 668:77: -> ^( ASSERT $expr1 $expr2)
							{
								// Java.g:668:81: ^( ASSERT $expr1 $expr2)
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_ASSERT.nextNode(), root_1);
								adaptor.addChild(root_1, stream_expr1.nextTree());
								adaptor.addChild(root_1, stream_expr2.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 2 :
							// Java.g:669:13: SEMI
							{
							SEMI279=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement8658); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SEMI.add(SEMI279);


							// AST REWRITE
							// elements: expr1, ASSERT
							// token labels: 
							// rule labels: expr1, retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_expr1=new RewriteRuleSubtreeStream(adaptor,"rule expr1",expr1!=null?expr1.getTree():null);
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 669:77: -> ^( ASSERT $expr1)
							{
								// Java.g:669:81: ^( ASSERT $expr1)
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_ASSERT.nextNode(), root_1);
								adaptor.addChild(root_1, stream_expr1.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;
				case 3 :
					// Java.g:671:9: IF parenthesizedExpression ifStat= statement ( ELSE elseStat= statement -> ^( IF parenthesizedExpression $ifStat $elseStat) | -> ^( IF parenthesizedExpression $ifStat) )
					{
					IF280=(Token)match(input,IF,FOLLOW_IF_in_statement8747); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_IF.add(IF280);

					pushFollow(FOLLOW_parenthesizedExpression_in_statement8749);
					parenthesizedExpression281=parenthesizedExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_parenthesizedExpression.add(parenthesizedExpression281.getTree());
					pushFollow(FOLLOW_statement_in_statement8753);
					ifStat=statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_statement.add(ifStat.getTree());
					// Java.g:672:9: ( ELSE elseStat= statement -> ^( IF parenthesizedExpression $ifStat $elseStat) | -> ^( IF parenthesizedExpression $ifStat) )
					int alt90=2;
					int LA90_0 = input.LA(1);
					if ( (LA90_0==ELSE) ) {
						int LA90_1 = input.LA(2);
						if ( (synpred121_Java()) ) {
							alt90=1;
						}
						else if ( (true) ) {
							alt90=2;
						}

					}
					else if ( (LA90_0==EOF||LA90_0==ABSTRACT||LA90_0==ASSERT||LA90_0==AT||(LA90_0 >= BOOLEAN && LA90_0 <= CASE)||(LA90_0 >= CHAR && LA90_0 <= CLASS)||(LA90_0 >= CONTINUE && LA90_0 <= DEFAULT)||LA90_0==DO||LA90_0==DOUBLE||LA90_0==ENUM||(LA90_0 >= FALSE && LA90_0 <= FINAL)||(LA90_0 >= FLOAT && LA90_0 <= FLOATING_POINT_LITERAL)||LA90_0==FOR||(LA90_0 >= HEX_LITERAL && LA90_0 <= IF)||LA90_0==INC||LA90_0==INT||LA90_0==INTERFACE||LA90_0==LCURLY||LA90_0==LESS_THAN||LA90_0==LOGICAL_NOT||(LA90_0 >= LONG && LA90_0 <= LPAREN)||LA90_0==MINUS||(LA90_0 >= NATIVE && LA90_0 <= NEW)||LA90_0==NOT||LA90_0==NULL||LA90_0==OCTAL_LITERAL||LA90_0==PLUS||(LA90_0 >= PRIVATE && LA90_0 <= PUBLIC)||(LA90_0 >= RCURLY && LA90_0 <= RETURN)||LA90_0==SEMI||LA90_0==SHORT||LA90_0==STATIC||(LA90_0 >= STRICTFP && LA90_0 <= SUPER)||LA90_0==SWITCH||(LA90_0 >= SYNCHRONIZED && LA90_0 <= THIS)||LA90_0==THROW||(LA90_0 >= TRANSIENT && LA90_0 <= TRY)||LA90_0==VOID||(LA90_0 >= VOLATILE && LA90_0 <= WHILE)) ) {
						alt90=2;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 90, 0, input);
						throw nvae;
					}

					switch (alt90) {
						case 1 :
							// Java.g:672:13: ELSE elseStat= statement
							{
							ELSE282=(Token)match(input,ELSE,FOLLOW_ELSE_in_statement8767); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_ELSE.add(ELSE282);

							pushFollow(FOLLOW_statement_in_statement8771);
							elseStat=statement();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_statement.add(elseStat.getTree());

							// AST REWRITE
							// elements: ifStat, elseStat, IF, parenthesizedExpression
							// token labels: 
							// rule labels: ifStat, elseStat, retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_ifStat=new RewriteRuleSubtreeStream(adaptor,"rule ifStat",ifStat!=null?ifStat.getTree():null);
							RewriteRuleSubtreeStream stream_elseStat=new RewriteRuleSubtreeStream(adaptor,"rule elseStat",elseStat!=null?elseStat.getTree():null);
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 672:77: -> ^( IF parenthesizedExpression $ifStat $elseStat)
							{
								// Java.g:672:81: ^( IF parenthesizedExpression $ifStat $elseStat)
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_IF.nextNode(), root_1);
								adaptor.addChild(root_1, stream_parenthesizedExpression.nextTree());
								adaptor.addChild(root_1, stream_ifStat.nextTree());
								adaptor.addChild(root_1, stream_elseStat.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 2 :
							// Java.g:673:77: 
							{

							// AST REWRITE
							// elements: ifStat, parenthesizedExpression, IF
							// token labels: 
							// rule labels: ifStat, retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_ifStat=new RewriteRuleSubtreeStream(adaptor,"rule ifStat",ifStat!=null?ifStat.getTree():null);
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 673:77: -> ^( IF parenthesizedExpression $ifStat)
							{
								// Java.g:673:81: ^( IF parenthesizedExpression $ifStat)
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_IF.nextNode(), root_1);
								adaptor.addChild(root_1, stream_parenthesizedExpression.nextTree());
								adaptor.addChild(root_1, stream_ifStat.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;
				case 4 :
					// Java.g:675:9: FOR LPAREN ( forInit SEMI forCondition SEMI forUpdater RPAREN statement -> ^( FOR forInit forCondition forUpdater statement ) | localModifierList type IDENT COLON expression RPAREN statement -> ^( FOR_EACH[$FOR, \"FOR_EACH\"] localModifierList type IDENT expression statement ) )
					{
					FOR283=(Token)match(input,FOR,FOLLOW_FOR_in_statement8934); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_FOR.add(FOR283);

					LPAREN284=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_statement8936); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_LPAREN.add(LPAREN284);

					// Java.g:676:9: ( forInit SEMI forCondition SEMI forUpdater RPAREN statement -> ^( FOR forInit forCondition forUpdater statement ) | localModifierList type IDENT COLON expression RPAREN statement -> ^( FOR_EACH[$FOR, \"FOR_EACH\"] localModifierList type IDENT expression statement ) )
					int alt91=2;
					switch ( input.LA(1) ) {
					case FINAL:
						{
						int LA91_1 = input.LA(2);
						if ( (synpred123_Java()) ) {
							alt91=1;
						}
						else if ( (true) ) {
							alt91=2;
						}

						}
						break;
					case AT:
						{
						int LA91_2 = input.LA(2);
						if ( (synpred123_Java()) ) {
							alt91=1;
						}
						else if ( (true) ) {
							alt91=2;
						}

						}
						break;
					case BOOLEAN:
					case BYTE:
					case CHAR:
					case DOUBLE:
					case FLOAT:
					case INT:
					case LONG:
					case SHORT:
						{
						int LA91_3 = input.LA(2);
						if ( (synpred123_Java()) ) {
							alt91=1;
						}
						else if ( (true) ) {
							alt91=2;
						}

						}
						break;
					case IDENT:
						{
						int LA91_4 = input.LA(2);
						if ( (synpred123_Java()) ) {
							alt91=1;
						}
						else if ( (true) ) {
							alt91=2;
						}

						}
						break;
					case CHARACTER_LITERAL:
					case DEC:
					case DECIMAL_LITERAL:
					case FALSE:
					case FLOATING_POINT_LITERAL:
					case HEX_LITERAL:
					case INC:
					case LESS_THAN:
					case LOGICAL_NOT:
					case LPAREN:
					case MINUS:
					case NEW:
					case NOT:
					case NULL:
					case OCTAL_LITERAL:
					case PLUS:
					case SEMI:
					case STRING_LITERAL:
					case SUPER:
					case THIS:
					case TRUE:
					case VOID:
						{
						alt91=1;
						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 91, 0, input);
						throw nvae;
					}
					switch (alt91) {
						case 1 :
							// Java.g:676:13: forInit SEMI forCondition SEMI forUpdater RPAREN statement
							{
							pushFollow(FOLLOW_forInit_in_statement8950);
							forInit285=forInit();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_forInit.add(forInit285.getTree());
							SEMI286=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement8952); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SEMI.add(SEMI286);

							pushFollow(FOLLOW_forCondition_in_statement8954);
							forCondition287=forCondition();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_forCondition.add(forCondition287.getTree());
							SEMI288=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement8956); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SEMI.add(SEMI288);

							pushFollow(FOLLOW_forUpdater_in_statement8958);
							forUpdater289=forUpdater();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_forUpdater.add(forUpdater289.getTree());
							RPAREN290=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_statement8960); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_RPAREN.add(RPAREN290);

							pushFollow(FOLLOW_statement_in_statement8962);
							statement291=statement();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_statement.add(statement291.getTree());

							// AST REWRITE
							// elements: FOR, forInit, forCondition, statement, forUpdater
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 676:77: -> ^( FOR forInit forCondition forUpdater statement )
							{
								// Java.g:676:81: ^( FOR forInit forCondition forUpdater statement )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_FOR.nextNode(), root_1);
								adaptor.addChild(root_1, stream_forInit.nextTree());
								adaptor.addChild(root_1, stream_forCondition.nextTree());
								adaptor.addChild(root_1, stream_forUpdater.nextTree());
								adaptor.addChild(root_1, stream_statement.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 2 :
							// Java.g:677:13: localModifierList type IDENT COLON expression RPAREN statement
							{
							pushFollow(FOLLOW_localModifierList_in_statement8996);
							localModifierList292=localModifierList();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_localModifierList.add(localModifierList292.getTree());
							pushFollow(FOLLOW_type_in_statement8998);
							type293=type();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_type.add(type293.getTree());
							IDENT294=(Token)match(input,IDENT,FOLLOW_IDENT_in_statement9000); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_IDENT.add(IDENT294);

							COLON295=(Token)match(input,COLON,FOLLOW_COLON_in_statement9002); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_COLON.add(COLON295);

							pushFollow(FOLLOW_expression_in_statement9004);
							expression296=expression();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_expression.add(expression296.getTree());
							RPAREN297=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_statement9006); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_RPAREN.add(RPAREN297);

							pushFollow(FOLLOW_statement_in_statement9008);
							statement298=statement();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_statement.add(statement298.getTree());

							// AST REWRITE
							// elements: IDENT, type, expression, localModifierList, statement
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 678:77: -> ^( FOR_EACH[$FOR, \"FOR_EACH\"] localModifierList type IDENT expression statement )
							{
								// Java.g:678:81: ^( FOR_EACH[$FOR, \"FOR_EACH\"] localModifierList type IDENT expression statement )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FOR_EACH, FOR283, "FOR_EACH"), root_1);
								adaptor.addChild(root_1, stream_localModifierList.nextTree());
								adaptor.addChild(root_1, stream_type.nextTree());
								adaptor.addChild(root_1, stream_IDENT.nextNode());
								adaptor.addChild(root_1, stream_expression.nextTree());
								adaptor.addChild(root_1, stream_statement.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;
				case 5 :
					// Java.g:680:9: WHILE parenthesizedExpression statement
					{
					WHILE299=(Token)match(input,WHILE,FOLLOW_WHILE_in_statement9122); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_WHILE.add(WHILE299);

					pushFollow(FOLLOW_parenthesizedExpression_in_statement9124);
					parenthesizedExpression300=parenthesizedExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_parenthesizedExpression.add(parenthesizedExpression300.getTree());
					pushFollow(FOLLOW_statement_in_statement9126);
					statement301=statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_statement.add(statement301.getTree());

					// AST REWRITE
					// elements: WHILE, statement, parenthesizedExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 680:77: -> ^( WHILE parenthesizedExpression statement )
					{
						// Java.g:680:81: ^( WHILE parenthesizedExpression statement )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_WHILE.nextNode(), root_1);
						adaptor.addChild(root_1, stream_parenthesizedExpression.nextTree());
						adaptor.addChild(root_1, stream_statement.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 6 :
					// Java.g:681:9: DO statement WHILE parenthesizedExpression SEMI
					{
					DO302=(Token)match(input,DO,FOLLOW_DO_in_statement9175); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DO.add(DO302);

					pushFollow(FOLLOW_statement_in_statement9177);
					statement303=statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_statement.add(statement303.getTree());
					WHILE304=(Token)match(input,WHILE,FOLLOW_WHILE_in_statement9179); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_WHILE.add(WHILE304);

					pushFollow(FOLLOW_parenthesizedExpression_in_statement9181);
					parenthesizedExpression305=parenthesizedExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_parenthesizedExpression.add(parenthesizedExpression305.getTree());
					SEMI306=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement9183); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_SEMI.add(SEMI306);


					// AST REWRITE
					// elements: parenthesizedExpression, DO, statement
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 681:77: -> ^( DO statement parenthesizedExpression )
					{
						// Java.g:681:81: ^( DO statement parenthesizedExpression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_DO.nextNode(), root_1);
						adaptor.addChild(root_1, stream_statement.nextTree());
						adaptor.addChild(root_1, stream_parenthesizedExpression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 7 :
					// Java.g:682:9: TRY block ( catches ( finallyClause )? | finallyClause )
					{
					TRY307=(Token)match(input,TRY,FOLLOW_TRY_in_statement9224); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_TRY.add(TRY307);

					pushFollow(FOLLOW_block_in_statement9226);
					block308=block();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_block.add(block308.getTree());
					// Java.g:682:19: ( catches ( finallyClause )? | finallyClause )
					int alt93=2;
					int LA93_0 = input.LA(1);
					if ( (LA93_0==CATCH) ) {
						alt93=1;
					}
					else if ( (LA93_0==FINALLY) ) {
						alt93=2;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 93, 0, input);
						throw nvae;
					}

					switch (alt93) {
						case 1 :
							// Java.g:682:20: catches ( finallyClause )?
							{
							pushFollow(FOLLOW_catches_in_statement9229);
							catches309=catches();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_catches.add(catches309.getTree());
							// Java.g:682:28: ( finallyClause )?
							int alt92=2;
							int LA92_0 = input.LA(1);
							if ( (LA92_0==FINALLY) ) {
								alt92=1;
							}
							switch (alt92) {
								case 1 :
									// Java.g:682:28: finallyClause
									{
									pushFollow(FOLLOW_finallyClause_in_statement9231);
									finallyClause310=finallyClause();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_finallyClause.add(finallyClause310.getTree());
									}
									break;

							}

							}
							break;
						case 2 :
							// Java.g:682:45: finallyClause
							{
							pushFollow(FOLLOW_finallyClause_in_statement9236);
							finallyClause311=finallyClause();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_finallyClause.add(finallyClause311.getTree());
							}
							break;

					}


					// AST REWRITE
					// elements: catches, block, finallyClause, TRY
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 682:77: -> ^( TRY block ( catches )? ( finallyClause )? )
					{
						// Java.g:682:81: ^( TRY block ( catches )? ( finallyClause )? )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_TRY.nextNode(), root_1);
						adaptor.addChild(root_1, stream_block.nextTree());
						// Java.g:682:93: ( catches )?
						if ( stream_catches.hasNext() ) {
							adaptor.addChild(root_1, stream_catches.nextTree());
						}
						stream_catches.reset();

						// Java.g:682:102: ( finallyClause )?
						if ( stream_finallyClause.hasNext() ) {
							adaptor.addChild(root_1, stream_finallyClause.nextTree());
						}
						stream_finallyClause.reset();

						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 8 :
					// Java.g:683:9: SWITCH parenthesizedExpression LCURLY ( switchBlockLabels )? RCURLY
					{
					SWITCH312=(Token)match(input,SWITCH,FOLLOW_SWITCH_in_statement9279); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_SWITCH.add(SWITCH312);

					pushFollow(FOLLOW_parenthesizedExpression_in_statement9281);
					parenthesizedExpression313=parenthesizedExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_parenthesizedExpression.add(parenthesizedExpression313.getTree());
					LCURLY314=(Token)match(input,LCURLY,FOLLOW_LCURLY_in_statement9283); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_LCURLY.add(LCURLY314);

					// Java.g:683:47: ( switchBlockLabels )?
					int alt94=2;
					int LA94_0 = input.LA(1);
					if ( (LA94_0==CASE||LA94_0==DEFAULT) ) {
						alt94=1;
					}
					else if ( (LA94_0==RCURLY) ) {
						int LA94_2 = input.LA(2);
						if ( (synpred130_Java()) ) {
							alt94=1;
						}
					}
					switch (alt94) {
						case 1 :
							// Java.g:683:47: switchBlockLabels
							{
							pushFollow(FOLLOW_switchBlockLabels_in_statement9285);
							switchBlockLabels315=switchBlockLabels();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_switchBlockLabels.add(switchBlockLabels315.getTree());
							}
							break;

					}

					RCURLY316=(Token)match(input,RCURLY,FOLLOW_RCURLY_in_statement9288); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_RCURLY.add(RCURLY316);


					// AST REWRITE
					// elements: switchBlockLabels, parenthesizedExpression, SWITCH
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 683:78: -> ^( SWITCH parenthesizedExpression ( switchBlockLabels )? )
					{
						// Java.g:683:82: ^( SWITCH parenthesizedExpression ( switchBlockLabels )? )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_SWITCH.nextNode(), root_1);
						adaptor.addChild(root_1, stream_parenthesizedExpression.nextTree());
						// Java.g:683:115: ( switchBlockLabels )?
						if ( stream_switchBlockLabels.hasNext() ) {
							adaptor.addChild(root_1, stream_switchBlockLabels.nextTree());
						}
						stream_switchBlockLabels.reset();

						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 9 :
					// Java.g:684:9: SYNCHRONIZED parenthesizedExpression block
					{
					SYNCHRONIZED317=(Token)match(input,SYNCHRONIZED,FOLLOW_SYNCHRONIZED_in_statement9315); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_SYNCHRONIZED.add(SYNCHRONIZED317);

					pushFollow(FOLLOW_parenthesizedExpression_in_statement9317);
					parenthesizedExpression318=parenthesizedExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_parenthesizedExpression.add(parenthesizedExpression318.getTree());
					pushFollow(FOLLOW_block_in_statement9319);
					block319=block();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_block.add(block319.getTree());

					// AST REWRITE
					// elements: block, SYNCHRONIZED, parenthesizedExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 684:77: -> ^( SYNCHRONIZED parenthesizedExpression block )
					{
						// Java.g:684:81: ^( SYNCHRONIZED parenthesizedExpression block )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_SYNCHRONIZED.nextNode(), root_1);
						adaptor.addChild(root_1, stream_parenthesizedExpression.nextTree());
						adaptor.addChild(root_1, stream_block.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 10 :
					// Java.g:685:9: RETURN ( expression )? SEMI
					{
					RETURN320=(Token)match(input,RETURN,FOLLOW_RETURN_in_statement9365); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_RETURN.add(RETURN320);

					// Java.g:685:16: ( expression )?
					int alt95=2;
					int LA95_0 = input.LA(1);
					if ( (LA95_0==BOOLEAN||LA95_0==BYTE||(LA95_0 >= CHAR && LA95_0 <= CHARACTER_LITERAL)||(LA95_0 >= DEC && LA95_0 <= DECIMAL_LITERAL)||LA95_0==DOUBLE||LA95_0==FALSE||(LA95_0 >= FLOAT && LA95_0 <= FLOATING_POINT_LITERAL)||(LA95_0 >= HEX_LITERAL && LA95_0 <= IDENT)||LA95_0==INC||LA95_0==INT||LA95_0==LESS_THAN||LA95_0==LOGICAL_NOT||(LA95_0 >= LONG && LA95_0 <= LPAREN)||LA95_0==MINUS||LA95_0==NEW||LA95_0==NOT||LA95_0==NULL||LA95_0==OCTAL_LITERAL||LA95_0==PLUS||LA95_0==SHORT||(LA95_0 >= STRING_LITERAL && LA95_0 <= SUPER)||LA95_0==THIS||LA95_0==TRUE||LA95_0==VOID) ) {
						alt95=1;
					}
					switch (alt95) {
						case 1 :
							// Java.g:685:16: expression
							{
							pushFollow(FOLLOW_expression_in_statement9367);
							expression321=expression();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_expression.add(expression321.getTree());
							}
							break;

					}

					SEMI322=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement9370); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_SEMI.add(SEMI322);


					// AST REWRITE
					// elements: RETURN, expression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 685:77: -> ^( RETURN[\"RETURN-STATEMENT\"] ( expression )? )
					{
						// Java.g:685:81: ^( RETURN[\"RETURN-STATEMENT\"] ( expression )? )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(RETURN, "RETURN-STATEMENT"), root_1);
						// Java.g:685:110: ( expression )?
						if ( stream_expression.hasNext() ) {
							adaptor.addChild(root_1, stream_expression.nextTree());
						}
						stream_expression.reset();

						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 11 :
					// Java.g:686:9: THROW expression SEMI
					{
					THROW323=(Token)match(input,THROW,FOLLOW_THROW_in_statement9435); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_THROW.add(THROW323);

					pushFollow(FOLLOW_expression_in_statement9437);
					expression324=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_expression.add(expression324.getTree());
					SEMI325=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement9439); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_SEMI.add(SEMI325);


					// AST REWRITE
					// elements: THROW, expression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 686:77: -> ^( THROW expression )
					{
						// Java.g:686:81: ^( THROW expression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_THROW.nextNode(), root_1);
						adaptor.addChild(root_1, stream_expression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 12 :
					// Java.g:687:9: BREAK ( IDENT )? SEMI
					{
					BREAK326=(Token)match(input,BREAK,FOLLOW_BREAK_in_statement9504); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_BREAK.add(BREAK326);

					// Java.g:687:15: ( IDENT )?
					int alt96=2;
					int LA96_0 = input.LA(1);
					if ( (LA96_0==IDENT) ) {
						alt96=1;
					}
					switch (alt96) {
						case 1 :
							// Java.g:687:15: IDENT
							{
							IDENT327=(Token)match(input,IDENT,FOLLOW_IDENT_in_statement9506); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_IDENT.add(IDENT327);

							}
							break;

					}

					SEMI328=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement9509); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_SEMI.add(SEMI328);


					// AST REWRITE
					// elements: IDENT, BREAK
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 687:77: -> ^( BREAK ( IDENT )? )
					{
						// Java.g:687:81: ^( BREAK ( IDENT )? )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_BREAK.nextNode(), root_1);
						// Java.g:687:89: ( IDENT )?
						if ( stream_IDENT.hasNext() ) {
							adaptor.addChild(root_1, stream_IDENT.nextNode());
						}
						stream_IDENT.reset();

						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 13 :
					// Java.g:688:9: CONTINUE ( IDENT )? SEMI
					{
					CONTINUE329=(Token)match(input,CONTINUE,FOLLOW_CONTINUE_in_statement9579); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_CONTINUE.add(CONTINUE329);

					// Java.g:688:18: ( IDENT )?
					int alt97=2;
					int LA97_0 = input.LA(1);
					if ( (LA97_0==IDENT) ) {
						alt97=1;
					}
					switch (alt97) {
						case 1 :
							// Java.g:688:18: IDENT
							{
							IDENT330=(Token)match(input,IDENT,FOLLOW_IDENT_in_statement9581); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_IDENT.add(IDENT330);

							}
							break;

					}

					SEMI331=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement9584); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_SEMI.add(SEMI331);


					// AST REWRITE
					// elements: IDENT, CONTINUE
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 688:77: -> ^( CONTINUE ( IDENT )? )
					{
						// Java.g:688:81: ^( CONTINUE ( IDENT )? )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_CONTINUE.nextNode(), root_1);
						// Java.g:688:92: ( IDENT )?
						if ( stream_IDENT.hasNext() ) {
							adaptor.addChild(root_1, stream_IDENT.nextNode());
						}
						stream_IDENT.reset();

						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 14 :
					// Java.g:689:9: IDENT COLON statement
					{
					IDENT332=(Token)match(input,IDENT,FOLLOW_IDENT_in_statement9651); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_IDENT.add(IDENT332);

					COLON333=(Token)match(input,COLON,FOLLOW_COLON_in_statement9653); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_COLON.add(COLON333);

					pushFollow(FOLLOW_statement_in_statement9655);
					statement334=statement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_statement.add(statement334.getTree());

					// AST REWRITE
					// elements: IDENT, statement
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 689:77: -> ^( LABELED_STATEMENT IDENT statement )
					{
						// Java.g:689:81: ^( LABELED_STATEMENT IDENT statement )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(LABELED_STATEMENT, "LABELED_STATEMENT"), root_1);
						adaptor.addChild(root_1, stream_IDENT.nextNode());
						adaptor.addChild(root_1, stream_statement.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 15 :
					// Java.g:690:9: expression SEMI !
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_expression_in_statement9722);
					expression335=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, expression335.getTree());

					SEMI336=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement9724); if (state.failed) return retval;
					}
					break;
				case 16 :
					// Java.g:691:9: SEMI
					{
					root_0 = (CommonTree)adaptor.nil();


					SEMI337=(Token)match(input,SEMI,FOLLOW_SEMI_in_statement9735); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					SEMI337_tree = (CommonTree)adaptor.create(SEMI337);
					adaptor.addChild(root_0, SEMI337_tree);
					}

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 75, statement_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "statement"


	public static class catches_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "catches"
	// Java.g:694:1: catches : ( catchClause )+ -> ^( CATCH_CLAUSE_LIST ( catchClause )+ ) ;
	public final JavaParser.catches_return catches() throws RecognitionException {
		JavaParser.catches_return retval = new JavaParser.catches_return();
		retval.start = input.LT(1);
		int catches_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope catchClause338 =null;

		RewriteRuleSubtreeStream stream_catchClause=new RewriteRuleSubtreeStream(adaptor,"rule catchClause");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 76) ) { return retval; }

			// Java.g:695:5: ( ( catchClause )+ -> ^( CATCH_CLAUSE_LIST ( catchClause )+ ) )
			// Java.g:695:9: ( catchClause )+
			{
			// Java.g:695:9: ( catchClause )+
			int cnt99=0;
			loop99:
			while (true) {
				int alt99=2;
				int LA99_0 = input.LA(1);
				if ( (LA99_0==CATCH) ) {
					alt99=1;
				}

				switch (alt99) {
				case 1 :
					// Java.g:695:9: catchClause
					{
					pushFollow(FOLLOW_catchClause_in_catches9755);
					catchClause338=catchClause();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_catchClause.add(catchClause338.getTree());
					}
					break;

				default :
					if ( cnt99 >= 1 ) break loop99;
					if (state.backtracking>0) {state.failed=true; return retval;}
					EarlyExitException eee = new EarlyExitException(99, input);
					throw eee;
				}
				cnt99++;
			}


			// AST REWRITE
			// elements: catchClause
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 696:9: -> ^( CATCH_CLAUSE_LIST ( catchClause )+ )
			{
				// Java.g:696:13: ^( CATCH_CLAUSE_LIST ( catchClause )+ )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CATCH_CLAUSE_LIST, "CATCH_CLAUSE_LIST"), root_1);
				if ( !(stream_catchClause.hasNext()) ) {
					throw new RewriteEarlyExitException();
				}
				while ( stream_catchClause.hasNext() ) {
					adaptor.addChild(root_1, stream_catchClause.nextTree());
				}
				stream_catchClause.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 76, catches_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "catches"


	public static class catchClause_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "catchClause"
	// Java.g:699:1: catchClause : CATCH ^ LPAREN ! formalParameterStandardDecl RPAREN ! block ;
	public final JavaParser.catchClause_return catchClause() throws RecognitionException {
		JavaParser.catchClause_return retval = new JavaParser.catchClause_return();
		retval.start = input.LT(1);
		int catchClause_StartIndex = input.index();

		CommonTree root_0 = null;

		Token CATCH339=null;
		Token LPAREN340=null;
		Token RPAREN342=null;
		ParserRuleReturnScope formalParameterStandardDecl341 =null;
		ParserRuleReturnScope block343 =null;

		CommonTree CATCH339_tree=null;
		CommonTree LPAREN340_tree=null;
		CommonTree RPAREN342_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 77) ) { return retval; }

			// Java.g:700:5: ( CATCH ^ LPAREN ! formalParameterStandardDecl RPAREN ! block )
			// Java.g:700:9: CATCH ^ LPAREN ! formalParameterStandardDecl RPAREN ! block
			{
			root_0 = (CommonTree)adaptor.nil();


			CATCH339=(Token)match(input,CATCH,FOLLOW_CATCH_in_catchClause9793); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			CATCH339_tree = (CommonTree)adaptor.create(CATCH339);
			root_0 = (CommonTree)adaptor.becomeRoot(CATCH339_tree, root_0);
			}

			LPAREN340=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_catchClause9796); if (state.failed) return retval;
			pushFollow(FOLLOW_formalParameterStandardDecl_in_catchClause9799);
			formalParameterStandardDecl341=formalParameterStandardDecl();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, formalParameterStandardDecl341.getTree());

			RPAREN342=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_catchClause9801); if (state.failed) return retval;
			pushFollow(FOLLOW_block_in_catchClause9804);
			block343=block();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, block343.getTree());

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 77, catchClause_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "catchClause"


	public static class finallyClause_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "finallyClause"
	// Java.g:703:1: finallyClause : FINALLY block -> block ;
	public final JavaParser.finallyClause_return finallyClause() throws RecognitionException {
		JavaParser.finallyClause_return retval = new JavaParser.finallyClause_return();
		retval.start = input.LT(1);
		int finallyClause_StartIndex = input.index();

		CommonTree root_0 = null;

		Token FINALLY344=null;
		ParserRuleReturnScope block345 =null;

		CommonTree FINALLY344_tree=null;
		RewriteRuleTokenStream stream_FINALLY=new RewriteRuleTokenStream(adaptor,"token FINALLY");
		RewriteRuleSubtreeStream stream_block=new RewriteRuleSubtreeStream(adaptor,"rule block");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 78) ) { return retval; }

			// Java.g:704:5: ( FINALLY block -> block )
			// Java.g:704:9: FINALLY block
			{
			FINALLY344=(Token)match(input,FINALLY,FOLLOW_FINALLY_in_finallyClause9823); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_FINALLY.add(FINALLY344);

			pushFollow(FOLLOW_block_in_finallyClause9825);
			block345=block();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_block.add(block345.getTree());

			// AST REWRITE
			// elements: block
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 705:9: -> block
			{
				adaptor.addChild(root_0, stream_block.nextTree());
			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 78, finallyClause_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "finallyClause"


	public static class switchBlockLabels_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "switchBlockLabels"
	// Java.g:708:1: switchBlockLabels : (c0= switchCaseLabels )? ( switchDefaultLabel )? (c1= switchCaseLabels )? -> ^( SWITCH_BLOCK_LABEL_LIST ( $c0)? ( switchDefaultLabel )? ( $c1)? ) ;
	public final JavaParser.switchBlockLabels_return switchBlockLabels() throws RecognitionException {
		JavaParser.switchBlockLabels_return retval = new JavaParser.switchBlockLabels_return();
		retval.start = input.LT(1);
		int switchBlockLabels_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope c0 =null;
		ParserRuleReturnScope c1 =null;
		ParserRuleReturnScope switchDefaultLabel346 =null;

		RewriteRuleSubtreeStream stream_switchDefaultLabel=new RewriteRuleSubtreeStream(adaptor,"rule switchDefaultLabel");
		RewriteRuleSubtreeStream stream_switchCaseLabels=new RewriteRuleSubtreeStream(adaptor,"rule switchCaseLabels");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 79) ) { return retval; }

			// Java.g:712:5: ( (c0= switchCaseLabels )? ( switchDefaultLabel )? (c1= switchCaseLabels )? -> ^( SWITCH_BLOCK_LABEL_LIST ( $c0)? ( switchDefaultLabel )? ( $c1)? ) )
			// Java.g:712:9: (c0= switchCaseLabels )? ( switchDefaultLabel )? (c1= switchCaseLabels )?
			{
			// Java.g:712:11: (c0= switchCaseLabels )?
			int alt100=2;
			switch ( input.LA(1) ) {
				case CASE:
					{
					int LA100_1 = input.LA(2);
					if ( (synpred143_Java()) ) {
						alt100=1;
					}
					}
					break;
				case DEFAULT:
					{
					int LA100_2 = input.LA(2);
					if ( (synpred143_Java()) ) {
						alt100=1;
					}
					}
					break;
				case RCURLY:
					{
					int LA100_3 = input.LA(2);
					if ( (synpred143_Java()) ) {
						alt100=1;
					}
					}
					break;
				case EOF:
					{
					int LA100_4 = input.LA(2);
					if ( (synpred143_Java()) ) {
						alt100=1;
					}
					}
					break;
			}
			switch (alt100) {
				case 1 :
					// Java.g:712:11: c0= switchCaseLabels
					{
					pushFollow(FOLLOW_switchCaseLabels_in_switchBlockLabels9874);
					c0=switchCaseLabels();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_switchCaseLabels.add(c0.getTree());
					}
					break;

			}

			// Java.g:712:30: ( switchDefaultLabel )?
			int alt101=2;
			int LA101_0 = input.LA(1);
			if ( (LA101_0==DEFAULT) ) {
				alt101=1;
			}
			switch (alt101) {
				case 1 :
					// Java.g:712:30: switchDefaultLabel
					{
					pushFollow(FOLLOW_switchDefaultLabel_in_switchBlockLabels9877);
					switchDefaultLabel346=switchDefaultLabel();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_switchDefaultLabel.add(switchDefaultLabel346.getTree());
					}
					break;

			}

			// Java.g:712:52: (c1= switchCaseLabels )?
			int alt102=2;
			switch ( input.LA(1) ) {
				case CASE:
					{
					alt102=1;
					}
					break;
				case RCURLY:
					{
					int LA102_2 = input.LA(2);
					if ( (synpred145_Java()) ) {
						alt102=1;
					}
					}
					break;
				case EOF:
					{
					int LA102_3 = input.LA(2);
					if ( (synpred145_Java()) ) {
						alt102=1;
					}
					}
					break;
			}
			switch (alt102) {
				case 1 :
					// Java.g:712:52: c1= switchCaseLabels
					{
					pushFollow(FOLLOW_switchCaseLabels_in_switchBlockLabels9882);
					c1=switchCaseLabels();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_switchCaseLabels.add(c1.getTree());
					}
					break;

			}


			// AST REWRITE
			// elements: c1, c0, switchDefaultLabel
			// token labels: 
			// rule labels: c0, c1, retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_c0=new RewriteRuleSubtreeStream(adaptor,"rule c0",c0!=null?c0.getTree():null);
			RewriteRuleSubtreeStream stream_c1=new RewriteRuleSubtreeStream(adaptor,"rule c1",c1!=null?c1.getTree():null);
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 713:9: -> ^( SWITCH_BLOCK_LABEL_LIST ( $c0)? ( switchDefaultLabel )? ( $c1)? )
			{
				// Java.g:713:13: ^( SWITCH_BLOCK_LABEL_LIST ( $c0)? ( switchDefaultLabel )? ( $c1)? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(SWITCH_BLOCK_LABEL_LIST, "SWITCH_BLOCK_LABEL_LIST"), root_1);
				// Java.g:713:40: ( $c0)?
				if ( stream_c0.hasNext() ) {
					adaptor.addChild(root_1, stream_c0.nextTree());
				}
				stream_c0.reset();

				// Java.g:713:44: ( switchDefaultLabel )?
				if ( stream_switchDefaultLabel.hasNext() ) {
					adaptor.addChild(root_1, stream_switchDefaultLabel.nextTree());
				}
				stream_switchDefaultLabel.reset();

				// Java.g:713:65: ( $c1)?
				if ( stream_c1.hasNext() ) {
					adaptor.addChild(root_1, stream_c1.nextTree());
				}
				stream_c1.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 79, switchBlockLabels_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "switchBlockLabels"


	public static class switchCaseLabels_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "switchCaseLabels"
	// Java.g:716:1: switchCaseLabels : ( switchCaseLabel )* ;
	public final JavaParser.switchCaseLabels_return switchCaseLabels() throws RecognitionException {
		JavaParser.switchCaseLabels_return retval = new JavaParser.switchCaseLabels_return();
		retval.start = input.LT(1);
		int switchCaseLabels_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope switchCaseLabel347 =null;


		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 80) ) { return retval; }

			// Java.g:717:5: ( ( switchCaseLabel )* )
			// Java.g:717:9: ( switchCaseLabel )*
			{
			root_0 = (CommonTree)adaptor.nil();


			// Java.g:717:9: ( switchCaseLabel )*
			loop103:
			while (true) {
				int alt103=2;
				int LA103_0 = input.LA(1);
				if ( (LA103_0==CASE) ) {
					int LA103_2 = input.LA(2);
					if ( (synpred146_Java()) ) {
						alt103=1;
					}

				}

				switch (alt103) {
				case 1 :
					// Java.g:717:9: switchCaseLabel
					{
					pushFollow(FOLLOW_switchCaseLabel_in_switchCaseLabels9928);
					switchCaseLabel347=switchCaseLabel();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, switchCaseLabel347.getTree());

					}
					break;

				default :
					break loop103;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 80, switchCaseLabels_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "switchCaseLabels"


	public static class switchCaseLabel_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "switchCaseLabel"
	// Java.g:720:1: switchCaseLabel : CASE ^ expression COLON ! ( blockStatement )* ;
	public final JavaParser.switchCaseLabel_return switchCaseLabel() throws RecognitionException {
		JavaParser.switchCaseLabel_return retval = new JavaParser.switchCaseLabel_return();
		retval.start = input.LT(1);
		int switchCaseLabel_StartIndex = input.index();

		CommonTree root_0 = null;

		Token CASE348=null;
		Token COLON350=null;
		ParserRuleReturnScope expression349 =null;
		ParserRuleReturnScope blockStatement351 =null;

		CommonTree CASE348_tree=null;
		CommonTree COLON350_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 81) ) { return retval; }

			// Java.g:721:5: ( CASE ^ expression COLON ! ( blockStatement )* )
			// Java.g:721:9: CASE ^ expression COLON ! ( blockStatement )*
			{
			root_0 = (CommonTree)adaptor.nil();


			CASE348=(Token)match(input,CASE,FOLLOW_CASE_in_switchCaseLabel9948); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			CASE348_tree = (CommonTree)adaptor.create(CASE348);
			root_0 = (CommonTree)adaptor.becomeRoot(CASE348_tree, root_0);
			}

			pushFollow(FOLLOW_expression_in_switchCaseLabel9951);
			expression349=expression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, expression349.getTree());

			COLON350=(Token)match(input,COLON,FOLLOW_COLON_in_switchCaseLabel9953); if (state.failed) return retval;
			// Java.g:721:33: ( blockStatement )*
			loop104:
			while (true) {
				int alt104=2;
				int LA104_0 = input.LA(1);
				if ( (LA104_0==ABSTRACT||LA104_0==ASSERT||LA104_0==AT||(LA104_0 >= BOOLEAN && LA104_0 <= BYTE)||(LA104_0 >= CHAR && LA104_0 <= CLASS)||(LA104_0 >= CONTINUE && LA104_0 <= DECIMAL_LITERAL)||LA104_0==DO||LA104_0==DOUBLE||LA104_0==ENUM||(LA104_0 >= FALSE && LA104_0 <= FINAL)||(LA104_0 >= FLOAT && LA104_0 <= FLOATING_POINT_LITERAL)||LA104_0==FOR||(LA104_0 >= HEX_LITERAL && LA104_0 <= IF)||LA104_0==INC||LA104_0==INT||LA104_0==INTERFACE||LA104_0==LCURLY||LA104_0==LESS_THAN||LA104_0==LOGICAL_NOT||(LA104_0 >= LONG && LA104_0 <= LPAREN)||LA104_0==MINUS||(LA104_0 >= NATIVE && LA104_0 <= NEW)||LA104_0==NOT||LA104_0==NULL||LA104_0==OCTAL_LITERAL||LA104_0==PLUS||(LA104_0 >= PRIVATE && LA104_0 <= PUBLIC)||LA104_0==RETURN||LA104_0==SEMI||LA104_0==SHORT||LA104_0==STATIC||(LA104_0 >= STRICTFP && LA104_0 <= SUPER)||LA104_0==SWITCH||(LA104_0 >= SYNCHRONIZED && LA104_0 <= THIS)||LA104_0==THROW||(LA104_0 >= TRANSIENT && LA104_0 <= TRY)||LA104_0==VOID||(LA104_0 >= VOLATILE && LA104_0 <= WHILE)) ) {
					alt104=1;
				}

				switch (alt104) {
				case 1 :
					// Java.g:721:33: blockStatement
					{
					pushFollow(FOLLOW_blockStatement_in_switchCaseLabel9956);
					blockStatement351=blockStatement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, blockStatement351.getTree());

					}
					break;

				default :
					break loop104;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 81, switchCaseLabel_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "switchCaseLabel"


	public static class switchDefaultLabel_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "switchDefaultLabel"
	// Java.g:724:1: switchDefaultLabel : DEFAULT ^ COLON ! ( blockStatement )* ;
	public final JavaParser.switchDefaultLabel_return switchDefaultLabel() throws RecognitionException {
		JavaParser.switchDefaultLabel_return retval = new JavaParser.switchDefaultLabel_return();
		retval.start = input.LT(1);
		int switchDefaultLabel_StartIndex = input.index();

		CommonTree root_0 = null;

		Token DEFAULT352=null;
		Token COLON353=null;
		ParserRuleReturnScope blockStatement354 =null;

		CommonTree DEFAULT352_tree=null;
		CommonTree COLON353_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 82) ) { return retval; }

			// Java.g:725:5: ( DEFAULT ^ COLON ! ( blockStatement )* )
			// Java.g:725:9: DEFAULT ^ COLON ! ( blockStatement )*
			{
			root_0 = (CommonTree)adaptor.nil();


			DEFAULT352=(Token)match(input,DEFAULT,FOLLOW_DEFAULT_in_switchDefaultLabel9976); if (state.failed) return retval;
			if ( state.backtracking==0 ) {
			DEFAULT352_tree = (CommonTree)adaptor.create(DEFAULT352);
			root_0 = (CommonTree)adaptor.becomeRoot(DEFAULT352_tree, root_0);
			}

			COLON353=(Token)match(input,COLON,FOLLOW_COLON_in_switchDefaultLabel9979); if (state.failed) return retval;
			// Java.g:725:25: ( blockStatement )*
			loop105:
			while (true) {
				int alt105=2;
				int LA105_0 = input.LA(1);
				if ( (LA105_0==ABSTRACT||LA105_0==ASSERT||LA105_0==AT||(LA105_0 >= BOOLEAN && LA105_0 <= BYTE)||(LA105_0 >= CHAR && LA105_0 <= CLASS)||(LA105_0 >= CONTINUE && LA105_0 <= DECIMAL_LITERAL)||LA105_0==DO||LA105_0==DOUBLE||LA105_0==ENUM||(LA105_0 >= FALSE && LA105_0 <= FINAL)||(LA105_0 >= FLOAT && LA105_0 <= FLOATING_POINT_LITERAL)||LA105_0==FOR||(LA105_0 >= HEX_LITERAL && LA105_0 <= IF)||LA105_0==INC||LA105_0==INT||LA105_0==INTERFACE||LA105_0==LCURLY||LA105_0==LESS_THAN||LA105_0==LOGICAL_NOT||(LA105_0 >= LONG && LA105_0 <= LPAREN)||LA105_0==MINUS||(LA105_0 >= NATIVE && LA105_0 <= NEW)||LA105_0==NOT||LA105_0==NULL||LA105_0==OCTAL_LITERAL||LA105_0==PLUS||(LA105_0 >= PRIVATE && LA105_0 <= PUBLIC)||LA105_0==RETURN||LA105_0==SEMI||LA105_0==SHORT||LA105_0==STATIC||(LA105_0 >= STRICTFP && LA105_0 <= SUPER)||LA105_0==SWITCH||(LA105_0 >= SYNCHRONIZED && LA105_0 <= THIS)||LA105_0==THROW||(LA105_0 >= TRANSIENT && LA105_0 <= TRY)||LA105_0==VOID||(LA105_0 >= VOLATILE && LA105_0 <= WHILE)) ) {
					alt105=1;
				}

				switch (alt105) {
				case 1 :
					// Java.g:725:25: blockStatement
					{
					pushFollow(FOLLOW_blockStatement_in_switchDefaultLabel9982);
					blockStatement354=blockStatement();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, blockStatement354.getTree());

					}
					break;

				default :
					break loop105;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 82, switchDefaultLabel_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "switchDefaultLabel"


	public static class forInit_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "forInit"
	// Java.g:728:1: forInit : ( localVariableDeclaration -> ^( FOR_INIT localVariableDeclaration ) | expressionList -> ^( FOR_INIT expressionList ) | -> ^( FOR_INIT ) );
	public final JavaParser.forInit_return forInit() throws RecognitionException {
		JavaParser.forInit_return retval = new JavaParser.forInit_return();
		retval.start = input.LT(1);
		int forInit_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope localVariableDeclaration355 =null;
		ParserRuleReturnScope expressionList356 =null;

		RewriteRuleSubtreeStream stream_localVariableDeclaration=new RewriteRuleSubtreeStream(adaptor,"rule localVariableDeclaration");
		RewriteRuleSubtreeStream stream_expressionList=new RewriteRuleSubtreeStream(adaptor,"rule expressionList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 83) ) { return retval; }

			// Java.g:729:5: ( localVariableDeclaration -> ^( FOR_INIT localVariableDeclaration ) | expressionList -> ^( FOR_INIT expressionList ) | -> ^( FOR_INIT ) )
			int alt106=3;
			switch ( input.LA(1) ) {
			case AT:
			case FINAL:
				{
				alt106=1;
				}
				break;
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case DOUBLE:
			case FLOAT:
			case INT:
			case LONG:
			case SHORT:
				{
				int LA106_3 = input.LA(2);
				if ( (synpred149_Java()) ) {
					alt106=1;
				}
				else if ( (synpred150_Java()) ) {
					alt106=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 106, 3, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case IDENT:
				{
				int LA106_4 = input.LA(2);
				if ( (synpred149_Java()) ) {
					alt106=1;
				}
				else if ( (synpred150_Java()) ) {
					alt106=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 106, 4, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case CHARACTER_LITERAL:
			case DEC:
			case DECIMAL_LITERAL:
			case FALSE:
			case FLOATING_POINT_LITERAL:
			case HEX_LITERAL:
			case INC:
			case LESS_THAN:
			case LOGICAL_NOT:
			case LPAREN:
			case MINUS:
			case NEW:
			case NOT:
			case NULL:
			case OCTAL_LITERAL:
			case PLUS:
			case STRING_LITERAL:
			case SUPER:
			case THIS:
			case TRUE:
			case VOID:
				{
				alt106=2;
				}
				break;
			case SEMI:
				{
				alt106=3;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 106, 0, input);
				throw nvae;
			}
			switch (alt106) {
				case 1 :
					// Java.g:729:9: localVariableDeclaration
					{
					pushFollow(FOLLOW_localVariableDeclaration_in_forInit10002);
					localVariableDeclaration355=localVariableDeclaration();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_localVariableDeclaration.add(localVariableDeclaration355.getTree());

					// AST REWRITE
					// elements: localVariableDeclaration
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 729:37: -> ^( FOR_INIT localVariableDeclaration )
					{
						// Java.g:729:41: ^( FOR_INIT localVariableDeclaration )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FOR_INIT, "FOR_INIT"), root_1);
						adaptor.addChild(root_1, stream_localVariableDeclaration.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 2 :
					// Java.g:730:9: expressionList
					{
					pushFollow(FOLLOW_expressionList_in_forInit10024);
					expressionList356=expressionList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_expressionList.add(expressionList356.getTree());

					// AST REWRITE
					// elements: expressionList
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 730:37: -> ^( FOR_INIT expressionList )
					{
						// Java.g:730:41: ^( FOR_INIT expressionList )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FOR_INIT, "FOR_INIT"), root_1);
						adaptor.addChild(root_1, stream_expressionList.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 3 :
					// Java.g:731:37: 
					{

					// AST REWRITE
					// elements: 
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 731:37: -> ^( FOR_INIT )
					{
						// Java.g:731:41: ^( FOR_INIT )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FOR_INIT, "FOR_INIT"), root_1);
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 83, forInit_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "forInit"


	public static class forCondition_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "forCondition"
	// Java.g:734:1: forCondition : ( expression )? -> ^( FOR_CONDITION ( expression )? ) ;
	public final JavaParser.forCondition_return forCondition() throws RecognitionException {
		JavaParser.forCondition_return retval = new JavaParser.forCondition_return();
		retval.start = input.LT(1);
		int forCondition_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope expression357 =null;

		RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 84) ) { return retval; }

			// Java.g:735:5: ( ( expression )? -> ^( FOR_CONDITION ( expression )? ) )
			// Java.g:735:9: ( expression )?
			{
			// Java.g:735:9: ( expression )?
			int alt107=2;
			int LA107_0 = input.LA(1);
			if ( (LA107_0==BOOLEAN||LA107_0==BYTE||(LA107_0 >= CHAR && LA107_0 <= CHARACTER_LITERAL)||(LA107_0 >= DEC && LA107_0 <= DECIMAL_LITERAL)||LA107_0==DOUBLE||LA107_0==FALSE||(LA107_0 >= FLOAT && LA107_0 <= FLOATING_POINT_LITERAL)||(LA107_0 >= HEX_LITERAL && LA107_0 <= IDENT)||LA107_0==INC||LA107_0==INT||LA107_0==LESS_THAN||LA107_0==LOGICAL_NOT||(LA107_0 >= LONG && LA107_0 <= LPAREN)||LA107_0==MINUS||LA107_0==NEW||LA107_0==NOT||LA107_0==NULL||LA107_0==OCTAL_LITERAL||LA107_0==PLUS||LA107_0==SHORT||(LA107_0 >= STRING_LITERAL && LA107_0 <= SUPER)||LA107_0==THIS||LA107_0==TRUE||LA107_0==VOID) ) {
				alt107=1;
			}
			switch (alt107) {
				case 1 :
					// Java.g:735:9: expression
					{
					pushFollow(FOLLOW_expression_in_forCondition10108);
					expression357=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_expression.add(expression357.getTree());
					}
					break;

			}


			// AST REWRITE
			// elements: expression
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 736:9: -> ^( FOR_CONDITION ( expression )? )
			{
				// Java.g:736:13: ^( FOR_CONDITION ( expression )? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FOR_CONDITION, "FOR_CONDITION"), root_1);
				// Java.g:736:29: ( expression )?
				if ( stream_expression.hasNext() ) {
					adaptor.addChild(root_1, stream_expression.nextTree());
				}
				stream_expression.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 84, forCondition_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "forCondition"


	public static class forUpdater_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "forUpdater"
	// Java.g:739:1: forUpdater : ( expressionList )? -> ^( FOR_UPDATE ( expressionList )? ) ;
	public final JavaParser.forUpdater_return forUpdater() throws RecognitionException {
		JavaParser.forUpdater_return retval = new JavaParser.forUpdater_return();
		retval.start = input.LT(1);
		int forUpdater_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope expressionList358 =null;

		RewriteRuleSubtreeStream stream_expressionList=new RewriteRuleSubtreeStream(adaptor,"rule expressionList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 85) ) { return retval; }

			// Java.g:740:5: ( ( expressionList )? -> ^( FOR_UPDATE ( expressionList )? ) )
			// Java.g:740:9: ( expressionList )?
			{
			// Java.g:740:9: ( expressionList )?
			int alt108=2;
			int LA108_0 = input.LA(1);
			if ( (LA108_0==BOOLEAN||LA108_0==BYTE||(LA108_0 >= CHAR && LA108_0 <= CHARACTER_LITERAL)||(LA108_0 >= DEC && LA108_0 <= DECIMAL_LITERAL)||LA108_0==DOUBLE||LA108_0==FALSE||(LA108_0 >= FLOAT && LA108_0 <= FLOATING_POINT_LITERAL)||(LA108_0 >= HEX_LITERAL && LA108_0 <= IDENT)||LA108_0==INC||LA108_0==INT||LA108_0==LESS_THAN||LA108_0==LOGICAL_NOT||(LA108_0 >= LONG && LA108_0 <= LPAREN)||LA108_0==MINUS||LA108_0==NEW||LA108_0==NOT||LA108_0==NULL||LA108_0==OCTAL_LITERAL||LA108_0==PLUS||LA108_0==SHORT||(LA108_0 >= STRING_LITERAL && LA108_0 <= SUPER)||LA108_0==THIS||LA108_0==TRUE||LA108_0==VOID) ) {
				alt108=1;
			}
			switch (alt108) {
				case 1 :
					// Java.g:740:9: expressionList
					{
					pushFollow(FOLLOW_expressionList_in_forUpdater10146);
					expressionList358=expressionList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_expressionList.add(expressionList358.getTree());
					}
					break;

			}


			// AST REWRITE
			// elements: expressionList
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 741:9: -> ^( FOR_UPDATE ( expressionList )? )
			{
				// Java.g:741:13: ^( FOR_UPDATE ( expressionList )? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FOR_UPDATE, "FOR_UPDATE"), root_1);
				// Java.g:741:26: ( expressionList )?
				if ( stream_expressionList.hasNext() ) {
					adaptor.addChild(root_1, stream_expressionList.nextTree());
				}
				stream_expressionList.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 85, forUpdater_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "forUpdater"


	public static class parenthesizedExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "parenthesizedExpression"
	// Java.g:746:1: parenthesizedExpression : LPAREN expression RPAREN -> ^( PARENTESIZED_EXPR[$LPAREN, \"PARENTESIZED_EXPR\"] expression ) ;
	public final JavaParser.parenthesizedExpression_return parenthesizedExpression() throws RecognitionException {
		JavaParser.parenthesizedExpression_return retval = new JavaParser.parenthesizedExpression_return();
		retval.start = input.LT(1);
		int parenthesizedExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LPAREN359=null;
		Token RPAREN361=null;
		ParserRuleReturnScope expression360 =null;

		CommonTree LPAREN359_tree=null;
		CommonTree RPAREN361_tree=null;
		RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
		RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
		RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 86) ) { return retval; }

			// Java.g:747:5: ( LPAREN expression RPAREN -> ^( PARENTESIZED_EXPR[$LPAREN, \"PARENTESIZED_EXPR\"] expression ) )
			// Java.g:747:9: LPAREN expression RPAREN
			{
			LPAREN359=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_parenthesizedExpression10186); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LPAREN.add(LPAREN359);

			pushFollow(FOLLOW_expression_in_parenthesizedExpression10188);
			expression360=expression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_expression.add(expression360.getTree());
			RPAREN361=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_parenthesizedExpression10190); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RPAREN.add(RPAREN361);


			// AST REWRITE
			// elements: expression
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 748:9: -> ^( PARENTESIZED_EXPR[$LPAREN, \"PARENTESIZED_EXPR\"] expression )
			{
				// Java.g:748:13: ^( PARENTESIZED_EXPR[$LPAREN, \"PARENTESIZED_EXPR\"] expression )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(PARENTESIZED_EXPR, LPAREN359, "PARENTESIZED_EXPR"), root_1);
				adaptor.addChild(root_1, stream_expression.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 86, parenthesizedExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "parenthesizedExpression"


	public static class expressionList_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "expressionList"
	// Java.g:751:1: expressionList : expression ( COMMA ! expression )* ;
	public final JavaParser.expressionList_return expressionList() throws RecognitionException {
		JavaParser.expressionList_return retval = new JavaParser.expressionList_return();
		retval.start = input.LT(1);
		int expressionList_StartIndex = input.index();

		CommonTree root_0 = null;

		Token COMMA363=null;
		ParserRuleReturnScope expression362 =null;
		ParserRuleReturnScope expression364 =null;

		CommonTree COMMA363_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 87) ) { return retval; }

			// Java.g:752:5: ( expression ( COMMA ! expression )* )
			// Java.g:752:9: expression ( COMMA ! expression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_expression_in_expressionList10227);
			expression362=expression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, expression362.getTree());

			// Java.g:752:20: ( COMMA ! expression )*
			loop109:
			while (true) {
				int alt109=2;
				int LA109_0 = input.LA(1);
				if ( (LA109_0==COMMA) ) {
					alt109=1;
				}

				switch (alt109) {
				case 1 :
					// Java.g:752:21: COMMA ! expression
					{
					COMMA363=(Token)match(input,COMMA,FOLLOW_COMMA_in_expressionList10230); if (state.failed) return retval;
					pushFollow(FOLLOW_expression_in_expressionList10233);
					expression364=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, expression364.getTree());

					}
					break;

				default :
					break loop109;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 87, expressionList_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "expressionList"


	public static class expression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "expression"
	// Java.g:755:1: expression : assignmentExpression -> ^( EXPR assignmentExpression ) ;
	public final JavaParser.expression_return expression() throws RecognitionException {
		JavaParser.expression_return retval = new JavaParser.expression_return();
		retval.start = input.LT(1);
		int expression_StartIndex = input.index();

		CommonTree root_0 = null;

		ParserRuleReturnScope assignmentExpression365 =null;

		RewriteRuleSubtreeStream stream_assignmentExpression=new RewriteRuleSubtreeStream(adaptor,"rule assignmentExpression");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 88) ) { return retval; }

			// Java.g:756:5: ( assignmentExpression -> ^( EXPR assignmentExpression ) )
			// Java.g:756:9: assignmentExpression
			{
			pushFollow(FOLLOW_assignmentExpression_in_expression10254);
			assignmentExpression365=assignmentExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_assignmentExpression.add(assignmentExpression365.getTree());

			// AST REWRITE
			// elements: assignmentExpression
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 757:9: -> ^( EXPR assignmentExpression )
			{
				// Java.g:757:13: ^( EXPR assignmentExpression )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EXPR, "EXPR"), root_1);
				adaptor.addChild(root_1, stream_assignmentExpression.nextTree());
				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 88, expression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "expression"


	public static class assignmentExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "assignmentExpression"
	// Java.g:760:1: assignmentExpression : conditionalExpression ( ( ASSIGN ^| PLUS_ASSIGN ^| MINUS_ASSIGN ^| STAR_ASSIGN ^| DIV_ASSIGN ^| AND_ASSIGN ^| OR_ASSIGN ^| XOR_ASSIGN ^| MOD_ASSIGN ^| SHIFT_LEFT_ASSIGN ^| SHIFT_RIGHT_ASSIGN ^| BIT_SHIFT_RIGHT_ASSIGN ^) assignmentExpression )? ;
	public final JavaParser.assignmentExpression_return assignmentExpression() throws RecognitionException {
		JavaParser.assignmentExpression_return retval = new JavaParser.assignmentExpression_return();
		retval.start = input.LT(1);
		int assignmentExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token ASSIGN367=null;
		Token PLUS_ASSIGN368=null;
		Token MINUS_ASSIGN369=null;
		Token STAR_ASSIGN370=null;
		Token DIV_ASSIGN371=null;
		Token AND_ASSIGN372=null;
		Token OR_ASSIGN373=null;
		Token XOR_ASSIGN374=null;
		Token MOD_ASSIGN375=null;
		Token SHIFT_LEFT_ASSIGN376=null;
		Token SHIFT_RIGHT_ASSIGN377=null;
		Token BIT_SHIFT_RIGHT_ASSIGN378=null;
		ParserRuleReturnScope conditionalExpression366 =null;
		ParserRuleReturnScope assignmentExpression379 =null;

		CommonTree ASSIGN367_tree=null;
		CommonTree PLUS_ASSIGN368_tree=null;
		CommonTree MINUS_ASSIGN369_tree=null;
		CommonTree STAR_ASSIGN370_tree=null;
		CommonTree DIV_ASSIGN371_tree=null;
		CommonTree AND_ASSIGN372_tree=null;
		CommonTree OR_ASSIGN373_tree=null;
		CommonTree XOR_ASSIGN374_tree=null;
		CommonTree MOD_ASSIGN375_tree=null;
		CommonTree SHIFT_LEFT_ASSIGN376_tree=null;
		CommonTree SHIFT_RIGHT_ASSIGN377_tree=null;
		CommonTree BIT_SHIFT_RIGHT_ASSIGN378_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 89) ) { return retval; }

			// Java.g:761:5: ( conditionalExpression ( ( ASSIGN ^| PLUS_ASSIGN ^| MINUS_ASSIGN ^| STAR_ASSIGN ^| DIV_ASSIGN ^| AND_ASSIGN ^| OR_ASSIGN ^| XOR_ASSIGN ^| MOD_ASSIGN ^| SHIFT_LEFT_ASSIGN ^| SHIFT_RIGHT_ASSIGN ^| BIT_SHIFT_RIGHT_ASSIGN ^) assignmentExpression )? )
			// Java.g:761:9: conditionalExpression ( ( ASSIGN ^| PLUS_ASSIGN ^| MINUS_ASSIGN ^| STAR_ASSIGN ^| DIV_ASSIGN ^| AND_ASSIGN ^| OR_ASSIGN ^| XOR_ASSIGN ^| MOD_ASSIGN ^| SHIFT_LEFT_ASSIGN ^| SHIFT_RIGHT_ASSIGN ^| BIT_SHIFT_RIGHT_ASSIGN ^) assignmentExpression )?
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_conditionalExpression_in_assignmentExpression10290);
			conditionalExpression366=conditionalExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, conditionalExpression366.getTree());

			// Java.g:762:9: ( ( ASSIGN ^| PLUS_ASSIGN ^| MINUS_ASSIGN ^| STAR_ASSIGN ^| DIV_ASSIGN ^| AND_ASSIGN ^| OR_ASSIGN ^| XOR_ASSIGN ^| MOD_ASSIGN ^| SHIFT_LEFT_ASSIGN ^| SHIFT_RIGHT_ASSIGN ^| BIT_SHIFT_RIGHT_ASSIGN ^) assignmentExpression )?
			int alt111=2;
			int LA111_0 = input.LA(1);
			if ( (LA111_0==AND_ASSIGN||LA111_0==ASSIGN||LA111_0==BIT_SHIFT_RIGHT_ASSIGN||LA111_0==DIV_ASSIGN||LA111_0==MINUS_ASSIGN||LA111_0==MOD_ASSIGN||LA111_0==OR_ASSIGN||LA111_0==PLUS_ASSIGN||LA111_0==SHIFT_LEFT_ASSIGN||LA111_0==SHIFT_RIGHT_ASSIGN||LA111_0==STAR_ASSIGN||LA111_0==XOR_ASSIGN) ) {
				alt111=1;
			}
			switch (alt111) {
				case 1 :
					// Java.g:762:13: ( ASSIGN ^| PLUS_ASSIGN ^| MINUS_ASSIGN ^| STAR_ASSIGN ^| DIV_ASSIGN ^| AND_ASSIGN ^| OR_ASSIGN ^| XOR_ASSIGN ^| MOD_ASSIGN ^| SHIFT_LEFT_ASSIGN ^| SHIFT_RIGHT_ASSIGN ^| BIT_SHIFT_RIGHT_ASSIGN ^) assignmentExpression
					{
					// Java.g:762:13: ( ASSIGN ^| PLUS_ASSIGN ^| MINUS_ASSIGN ^| STAR_ASSIGN ^| DIV_ASSIGN ^| AND_ASSIGN ^| OR_ASSIGN ^| XOR_ASSIGN ^| MOD_ASSIGN ^| SHIFT_LEFT_ASSIGN ^| SHIFT_RIGHT_ASSIGN ^| BIT_SHIFT_RIGHT_ASSIGN ^)
					int alt110=12;
					switch ( input.LA(1) ) {
					case ASSIGN:
						{
						alt110=1;
						}
						break;
					case PLUS_ASSIGN:
						{
						alt110=2;
						}
						break;
					case MINUS_ASSIGN:
						{
						alt110=3;
						}
						break;
					case STAR_ASSIGN:
						{
						alt110=4;
						}
						break;
					case DIV_ASSIGN:
						{
						alt110=5;
						}
						break;
					case AND_ASSIGN:
						{
						alt110=6;
						}
						break;
					case OR_ASSIGN:
						{
						alt110=7;
						}
						break;
					case XOR_ASSIGN:
						{
						alt110=8;
						}
						break;
					case MOD_ASSIGN:
						{
						alt110=9;
						}
						break;
					case SHIFT_LEFT_ASSIGN:
						{
						alt110=10;
						}
						break;
					case SHIFT_RIGHT_ASSIGN:
						{
						alt110=11;
						}
						break;
					case BIT_SHIFT_RIGHT_ASSIGN:
						{
						alt110=12;
						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 110, 0, input);
						throw nvae;
					}
					switch (alt110) {
						case 1 :
							// Java.g:762:17: ASSIGN ^
							{
							ASSIGN367=(Token)match(input,ASSIGN,FOLLOW_ASSIGN_in_assignmentExpression10308); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							ASSIGN367_tree = (CommonTree)adaptor.create(ASSIGN367);
							root_0 = (CommonTree)adaptor.becomeRoot(ASSIGN367_tree, root_0);
							}

							}
							break;
						case 2 :
							// Java.g:763:17: PLUS_ASSIGN ^
							{
							PLUS_ASSIGN368=(Token)match(input,PLUS_ASSIGN,FOLLOW_PLUS_ASSIGN_in_assignmentExpression10327); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							PLUS_ASSIGN368_tree = (CommonTree)adaptor.create(PLUS_ASSIGN368);
							root_0 = (CommonTree)adaptor.becomeRoot(PLUS_ASSIGN368_tree, root_0);
							}

							}
							break;
						case 3 :
							// Java.g:764:17: MINUS_ASSIGN ^
							{
							MINUS_ASSIGN369=(Token)match(input,MINUS_ASSIGN,FOLLOW_MINUS_ASSIGN_in_assignmentExpression10346); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							MINUS_ASSIGN369_tree = (CommonTree)adaptor.create(MINUS_ASSIGN369);
							root_0 = (CommonTree)adaptor.becomeRoot(MINUS_ASSIGN369_tree, root_0);
							}

							}
							break;
						case 4 :
							// Java.g:765:17: STAR_ASSIGN ^
							{
							STAR_ASSIGN370=(Token)match(input,STAR_ASSIGN,FOLLOW_STAR_ASSIGN_in_assignmentExpression10365); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							STAR_ASSIGN370_tree = (CommonTree)adaptor.create(STAR_ASSIGN370);
							root_0 = (CommonTree)adaptor.becomeRoot(STAR_ASSIGN370_tree, root_0);
							}

							}
							break;
						case 5 :
							// Java.g:766:17: DIV_ASSIGN ^
							{
							DIV_ASSIGN371=(Token)match(input,DIV_ASSIGN,FOLLOW_DIV_ASSIGN_in_assignmentExpression10384); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							DIV_ASSIGN371_tree = (CommonTree)adaptor.create(DIV_ASSIGN371);
							root_0 = (CommonTree)adaptor.becomeRoot(DIV_ASSIGN371_tree, root_0);
							}

							}
							break;
						case 6 :
							// Java.g:767:17: AND_ASSIGN ^
							{
							AND_ASSIGN372=(Token)match(input,AND_ASSIGN,FOLLOW_AND_ASSIGN_in_assignmentExpression10403); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							AND_ASSIGN372_tree = (CommonTree)adaptor.create(AND_ASSIGN372);
							root_0 = (CommonTree)adaptor.becomeRoot(AND_ASSIGN372_tree, root_0);
							}

							}
							break;
						case 7 :
							// Java.g:768:17: OR_ASSIGN ^
							{
							OR_ASSIGN373=(Token)match(input,OR_ASSIGN,FOLLOW_OR_ASSIGN_in_assignmentExpression10422); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							OR_ASSIGN373_tree = (CommonTree)adaptor.create(OR_ASSIGN373);
							root_0 = (CommonTree)adaptor.becomeRoot(OR_ASSIGN373_tree, root_0);
							}

							}
							break;
						case 8 :
							// Java.g:769:17: XOR_ASSIGN ^
							{
							XOR_ASSIGN374=(Token)match(input,XOR_ASSIGN,FOLLOW_XOR_ASSIGN_in_assignmentExpression10441); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							XOR_ASSIGN374_tree = (CommonTree)adaptor.create(XOR_ASSIGN374);
							root_0 = (CommonTree)adaptor.becomeRoot(XOR_ASSIGN374_tree, root_0);
							}

							}
							break;
						case 9 :
							// Java.g:770:17: MOD_ASSIGN ^
							{
							MOD_ASSIGN375=(Token)match(input,MOD_ASSIGN,FOLLOW_MOD_ASSIGN_in_assignmentExpression10460); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							MOD_ASSIGN375_tree = (CommonTree)adaptor.create(MOD_ASSIGN375);
							root_0 = (CommonTree)adaptor.becomeRoot(MOD_ASSIGN375_tree, root_0);
							}

							}
							break;
						case 10 :
							// Java.g:771:17: SHIFT_LEFT_ASSIGN ^
							{
							SHIFT_LEFT_ASSIGN376=(Token)match(input,SHIFT_LEFT_ASSIGN,FOLLOW_SHIFT_LEFT_ASSIGN_in_assignmentExpression10479); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							SHIFT_LEFT_ASSIGN376_tree = (CommonTree)adaptor.create(SHIFT_LEFT_ASSIGN376);
							root_0 = (CommonTree)adaptor.becomeRoot(SHIFT_LEFT_ASSIGN376_tree, root_0);
							}

							}
							break;
						case 11 :
							// Java.g:772:17: SHIFT_RIGHT_ASSIGN ^
							{
							SHIFT_RIGHT_ASSIGN377=(Token)match(input,SHIFT_RIGHT_ASSIGN,FOLLOW_SHIFT_RIGHT_ASSIGN_in_assignmentExpression10498); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							SHIFT_RIGHT_ASSIGN377_tree = (CommonTree)adaptor.create(SHIFT_RIGHT_ASSIGN377);
							root_0 = (CommonTree)adaptor.becomeRoot(SHIFT_RIGHT_ASSIGN377_tree, root_0);
							}

							}
							break;
						case 12 :
							// Java.g:773:17: BIT_SHIFT_RIGHT_ASSIGN ^
							{
							BIT_SHIFT_RIGHT_ASSIGN378=(Token)match(input,BIT_SHIFT_RIGHT_ASSIGN,FOLLOW_BIT_SHIFT_RIGHT_ASSIGN_in_assignmentExpression10517); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							BIT_SHIFT_RIGHT_ASSIGN378_tree = (CommonTree)adaptor.create(BIT_SHIFT_RIGHT_ASSIGN378);
							root_0 = (CommonTree)adaptor.becomeRoot(BIT_SHIFT_RIGHT_ASSIGN378_tree, root_0);
							}

							}
							break;

					}

					pushFollow(FOLLOW_assignmentExpression_in_assignmentExpression10538);
					assignmentExpression379=assignmentExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, assignmentExpression379.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 89, assignmentExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "assignmentExpression"


	public static class conditionalExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "conditionalExpression"
	// Java.g:778:1: conditionalExpression : logicalOrExpression ( QUESTION ^ assignmentExpression COLON ! conditionalExpression )? ;
	public final JavaParser.conditionalExpression_return conditionalExpression() throws RecognitionException {
		JavaParser.conditionalExpression_return retval = new JavaParser.conditionalExpression_return();
		retval.start = input.LT(1);
		int conditionalExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token QUESTION381=null;
		Token COLON383=null;
		ParserRuleReturnScope logicalOrExpression380 =null;
		ParserRuleReturnScope assignmentExpression382 =null;
		ParserRuleReturnScope conditionalExpression384 =null;

		CommonTree QUESTION381_tree=null;
		CommonTree COLON383_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 90) ) { return retval; }

			// Java.g:779:5: ( logicalOrExpression ( QUESTION ^ assignmentExpression COLON ! conditionalExpression )? )
			// Java.g:779:9: logicalOrExpression ( QUESTION ^ assignmentExpression COLON ! conditionalExpression )?
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_logicalOrExpression_in_conditionalExpression10559);
			logicalOrExpression380=logicalOrExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, logicalOrExpression380.getTree());

			// Java.g:779:29: ( QUESTION ^ assignmentExpression COLON ! conditionalExpression )?
			int alt112=2;
			int LA112_0 = input.LA(1);
			if ( (LA112_0==QUESTION) ) {
				alt112=1;
			}
			switch (alt112) {
				case 1 :
					// Java.g:779:30: QUESTION ^ assignmentExpression COLON ! conditionalExpression
					{
					QUESTION381=(Token)match(input,QUESTION,FOLLOW_QUESTION_in_conditionalExpression10562); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					QUESTION381_tree = (CommonTree)adaptor.create(QUESTION381);
					root_0 = (CommonTree)adaptor.becomeRoot(QUESTION381_tree, root_0);
					}

					pushFollow(FOLLOW_assignmentExpression_in_conditionalExpression10565);
					assignmentExpression382=assignmentExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, assignmentExpression382.getTree());

					COLON383=(Token)match(input,COLON,FOLLOW_COLON_in_conditionalExpression10567); if (state.failed) return retval;
					pushFollow(FOLLOW_conditionalExpression_in_conditionalExpression10570);
					conditionalExpression384=conditionalExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, conditionalExpression384.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 90, conditionalExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "conditionalExpression"


	public static class logicalOrExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "logicalOrExpression"
	// Java.g:782:1: logicalOrExpression : logicalAndExpression ( LOGICAL_OR ^ logicalAndExpression )* ;
	public final JavaParser.logicalOrExpression_return logicalOrExpression() throws RecognitionException {
		JavaParser.logicalOrExpression_return retval = new JavaParser.logicalOrExpression_return();
		retval.start = input.LT(1);
		int logicalOrExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LOGICAL_OR386=null;
		ParserRuleReturnScope logicalAndExpression385 =null;
		ParserRuleReturnScope logicalAndExpression387 =null;

		CommonTree LOGICAL_OR386_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 91) ) { return retval; }

			// Java.g:783:5: ( logicalAndExpression ( LOGICAL_OR ^ logicalAndExpression )* )
			// Java.g:783:9: logicalAndExpression ( LOGICAL_OR ^ logicalAndExpression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_logicalAndExpression_in_logicalOrExpression10591);
			logicalAndExpression385=logicalAndExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, logicalAndExpression385.getTree());

			// Java.g:783:30: ( LOGICAL_OR ^ logicalAndExpression )*
			loop113:
			while (true) {
				int alt113=2;
				int LA113_0 = input.LA(1);
				if ( (LA113_0==LOGICAL_OR) ) {
					alt113=1;
				}

				switch (alt113) {
				case 1 :
					// Java.g:783:31: LOGICAL_OR ^ logicalAndExpression
					{
					LOGICAL_OR386=(Token)match(input,LOGICAL_OR,FOLLOW_LOGICAL_OR_in_logicalOrExpression10594); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					LOGICAL_OR386_tree = (CommonTree)adaptor.create(LOGICAL_OR386);
					root_0 = (CommonTree)adaptor.becomeRoot(LOGICAL_OR386_tree, root_0);
					}

					pushFollow(FOLLOW_logicalAndExpression_in_logicalOrExpression10597);
					logicalAndExpression387=logicalAndExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, logicalAndExpression387.getTree());

					}
					break;

				default :
					break loop113;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 91, logicalOrExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "logicalOrExpression"


	public static class logicalAndExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "logicalAndExpression"
	// Java.g:786:1: logicalAndExpression : inclusiveOrExpression ( LOGICAL_AND ^ inclusiveOrExpression )* ;
	public final JavaParser.logicalAndExpression_return logicalAndExpression() throws RecognitionException {
		JavaParser.logicalAndExpression_return retval = new JavaParser.logicalAndExpression_return();
		retval.start = input.LT(1);
		int logicalAndExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LOGICAL_AND389=null;
		ParserRuleReturnScope inclusiveOrExpression388 =null;
		ParserRuleReturnScope inclusiveOrExpression390 =null;

		CommonTree LOGICAL_AND389_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 92) ) { return retval; }

			// Java.g:787:5: ( inclusiveOrExpression ( LOGICAL_AND ^ inclusiveOrExpression )* )
			// Java.g:787:9: inclusiveOrExpression ( LOGICAL_AND ^ inclusiveOrExpression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_inclusiveOrExpression_in_logicalAndExpression10618);
			inclusiveOrExpression388=inclusiveOrExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, inclusiveOrExpression388.getTree());

			// Java.g:787:31: ( LOGICAL_AND ^ inclusiveOrExpression )*
			loop114:
			while (true) {
				int alt114=2;
				int LA114_0 = input.LA(1);
				if ( (LA114_0==LOGICAL_AND) ) {
					alt114=1;
				}

				switch (alt114) {
				case 1 :
					// Java.g:787:32: LOGICAL_AND ^ inclusiveOrExpression
					{
					LOGICAL_AND389=(Token)match(input,LOGICAL_AND,FOLLOW_LOGICAL_AND_in_logicalAndExpression10621); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					LOGICAL_AND389_tree = (CommonTree)adaptor.create(LOGICAL_AND389);
					root_0 = (CommonTree)adaptor.becomeRoot(LOGICAL_AND389_tree, root_0);
					}

					pushFollow(FOLLOW_inclusiveOrExpression_in_logicalAndExpression10624);
					inclusiveOrExpression390=inclusiveOrExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, inclusiveOrExpression390.getTree());

					}
					break;

				default :
					break loop114;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 92, logicalAndExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "logicalAndExpression"


	public static class inclusiveOrExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "inclusiveOrExpression"
	// Java.g:790:1: inclusiveOrExpression : exclusiveOrExpression ( OR ^ exclusiveOrExpression )* ;
	public final JavaParser.inclusiveOrExpression_return inclusiveOrExpression() throws RecognitionException {
		JavaParser.inclusiveOrExpression_return retval = new JavaParser.inclusiveOrExpression_return();
		retval.start = input.LT(1);
		int inclusiveOrExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token OR392=null;
		ParserRuleReturnScope exclusiveOrExpression391 =null;
		ParserRuleReturnScope exclusiveOrExpression393 =null;

		CommonTree OR392_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 93) ) { return retval; }

			// Java.g:791:5: ( exclusiveOrExpression ( OR ^ exclusiveOrExpression )* )
			// Java.g:791:9: exclusiveOrExpression ( OR ^ exclusiveOrExpression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_exclusiveOrExpression_in_inclusiveOrExpression10645);
			exclusiveOrExpression391=exclusiveOrExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, exclusiveOrExpression391.getTree());

			// Java.g:791:31: ( OR ^ exclusiveOrExpression )*
			loop115:
			while (true) {
				int alt115=2;
				int LA115_0 = input.LA(1);
				if ( (LA115_0==OR) ) {
					alt115=1;
				}

				switch (alt115) {
				case 1 :
					// Java.g:791:32: OR ^ exclusiveOrExpression
					{
					OR392=(Token)match(input,OR,FOLLOW_OR_in_inclusiveOrExpression10648); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					OR392_tree = (CommonTree)adaptor.create(OR392);
					root_0 = (CommonTree)adaptor.becomeRoot(OR392_tree, root_0);
					}

					pushFollow(FOLLOW_exclusiveOrExpression_in_inclusiveOrExpression10651);
					exclusiveOrExpression393=exclusiveOrExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, exclusiveOrExpression393.getTree());

					}
					break;

				default :
					break loop115;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 93, inclusiveOrExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "inclusiveOrExpression"


	public static class exclusiveOrExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "exclusiveOrExpression"
	// Java.g:794:1: exclusiveOrExpression : andExpression ( XOR ^ andExpression )* ;
	public final JavaParser.exclusiveOrExpression_return exclusiveOrExpression() throws RecognitionException {
		JavaParser.exclusiveOrExpression_return retval = new JavaParser.exclusiveOrExpression_return();
		retval.start = input.LT(1);
		int exclusiveOrExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token XOR395=null;
		ParserRuleReturnScope andExpression394 =null;
		ParserRuleReturnScope andExpression396 =null;

		CommonTree XOR395_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 94) ) { return retval; }

			// Java.g:795:5: ( andExpression ( XOR ^ andExpression )* )
			// Java.g:795:9: andExpression ( XOR ^ andExpression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_andExpression_in_exclusiveOrExpression10672);
			andExpression394=andExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, andExpression394.getTree());

			// Java.g:795:23: ( XOR ^ andExpression )*
			loop116:
			while (true) {
				int alt116=2;
				int LA116_0 = input.LA(1);
				if ( (LA116_0==XOR) ) {
					alt116=1;
				}

				switch (alt116) {
				case 1 :
					// Java.g:795:24: XOR ^ andExpression
					{
					XOR395=(Token)match(input,XOR,FOLLOW_XOR_in_exclusiveOrExpression10675); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					XOR395_tree = (CommonTree)adaptor.create(XOR395);
					root_0 = (CommonTree)adaptor.becomeRoot(XOR395_tree, root_0);
					}

					pushFollow(FOLLOW_andExpression_in_exclusiveOrExpression10678);
					andExpression396=andExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, andExpression396.getTree());

					}
					break;

				default :
					break loop116;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 94, exclusiveOrExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "exclusiveOrExpression"


	public static class andExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "andExpression"
	// Java.g:798:1: andExpression : equalityExpression ( AND ^ equalityExpression )* ;
	public final JavaParser.andExpression_return andExpression() throws RecognitionException {
		JavaParser.andExpression_return retval = new JavaParser.andExpression_return();
		retval.start = input.LT(1);
		int andExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token AND398=null;
		ParserRuleReturnScope equalityExpression397 =null;
		ParserRuleReturnScope equalityExpression399 =null;

		CommonTree AND398_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 95) ) { return retval; }

			// Java.g:799:5: ( equalityExpression ( AND ^ equalityExpression )* )
			// Java.g:799:9: equalityExpression ( AND ^ equalityExpression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_equalityExpression_in_andExpression10699);
			equalityExpression397=equalityExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, equalityExpression397.getTree());

			// Java.g:799:28: ( AND ^ equalityExpression )*
			loop117:
			while (true) {
				int alt117=2;
				int LA117_0 = input.LA(1);
				if ( (LA117_0==AND) ) {
					alt117=1;
				}

				switch (alt117) {
				case 1 :
					// Java.g:799:29: AND ^ equalityExpression
					{
					AND398=(Token)match(input,AND,FOLLOW_AND_in_andExpression10702); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					AND398_tree = (CommonTree)adaptor.create(AND398);
					root_0 = (CommonTree)adaptor.becomeRoot(AND398_tree, root_0);
					}

					pushFollow(FOLLOW_equalityExpression_in_andExpression10705);
					equalityExpression399=equalityExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, equalityExpression399.getTree());

					}
					break;

				default :
					break loop117;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 95, andExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "andExpression"


	public static class equalityExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "equalityExpression"
	// Java.g:802:1: equalityExpression : instanceOfExpression ( ( EQUAL ^| NOT_EQUAL ^) instanceOfExpression )* ;
	public final JavaParser.equalityExpression_return equalityExpression() throws RecognitionException {
		JavaParser.equalityExpression_return retval = new JavaParser.equalityExpression_return();
		retval.start = input.LT(1);
		int equalityExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token EQUAL401=null;
		Token NOT_EQUAL402=null;
		ParserRuleReturnScope instanceOfExpression400 =null;
		ParserRuleReturnScope instanceOfExpression403 =null;

		CommonTree EQUAL401_tree=null;
		CommonTree NOT_EQUAL402_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 96) ) { return retval; }

			// Java.g:803:5: ( instanceOfExpression ( ( EQUAL ^| NOT_EQUAL ^) instanceOfExpression )* )
			// Java.g:803:9: instanceOfExpression ( ( EQUAL ^| NOT_EQUAL ^) instanceOfExpression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_instanceOfExpression_in_equalityExpression10726);
			instanceOfExpression400=instanceOfExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, instanceOfExpression400.getTree());

			// Java.g:804:9: ( ( EQUAL ^| NOT_EQUAL ^) instanceOfExpression )*
			loop119:
			while (true) {
				int alt119=2;
				int LA119_0 = input.LA(1);
				if ( (LA119_0==EQUAL||LA119_0==NOT_EQUAL) ) {
					alt119=1;
				}

				switch (alt119) {
				case 1 :
					// Java.g:804:13: ( EQUAL ^| NOT_EQUAL ^) instanceOfExpression
					{
					// Java.g:804:13: ( EQUAL ^| NOT_EQUAL ^)
					int alt118=2;
					int LA118_0 = input.LA(1);
					if ( (LA118_0==EQUAL) ) {
						alt118=1;
					}
					else if ( (LA118_0==NOT_EQUAL) ) {
						alt118=2;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 118, 0, input);
						throw nvae;
					}

					switch (alt118) {
						case 1 :
							// Java.g:804:17: EQUAL ^
							{
							EQUAL401=(Token)match(input,EQUAL,FOLLOW_EQUAL_in_equalityExpression10744); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							EQUAL401_tree = (CommonTree)adaptor.create(EQUAL401);
							root_0 = (CommonTree)adaptor.becomeRoot(EQUAL401_tree, root_0);
							}

							}
							break;
						case 2 :
							// Java.g:805:17: NOT_EQUAL ^
							{
							NOT_EQUAL402=(Token)match(input,NOT_EQUAL,FOLLOW_NOT_EQUAL_in_equalityExpression10763); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							NOT_EQUAL402_tree = (CommonTree)adaptor.create(NOT_EQUAL402);
							root_0 = (CommonTree)adaptor.becomeRoot(NOT_EQUAL402_tree, root_0);
							}

							}
							break;

					}

					pushFollow(FOLLOW_instanceOfExpression_in_equalityExpression10792);
					instanceOfExpression403=instanceOfExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, instanceOfExpression403.getTree());

					}
					break;

				default :
					break loop119;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 96, equalityExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "equalityExpression"


	public static class instanceOfExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "instanceOfExpression"
	// Java.g:811:1: instanceOfExpression : relationalExpression ( INSTANCEOF ^ type )? ;
	public final JavaParser.instanceOfExpression_return instanceOfExpression() throws RecognitionException {
		JavaParser.instanceOfExpression_return retval = new JavaParser.instanceOfExpression_return();
		retval.start = input.LT(1);
		int instanceOfExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token INSTANCEOF405=null;
		ParserRuleReturnScope relationalExpression404 =null;
		ParserRuleReturnScope type406 =null;

		CommonTree INSTANCEOF405_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 97) ) { return retval; }

			// Java.g:812:5: ( relationalExpression ( INSTANCEOF ^ type )? )
			// Java.g:812:9: relationalExpression ( INSTANCEOF ^ type )?
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_relationalExpression_in_instanceOfExpression10822);
			relationalExpression404=relationalExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, relationalExpression404.getTree());

			// Java.g:812:30: ( INSTANCEOF ^ type )?
			int alt120=2;
			int LA120_0 = input.LA(1);
			if ( (LA120_0==INSTANCEOF) ) {
				alt120=1;
			}
			switch (alt120) {
				case 1 :
					// Java.g:812:31: INSTANCEOF ^ type
					{
					INSTANCEOF405=(Token)match(input,INSTANCEOF,FOLLOW_INSTANCEOF_in_instanceOfExpression10825); if (state.failed) return retval;
					if ( state.backtracking==0 ) {
					INSTANCEOF405_tree = (CommonTree)adaptor.create(INSTANCEOF405);
					root_0 = (CommonTree)adaptor.becomeRoot(INSTANCEOF405_tree, root_0);
					}

					pushFollow(FOLLOW_type_in_instanceOfExpression10828);
					type406=type();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, type406.getTree());

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 97, instanceOfExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "instanceOfExpression"


	public static class relationalExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "relationalExpression"
	// Java.g:815:1: relationalExpression : shiftExpression ( ( LESS_OR_EQUAL ^| GREATER_OR_EQUAL ^| LESS_THAN ^| GREATER_THAN ^) shiftExpression )* ;
	public final JavaParser.relationalExpression_return relationalExpression() throws RecognitionException {
		JavaParser.relationalExpression_return retval = new JavaParser.relationalExpression_return();
		retval.start = input.LT(1);
		int relationalExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LESS_OR_EQUAL408=null;
		Token GREATER_OR_EQUAL409=null;
		Token LESS_THAN410=null;
		Token GREATER_THAN411=null;
		ParserRuleReturnScope shiftExpression407 =null;
		ParserRuleReturnScope shiftExpression412 =null;

		CommonTree LESS_OR_EQUAL408_tree=null;
		CommonTree GREATER_OR_EQUAL409_tree=null;
		CommonTree LESS_THAN410_tree=null;
		CommonTree GREATER_THAN411_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 98) ) { return retval; }

			// Java.g:816:5: ( shiftExpression ( ( LESS_OR_EQUAL ^| GREATER_OR_EQUAL ^| LESS_THAN ^| GREATER_THAN ^) shiftExpression )* )
			// Java.g:816:9: shiftExpression ( ( LESS_OR_EQUAL ^| GREATER_OR_EQUAL ^| LESS_THAN ^| GREATER_THAN ^) shiftExpression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_shiftExpression_in_relationalExpression10849);
			shiftExpression407=shiftExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, shiftExpression407.getTree());

			// Java.g:817:9: ( ( LESS_OR_EQUAL ^| GREATER_OR_EQUAL ^| LESS_THAN ^| GREATER_THAN ^) shiftExpression )*
			loop122:
			while (true) {
				int alt122=2;
				int LA122_0 = input.LA(1);
				if ( ((LA122_0 >= GREATER_OR_EQUAL && LA122_0 <= GREATER_THAN)||(LA122_0 >= LESS_OR_EQUAL && LA122_0 <= LESS_THAN)) ) {
					alt122=1;
				}

				switch (alt122) {
				case 1 :
					// Java.g:817:13: ( LESS_OR_EQUAL ^| GREATER_OR_EQUAL ^| LESS_THAN ^| GREATER_THAN ^) shiftExpression
					{
					// Java.g:817:13: ( LESS_OR_EQUAL ^| GREATER_OR_EQUAL ^| LESS_THAN ^| GREATER_THAN ^)
					int alt121=4;
					switch ( input.LA(1) ) {
					case LESS_OR_EQUAL:
						{
						alt121=1;
						}
						break;
					case GREATER_OR_EQUAL:
						{
						alt121=2;
						}
						break;
					case LESS_THAN:
						{
						alt121=3;
						}
						break;
					case GREATER_THAN:
						{
						alt121=4;
						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 121, 0, input);
						throw nvae;
					}
					switch (alt121) {
						case 1 :
							// Java.g:817:17: LESS_OR_EQUAL ^
							{
							LESS_OR_EQUAL408=(Token)match(input,LESS_OR_EQUAL,FOLLOW_LESS_OR_EQUAL_in_relationalExpression10867); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							LESS_OR_EQUAL408_tree = (CommonTree)adaptor.create(LESS_OR_EQUAL408);
							root_0 = (CommonTree)adaptor.becomeRoot(LESS_OR_EQUAL408_tree, root_0);
							}

							}
							break;
						case 2 :
							// Java.g:818:17: GREATER_OR_EQUAL ^
							{
							GREATER_OR_EQUAL409=(Token)match(input,GREATER_OR_EQUAL,FOLLOW_GREATER_OR_EQUAL_in_relationalExpression10886); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							GREATER_OR_EQUAL409_tree = (CommonTree)adaptor.create(GREATER_OR_EQUAL409);
							root_0 = (CommonTree)adaptor.becomeRoot(GREATER_OR_EQUAL409_tree, root_0);
							}

							}
							break;
						case 3 :
							// Java.g:819:17: LESS_THAN ^
							{
							LESS_THAN410=(Token)match(input,LESS_THAN,FOLLOW_LESS_THAN_in_relationalExpression10905); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							LESS_THAN410_tree = (CommonTree)adaptor.create(LESS_THAN410);
							root_0 = (CommonTree)adaptor.becomeRoot(LESS_THAN410_tree, root_0);
							}

							}
							break;
						case 4 :
							// Java.g:820:17: GREATER_THAN ^
							{
							GREATER_THAN411=(Token)match(input,GREATER_THAN,FOLLOW_GREATER_THAN_in_relationalExpression10924); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							GREATER_THAN411_tree = (CommonTree)adaptor.create(GREATER_THAN411);
							root_0 = (CommonTree)adaptor.becomeRoot(GREATER_THAN411_tree, root_0);
							}

							}
							break;

					}

					pushFollow(FOLLOW_shiftExpression_in_relationalExpression10953);
					shiftExpression412=shiftExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, shiftExpression412.getTree());

					}
					break;

				default :
					break loop122;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 98, relationalExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "relationalExpression"


	public static class shiftExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "shiftExpression"
	// Java.g:826:1: shiftExpression : additiveExpression ( ( BIT_SHIFT_RIGHT ^| SHIFT_RIGHT ^| SHIFT_LEFT ^) additiveExpression )* ;
	public final JavaParser.shiftExpression_return shiftExpression() throws RecognitionException {
		JavaParser.shiftExpression_return retval = new JavaParser.shiftExpression_return();
		retval.start = input.LT(1);
		int shiftExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token BIT_SHIFT_RIGHT414=null;
		Token SHIFT_RIGHT415=null;
		Token SHIFT_LEFT416=null;
		ParserRuleReturnScope additiveExpression413 =null;
		ParserRuleReturnScope additiveExpression417 =null;

		CommonTree BIT_SHIFT_RIGHT414_tree=null;
		CommonTree SHIFT_RIGHT415_tree=null;
		CommonTree SHIFT_LEFT416_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 99) ) { return retval; }

			// Java.g:827:5: ( additiveExpression ( ( BIT_SHIFT_RIGHT ^| SHIFT_RIGHT ^| SHIFT_LEFT ^) additiveExpression )* )
			// Java.g:827:9: additiveExpression ( ( BIT_SHIFT_RIGHT ^| SHIFT_RIGHT ^| SHIFT_LEFT ^) additiveExpression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_additiveExpression_in_shiftExpression10983);
			additiveExpression413=additiveExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, additiveExpression413.getTree());

			// Java.g:828:9: ( ( BIT_SHIFT_RIGHT ^| SHIFT_RIGHT ^| SHIFT_LEFT ^) additiveExpression )*
			loop124:
			while (true) {
				int alt124=2;
				int LA124_0 = input.LA(1);
				if ( (LA124_0==BIT_SHIFT_RIGHT||LA124_0==SHIFT_LEFT||LA124_0==SHIFT_RIGHT) ) {
					alt124=1;
				}

				switch (alt124) {
				case 1 :
					// Java.g:828:13: ( BIT_SHIFT_RIGHT ^| SHIFT_RIGHT ^| SHIFT_LEFT ^) additiveExpression
					{
					// Java.g:828:13: ( BIT_SHIFT_RIGHT ^| SHIFT_RIGHT ^| SHIFT_LEFT ^)
					int alt123=3;
					switch ( input.LA(1) ) {
					case BIT_SHIFT_RIGHT:
						{
						alt123=1;
						}
						break;
					case SHIFT_RIGHT:
						{
						alt123=2;
						}
						break;
					case SHIFT_LEFT:
						{
						alt123=3;
						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 123, 0, input);
						throw nvae;
					}
					switch (alt123) {
						case 1 :
							// Java.g:828:17: BIT_SHIFT_RIGHT ^
							{
							BIT_SHIFT_RIGHT414=(Token)match(input,BIT_SHIFT_RIGHT,FOLLOW_BIT_SHIFT_RIGHT_in_shiftExpression11001); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							BIT_SHIFT_RIGHT414_tree = (CommonTree)adaptor.create(BIT_SHIFT_RIGHT414);
							root_0 = (CommonTree)adaptor.becomeRoot(BIT_SHIFT_RIGHT414_tree, root_0);
							}

							}
							break;
						case 2 :
							// Java.g:829:17: SHIFT_RIGHT ^
							{
							SHIFT_RIGHT415=(Token)match(input,SHIFT_RIGHT,FOLLOW_SHIFT_RIGHT_in_shiftExpression11020); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							SHIFT_RIGHT415_tree = (CommonTree)adaptor.create(SHIFT_RIGHT415);
							root_0 = (CommonTree)adaptor.becomeRoot(SHIFT_RIGHT415_tree, root_0);
							}

							}
							break;
						case 3 :
							// Java.g:830:17: SHIFT_LEFT ^
							{
							SHIFT_LEFT416=(Token)match(input,SHIFT_LEFT,FOLLOW_SHIFT_LEFT_in_shiftExpression11039); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							SHIFT_LEFT416_tree = (CommonTree)adaptor.create(SHIFT_LEFT416);
							root_0 = (CommonTree)adaptor.becomeRoot(SHIFT_LEFT416_tree, root_0);
							}

							}
							break;

					}

					pushFollow(FOLLOW_additiveExpression_in_shiftExpression11068);
					additiveExpression417=additiveExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, additiveExpression417.getTree());

					}
					break;

				default :
					break loop124;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 99, shiftExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "shiftExpression"


	public static class additiveExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "additiveExpression"
	// Java.g:836:1: additiveExpression : multiplicativeExpression ( ( PLUS ^| MINUS ^) multiplicativeExpression )* ;
	public final JavaParser.additiveExpression_return additiveExpression() throws RecognitionException {
		JavaParser.additiveExpression_return retval = new JavaParser.additiveExpression_return();
		retval.start = input.LT(1);
		int additiveExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token PLUS419=null;
		Token MINUS420=null;
		ParserRuleReturnScope multiplicativeExpression418 =null;
		ParserRuleReturnScope multiplicativeExpression421 =null;

		CommonTree PLUS419_tree=null;
		CommonTree MINUS420_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 100) ) { return retval; }

			// Java.g:837:5: ( multiplicativeExpression ( ( PLUS ^| MINUS ^) multiplicativeExpression )* )
			// Java.g:837:9: multiplicativeExpression ( ( PLUS ^| MINUS ^) multiplicativeExpression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_multiplicativeExpression_in_additiveExpression11098);
			multiplicativeExpression418=multiplicativeExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, multiplicativeExpression418.getTree());

			// Java.g:838:9: ( ( PLUS ^| MINUS ^) multiplicativeExpression )*
			loop126:
			while (true) {
				int alt126=2;
				int LA126_0 = input.LA(1);
				if ( (LA126_0==MINUS||LA126_0==PLUS) ) {
					alt126=1;
				}

				switch (alt126) {
				case 1 :
					// Java.g:838:13: ( PLUS ^| MINUS ^) multiplicativeExpression
					{
					// Java.g:838:13: ( PLUS ^| MINUS ^)
					int alt125=2;
					int LA125_0 = input.LA(1);
					if ( (LA125_0==PLUS) ) {
						alt125=1;
					}
					else if ( (LA125_0==MINUS) ) {
						alt125=2;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 125, 0, input);
						throw nvae;
					}

					switch (alt125) {
						case 1 :
							// Java.g:838:17: PLUS ^
							{
							PLUS419=(Token)match(input,PLUS,FOLLOW_PLUS_in_additiveExpression11116); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							PLUS419_tree = (CommonTree)adaptor.create(PLUS419);
							root_0 = (CommonTree)adaptor.becomeRoot(PLUS419_tree, root_0);
							}

							}
							break;
						case 2 :
							// Java.g:839:17: MINUS ^
							{
							MINUS420=(Token)match(input,MINUS,FOLLOW_MINUS_in_additiveExpression11135); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							MINUS420_tree = (CommonTree)adaptor.create(MINUS420);
							root_0 = (CommonTree)adaptor.becomeRoot(MINUS420_tree, root_0);
							}

							}
							break;

					}

					pushFollow(FOLLOW_multiplicativeExpression_in_additiveExpression11164);
					multiplicativeExpression421=multiplicativeExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, multiplicativeExpression421.getTree());

					}
					break;

				default :
					break loop126;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 100, additiveExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "additiveExpression"


	public static class multiplicativeExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "multiplicativeExpression"
	// Java.g:845:1: multiplicativeExpression : unaryExpression ( ( STAR ^| DIV ^| MOD ^) unaryExpression )* ;
	public final JavaParser.multiplicativeExpression_return multiplicativeExpression() throws RecognitionException {
		JavaParser.multiplicativeExpression_return retval = new JavaParser.multiplicativeExpression_return();
		retval.start = input.LT(1);
		int multiplicativeExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token STAR423=null;
		Token DIV424=null;
		Token MOD425=null;
		ParserRuleReturnScope unaryExpression422 =null;
		ParserRuleReturnScope unaryExpression426 =null;

		CommonTree STAR423_tree=null;
		CommonTree DIV424_tree=null;
		CommonTree MOD425_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 101) ) { return retval; }

			// Java.g:846:5: ( unaryExpression ( ( STAR ^| DIV ^| MOD ^) unaryExpression )* )
			// Java.g:846:9: unaryExpression ( ( STAR ^| DIV ^| MOD ^) unaryExpression )*
			{
			root_0 = (CommonTree)adaptor.nil();


			pushFollow(FOLLOW_unaryExpression_in_multiplicativeExpression11194);
			unaryExpression422=unaryExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) adaptor.addChild(root_0, unaryExpression422.getTree());

			// Java.g:847:9: ( ( STAR ^| DIV ^| MOD ^) unaryExpression )*
			loop128:
			while (true) {
				int alt128=2;
				int LA128_0 = input.LA(1);
				if ( (LA128_0==DIV||LA128_0==MOD||LA128_0==STAR) ) {
					alt128=1;
				}

				switch (alt128) {
				case 1 :
					// Java.g:847:13: ( STAR ^| DIV ^| MOD ^) unaryExpression
					{
					// Java.g:847:13: ( STAR ^| DIV ^| MOD ^)
					int alt127=3;
					switch ( input.LA(1) ) {
					case STAR:
						{
						alt127=1;
						}
						break;
					case DIV:
						{
						alt127=2;
						}
						break;
					case MOD:
						{
						alt127=3;
						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 127, 0, input);
						throw nvae;
					}
					switch (alt127) {
						case 1 :
							// Java.g:847:17: STAR ^
							{
							STAR423=(Token)match(input,STAR,FOLLOW_STAR_in_multiplicativeExpression11212); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							STAR423_tree = (CommonTree)adaptor.create(STAR423);
							root_0 = (CommonTree)adaptor.becomeRoot(STAR423_tree, root_0);
							}

							}
							break;
						case 2 :
							// Java.g:848:17: DIV ^
							{
							DIV424=(Token)match(input,DIV,FOLLOW_DIV_in_multiplicativeExpression11231); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							DIV424_tree = (CommonTree)adaptor.create(DIV424);
							root_0 = (CommonTree)adaptor.becomeRoot(DIV424_tree, root_0);
							}

							}
							break;
						case 3 :
							// Java.g:849:17: MOD ^
							{
							MOD425=(Token)match(input,MOD,FOLLOW_MOD_in_multiplicativeExpression11250); if (state.failed) return retval;
							if ( state.backtracking==0 ) {
							MOD425_tree = (CommonTree)adaptor.create(MOD425);
							root_0 = (CommonTree)adaptor.becomeRoot(MOD425_tree, root_0);
							}

							}
							break;

					}

					pushFollow(FOLLOW_unaryExpression_in_multiplicativeExpression11279);
					unaryExpression426=unaryExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, unaryExpression426.getTree());

					}
					break;

				default :
					break loop128;
				}
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 101, multiplicativeExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "multiplicativeExpression"


	public static class unaryExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "unaryExpression"
	// Java.g:855:1: unaryExpression : ( PLUS unaryExpression -> ^( UNARY_PLUS[$PLUS, \"UNARY_PLUS\"] unaryExpression ) | MINUS unaryExpression -> ^( UNARY_MINUS[$MINUS, \"UNARY_MINUS\"] unaryExpression ) | INC postfixedExpression -> ^( PRE_INC[$INC, \"PRE_INC\"] postfixedExpression ) | DEC postfixedExpression -> ^( PRE_DEC[$DEC, \"PRE_DEC\"] postfixedExpression ) | unaryExpressionNotPlusMinus );
	public final JavaParser.unaryExpression_return unaryExpression() throws RecognitionException {
		JavaParser.unaryExpression_return retval = new JavaParser.unaryExpression_return();
		retval.start = input.LT(1);
		int unaryExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token PLUS427=null;
		Token MINUS429=null;
		Token INC431=null;
		Token DEC433=null;
		ParserRuleReturnScope unaryExpression428 =null;
		ParserRuleReturnScope unaryExpression430 =null;
		ParserRuleReturnScope postfixedExpression432 =null;
		ParserRuleReturnScope postfixedExpression434 =null;
		ParserRuleReturnScope unaryExpressionNotPlusMinus435 =null;

		CommonTree PLUS427_tree=null;
		CommonTree MINUS429_tree=null;
		CommonTree INC431_tree=null;
		CommonTree DEC433_tree=null;
		RewriteRuleTokenStream stream_DEC=new RewriteRuleTokenStream(adaptor,"token DEC");
		RewriteRuleTokenStream stream_PLUS=new RewriteRuleTokenStream(adaptor,"token PLUS");
		RewriteRuleTokenStream stream_MINUS=new RewriteRuleTokenStream(adaptor,"token MINUS");
		RewriteRuleTokenStream stream_INC=new RewriteRuleTokenStream(adaptor,"token INC");
		RewriteRuleSubtreeStream stream_postfixedExpression=new RewriteRuleSubtreeStream(adaptor,"rule postfixedExpression");
		RewriteRuleSubtreeStream stream_unaryExpression=new RewriteRuleSubtreeStream(adaptor,"rule unaryExpression");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 102) ) { return retval; }

			// Java.g:856:5: ( PLUS unaryExpression -> ^( UNARY_PLUS[$PLUS, \"UNARY_PLUS\"] unaryExpression ) | MINUS unaryExpression -> ^( UNARY_MINUS[$MINUS, \"UNARY_MINUS\"] unaryExpression ) | INC postfixedExpression -> ^( PRE_INC[$INC, \"PRE_INC\"] postfixedExpression ) | DEC postfixedExpression -> ^( PRE_DEC[$DEC, \"PRE_DEC\"] postfixedExpression ) | unaryExpressionNotPlusMinus )
			int alt129=5;
			switch ( input.LA(1) ) {
			case PLUS:
				{
				alt129=1;
				}
				break;
			case MINUS:
				{
				alt129=2;
				}
				break;
			case INC:
				{
				alt129=3;
				}
				break;
			case DEC:
				{
				alt129=4;
				}
				break;
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case CHARACTER_LITERAL:
			case DECIMAL_LITERAL:
			case DOUBLE:
			case FALSE:
			case FLOAT:
			case FLOATING_POINT_LITERAL:
			case HEX_LITERAL:
			case IDENT:
			case INT:
			case LESS_THAN:
			case LOGICAL_NOT:
			case LONG:
			case LPAREN:
			case NEW:
			case NOT:
			case NULL:
			case OCTAL_LITERAL:
			case SHORT:
			case STRING_LITERAL:
			case SUPER:
			case THIS:
			case TRUE:
			case VOID:
				{
				alt129=5;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 129, 0, input);
				throw nvae;
			}
			switch (alt129) {
				case 1 :
					// Java.g:856:9: PLUS unaryExpression
					{
					PLUS427=(Token)match(input,PLUS,FOLLOW_PLUS_in_unaryExpression11309); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_PLUS.add(PLUS427);

					pushFollow(FOLLOW_unaryExpression_in_unaryExpression11311);
					unaryExpression428=unaryExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_unaryExpression.add(unaryExpression428.getTree());

					// AST REWRITE
					// elements: unaryExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 856:37: -> ^( UNARY_PLUS[$PLUS, \"UNARY_PLUS\"] unaryExpression )
					{
						// Java.g:856:41: ^( UNARY_PLUS[$PLUS, \"UNARY_PLUS\"] unaryExpression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(UNARY_PLUS, PLUS427, "UNARY_PLUS"), root_1);
						adaptor.addChild(root_1, stream_unaryExpression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 2 :
					// Java.g:857:9: MINUS unaryExpression
					{
					MINUS429=(Token)match(input,MINUS,FOLLOW_MINUS_in_unaryExpression11338); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_MINUS.add(MINUS429);

					pushFollow(FOLLOW_unaryExpression_in_unaryExpression11340);
					unaryExpression430=unaryExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_unaryExpression.add(unaryExpression430.getTree());

					// AST REWRITE
					// elements: unaryExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 857:37: -> ^( UNARY_MINUS[$MINUS, \"UNARY_MINUS\"] unaryExpression )
					{
						// Java.g:857:41: ^( UNARY_MINUS[$MINUS, \"UNARY_MINUS\"] unaryExpression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(UNARY_MINUS, MINUS429, "UNARY_MINUS"), root_1);
						adaptor.addChild(root_1, stream_unaryExpression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 3 :
					// Java.g:858:9: INC postfixedExpression
					{
					INC431=(Token)match(input,INC,FOLLOW_INC_in_unaryExpression11366); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_INC.add(INC431);

					pushFollow(FOLLOW_postfixedExpression_in_unaryExpression11368);
					postfixedExpression432=postfixedExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_postfixedExpression.add(postfixedExpression432.getTree());

					// AST REWRITE
					// elements: postfixedExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 858:37: -> ^( PRE_INC[$INC, \"PRE_INC\"] postfixedExpression )
					{
						// Java.g:858:41: ^( PRE_INC[$INC, \"PRE_INC\"] postfixedExpression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(PRE_INC, INC431, "PRE_INC"), root_1);
						adaptor.addChild(root_1, stream_postfixedExpression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 4 :
					// Java.g:859:9: DEC postfixedExpression
					{
					DEC433=(Token)match(input,DEC,FOLLOW_DEC_in_unaryExpression11392); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DEC.add(DEC433);

					pushFollow(FOLLOW_postfixedExpression_in_unaryExpression11394);
					postfixedExpression434=postfixedExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_postfixedExpression.add(postfixedExpression434.getTree());

					// AST REWRITE
					// elements: postfixedExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 859:37: -> ^( PRE_DEC[$DEC, \"PRE_DEC\"] postfixedExpression )
					{
						// Java.g:859:41: ^( PRE_DEC[$DEC, \"PRE_DEC\"] postfixedExpression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(PRE_DEC, DEC433, "PRE_DEC"), root_1);
						adaptor.addChild(root_1, stream_postfixedExpression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 5 :
					// Java.g:860:9: unaryExpressionNotPlusMinus
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_unaryExpressionNotPlusMinus_in_unaryExpression11418);
					unaryExpressionNotPlusMinus435=unaryExpressionNotPlusMinus();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, unaryExpressionNotPlusMinus435.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 102, unaryExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "unaryExpression"


	public static class unaryExpressionNotPlusMinus_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "unaryExpressionNotPlusMinus"
	// Java.g:863:1: unaryExpressionNotPlusMinus : ( NOT unaryExpression -> ^( NOT unaryExpression ) | LOGICAL_NOT unaryExpression -> ^( LOGICAL_NOT unaryExpression ) | LPAREN type RPAREN unaryExpression -> ^( CAST_EXPR[$LPAREN, \"CAST_EXPR\"] type unaryExpression ) | postfixedExpression );
	public final JavaParser.unaryExpressionNotPlusMinus_return unaryExpressionNotPlusMinus() throws RecognitionException {
		JavaParser.unaryExpressionNotPlusMinus_return retval = new JavaParser.unaryExpressionNotPlusMinus_return();
		retval.start = input.LT(1);
		int unaryExpressionNotPlusMinus_StartIndex = input.index();

		CommonTree root_0 = null;

		Token NOT436=null;
		Token LOGICAL_NOT438=null;
		Token LPAREN440=null;
		Token RPAREN442=null;
		ParserRuleReturnScope unaryExpression437 =null;
		ParserRuleReturnScope unaryExpression439 =null;
		ParserRuleReturnScope type441 =null;
		ParserRuleReturnScope unaryExpression443 =null;
		ParserRuleReturnScope postfixedExpression444 =null;

		CommonTree NOT436_tree=null;
		CommonTree LOGICAL_NOT438_tree=null;
		CommonTree LPAREN440_tree=null;
		CommonTree RPAREN442_tree=null;
		RewriteRuleTokenStream stream_NOT=new RewriteRuleTokenStream(adaptor,"token NOT");
		RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
		RewriteRuleTokenStream stream_LOGICAL_NOT=new RewriteRuleTokenStream(adaptor,"token LOGICAL_NOT");
		RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
		RewriteRuleSubtreeStream stream_unaryExpression=new RewriteRuleSubtreeStream(adaptor,"rule unaryExpression");
		RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 103) ) { return retval; }

			// Java.g:864:5: ( NOT unaryExpression -> ^( NOT unaryExpression ) | LOGICAL_NOT unaryExpression -> ^( LOGICAL_NOT unaryExpression ) | LPAREN type RPAREN unaryExpression -> ^( CAST_EXPR[$LPAREN, \"CAST_EXPR\"] type unaryExpression ) | postfixedExpression )
			int alt130=4;
			switch ( input.LA(1) ) {
			case NOT:
				{
				alt130=1;
				}
				break;
			case LOGICAL_NOT:
				{
				alt130=2;
				}
				break;
			case LPAREN:
				{
				int LA130_3 = input.LA(2);
				if ( (synpred193_Java()) ) {
					alt130=3;
				}
				else if ( (true) ) {
					alt130=4;
				}

				}
				break;
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case CHARACTER_LITERAL:
			case DECIMAL_LITERAL:
			case DOUBLE:
			case FALSE:
			case FLOAT:
			case FLOATING_POINT_LITERAL:
			case HEX_LITERAL:
			case IDENT:
			case INT:
			case LESS_THAN:
			case LONG:
			case NEW:
			case NULL:
			case OCTAL_LITERAL:
			case SHORT:
			case STRING_LITERAL:
			case SUPER:
			case THIS:
			case TRUE:
			case VOID:
				{
				alt130=4;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 130, 0, input);
				throw nvae;
			}
			switch (alt130) {
				case 1 :
					// Java.g:864:9: NOT unaryExpression
					{
					NOT436=(Token)match(input,NOT,FOLLOW_NOT_in_unaryExpressionNotPlusMinus11437); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_NOT.add(NOT436);

					pushFollow(FOLLOW_unaryExpression_in_unaryExpressionNotPlusMinus11439);
					unaryExpression437=unaryExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_unaryExpression.add(unaryExpression437.getTree());

					// AST REWRITE
					// elements: NOT, unaryExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 864:57: -> ^( NOT unaryExpression )
					{
						// Java.g:864:61: ^( NOT unaryExpression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_NOT.nextNode(), root_1);
						adaptor.addChild(root_1, stream_unaryExpression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 2 :
					// Java.g:865:9: LOGICAL_NOT unaryExpression
					{
					LOGICAL_NOT438=(Token)match(input,LOGICAL_NOT,FOLLOW_LOGICAL_NOT_in_unaryExpressionNotPlusMinus11486); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_LOGICAL_NOT.add(LOGICAL_NOT438);

					pushFollow(FOLLOW_unaryExpression_in_unaryExpressionNotPlusMinus11488);
					unaryExpression439=unaryExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_unaryExpression.add(unaryExpression439.getTree());

					// AST REWRITE
					// elements: unaryExpression, LOGICAL_NOT
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 865:57: -> ^( LOGICAL_NOT unaryExpression )
					{
						// Java.g:865:61: ^( LOGICAL_NOT unaryExpression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_LOGICAL_NOT.nextNode(), root_1);
						adaptor.addChild(root_1, stream_unaryExpression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 3 :
					// Java.g:866:9: LPAREN type RPAREN unaryExpression
					{
					LPAREN440=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_unaryExpressionNotPlusMinus11527); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_LPAREN.add(LPAREN440);

					pushFollow(FOLLOW_type_in_unaryExpressionNotPlusMinus11529);
					type441=type();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_type.add(type441.getTree());
					RPAREN442=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_unaryExpressionNotPlusMinus11531); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_RPAREN.add(RPAREN442);

					pushFollow(FOLLOW_unaryExpression_in_unaryExpressionNotPlusMinus11533);
					unaryExpression443=unaryExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_unaryExpression.add(unaryExpression443.getTree());

					// AST REWRITE
					// elements: unaryExpression, type
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 866:57: -> ^( CAST_EXPR[$LPAREN, \"CAST_EXPR\"] type unaryExpression )
					{
						// Java.g:866:61: ^( CAST_EXPR[$LPAREN, \"CAST_EXPR\"] type unaryExpression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CAST_EXPR, LPAREN440, "CAST_EXPR"), root_1);
						adaptor.addChild(root_1, stream_type.nextTree());
						adaptor.addChild(root_1, stream_unaryExpression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 4 :
					// Java.g:867:9: postfixedExpression
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_postfixedExpression_in_unaryExpressionNotPlusMinus11568);
					postfixedExpression444=postfixedExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, postfixedExpression444.getTree());

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 103, unaryExpressionNotPlusMinus_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "unaryExpressionNotPlusMinus"


	public static class postfixedExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "postfixedExpression"
	// Java.g:870:1: postfixedExpression : ( primaryExpression -> primaryExpression ) (outerDot= DOT ( ( ( genericTypeArgumentListSimplified )? IDENT -> ^( DOT $postfixedExpression IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression ( genericTypeArgumentListSimplified )? arguments ) )? | THIS -> ^( DOT $postfixedExpression THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] $postfixedExpression arguments ) | ( SUPER innerDot= DOT IDENT -> ^( $innerDot ^( $outerDot $postfixedExpression SUPER ) IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression arguments ) )? | innerNewExpression -> ^( DOT $postfixedExpression innerNewExpression ) ) | LBRACK expression RBRACK -> ^( ARRAY_ELEMENT_ACCESS $postfixedExpression expression ) )* ( INC -> ^( POST_INC[$INC, \"POST_INC\"] $postfixedExpression) | DEC -> ^( POST_DEC[$DEC, \"POST_DEC\"] $postfixedExpression) )? ;
	public final JavaParser.postfixedExpression_return postfixedExpression() throws RecognitionException {
		JavaParser.postfixedExpression_return retval = new JavaParser.postfixedExpression_return();
		retval.start = input.LT(1);
		int postfixedExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token outerDot=null;
		Token Super=null;
		Token innerDot=null;
		Token IDENT447=null;
		Token THIS449=null;
		Token SUPER451=null;
		Token IDENT452=null;
		Token LBRACK455=null;
		Token RBRACK457=null;
		Token INC458=null;
		Token DEC459=null;
		ParserRuleReturnScope primaryExpression445 =null;
		ParserRuleReturnScope genericTypeArgumentListSimplified446 =null;
		ParserRuleReturnScope arguments448 =null;
		ParserRuleReturnScope arguments450 =null;
		ParserRuleReturnScope arguments453 =null;
		ParserRuleReturnScope innerNewExpression454 =null;
		ParserRuleReturnScope expression456 =null;

		CommonTree outerDot_tree=null;
		CommonTree Super_tree=null;
		CommonTree innerDot_tree=null;
		CommonTree IDENT447_tree=null;
		CommonTree THIS449_tree=null;
		CommonTree SUPER451_tree=null;
		CommonTree IDENT452_tree=null;
		CommonTree LBRACK455_tree=null;
		CommonTree RBRACK457_tree=null;
		CommonTree INC458_tree=null;
		CommonTree DEC459_tree=null;
		RewriteRuleTokenStream stream_SUPER=new RewriteRuleTokenStream(adaptor,"token SUPER");
		RewriteRuleTokenStream stream_RBRACK=new RewriteRuleTokenStream(adaptor,"token RBRACK");
		RewriteRuleTokenStream stream_DEC=new RewriteRuleTokenStream(adaptor,"token DEC");
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleTokenStream stream_LBRACK=new RewriteRuleTokenStream(adaptor,"token LBRACK");
		RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
		RewriteRuleTokenStream stream_THIS=new RewriteRuleTokenStream(adaptor,"token THIS");
		RewriteRuleTokenStream stream_INC=new RewriteRuleTokenStream(adaptor,"token INC");
		RewriteRuleSubtreeStream stream_primaryExpression=new RewriteRuleSubtreeStream(adaptor,"rule primaryExpression");
		RewriteRuleSubtreeStream stream_innerNewExpression=new RewriteRuleSubtreeStream(adaptor,"rule innerNewExpression");
		RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
		RewriteRuleSubtreeStream stream_genericTypeArgumentListSimplified=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeArgumentListSimplified");
		RewriteRuleSubtreeStream stream_arguments=new RewriteRuleSubtreeStream(adaptor,"rule arguments");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 104) ) { return retval; }

			// Java.g:872:5: ( ( primaryExpression -> primaryExpression ) (outerDot= DOT ( ( ( genericTypeArgumentListSimplified )? IDENT -> ^( DOT $postfixedExpression IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression ( genericTypeArgumentListSimplified )? arguments ) )? | THIS -> ^( DOT $postfixedExpression THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] $postfixedExpression arguments ) | ( SUPER innerDot= DOT IDENT -> ^( $innerDot ^( $outerDot $postfixedExpression SUPER ) IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression arguments ) )? | innerNewExpression -> ^( DOT $postfixedExpression innerNewExpression ) ) | LBRACK expression RBRACK -> ^( ARRAY_ELEMENT_ACCESS $postfixedExpression expression ) )* ( INC -> ^( POST_INC[$INC, \"POST_INC\"] $postfixedExpression) | DEC -> ^( POST_DEC[$DEC, \"POST_DEC\"] $postfixedExpression) )? )
			// Java.g:872:9: ( primaryExpression -> primaryExpression ) (outerDot= DOT ( ( ( genericTypeArgumentListSimplified )? IDENT -> ^( DOT $postfixedExpression IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression ( genericTypeArgumentListSimplified )? arguments ) )? | THIS -> ^( DOT $postfixedExpression THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] $postfixedExpression arguments ) | ( SUPER innerDot= DOT IDENT -> ^( $innerDot ^( $outerDot $postfixedExpression SUPER ) IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression arguments ) )? | innerNewExpression -> ^( DOT $postfixedExpression innerNewExpression ) ) | LBRACK expression RBRACK -> ^( ARRAY_ELEMENT_ACCESS $postfixedExpression expression ) )* ( INC -> ^( POST_INC[$INC, \"POST_INC\"] $postfixedExpression) | DEC -> ^( POST_DEC[$DEC, \"POST_DEC\"] $postfixedExpression) )?
			{
			// Java.g:872:9: ( primaryExpression -> primaryExpression )
			// Java.g:872:13: primaryExpression
			{
			pushFollow(FOLLOW_primaryExpression_in_postfixedExpression11600);
			primaryExpression445=primaryExpression();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_primaryExpression.add(primaryExpression445.getTree());

			// AST REWRITE
			// elements: primaryExpression
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 872:53: -> primaryExpression
			{
				adaptor.addChild(root_0, stream_primaryExpression.nextTree());
			}


			retval.tree = root_0;
			}

			}

			// Java.g:875:9: (outerDot= DOT ( ( ( genericTypeArgumentListSimplified )? IDENT -> ^( DOT $postfixedExpression IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression ( genericTypeArgumentListSimplified )? arguments ) )? | THIS -> ^( DOT $postfixedExpression THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] $postfixedExpression arguments ) | ( SUPER innerDot= DOT IDENT -> ^( $innerDot ^( $outerDot $postfixedExpression SUPER ) IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression arguments ) )? | innerNewExpression -> ^( DOT $postfixedExpression innerNewExpression ) ) | LBRACK expression RBRACK -> ^( ARRAY_ELEMENT_ACCESS $postfixedExpression expression ) )*
			loop135:
			while (true) {
				int alt135=3;
				int LA135_0 = input.LA(1);
				if ( (LA135_0==DOT) ) {
					alt135=1;
				}
				else if ( (LA135_0==LBRACK) ) {
					alt135=2;
				}

				switch (alt135) {
				case 1 :
					// Java.g:875:13: outerDot= DOT ( ( ( genericTypeArgumentListSimplified )? IDENT -> ^( DOT $postfixedExpression IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression ( genericTypeArgumentListSimplified )? arguments ) )? | THIS -> ^( DOT $postfixedExpression THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] $postfixedExpression arguments ) | ( SUPER innerDot= DOT IDENT -> ^( $innerDot ^( $outerDot $postfixedExpression SUPER ) IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression arguments ) )? | innerNewExpression -> ^( DOT $postfixedExpression innerNewExpression ) )
					{
					outerDot=(Token)match(input,DOT,FOLLOW_DOT_in_postfixedExpression11662); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DOT.add(outerDot);

					// Java.g:876:13: ( ( ( genericTypeArgumentListSimplified )? IDENT -> ^( DOT $postfixedExpression IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression ( genericTypeArgumentListSimplified )? arguments ) )? | THIS -> ^( DOT $postfixedExpression THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] $postfixedExpression arguments ) | ( SUPER innerDot= DOT IDENT -> ^( $innerDot ^( $outerDot $postfixedExpression SUPER ) IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression arguments ) )? | innerNewExpression -> ^( DOT $postfixedExpression innerNewExpression ) )
					int alt134=5;
					switch ( input.LA(1) ) {
					case IDENT:
					case LESS_THAN:
						{
						alt134=1;
						}
						break;
					case THIS:
						{
						alt134=2;
						}
						break;
					case SUPER:
						{
						int LA134_3 = input.LA(2);
						if ( (LA134_3==DOT) ) {
							alt134=4;
						}
						else if ( (LA134_3==LPAREN) ) {
							alt134=3;
						}

						else {
							if (state.backtracking>0) {state.failed=true; return retval;}
							int nvaeMark = input.mark();
							try {
								input.consume();
								NoViableAltException nvae =
									new NoViableAltException("", 134, 3, input);
								throw nvae;
							} finally {
								input.rewind(nvaeMark);
							}
						}

						}
						break;
					case NEW:
						{
						alt134=5;
						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 134, 0, input);
						throw nvae;
					}
					switch (alt134) {
						case 1 :
							// Java.g:876:17: ( ( genericTypeArgumentListSimplified )? IDENT -> ^( DOT $postfixedExpression IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression ( genericTypeArgumentListSimplified )? arguments ) )?
							{
							// Java.g:876:17: ( ( genericTypeArgumentListSimplified )? IDENT -> ^( DOT $postfixedExpression IDENT ) )
							// Java.g:876:21: ( genericTypeArgumentListSimplified )? IDENT
							{
							// Java.g:876:21: ( genericTypeArgumentListSimplified )?
							int alt131=2;
							int LA131_0 = input.LA(1);
							if ( (LA131_0==LESS_THAN) ) {
								alt131=1;
							}
							switch (alt131) {
								case 1 :
									// Java.g:876:21: genericTypeArgumentListSimplified
									{
									pushFollow(FOLLOW_genericTypeArgumentListSimplified_in_postfixedExpression11684);
									genericTypeArgumentListSimplified446=genericTypeArgumentListSimplified();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_genericTypeArgumentListSimplified.add(genericTypeArgumentListSimplified446.getTree());
									}
									break;

							}

							IDENT447=(Token)match(input,IDENT,FOLLOW_IDENT_in_postfixedExpression11766); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_IDENT.add(IDENT447);


							// AST REWRITE
							// elements: postfixedExpression, IDENT, DOT
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 878:53: -> ^( DOT $postfixedExpression IDENT )
							{
								// Java.g:878:57: ^( DOT $postfixedExpression IDENT )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
								adaptor.addChild(root_1, stream_retval.nextTree());
								adaptor.addChild(root_1, stream_IDENT.nextNode());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}

							// Java.g:880:17: ( arguments -> ^( METHOD_CALL $postfixedExpression ( genericTypeArgumentListSimplified )? arguments ) )?
							int alt132=2;
							int LA132_0 = input.LA(1);
							if ( (LA132_0==LPAREN) ) {
								alt132=1;
							}
							switch (alt132) {
								case 1 :
									// Java.g:880:21: arguments
									{
									pushFollow(FOLLOW_arguments_in_postfixedExpression11844);
									arguments448=arguments();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_arguments.add(arguments448.getTree());

									// AST REWRITE
									// elements: postfixedExpression, arguments, genericTypeArgumentListSimplified
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 880:53: -> ^( METHOD_CALL $postfixedExpression ( genericTypeArgumentListSimplified )? arguments )
									{
										// Java.g:880:57: ^( METHOD_CALL $postfixedExpression ( genericTypeArgumentListSimplified )? arguments )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_CALL, "METHOD_CALL"), root_1);
										adaptor.addChild(root_1, stream_retval.nextTree());
										// Java.g:880:92: ( genericTypeArgumentListSimplified )?
										if ( stream_genericTypeArgumentListSimplified.hasNext() ) {
											adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
										}
										stream_genericTypeArgumentListSimplified.reset();

										adaptor.addChild(root_1, stream_arguments.nextTree());
										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;

							}

							}
							break;
						case 2 :
							// Java.g:882:17: THIS
							{
							THIS449=(Token)match(input,THIS,FOLLOW_THIS_in_postfixedExpression11918); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_THIS.add(THIS449);


							// AST REWRITE
							// elements: DOT, THIS, postfixedExpression
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 882:53: -> ^( DOT $postfixedExpression THIS )
							{
								// Java.g:882:57: ^( DOT $postfixedExpression THIS )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
								adaptor.addChild(root_1, stream_retval.nextTree());
								adaptor.addChild(root_1, stream_THIS.nextNode());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 3 :
							// Java.g:883:17: Super= SUPER arguments
							{
							Super=(Token)match(input,SUPER,FOLLOW_SUPER_in_postfixedExpression11981); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SUPER.add(Super);

							pushFollow(FOLLOW_arguments_in_postfixedExpression11983);
							arguments450=arguments();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_arguments.add(arguments450.getTree());

							// AST REWRITE
							// elements: arguments, postfixedExpression
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 883:57: -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] $postfixedExpression arguments )
							{
								// Java.g:883:61: ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] $postfixedExpression arguments )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(SUPER_CONSTRUCTOR_CALL, Super, "SUPER_CONSTRUCTOR_CALL"), root_1);
								adaptor.addChild(root_1, stream_retval.nextTree());
								adaptor.addChild(root_1, stream_arguments.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 4 :
							// Java.g:884:17: ( SUPER innerDot= DOT IDENT -> ^( $innerDot ^( $outerDot $postfixedExpression SUPER ) IDENT ) ) ( arguments -> ^( METHOD_CALL $postfixedExpression arguments ) )?
							{
							// Java.g:884:17: ( SUPER innerDot= DOT IDENT -> ^( $innerDot ^( $outerDot $postfixedExpression SUPER ) IDENT ) )
							// Java.g:884:21: SUPER innerDot= DOT IDENT
							{
							SUPER451=(Token)match(input,SUPER,FOLLOW_SUPER_in_postfixedExpression12036); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SUPER.add(SUPER451);

							innerDot=(Token)match(input,DOT,FOLLOW_DOT_in_postfixedExpression12040); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_DOT.add(innerDot);

							IDENT452=(Token)match(input,IDENT,FOLLOW_IDENT_in_postfixedExpression12042); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_IDENT.add(IDENT452);


							// AST REWRITE
							// elements: innerDot, SUPER, outerDot, postfixedExpression, IDENT
							// token labels: innerDot, outerDot
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleTokenStream stream_innerDot=new RewriteRuleTokenStream(adaptor,"token innerDot",innerDot);
							RewriteRuleTokenStream stream_outerDot=new RewriteRuleTokenStream(adaptor,"token outerDot",outerDot);
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 884:53: -> ^( $innerDot ^( $outerDot $postfixedExpression SUPER ) IDENT )
							{
								// Java.g:884:57: ^( $innerDot ^( $outerDot $postfixedExpression SUPER ) IDENT )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_innerDot.nextNode(), root_1);
								// Java.g:884:69: ^( $outerDot $postfixedExpression SUPER )
								{
								CommonTree root_2 = (CommonTree)adaptor.nil();
								root_2 = (CommonTree)adaptor.becomeRoot(stream_outerDot.nextNode(), root_2);
								adaptor.addChild(root_2, stream_retval.nextTree());
								adaptor.addChild(root_2, stream_SUPER.nextNode());
								adaptor.addChild(root_1, root_2);
								}

								adaptor.addChild(root_1, stream_IDENT.nextNode());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}

							// Java.g:886:17: ( arguments -> ^( METHOD_CALL $postfixedExpression arguments ) )?
							int alt133=2;
							int LA133_0 = input.LA(1);
							if ( (LA133_0==LPAREN) ) {
								alt133=1;
							}
							switch (alt133) {
								case 1 :
									// Java.g:886:21: arguments
									{
									pushFollow(FOLLOW_arguments_in_postfixedExpression12109);
									arguments453=arguments();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_arguments.add(arguments453.getTree());

									// AST REWRITE
									// elements: arguments, postfixedExpression
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 886:53: -> ^( METHOD_CALL $postfixedExpression arguments )
									{
										// Java.g:886:57: ^( METHOD_CALL $postfixedExpression arguments )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_CALL, "METHOD_CALL"), root_1);
										adaptor.addChild(root_1, stream_retval.nextTree());
										adaptor.addChild(root_1, stream_arguments.nextTree());
										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;

							}

							}
							break;
						case 5 :
							// Java.g:888:17: innerNewExpression
							{
							pushFollow(FOLLOW_innerNewExpression_in_postfixedExpression12180);
							innerNewExpression454=innerNewExpression();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_innerNewExpression.add(innerNewExpression454.getTree());

							// AST REWRITE
							// elements: DOT, postfixedExpression, innerNewExpression
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 888:53: -> ^( DOT $postfixedExpression innerNewExpression )
							{
								// Java.g:888:57: ^( DOT $postfixedExpression innerNewExpression )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
								adaptor.addChild(root_1, stream_retval.nextTree());
								adaptor.addChild(root_1, stream_innerNewExpression.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;
				case 2 :
					// Java.g:890:13: LBRACK expression RBRACK
					{
					LBRACK455=(Token)match(input,LBRACK,FOLLOW_LBRACK_in_postfixedExpression12237); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_LBRACK.add(LBRACK455);

					pushFollow(FOLLOW_expression_in_postfixedExpression12239);
					expression456=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_expression.add(expression456.getTree());
					RBRACK457=(Token)match(input,RBRACK,FOLLOW_RBRACK_in_postfixedExpression12241); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_RBRACK.add(RBRACK457);


					// AST REWRITE
					// elements: expression, postfixedExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 890:53: -> ^( ARRAY_ELEMENT_ACCESS $postfixedExpression expression )
					{
						// Java.g:890:57: ^( ARRAY_ELEMENT_ACCESS $postfixedExpression expression )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ARRAY_ELEMENT_ACCESS, "ARRAY_ELEMENT_ACCESS"), root_1);
						adaptor.addChild(root_1, stream_retval.nextTree());
						adaptor.addChild(root_1, stream_expression.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;

				default :
					break loop135;
				}
			}

			// Java.g:893:9: ( INC -> ^( POST_INC[$INC, \"POST_INC\"] $postfixedExpression) | DEC -> ^( POST_DEC[$DEC, \"POST_DEC\"] $postfixedExpression) )?
			int alt136=3;
			int LA136_0 = input.LA(1);
			if ( (LA136_0==INC) ) {
				alt136=1;
			}
			else if ( (LA136_0==DEC) ) {
				alt136=2;
			}
			switch (alt136) {
				case 1 :
					// Java.g:893:13: INC
					{
					INC458=(Token)match(input,INC,FOLLOW_INC_in_postfixedExpression12302); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_INC.add(INC458);


					// AST REWRITE
					// elements: postfixedExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 893:17: -> ^( POST_INC[$INC, \"POST_INC\"] $postfixedExpression)
					{
						// Java.g:893:20: ^( POST_INC[$INC, \"POST_INC\"] $postfixedExpression)
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(POST_INC, INC458, "POST_INC"), root_1);
						adaptor.addChild(root_1, stream_retval.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 2 :
					// Java.g:894:13: DEC
					{
					DEC459=(Token)match(input,DEC,FOLLOW_DEC_in_postfixedExpression12326); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DEC.add(DEC459);


					// AST REWRITE
					// elements: postfixedExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 894:17: -> ^( POST_DEC[$DEC, \"POST_DEC\"] $postfixedExpression)
					{
						// Java.g:894:20: ^( POST_DEC[$DEC, \"POST_DEC\"] $postfixedExpression)
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(POST_DEC, DEC459, "POST_DEC"), root_1);
						adaptor.addChild(root_1, stream_retval.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 104, postfixedExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "postfixedExpression"


	public static class primaryExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "primaryExpression"
	// Java.g:898:1: primaryExpression : ( parenthesizedExpression | literal | newExpression | qualifiedIdentExpression | genericTypeArgumentListSimplified ( SUPER ( arguments -> ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments ) | DOT IDENT arguments -> ^( METHOD_CALL ^( DOT SUPER IDENT ) genericTypeArgumentListSimplified arguments ) ) | IDENT arguments -> ^( METHOD_CALL IDENT genericTypeArgumentListSimplified arguments ) | THIS arguments -> ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments ) ) | ( THIS -> THIS ) ( arguments -> ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] arguments ) )? | SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] arguments ) | ( SUPER DOT IDENT ) ( arguments -> ^( METHOD_CALL ^( DOT SUPER IDENT ) arguments ) | -> ^( DOT SUPER IDENT ) ) | ( primitiveType -> primitiveType ) ( arrayDeclarator -> ^( arrayDeclarator $primaryExpression) )* DOT CLASS -> ^( DOT $primaryExpression CLASS ) | VOID DOT CLASS -> ^( DOT VOID CLASS ) );
	public final JavaParser.primaryExpression_return primaryExpression() throws RecognitionException {
		JavaParser.primaryExpression_return retval = new JavaParser.primaryExpression_return();
		retval.start = input.LT(1);
		int primaryExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token SUPER465=null;
		Token DOT467=null;
		Token IDENT468=null;
		Token IDENT470=null;
		Token THIS472=null;
		Token THIS474=null;
		Token SUPER476=null;
		Token SUPER478=null;
		Token DOT479=null;
		Token IDENT480=null;
		Token DOT484=null;
		Token CLASS485=null;
		Token VOID486=null;
		Token DOT487=null;
		Token CLASS488=null;
		ParserRuleReturnScope parenthesizedExpression460 =null;
		ParserRuleReturnScope literal461 =null;
		ParserRuleReturnScope newExpression462 =null;
		ParserRuleReturnScope qualifiedIdentExpression463 =null;
		ParserRuleReturnScope genericTypeArgumentListSimplified464 =null;
		ParserRuleReturnScope arguments466 =null;
		ParserRuleReturnScope arguments469 =null;
		ParserRuleReturnScope arguments471 =null;
		ParserRuleReturnScope arguments473 =null;
		ParserRuleReturnScope arguments475 =null;
		ParserRuleReturnScope arguments477 =null;
		ParserRuleReturnScope arguments481 =null;
		ParserRuleReturnScope primitiveType482 =null;
		ParserRuleReturnScope arrayDeclarator483 =null;

		CommonTree SUPER465_tree=null;
		CommonTree DOT467_tree=null;
		CommonTree IDENT468_tree=null;
		CommonTree IDENT470_tree=null;
		CommonTree THIS472_tree=null;
		CommonTree THIS474_tree=null;
		CommonTree SUPER476_tree=null;
		CommonTree SUPER478_tree=null;
		CommonTree DOT479_tree=null;
		CommonTree IDENT480_tree=null;
		CommonTree DOT484_tree=null;
		CommonTree CLASS485_tree=null;
		CommonTree VOID486_tree=null;
		CommonTree DOT487_tree=null;
		CommonTree CLASS488_tree=null;
		RewriteRuleTokenStream stream_SUPER=new RewriteRuleTokenStream(adaptor,"token SUPER");
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
		RewriteRuleTokenStream stream_THIS=new RewriteRuleTokenStream(adaptor,"token THIS");
		RewriteRuleTokenStream stream_CLASS=new RewriteRuleTokenStream(adaptor,"token CLASS");
		RewriteRuleTokenStream stream_VOID=new RewriteRuleTokenStream(adaptor,"token VOID");
		RewriteRuleSubtreeStream stream_arrayDeclarator=new RewriteRuleSubtreeStream(adaptor,"rule arrayDeclarator");
		RewriteRuleSubtreeStream stream_genericTypeArgumentListSimplified=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeArgumentListSimplified");
		RewriteRuleSubtreeStream stream_arguments=new RewriteRuleSubtreeStream(adaptor,"rule arguments");
		RewriteRuleSubtreeStream stream_primitiveType=new RewriteRuleSubtreeStream(adaptor,"rule primitiveType");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 105) ) { return retval; }

			// Java.g:899:5: ( parenthesizedExpression | literal | newExpression | qualifiedIdentExpression | genericTypeArgumentListSimplified ( SUPER ( arguments -> ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments ) | DOT IDENT arguments -> ^( METHOD_CALL ^( DOT SUPER IDENT ) genericTypeArgumentListSimplified arguments ) ) | IDENT arguments -> ^( METHOD_CALL IDENT genericTypeArgumentListSimplified arguments ) | THIS arguments -> ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments ) ) | ( THIS -> THIS ) ( arguments -> ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] arguments ) )? | SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] arguments ) | ( SUPER DOT IDENT ) ( arguments -> ^( METHOD_CALL ^( DOT SUPER IDENT ) arguments ) | -> ^( DOT SUPER IDENT ) ) | ( primitiveType -> primitiveType ) ( arrayDeclarator -> ^( arrayDeclarator $primaryExpression) )* DOT CLASS -> ^( DOT $primaryExpression CLASS ) | VOID DOT CLASS -> ^( DOT VOID CLASS ) )
			int alt142=10;
			switch ( input.LA(1) ) {
			case LPAREN:
				{
				alt142=1;
				}
				break;
			case CHARACTER_LITERAL:
			case DECIMAL_LITERAL:
			case FALSE:
			case FLOATING_POINT_LITERAL:
			case HEX_LITERAL:
			case NULL:
			case OCTAL_LITERAL:
			case STRING_LITERAL:
			case TRUE:
				{
				alt142=2;
				}
				break;
			case NEW:
				{
				alt142=3;
				}
				break;
			case IDENT:
				{
				alt142=4;
				}
				break;
			case LESS_THAN:
				{
				alt142=5;
				}
				break;
			case THIS:
				{
				alt142=6;
				}
				break;
			case SUPER:
				{
				int LA142_7 = input.LA(2);
				if ( (LA142_7==DOT) ) {
					alt142=8;
				}
				else if ( (LA142_7==LPAREN) ) {
					alt142=7;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 142, 7, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

				}
				break;
			case BOOLEAN:
			case BYTE:
			case CHAR:
			case DOUBLE:
			case FLOAT:
			case INT:
			case LONG:
			case SHORT:
				{
				alt142=9;
				}
				break;
			case VOID:
				{
				alt142=10;
				}
				break;
			default:
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 142, 0, input);
				throw nvae;
			}
			switch (alt142) {
				case 1 :
					// Java.g:899:9: parenthesizedExpression
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_parenthesizedExpression_in_primaryExpression12366);
					parenthesizedExpression460=parenthesizedExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, parenthesizedExpression460.getTree());

					}
					break;
				case 2 :
					// Java.g:900:9: literal
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_literal_in_primaryExpression12376);
					literal461=literal();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, literal461.getTree());

					}
					break;
				case 3 :
					// Java.g:901:9: newExpression
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_newExpression_in_primaryExpression12386);
					newExpression462=newExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, newExpression462.getTree());

					}
					break;
				case 4 :
					// Java.g:902:9: qualifiedIdentExpression
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_qualifiedIdentExpression_in_primaryExpression12396);
					qualifiedIdentExpression463=qualifiedIdentExpression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, qualifiedIdentExpression463.getTree());

					}
					break;
				case 5 :
					// Java.g:903:9: genericTypeArgumentListSimplified ( SUPER ( arguments -> ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments ) | DOT IDENT arguments -> ^( METHOD_CALL ^( DOT SUPER IDENT ) genericTypeArgumentListSimplified arguments ) ) | IDENT arguments -> ^( METHOD_CALL IDENT genericTypeArgumentListSimplified arguments ) | THIS arguments -> ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments ) )
					{
					pushFollow(FOLLOW_genericTypeArgumentListSimplified_in_primaryExpression12406);
					genericTypeArgumentListSimplified464=genericTypeArgumentListSimplified();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_genericTypeArgumentListSimplified.add(genericTypeArgumentListSimplified464.getTree());
					// Java.g:904:9: ( SUPER ( arguments -> ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments ) | DOT IDENT arguments -> ^( METHOD_CALL ^( DOT SUPER IDENT ) genericTypeArgumentListSimplified arguments ) ) | IDENT arguments -> ^( METHOD_CALL IDENT genericTypeArgumentListSimplified arguments ) | THIS arguments -> ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments ) )
					int alt138=3;
					switch ( input.LA(1) ) {
					case SUPER:
						{
						alt138=1;
						}
						break;
					case IDENT:
						{
						alt138=2;
						}
						break;
					case THIS:
						{
						alt138=3;
						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 138, 0, input);
						throw nvae;
					}
					switch (alt138) {
						case 1 :
							// Java.g:904:13: SUPER ( arguments -> ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments ) | DOT IDENT arguments -> ^( METHOD_CALL ^( DOT SUPER IDENT ) genericTypeArgumentListSimplified arguments ) )
							{
							SUPER465=(Token)match(input,SUPER,FOLLOW_SUPER_in_primaryExpression12420); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SUPER.add(SUPER465);

							// Java.g:905:13: ( arguments -> ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments ) | DOT IDENT arguments -> ^( METHOD_CALL ^( DOT SUPER IDENT ) genericTypeArgumentListSimplified arguments ) )
							int alt137=2;
							int LA137_0 = input.LA(1);
							if ( (LA137_0==LPAREN) ) {
								alt137=1;
							}
							else if ( (LA137_0==DOT) ) {
								alt137=2;
							}

							else {
								if (state.backtracking>0) {state.failed=true; return retval;}
								NoViableAltException nvae =
									new NoViableAltException("", 137, 0, input);
								throw nvae;
							}

							switch (alt137) {
								case 1 :
									// Java.g:905:17: arguments
									{
									pushFollow(FOLLOW_arguments_in_primaryExpression12438);
									arguments466=arguments();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_arguments.add(arguments466.getTree());

									// AST REWRITE
									// elements: genericTypeArgumentListSimplified, arguments
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 905:57: -> ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments )
									{
										// Java.g:905:61: ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(SUPER_CONSTRUCTOR_CALL, SUPER465, "SUPER_CONSTRUCTOR_CALL"), root_1);
										adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
										adaptor.addChild(root_1, stream_arguments.nextTree());
										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;
								case 2 :
									// Java.g:906:17: DOT IDENT arguments
									{
									DOT467=(Token)match(input,DOT,FOLLOW_DOT_in_primaryExpression12498); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_DOT.add(DOT467);

									IDENT468=(Token)match(input,IDENT,FOLLOW_IDENT_in_primaryExpression12500); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_IDENT.add(IDENT468);

									pushFollow(FOLLOW_arguments_in_primaryExpression12502);
									arguments469=arguments();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_arguments.add(arguments469.getTree());

									// AST REWRITE
									// elements: SUPER, genericTypeArgumentListSimplified, arguments, DOT, IDENT
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 906:57: -> ^( METHOD_CALL ^( DOT SUPER IDENT ) genericTypeArgumentListSimplified arguments )
									{
										// Java.g:906:61: ^( METHOD_CALL ^( DOT SUPER IDENT ) genericTypeArgumentListSimplified arguments )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_CALL, "METHOD_CALL"), root_1);
										// Java.g:906:75: ^( DOT SUPER IDENT )
										{
										CommonTree root_2 = (CommonTree)adaptor.nil();
										root_2 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_2);
										adaptor.addChild(root_2, stream_SUPER.nextNode());
										adaptor.addChild(root_2, stream_IDENT.nextNode());
										adaptor.addChild(root_1, root_2);
										}

										adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
										adaptor.addChild(root_1, stream_arguments.nextTree());
										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;

							}

							}
							break;
						case 2 :
							// Java.g:908:13: IDENT arguments
							{
							IDENT470=(Token)match(input,IDENT,FOLLOW_IDENT_in_primaryExpression12569); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_IDENT.add(IDENT470);

							pushFollow(FOLLOW_arguments_in_primaryExpression12571);
							arguments471=arguments();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_arguments.add(arguments471.getTree());

							// AST REWRITE
							// elements: genericTypeArgumentListSimplified, arguments, IDENT
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 908:57: -> ^( METHOD_CALL IDENT genericTypeArgumentListSimplified arguments )
							{
								// Java.g:908:61: ^( METHOD_CALL IDENT genericTypeArgumentListSimplified arguments )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_CALL, "METHOD_CALL"), root_1);
								adaptor.addChild(root_1, stream_IDENT.nextNode());
								adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
								adaptor.addChild(root_1, stream_arguments.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 3 :
							// Java.g:909:13: THIS arguments
							{
							THIS472=(Token)match(input,THIS,FOLLOW_THIS_in_primaryExpression12626); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_THIS.add(THIS472);

							pushFollow(FOLLOW_arguments_in_primaryExpression12628);
							arguments473=arguments();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_arguments.add(arguments473.getTree());

							// AST REWRITE
							// elements: genericTypeArgumentListSimplified, arguments
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 909:57: -> ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments )
							{
								// Java.g:909:61: ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] genericTypeArgumentListSimplified arguments )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(THIS_CONSTRUCTOR_CALL, THIS472, "THIS_CONSTRUCTOR_CALL"), root_1);
								adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
								adaptor.addChild(root_1, stream_arguments.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;
				case 6 :
					// Java.g:911:9: ( THIS -> THIS ) ( arguments -> ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] arguments ) )?
					{
					// Java.g:911:9: ( THIS -> THIS )
					// Java.g:911:13: THIS
					{
					THIS474=(Token)match(input,THIS,FOLLOW_THIS_in_primaryExpression12693); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_THIS.add(THIS474);


					// AST REWRITE
					// elements: THIS
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 911:57: -> THIS
					{
						adaptor.addChild(root_0, stream_THIS.nextNode());
					}


					retval.tree = root_0;
					}

					}

					// Java.g:913:9: ( arguments -> ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] arguments ) )?
					int alt139=2;
					int LA139_0 = input.LA(1);
					if ( (LA139_0==LPAREN) ) {
						alt139=1;
					}
					switch (alt139) {
						case 1 :
							// Java.g:913:13: arguments
							{
							pushFollow(FOLLOW_arguments_in_primaryExpression12761);
							arguments475=arguments();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_arguments.add(arguments475.getTree());

							// AST REWRITE
							// elements: arguments
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 913:57: -> ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] arguments )
							{
								// Java.g:913:61: ^( THIS_CONSTRUCTOR_CALL[$THIS, \"THIS_CONSTRUCTOR_CALL\"] arguments )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(THIS_CONSTRUCTOR_CALL, THIS474, "THIS_CONSTRUCTOR_CALL"), root_1);
								adaptor.addChild(root_1, stream_arguments.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;
				case 7 :
					// Java.g:915:9: SUPER arguments
					{
					SUPER476=(Token)match(input,SUPER,FOLLOW_SUPER_in_primaryExpression12826); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_SUPER.add(SUPER476);

					pushFollow(FOLLOW_arguments_in_primaryExpression12828);
					arguments477=arguments();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_arguments.add(arguments477.getTree());

					// AST REWRITE
					// elements: arguments
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 915:57: -> ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] arguments )
					{
						// Java.g:915:61: ^( SUPER_CONSTRUCTOR_CALL[$SUPER, \"SUPER_CONSTRUCTOR_CALL\"] arguments )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(SUPER_CONSTRUCTOR_CALL, SUPER476, "SUPER_CONSTRUCTOR_CALL"), root_1);
						adaptor.addChild(root_1, stream_arguments.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 8 :
					// Java.g:916:9: ( SUPER DOT IDENT ) ( arguments -> ^( METHOD_CALL ^( DOT SUPER IDENT ) arguments ) | -> ^( DOT SUPER IDENT ) )
					{
					// Java.g:916:9: ( SUPER DOT IDENT )
					// Java.g:916:13: SUPER DOT IDENT
					{
					SUPER478=(Token)match(input,SUPER,FOLLOW_SUPER_in_primaryExpression12884); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_SUPER.add(SUPER478);

					DOT479=(Token)match(input,DOT,FOLLOW_DOT_in_primaryExpression12886); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DOT.add(DOT479);

					IDENT480=(Token)match(input,IDENT,FOLLOW_IDENT_in_primaryExpression12888); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_IDENT.add(IDENT480);

					}

					// Java.g:918:9: ( arguments -> ^( METHOD_CALL ^( DOT SUPER IDENT ) arguments ) | -> ^( DOT SUPER IDENT ) )
					int alt140=2;
					int LA140_0 = input.LA(1);
					if ( (LA140_0==LPAREN) ) {
						alt140=1;
					}
					else if ( (LA140_0==EOF||(LA140_0 >= AND && LA140_0 <= AND_ASSIGN)||LA140_0==ASSIGN||(LA140_0 >= BIT_SHIFT_RIGHT && LA140_0 <= BIT_SHIFT_RIGHT_ASSIGN)||(LA140_0 >= COLON && LA140_0 <= COMMA)||LA140_0==DEC||(LA140_0 >= DIV && LA140_0 <= DIV_ASSIGN)||LA140_0==DOT||LA140_0==EQUAL||(LA140_0 >= GREATER_OR_EQUAL && LA140_0 <= GREATER_THAN)||(LA140_0 >= INC && LA140_0 <= INSTANCEOF)||LA140_0==LBRACK||(LA140_0 >= LESS_OR_EQUAL && LA140_0 <= LESS_THAN)||LA140_0==LOGICAL_AND||LA140_0==LOGICAL_OR||(LA140_0 >= MINUS && LA140_0 <= MOD)||LA140_0==MOD_ASSIGN||LA140_0==NOT_EQUAL||(LA140_0 >= OR && LA140_0 <= OR_ASSIGN)||(LA140_0 >= PLUS && LA140_0 <= PLUS_ASSIGN)||(LA140_0 >= QUESTION && LA140_0 <= RCURLY)||(LA140_0 >= RPAREN && LA140_0 <= SHIFT_RIGHT_ASSIGN)||(LA140_0 >= STAR && LA140_0 <= STAR_ASSIGN)||(LA140_0 >= XOR && LA140_0 <= XOR_ASSIGN)) ) {
						alt140=2;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 140, 0, input);
						throw nvae;
					}

					switch (alt140) {
						case 1 :
							// Java.g:918:13: arguments
							{
							pushFollow(FOLLOW_arguments_in_primaryExpression12912);
							arguments481=arguments();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_arguments.add(arguments481.getTree());

							// AST REWRITE
							// elements: arguments, SUPER, IDENT, DOT
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 918:57: -> ^( METHOD_CALL ^( DOT SUPER IDENT ) arguments )
							{
								// Java.g:918:61: ^( METHOD_CALL ^( DOT SUPER IDENT ) arguments )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_CALL, "METHOD_CALL"), root_1);
								// Java.g:918:75: ^( DOT SUPER IDENT )
								{
								CommonTree root_2 = (CommonTree)adaptor.nil();
								root_2 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_2);
								adaptor.addChild(root_2, stream_SUPER.nextNode());
								adaptor.addChild(root_2, stream_IDENT.nextNode());
								adaptor.addChild(root_1, root_2);
								}

								adaptor.addChild(root_1, stream_arguments.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 2 :
							// Java.g:919:57: 
							{

							// AST REWRITE
							// elements: IDENT, SUPER, DOT
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 919:57: -> ^( DOT SUPER IDENT )
							{
								// Java.g:919:61: ^( DOT SUPER IDENT )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
								adaptor.addChild(root_1, stream_SUPER.nextNode());
								adaptor.addChild(root_1, stream_IDENT.nextNode());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;
				case 9 :
					// Java.g:921:9: ( primitiveType -> primitiveType ) ( arrayDeclarator -> ^( arrayDeclarator $primaryExpression) )* DOT CLASS
					{
					// Java.g:921:9: ( primitiveType -> primitiveType )
					// Java.g:921:13: primitiveType
					{
					pushFollow(FOLLOW_primitiveType_in_primaryExpression13054);
					primitiveType482=primitiveType();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_primitiveType.add(primitiveType482.getTree());

					// AST REWRITE
					// elements: primitiveType
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 921:57: -> primitiveType
					{
						adaptor.addChild(root_0, stream_primitiveType.nextTree());
					}


					retval.tree = root_0;
					}

					}

					// Java.g:923:9: ( arrayDeclarator -> ^( arrayDeclarator $primaryExpression) )*
					loop141:
					while (true) {
						int alt141=2;
						int LA141_0 = input.LA(1);
						if ( (LA141_0==LBRACK) ) {
							alt141=1;
						}

						switch (alt141) {
						case 1 :
							// Java.g:923:13: arrayDeclarator
							{
							pushFollow(FOLLOW_arrayDeclarator_in_primaryExpression13113);
							arrayDeclarator483=arrayDeclarator();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_arrayDeclarator.add(arrayDeclarator483.getTree());

							// AST REWRITE
							// elements: arrayDeclarator, primaryExpression
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 923:57: -> ^( arrayDeclarator $primaryExpression)
							{
								// Java.g:923:61: ^( arrayDeclarator $primaryExpression)
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_arrayDeclarator.nextNode(), root_1);
								adaptor.addChild(root_1, stream_retval.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

						default :
							break loop141;
						}
					}

					DOT484=(Token)match(input,DOT,FOLLOW_DOT_in_primaryExpression13172); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DOT.add(DOT484);

					CLASS485=(Token)match(input,CLASS,FOLLOW_CLASS_in_primaryExpression13174); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_CLASS.add(CLASS485);


					// AST REWRITE
					// elements: primaryExpression, CLASS, DOT
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 925:57: -> ^( DOT $primaryExpression CLASS )
					{
						// Java.g:925:61: ^( DOT $primaryExpression CLASS )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
						adaptor.addChild(root_1, stream_retval.nextTree());
						adaptor.addChild(root_1, stream_CLASS.nextNode());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 10 :
					// Java.g:926:9: VOID DOT CLASS
					{
					VOID486=(Token)match(input,VOID,FOLLOW_VOID_in_primaryExpression13234); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_VOID.add(VOID486);

					DOT487=(Token)match(input,DOT,FOLLOW_DOT_in_primaryExpression13236); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DOT.add(DOT487);

					CLASS488=(Token)match(input,CLASS,FOLLOW_CLASS_in_primaryExpression13238); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_CLASS.add(CLASS488);


					// AST REWRITE
					// elements: CLASS, VOID, DOT
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 926:57: -> ^( DOT VOID CLASS )
					{
						// Java.g:926:61: ^( DOT VOID CLASS )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
						adaptor.addChild(root_1, stream_VOID.nextNode());
						adaptor.addChild(root_1, stream_CLASS.nextNode());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 105, primaryExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "primaryExpression"


	public static class qualifiedIdentExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "qualifiedIdentExpression"
	// Java.g:929:1: qualifiedIdentExpression : ( qualifiedIdentifier -> qualifiedIdentifier ) ( ( arrayDeclarator -> ^( arrayDeclarator $qualifiedIdentExpression) )+ ( DOT CLASS -> ^( DOT $qualifiedIdentExpression CLASS ) ) | arguments -> ^( METHOD_CALL qualifiedIdentifier arguments ) |outerDot= DOT ( CLASS -> ^( DOT qualifiedIdentifier CLASS ) | genericTypeArgumentListSimplified (Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier genericTypeArgumentListSimplified arguments ) | SUPER innerDot= DOT IDENT arguments -> ^( METHOD_CALL ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT ) genericTypeArgumentListSimplified arguments ) | IDENT arguments -> ^( METHOD_CALL ^( DOT qualifiedIdentifier IDENT ) genericTypeArgumentListSimplified arguments ) ) | THIS -> ^( DOT qualifiedIdentifier THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier arguments ) | innerNewExpression -> ^( DOT qualifiedIdentifier innerNewExpression ) ) )? ;
	public final JavaParser.qualifiedIdentExpression_return qualifiedIdentExpression() throws RecognitionException {
		JavaParser.qualifiedIdentExpression_return retval = new JavaParser.qualifiedIdentExpression_return();
		retval.start = input.LT(1);
		int qualifiedIdentExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token outerDot=null;
		Token Super=null;
		Token innerDot=null;
		Token DOT491=null;
		Token CLASS492=null;
		Token CLASS494=null;
		Token SUPER497=null;
		Token IDENT498=null;
		Token IDENT500=null;
		Token THIS502=null;
		ParserRuleReturnScope qualifiedIdentifier489 =null;
		ParserRuleReturnScope arrayDeclarator490 =null;
		ParserRuleReturnScope arguments493 =null;
		ParserRuleReturnScope genericTypeArgumentListSimplified495 =null;
		ParserRuleReturnScope arguments496 =null;
		ParserRuleReturnScope arguments499 =null;
		ParserRuleReturnScope arguments501 =null;
		ParserRuleReturnScope arguments503 =null;
		ParserRuleReturnScope innerNewExpression504 =null;

		CommonTree outerDot_tree=null;
		CommonTree Super_tree=null;
		CommonTree innerDot_tree=null;
		CommonTree DOT491_tree=null;
		CommonTree CLASS492_tree=null;
		CommonTree CLASS494_tree=null;
		CommonTree SUPER497_tree=null;
		CommonTree IDENT498_tree=null;
		CommonTree IDENT500_tree=null;
		CommonTree THIS502_tree=null;
		RewriteRuleTokenStream stream_SUPER=new RewriteRuleTokenStream(adaptor,"token SUPER");
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleTokenStream stream_DOT=new RewriteRuleTokenStream(adaptor,"token DOT");
		RewriteRuleTokenStream stream_THIS=new RewriteRuleTokenStream(adaptor,"token THIS");
		RewriteRuleTokenStream stream_CLASS=new RewriteRuleTokenStream(adaptor,"token CLASS");
		RewriteRuleSubtreeStream stream_innerNewExpression=new RewriteRuleSubtreeStream(adaptor,"rule innerNewExpression");
		RewriteRuleSubtreeStream stream_arrayDeclarator=new RewriteRuleSubtreeStream(adaptor,"rule arrayDeclarator");
		RewriteRuleSubtreeStream stream_genericTypeArgumentListSimplified=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeArgumentListSimplified");
		RewriteRuleSubtreeStream stream_arguments=new RewriteRuleSubtreeStream(adaptor,"rule arguments");
		RewriteRuleSubtreeStream stream_qualifiedIdentifier=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedIdentifier");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 106) ) { return retval; }

			// Java.g:931:5: ( ( qualifiedIdentifier -> qualifiedIdentifier ) ( ( arrayDeclarator -> ^( arrayDeclarator $qualifiedIdentExpression) )+ ( DOT CLASS -> ^( DOT $qualifiedIdentExpression CLASS ) ) | arguments -> ^( METHOD_CALL qualifiedIdentifier arguments ) |outerDot= DOT ( CLASS -> ^( DOT qualifiedIdentifier CLASS ) | genericTypeArgumentListSimplified (Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier genericTypeArgumentListSimplified arguments ) | SUPER innerDot= DOT IDENT arguments -> ^( METHOD_CALL ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT ) genericTypeArgumentListSimplified arguments ) | IDENT arguments -> ^( METHOD_CALL ^( DOT qualifiedIdentifier IDENT ) genericTypeArgumentListSimplified arguments ) ) | THIS -> ^( DOT qualifiedIdentifier THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier arguments ) | innerNewExpression -> ^( DOT qualifiedIdentifier innerNewExpression ) ) )? )
			// Java.g:931:9: ( qualifiedIdentifier -> qualifiedIdentifier ) ( ( arrayDeclarator -> ^( arrayDeclarator $qualifiedIdentExpression) )+ ( DOT CLASS -> ^( DOT $qualifiedIdentExpression CLASS ) ) | arguments -> ^( METHOD_CALL qualifiedIdentifier arguments ) |outerDot= DOT ( CLASS -> ^( DOT qualifiedIdentifier CLASS ) | genericTypeArgumentListSimplified (Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier genericTypeArgumentListSimplified arguments ) | SUPER innerDot= DOT IDENT arguments -> ^( METHOD_CALL ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT ) genericTypeArgumentListSimplified arguments ) | IDENT arguments -> ^( METHOD_CALL ^( DOT qualifiedIdentifier IDENT ) genericTypeArgumentListSimplified arguments ) ) | THIS -> ^( DOT qualifiedIdentifier THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier arguments ) | innerNewExpression -> ^( DOT qualifiedIdentifier innerNewExpression ) ) )?
			{
			// Java.g:931:9: ( qualifiedIdentifier -> qualifiedIdentifier )
			// Java.g:931:13: qualifiedIdentifier
			{
			pushFollow(FOLLOW_qualifiedIdentifier_in_qualifiedIdentExpression13314);
			qualifiedIdentifier489=qualifiedIdentifier();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_qualifiedIdentifier.add(qualifiedIdentifier489.getTree());

			// AST REWRITE
			// elements: qualifiedIdentifier
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 931:61: -> qualifiedIdentifier
			{
				adaptor.addChild(root_0, stream_qualifiedIdentifier.nextTree());
			}


			retval.tree = root_0;
			}

			}

			// Java.g:934:9: ( ( arrayDeclarator -> ^( arrayDeclarator $qualifiedIdentExpression) )+ ( DOT CLASS -> ^( DOT $qualifiedIdentExpression CLASS ) ) | arguments -> ^( METHOD_CALL qualifiedIdentifier arguments ) |outerDot= DOT ( CLASS -> ^( DOT qualifiedIdentifier CLASS ) | genericTypeArgumentListSimplified (Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier genericTypeArgumentListSimplified arguments ) | SUPER innerDot= DOT IDENT arguments -> ^( METHOD_CALL ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT ) genericTypeArgumentListSimplified arguments ) | IDENT arguments -> ^( METHOD_CALL ^( DOT qualifiedIdentifier IDENT ) genericTypeArgumentListSimplified arguments ) ) | THIS -> ^( DOT qualifiedIdentifier THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier arguments ) | innerNewExpression -> ^( DOT qualifiedIdentifier innerNewExpression ) ) )?
			int alt146=4;
			switch ( input.LA(1) ) {
				case LBRACK:
					{
					int LA146_1 = input.LA(2);
					if ( (synpred221_Java()) ) {
						alt146=1;
					}
					}
					break;
				case LPAREN:
					{
					alt146=2;
					}
					break;
				case DOT:
					{
					int LA146_3 = input.LA(2);
					if ( (synpred229_Java()) ) {
						alt146=3;
					}
					}
					break;
			}
			switch (alt146) {
				case 1 :
					// Java.g:934:13: ( arrayDeclarator -> ^( arrayDeclarator $qualifiedIdentExpression) )+ ( DOT CLASS -> ^( DOT $qualifiedIdentExpression CLASS ) )
					{
					// Java.g:934:13: ( arrayDeclarator -> ^( arrayDeclarator $qualifiedIdentExpression) )+
					int cnt143=0;
					loop143:
					while (true) {
						int alt143=2;
						int LA143_0 = input.LA(1);
						if ( (LA143_0==LBRACK) ) {
							alt143=1;
						}

						switch (alt143) {
						case 1 :
							// Java.g:934:17: arrayDeclarator
							{
							pushFollow(FOLLOW_arrayDeclarator_in_qualifiedIdentExpression13384);
							arrayDeclarator490=arrayDeclarator();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_arrayDeclarator.add(arrayDeclarator490.getTree());

							// AST REWRITE
							// elements: qualifiedIdentExpression, arrayDeclarator
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 934:57: -> ^( arrayDeclarator $qualifiedIdentExpression)
							{
								// Java.g:934:61: ^( arrayDeclarator $qualifiedIdentExpression)
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_arrayDeclarator.nextNode(), root_1);
								adaptor.addChild(root_1, stream_retval.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

						default :
							if ( cnt143 >= 1 ) break loop143;
							if (state.backtracking>0) {state.failed=true; return retval;}
							EarlyExitException eee = new EarlyExitException(143, input);
							throw eee;
						}
						cnt143++;
					}

					// Java.g:936:13: ( DOT CLASS -> ^( DOT $qualifiedIdentExpression CLASS ) )
					// Java.g:936:17: DOT CLASS
					{
					DOT491=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedIdentExpression13451); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DOT.add(DOT491);

					CLASS492=(Token)match(input,CLASS,FOLLOW_CLASS_in_qualifiedIdentExpression13453); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_CLASS.add(CLASS492);


					// AST REWRITE
					// elements: CLASS, DOT, qualifiedIdentExpression
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 936:57: -> ^( DOT $qualifiedIdentExpression CLASS )
					{
						// Java.g:936:61: ^( DOT $qualifiedIdentExpression CLASS )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
						adaptor.addChild(root_1, stream_retval.nextTree());
						adaptor.addChild(root_1, stream_CLASS.nextNode());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}

					}
					break;
				case 2 :
					// Java.g:938:13: arguments
					{
					pushFollow(FOLLOW_arguments_in_qualifiedIdentExpression13523);
					arguments493=arguments();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_arguments.add(arguments493.getTree());

					// AST REWRITE
					// elements: arguments, qualifiedIdentifier
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 938:57: -> ^( METHOD_CALL qualifiedIdentifier arguments )
					{
						// Java.g:938:61: ^( METHOD_CALL qualifiedIdentifier arguments )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_CALL, "METHOD_CALL"), root_1);
						adaptor.addChild(root_1, stream_qualifiedIdentifier.nextTree());
						adaptor.addChild(root_1, stream_arguments.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 3 :
					// Java.g:939:13: outerDot= DOT ( CLASS -> ^( DOT qualifiedIdentifier CLASS ) | genericTypeArgumentListSimplified (Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier genericTypeArgumentListSimplified arguments ) | SUPER innerDot= DOT IDENT arguments -> ^( METHOD_CALL ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT ) genericTypeArgumentListSimplified arguments ) | IDENT arguments -> ^( METHOD_CALL ^( DOT qualifiedIdentifier IDENT ) genericTypeArgumentListSimplified arguments ) ) | THIS -> ^( DOT qualifiedIdentifier THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier arguments ) | innerNewExpression -> ^( DOT qualifiedIdentifier innerNewExpression ) )
					{
					outerDot=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedIdentExpression13584); if (state.failed) return retval; 
					if ( state.backtracking==0 ) stream_DOT.add(outerDot);

					// Java.g:940:13: ( CLASS -> ^( DOT qualifiedIdentifier CLASS ) | genericTypeArgumentListSimplified (Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier genericTypeArgumentListSimplified arguments ) | SUPER innerDot= DOT IDENT arguments -> ^( METHOD_CALL ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT ) genericTypeArgumentListSimplified arguments ) | IDENT arguments -> ^( METHOD_CALL ^( DOT qualifiedIdentifier IDENT ) genericTypeArgumentListSimplified arguments ) ) | THIS -> ^( DOT qualifiedIdentifier THIS ) |Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier arguments ) | innerNewExpression -> ^( DOT qualifiedIdentifier innerNewExpression ) )
					int alt145=5;
					switch ( input.LA(1) ) {
					case CLASS:
						{
						alt145=1;
						}
						break;
					case LESS_THAN:
						{
						alt145=2;
						}
						break;
					case THIS:
						{
						alt145=3;
						}
						break;
					case SUPER:
						{
						alt145=4;
						}
						break;
					case NEW:
						{
						alt145=5;
						}
						break;
					default:
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 145, 0, input);
						throw nvae;
					}
					switch (alt145) {
						case 1 :
							// Java.g:940:17: CLASS
							{
							CLASS494=(Token)match(input,CLASS,FOLLOW_CLASS_in_qualifiedIdentExpression13602); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_CLASS.add(CLASS494);


							// AST REWRITE
							// elements: DOT, CLASS, qualifiedIdentifier
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 940:57: -> ^( DOT qualifiedIdentifier CLASS )
							{
								// Java.g:940:61: ^( DOT qualifiedIdentifier CLASS )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
								adaptor.addChild(root_1, stream_qualifiedIdentifier.nextTree());
								adaptor.addChild(root_1, stream_CLASS.nextNode());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 2 :
							// Java.g:941:17: genericTypeArgumentListSimplified (Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier genericTypeArgumentListSimplified arguments ) | SUPER innerDot= DOT IDENT arguments -> ^( METHOD_CALL ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT ) genericTypeArgumentListSimplified arguments ) | IDENT arguments -> ^( METHOD_CALL ^( DOT qualifiedIdentifier IDENT ) genericTypeArgumentListSimplified arguments ) )
							{
							pushFollow(FOLLOW_genericTypeArgumentListSimplified_in_qualifiedIdentExpression13665);
							genericTypeArgumentListSimplified495=genericTypeArgumentListSimplified();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_genericTypeArgumentListSimplified.add(genericTypeArgumentListSimplified495.getTree());
							// Java.g:942:17: (Super= SUPER arguments -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier genericTypeArgumentListSimplified arguments ) | SUPER innerDot= DOT IDENT arguments -> ^( METHOD_CALL ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT ) genericTypeArgumentListSimplified arguments ) | IDENT arguments -> ^( METHOD_CALL ^( DOT qualifiedIdentifier IDENT ) genericTypeArgumentListSimplified arguments ) )
							int alt144=3;
							int LA144_0 = input.LA(1);
							if ( (LA144_0==SUPER) ) {
								int LA144_1 = input.LA(2);
								if ( (LA144_1==DOT) ) {
									alt144=2;
								}
								else if ( (LA144_1==LPAREN) ) {
									alt144=1;
								}

								else {
									if (state.backtracking>0) {state.failed=true; return retval;}
									int nvaeMark = input.mark();
									try {
										input.consume();
										NoViableAltException nvae =
											new NoViableAltException("", 144, 1, input);
										throw nvae;
									} finally {
										input.rewind(nvaeMark);
									}
								}

							}
							else if ( (LA144_0==IDENT) ) {
								alt144=3;
							}

							else {
								if (state.backtracking>0) {state.failed=true; return retval;}
								NoViableAltException nvae =
									new NoViableAltException("", 144, 0, input);
								throw nvae;
							}

							switch (alt144) {
								case 1 :
									// Java.g:942:21: Super= SUPER arguments
									{
									Super=(Token)match(input,SUPER,FOLLOW_SUPER_in_qualifiedIdentExpression13689); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_SUPER.add(Super);

									pushFollow(FOLLOW_arguments_in_qualifiedIdentExpression13691);
									arguments496=arguments();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_arguments.add(arguments496.getTree());

									// AST REWRITE
									// elements: genericTypeArgumentListSimplified, qualifiedIdentifier, arguments
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 942:57: -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier genericTypeArgumentListSimplified arguments )
									{
										// Java.g:942:61: ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier genericTypeArgumentListSimplified arguments )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(SUPER_CONSTRUCTOR_CALL, Super, "SUPER_CONSTRUCTOR_CALL"), root_1);
										adaptor.addChild(root_1, stream_qualifiedIdentifier.nextTree());
										adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
										adaptor.addChild(root_1, stream_arguments.nextTree());
										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;
								case 2 :
									// Java.g:943:21: SUPER innerDot= DOT IDENT arguments
									{
									SUPER497=(Token)match(input,SUPER,FOLLOW_SUPER_in_qualifiedIdentExpression13741); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_SUPER.add(SUPER497);

									innerDot=(Token)match(input,DOT,FOLLOW_DOT_in_qualifiedIdentExpression13745); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_DOT.add(innerDot);

									IDENT498=(Token)match(input,IDENT,FOLLOW_IDENT_in_qualifiedIdentExpression13747); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_IDENT.add(IDENT498);

									pushFollow(FOLLOW_arguments_in_qualifiedIdentExpression13749);
									arguments499=arguments();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_arguments.add(arguments499.getTree());

									// AST REWRITE
									// elements: IDENT, outerDot, innerDot, qualifiedIdentifier, SUPER, genericTypeArgumentListSimplified, arguments
									// token labels: innerDot, outerDot
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleTokenStream stream_innerDot=new RewriteRuleTokenStream(adaptor,"token innerDot",innerDot);
									RewriteRuleTokenStream stream_outerDot=new RewriteRuleTokenStream(adaptor,"token outerDot",outerDot);
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 943:57: -> ^( METHOD_CALL ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT ) genericTypeArgumentListSimplified arguments )
									{
										// Java.g:943:61: ^( METHOD_CALL ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT ) genericTypeArgumentListSimplified arguments )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_CALL, "METHOD_CALL"), root_1);
										// Java.g:943:75: ^( $innerDot ^( $outerDot qualifiedIdentifier SUPER ) IDENT )
										{
										CommonTree root_2 = (CommonTree)adaptor.nil();
										root_2 = (CommonTree)adaptor.becomeRoot(stream_innerDot.nextNode(), root_2);
										// Java.g:943:87: ^( $outerDot qualifiedIdentifier SUPER )
										{
										CommonTree root_3 = (CommonTree)adaptor.nil();
										root_3 = (CommonTree)adaptor.becomeRoot(stream_outerDot.nextNode(), root_3);
										adaptor.addChild(root_3, stream_qualifiedIdentifier.nextTree());
										adaptor.addChild(root_3, stream_SUPER.nextNode());
										adaptor.addChild(root_2, root_3);
										}

										adaptor.addChild(root_2, stream_IDENT.nextNode());
										adaptor.addChild(root_1, root_2);
										}

										adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
										adaptor.addChild(root_1, stream_arguments.nextTree());
										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;
								case 3 :
									// Java.g:944:21: IDENT arguments
									{
									IDENT500=(Token)match(input,IDENT,FOLLOW_IDENT_in_qualifiedIdentExpression13799); if (state.failed) return retval; 
									if ( state.backtracking==0 ) stream_IDENT.add(IDENT500);

									pushFollow(FOLLOW_arguments_in_qualifiedIdentExpression13801);
									arguments501=arguments();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_arguments.add(arguments501.getTree());

									// AST REWRITE
									// elements: IDENT, arguments, qualifiedIdentifier, genericTypeArgumentListSimplified, DOT
									// token labels: 
									// rule labels: retval
									// token list labels: 
									// rule list labels: 
									// wildcard labels: 
									if ( state.backtracking==0 ) {
									retval.tree = root_0;
									RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

									root_0 = (CommonTree)adaptor.nil();
									// 944:57: -> ^( METHOD_CALL ^( DOT qualifiedIdentifier IDENT ) genericTypeArgumentListSimplified arguments )
									{
										// Java.g:944:61: ^( METHOD_CALL ^( DOT qualifiedIdentifier IDENT ) genericTypeArgumentListSimplified arguments )
										{
										CommonTree root_1 = (CommonTree)adaptor.nil();
										root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_CALL, "METHOD_CALL"), root_1);
										// Java.g:944:75: ^( DOT qualifiedIdentifier IDENT )
										{
										CommonTree root_2 = (CommonTree)adaptor.nil();
										root_2 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_2);
										adaptor.addChild(root_2, stream_qualifiedIdentifier.nextTree());
										adaptor.addChild(root_2, stream_IDENT.nextNode());
										adaptor.addChild(root_1, root_2);
										}

										adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
										adaptor.addChild(root_1, stream_arguments.nextTree());
										adaptor.addChild(root_0, root_1);
										}

									}


									retval.tree = root_0;
									}

									}
									break;

							}

							}
							break;
						case 3 :
							// Java.g:946:17: THIS
							{
							THIS502=(Token)match(input,THIS,FOLLOW_THIS_in_qualifiedIdentExpression13876); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_THIS.add(THIS502);


							// AST REWRITE
							// elements: DOT, qualifiedIdentifier, THIS
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 946:57: -> ^( DOT qualifiedIdentifier THIS )
							{
								// Java.g:946:61: ^( DOT qualifiedIdentifier THIS )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
								adaptor.addChild(root_1, stream_qualifiedIdentifier.nextTree());
								adaptor.addChild(root_1, stream_THIS.nextNode());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 4 :
							// Java.g:947:17: Super= SUPER arguments
							{
							Super=(Token)match(input,SUPER,FOLLOW_SUPER_in_qualifiedIdentExpression13942); if (state.failed) return retval; 
							if ( state.backtracking==0 ) stream_SUPER.add(Super);

							pushFollow(FOLLOW_arguments_in_qualifiedIdentExpression13944);
							arguments503=arguments();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_arguments.add(arguments503.getTree());

							// AST REWRITE
							// elements: qualifiedIdentifier, arguments
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 947:57: -> ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier arguments )
							{
								// Java.g:947:61: ^( SUPER_CONSTRUCTOR_CALL[$Super, \"SUPER_CONSTRUCTOR_CALL\"] qualifiedIdentifier arguments )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(SUPER_CONSTRUCTOR_CALL, Super, "SUPER_CONSTRUCTOR_CALL"), root_1);
								adaptor.addChild(root_1, stream_qualifiedIdentifier.nextTree());
								adaptor.addChild(root_1, stream_arguments.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 5 :
							// Java.g:948:17: innerNewExpression
							{
							pushFollow(FOLLOW_innerNewExpression_in_qualifiedIdentExpression13992);
							innerNewExpression504=innerNewExpression();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_innerNewExpression.add(innerNewExpression504.getTree());

							// AST REWRITE
							// elements: innerNewExpression, qualifiedIdentifier, DOT
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 948:57: -> ^( DOT qualifiedIdentifier innerNewExpression )
							{
								// Java.g:948:61: ^( DOT qualifiedIdentifier innerNewExpression )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot(stream_DOT.nextNode(), root_1);
								adaptor.addChild(root_1, stream_qualifiedIdentifier.nextTree());
								adaptor.addChild(root_1, stream_innerNewExpression.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 106, qualifiedIdentExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "qualifiedIdentExpression"


	public static class newExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "newExpression"
	// Java.g:953:1: newExpression : NEW ( primitiveType newArrayConstruction -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] primitiveType newArrayConstruction ) | ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified ( newArrayConstruction -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified newArrayConstruction ) | arguments ( classBody )? -> ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified arguments ( classBody )? ) ) ) ;
	public final JavaParser.newExpression_return newExpression() throws RecognitionException {
		JavaParser.newExpression_return retval = new JavaParser.newExpression_return();
		retval.start = input.LT(1);
		int newExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token NEW505=null;
		ParserRuleReturnScope primitiveType506 =null;
		ParserRuleReturnScope newArrayConstruction507 =null;
		ParserRuleReturnScope genericTypeArgumentListSimplified508 =null;
		ParserRuleReturnScope qualifiedTypeIdentSimplified509 =null;
		ParserRuleReturnScope newArrayConstruction510 =null;
		ParserRuleReturnScope arguments511 =null;
		ParserRuleReturnScope classBody512 =null;

		CommonTree NEW505_tree=null;
		RewriteRuleTokenStream stream_NEW=new RewriteRuleTokenStream(adaptor,"token NEW");
		RewriteRuleSubtreeStream stream_newArrayConstruction=new RewriteRuleSubtreeStream(adaptor,"rule newArrayConstruction");
		RewriteRuleSubtreeStream stream_genericTypeArgumentListSimplified=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeArgumentListSimplified");
		RewriteRuleSubtreeStream stream_classBody=new RewriteRuleSubtreeStream(adaptor,"rule classBody");
		RewriteRuleSubtreeStream stream_arguments=new RewriteRuleSubtreeStream(adaptor,"rule arguments");
		RewriteRuleSubtreeStream stream_qualifiedTypeIdentSimplified=new RewriteRuleSubtreeStream(adaptor,"rule qualifiedTypeIdentSimplified");
		RewriteRuleSubtreeStream stream_primitiveType=new RewriteRuleSubtreeStream(adaptor,"rule primitiveType");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 107) ) { return retval; }

			// Java.g:954:5: ( NEW ( primitiveType newArrayConstruction -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] primitiveType newArrayConstruction ) | ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified ( newArrayConstruction -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified newArrayConstruction ) | arguments ( classBody )? -> ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified arguments ( classBody )? ) ) ) )
			// Java.g:954:9: NEW ( primitiveType newArrayConstruction -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] primitiveType newArrayConstruction ) | ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified ( newArrayConstruction -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified newArrayConstruction ) | arguments ( classBody )? -> ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified arguments ( classBody )? ) ) )
			{
			NEW505=(Token)match(input,NEW,FOLLOW_NEW_in_newExpression14068); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_NEW.add(NEW505);

			// Java.g:955:9: ( primitiveType newArrayConstruction -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] primitiveType newArrayConstruction ) | ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified ( newArrayConstruction -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified newArrayConstruction ) | arguments ( classBody )? -> ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified arguments ( classBody )? ) ) )
			int alt150=2;
			int LA150_0 = input.LA(1);
			if ( (LA150_0==BOOLEAN||LA150_0==BYTE||LA150_0==CHAR||LA150_0==DOUBLE||LA150_0==FLOAT||LA150_0==INT||LA150_0==LONG||LA150_0==SHORT) ) {
				alt150=1;
			}
			else if ( (LA150_0==IDENT||LA150_0==LESS_THAN) ) {
				alt150=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 150, 0, input);
				throw nvae;
			}

			switch (alt150) {
				case 1 :
					// Java.g:955:13: primitiveType newArrayConstruction
					{
					pushFollow(FOLLOW_primitiveType_in_newExpression14082);
					primitiveType506=primitiveType();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_primitiveType.add(primitiveType506.getTree());
					pushFollow(FOLLOW_newArrayConstruction_in_newExpression14084);
					newArrayConstruction507=newArrayConstruction();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_newArrayConstruction.add(newArrayConstruction507.getTree());

					// AST REWRITE
					// elements: newArrayConstruction, primitiveType
					// token labels: 
					// rule labels: retval
					// token list labels: 
					// rule list labels: 
					// wildcard labels: 
					if ( state.backtracking==0 ) {
					retval.tree = root_0;
					RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

					root_0 = (CommonTree)adaptor.nil();
					// 956:13: -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] primitiveType newArrayConstruction )
					{
						// Java.g:956:17: ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] primitiveType newArrayConstruction )
						{
						CommonTree root_1 = (CommonTree)adaptor.nil();
						root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(STATIC_ARRAY_CREATOR, NEW505, "STATIC_ARRAY_CREATOR"), root_1);
						adaptor.addChild(root_1, stream_primitiveType.nextTree());
						adaptor.addChild(root_1, stream_newArrayConstruction.nextTree());
						adaptor.addChild(root_0, root_1);
						}

					}


					retval.tree = root_0;
					}

					}
					break;
				case 2 :
					// Java.g:957:13: ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified ( newArrayConstruction -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified newArrayConstruction ) | arguments ( classBody )? -> ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified arguments ( classBody )? ) )
					{
					// Java.g:957:13: ( genericTypeArgumentListSimplified )?
					int alt147=2;
					int LA147_0 = input.LA(1);
					if ( (LA147_0==LESS_THAN) ) {
						alt147=1;
					}
					switch (alt147) {
						case 1 :
							// Java.g:957:13: genericTypeArgumentListSimplified
							{
							pushFollow(FOLLOW_genericTypeArgumentListSimplified_in_newExpression14128);
							genericTypeArgumentListSimplified508=genericTypeArgumentListSimplified();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_genericTypeArgumentListSimplified.add(genericTypeArgumentListSimplified508.getTree());
							}
							break;

					}

					pushFollow(FOLLOW_qualifiedTypeIdentSimplified_in_newExpression14131);
					qualifiedTypeIdentSimplified509=qualifiedTypeIdentSimplified();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_qualifiedTypeIdentSimplified.add(qualifiedTypeIdentSimplified509.getTree());
					// Java.g:958:13: ( newArrayConstruction -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified newArrayConstruction ) | arguments ( classBody )? -> ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified arguments ( classBody )? ) )
					int alt149=2;
					int LA149_0 = input.LA(1);
					if ( (LA149_0==LBRACK) ) {
						alt149=1;
					}
					else if ( (LA149_0==LPAREN) ) {
						alt149=2;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return retval;}
						NoViableAltException nvae =
							new NoViableAltException("", 149, 0, input);
						throw nvae;
					}

					switch (alt149) {
						case 1 :
							// Java.g:958:17: newArrayConstruction
							{
							pushFollow(FOLLOW_newArrayConstruction_in_newExpression14149);
							newArrayConstruction510=newArrayConstruction();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_newArrayConstruction.add(newArrayConstruction510.getTree());

							// AST REWRITE
							// elements: qualifiedTypeIdentSimplified, newArrayConstruction, genericTypeArgumentListSimplified
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 959:17: -> ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified newArrayConstruction )
							{
								// Java.g:959:21: ^( STATIC_ARRAY_CREATOR[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified newArrayConstruction )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(STATIC_ARRAY_CREATOR, NEW505, "STATIC_ARRAY_CREATOR"), root_1);
								// Java.g:959:74: ( genericTypeArgumentListSimplified )?
								if ( stream_genericTypeArgumentListSimplified.hasNext() ) {
									adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
								}
								stream_genericTypeArgumentListSimplified.reset();

								adaptor.addChild(root_1, stream_qualifiedTypeIdentSimplified.nextTree());
								adaptor.addChild(root_1, stream_newArrayConstruction.nextTree());
								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;
						case 2 :
							// Java.g:960:17: arguments ( classBody )?
							{
							pushFollow(FOLLOW_arguments_in_newExpression14214);
							arguments511=arguments();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) stream_arguments.add(arguments511.getTree());
							// Java.g:960:27: ( classBody )?
							int alt148=2;
							int LA148_0 = input.LA(1);
							if ( (LA148_0==LCURLY) ) {
								alt148=1;
							}
							switch (alt148) {
								case 1 :
									// Java.g:960:27: classBody
									{
									pushFollow(FOLLOW_classBody_in_newExpression14216);
									classBody512=classBody();
									state._fsp--;
									if (state.failed) return retval;
									if ( state.backtracking==0 ) stream_classBody.add(classBody512.getTree());
									}
									break;

							}


							// AST REWRITE
							// elements: classBody, arguments, genericTypeArgumentListSimplified, qualifiedTypeIdentSimplified
							// token labels: 
							// rule labels: retval
							// token list labels: 
							// rule list labels: 
							// wildcard labels: 
							if ( state.backtracking==0 ) {
							retval.tree = root_0;
							RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

							root_0 = (CommonTree)adaptor.nil();
							// 961:17: -> ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified arguments ( classBody )? )
							{
								// Java.g:961:21: ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? qualifiedTypeIdentSimplified arguments ( classBody )? )
								{
								CommonTree root_1 = (CommonTree)adaptor.nil();
								root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CLASS_CONSTRUCTOR_CALL, NEW505, "STATIC_ARRAY_CREATOR"), root_1);
								// Java.g:961:76: ( genericTypeArgumentListSimplified )?
								if ( stream_genericTypeArgumentListSimplified.hasNext() ) {
									adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
								}
								stream_genericTypeArgumentListSimplified.reset();

								adaptor.addChild(root_1, stream_qualifiedTypeIdentSimplified.nextTree());
								adaptor.addChild(root_1, stream_arguments.nextTree());
								// Java.g:961:150: ( classBody )?
								if ( stream_classBody.hasNext() ) {
									adaptor.addChild(root_1, stream_classBody.nextTree());
								}
								stream_classBody.reset();

								adaptor.addChild(root_0, root_1);
								}

							}


							retval.tree = root_0;
							}

							}
							break;

					}

					}
					break;

			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 107, newExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "newExpression"


	public static class innerNewExpression_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "innerNewExpression"
	// Java.g:966:1: innerNewExpression : NEW ( genericTypeArgumentListSimplified )? IDENT arguments ( classBody )? -> ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? IDENT arguments ( classBody )? ) ;
	public final JavaParser.innerNewExpression_return innerNewExpression() throws RecognitionException {
		JavaParser.innerNewExpression_return retval = new JavaParser.innerNewExpression_return();
		retval.start = input.LT(1);
		int innerNewExpression_StartIndex = input.index();

		CommonTree root_0 = null;

		Token NEW513=null;
		Token IDENT515=null;
		ParserRuleReturnScope genericTypeArgumentListSimplified514 =null;
		ParserRuleReturnScope arguments516 =null;
		ParserRuleReturnScope classBody517 =null;

		CommonTree NEW513_tree=null;
		CommonTree IDENT515_tree=null;
		RewriteRuleTokenStream stream_NEW=new RewriteRuleTokenStream(adaptor,"token NEW");
		RewriteRuleTokenStream stream_IDENT=new RewriteRuleTokenStream(adaptor,"token IDENT");
		RewriteRuleSubtreeStream stream_genericTypeArgumentListSimplified=new RewriteRuleSubtreeStream(adaptor,"rule genericTypeArgumentListSimplified");
		RewriteRuleSubtreeStream stream_classBody=new RewriteRuleSubtreeStream(adaptor,"rule classBody");
		RewriteRuleSubtreeStream stream_arguments=new RewriteRuleSubtreeStream(adaptor,"rule arguments");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 108) ) { return retval; }

			// Java.g:967:5: ( NEW ( genericTypeArgumentListSimplified )? IDENT arguments ( classBody )? -> ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? IDENT arguments ( classBody )? ) )
			// Java.g:967:9: NEW ( genericTypeArgumentListSimplified )? IDENT arguments ( classBody )?
			{
			NEW513=(Token)match(input,NEW,FOLLOW_NEW_in_innerNewExpression14311); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_NEW.add(NEW513);

			// Java.g:967:13: ( genericTypeArgumentListSimplified )?
			int alt151=2;
			int LA151_0 = input.LA(1);
			if ( (LA151_0==LESS_THAN) ) {
				alt151=1;
			}
			switch (alt151) {
				case 1 :
					// Java.g:967:13: genericTypeArgumentListSimplified
					{
					pushFollow(FOLLOW_genericTypeArgumentListSimplified_in_innerNewExpression14313);
					genericTypeArgumentListSimplified514=genericTypeArgumentListSimplified();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_genericTypeArgumentListSimplified.add(genericTypeArgumentListSimplified514.getTree());
					}
					break;

			}

			IDENT515=(Token)match(input,IDENT,FOLLOW_IDENT_in_innerNewExpression14316); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_IDENT.add(IDENT515);

			pushFollow(FOLLOW_arguments_in_innerNewExpression14318);
			arguments516=arguments();
			state._fsp--;
			if (state.failed) return retval;
			if ( state.backtracking==0 ) stream_arguments.add(arguments516.getTree());
			// Java.g:967:64: ( classBody )?
			int alt152=2;
			int LA152_0 = input.LA(1);
			if ( (LA152_0==LCURLY) ) {
				alt152=1;
			}
			switch (alt152) {
				case 1 :
					// Java.g:967:64: classBody
					{
					pushFollow(FOLLOW_classBody_in_innerNewExpression14320);
					classBody517=classBody();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_classBody.add(classBody517.getTree());
					}
					break;

			}


			// AST REWRITE
			// elements: classBody, arguments, IDENT, genericTypeArgumentListSimplified
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 968:9: -> ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? IDENT arguments ( classBody )? )
			{
				// Java.g:968:13: ^( CLASS_CONSTRUCTOR_CALL[$NEW, \"STATIC_ARRAY_CREATOR\"] ( genericTypeArgumentListSimplified )? IDENT arguments ( classBody )? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CLASS_CONSTRUCTOR_CALL, NEW513, "STATIC_ARRAY_CREATOR"), root_1);
				// Java.g:968:68: ( genericTypeArgumentListSimplified )?
				if ( stream_genericTypeArgumentListSimplified.hasNext() ) {
					adaptor.addChild(root_1, stream_genericTypeArgumentListSimplified.nextTree());
				}
				stream_genericTypeArgumentListSimplified.reset();

				adaptor.addChild(root_1, stream_IDENT.nextNode());
				adaptor.addChild(root_1, stream_arguments.nextTree());
				// Java.g:968:119: ( classBody )?
				if ( stream_classBody.hasNext() ) {
					adaptor.addChild(root_1, stream_classBody.nextTree());
				}
				stream_classBody.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 108, innerNewExpression_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "innerNewExpression"


	public static class newArrayConstruction_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "newArrayConstruction"
	// Java.g:971:1: newArrayConstruction : ( arrayDeclaratorList arrayInitializer | LBRACK ! expression RBRACK ! ( LBRACK ! expression RBRACK !)* ( arrayDeclaratorList )? );
	public final JavaParser.newArrayConstruction_return newArrayConstruction() throws RecognitionException {
		JavaParser.newArrayConstruction_return retval = new JavaParser.newArrayConstruction_return();
		retval.start = input.LT(1);
		int newArrayConstruction_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LBRACK520=null;
		Token RBRACK522=null;
		Token LBRACK523=null;
		Token RBRACK525=null;
		ParserRuleReturnScope arrayDeclaratorList518 =null;
		ParserRuleReturnScope arrayInitializer519 =null;
		ParserRuleReturnScope expression521 =null;
		ParserRuleReturnScope expression524 =null;
		ParserRuleReturnScope arrayDeclaratorList526 =null;

		CommonTree LBRACK520_tree=null;
		CommonTree RBRACK522_tree=null;
		CommonTree LBRACK523_tree=null;
		CommonTree RBRACK525_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 109) ) { return retval; }

			// Java.g:972:5: ( arrayDeclaratorList arrayInitializer | LBRACK ! expression RBRACK ! ( LBRACK ! expression RBRACK !)* ( arrayDeclaratorList )? )
			int alt155=2;
			int LA155_0 = input.LA(1);
			if ( (LA155_0==LBRACK) ) {
				int LA155_1 = input.LA(2);
				if ( (LA155_1==RBRACK) ) {
					alt155=1;
				}
				else if ( (LA155_1==BOOLEAN||LA155_1==BYTE||(LA155_1 >= CHAR && LA155_1 <= CHARACTER_LITERAL)||(LA155_1 >= DEC && LA155_1 <= DECIMAL_LITERAL)||LA155_1==DOUBLE||LA155_1==FALSE||(LA155_1 >= FLOAT && LA155_1 <= FLOATING_POINT_LITERAL)||(LA155_1 >= HEX_LITERAL && LA155_1 <= IDENT)||LA155_1==INC||LA155_1==INT||LA155_1==LESS_THAN||LA155_1==LOGICAL_NOT||(LA155_1 >= LONG && LA155_1 <= LPAREN)||LA155_1==MINUS||LA155_1==NEW||LA155_1==NOT||LA155_1==NULL||LA155_1==OCTAL_LITERAL||LA155_1==PLUS||LA155_1==SHORT||(LA155_1 >= STRING_LITERAL && LA155_1 <= SUPER)||LA155_1==THIS||LA155_1==TRUE||LA155_1==VOID) ) {
					alt155=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return retval;}
					int nvaeMark = input.mark();
					try {
						input.consume();
						NoViableAltException nvae =
							new NoViableAltException("", 155, 1, input);
						throw nvae;
					} finally {
						input.rewind(nvaeMark);
					}
				}

			}

			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				NoViableAltException nvae =
					new NoViableAltException("", 155, 0, input);
				throw nvae;
			}

			switch (alt155) {
				case 1 :
					// Java.g:972:9: arrayDeclaratorList arrayInitializer
					{
					root_0 = (CommonTree)adaptor.nil();


					pushFollow(FOLLOW_arrayDeclaratorList_in_newArrayConstruction14366);
					arrayDeclaratorList518=arrayDeclaratorList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arrayDeclaratorList518.getTree());

					pushFollow(FOLLOW_arrayInitializer_in_newArrayConstruction14368);
					arrayInitializer519=arrayInitializer();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, arrayInitializer519.getTree());

					}
					break;
				case 2 :
					// Java.g:973:9: LBRACK ! expression RBRACK ! ( LBRACK ! expression RBRACK !)* ( arrayDeclaratorList )?
					{
					root_0 = (CommonTree)adaptor.nil();


					LBRACK520=(Token)match(input,LBRACK,FOLLOW_LBRACK_in_newArrayConstruction14378); if (state.failed) return retval;
					pushFollow(FOLLOW_expression_in_newArrayConstruction14381);
					expression521=expression();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) adaptor.addChild(root_0, expression521.getTree());

					RBRACK522=(Token)match(input,RBRACK,FOLLOW_RBRACK_in_newArrayConstruction14383); if (state.failed) return retval;
					// Java.g:973:36: ( LBRACK ! expression RBRACK !)*
					loop153:
					while (true) {
						int alt153=2;
						int LA153_0 = input.LA(1);
						if ( (LA153_0==LBRACK) ) {
							int LA153_1 = input.LA(2);
							if ( (synpred237_Java()) ) {
								alt153=1;
							}

						}

						switch (alt153) {
						case 1 :
							// Java.g:973:37: LBRACK ! expression RBRACK !
							{
							LBRACK523=(Token)match(input,LBRACK,FOLLOW_LBRACK_in_newArrayConstruction14387); if (state.failed) return retval;
							pushFollow(FOLLOW_expression_in_newArrayConstruction14390);
							expression524=expression();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) adaptor.addChild(root_0, expression524.getTree());

							RBRACK525=(Token)match(input,RBRACK,FOLLOW_RBRACK_in_newArrayConstruction14392); if (state.failed) return retval;
							}
							break;

						default :
							break loop153;
						}
					}

					// Java.g:973:66: ( arrayDeclaratorList )?
					int alt154=2;
					int LA154_0 = input.LA(1);
					if ( (LA154_0==LBRACK) ) {
						int LA154_1 = input.LA(2);
						if ( (LA154_1==RBRACK) ) {
							alt154=1;
						}
					}
					switch (alt154) {
						case 1 :
							// Java.g:973:66: arrayDeclaratorList
							{
							pushFollow(FOLLOW_arrayDeclaratorList_in_newArrayConstruction14397);
							arrayDeclaratorList526=arrayDeclaratorList();
							state._fsp--;
							if (state.failed) return retval;
							if ( state.backtracking==0 ) adaptor.addChild(root_0, arrayDeclaratorList526.getTree());

							}
							break;

					}

					}
					break;

			}
			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 109, newArrayConstruction_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "newArrayConstruction"


	public static class arguments_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "arguments"
	// Java.g:976:1: arguments : LPAREN ( expressionList )? RPAREN -> ^( ARGUMENT_LIST[$LPAREN, \"ARGUMENT_LIST\"] ( expressionList )? ) ;
	public final JavaParser.arguments_return arguments() throws RecognitionException {
		JavaParser.arguments_return retval = new JavaParser.arguments_return();
		retval.start = input.LT(1);
		int arguments_StartIndex = input.index();

		CommonTree root_0 = null;

		Token LPAREN527=null;
		Token RPAREN529=null;
		ParserRuleReturnScope expressionList528 =null;

		CommonTree LPAREN527_tree=null;
		CommonTree RPAREN529_tree=null;
		RewriteRuleTokenStream stream_LPAREN=new RewriteRuleTokenStream(adaptor,"token LPAREN");
		RewriteRuleTokenStream stream_RPAREN=new RewriteRuleTokenStream(adaptor,"token RPAREN");
		RewriteRuleSubtreeStream stream_expressionList=new RewriteRuleSubtreeStream(adaptor,"rule expressionList");

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 110) ) { return retval; }

			// Java.g:977:5: ( LPAREN ( expressionList )? RPAREN -> ^( ARGUMENT_LIST[$LPAREN, \"ARGUMENT_LIST\"] ( expressionList )? ) )
			// Java.g:977:9: LPAREN ( expressionList )? RPAREN
			{
			LPAREN527=(Token)match(input,LPAREN,FOLLOW_LPAREN_in_arguments14417); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_LPAREN.add(LPAREN527);

			// Java.g:977:16: ( expressionList )?
			int alt156=2;
			int LA156_0 = input.LA(1);
			if ( (LA156_0==BOOLEAN||LA156_0==BYTE||(LA156_0 >= CHAR && LA156_0 <= CHARACTER_LITERAL)||(LA156_0 >= DEC && LA156_0 <= DECIMAL_LITERAL)||LA156_0==DOUBLE||LA156_0==FALSE||(LA156_0 >= FLOAT && LA156_0 <= FLOATING_POINT_LITERAL)||(LA156_0 >= HEX_LITERAL && LA156_0 <= IDENT)||LA156_0==INC||LA156_0==INT||LA156_0==LESS_THAN||LA156_0==LOGICAL_NOT||(LA156_0 >= LONG && LA156_0 <= LPAREN)||LA156_0==MINUS||LA156_0==NEW||LA156_0==NOT||LA156_0==NULL||LA156_0==OCTAL_LITERAL||LA156_0==PLUS||LA156_0==SHORT||(LA156_0 >= STRING_LITERAL && LA156_0 <= SUPER)||LA156_0==THIS||LA156_0==TRUE||LA156_0==VOID) ) {
				alt156=1;
			}
			switch (alt156) {
				case 1 :
					// Java.g:977:16: expressionList
					{
					pushFollow(FOLLOW_expressionList_in_arguments14419);
					expressionList528=expressionList();
					state._fsp--;
					if (state.failed) return retval;
					if ( state.backtracking==0 ) stream_expressionList.add(expressionList528.getTree());
					}
					break;

			}

			RPAREN529=(Token)match(input,RPAREN,FOLLOW_RPAREN_in_arguments14422); if (state.failed) return retval; 
			if ( state.backtracking==0 ) stream_RPAREN.add(RPAREN529);


			// AST REWRITE
			// elements: expressionList
			// token labels: 
			// rule labels: retval
			// token list labels: 
			// rule list labels: 
			// wildcard labels: 
			if ( state.backtracking==0 ) {
			retval.tree = root_0;
			RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.getTree():null);

			root_0 = (CommonTree)adaptor.nil();
			// 978:9: -> ^( ARGUMENT_LIST[$LPAREN, \"ARGUMENT_LIST\"] ( expressionList )? )
			{
				// Java.g:978:13: ^( ARGUMENT_LIST[$LPAREN, \"ARGUMENT_LIST\"] ( expressionList )? )
				{
				CommonTree root_1 = (CommonTree)adaptor.nil();
				root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ARGUMENT_LIST, LPAREN527, "ARGUMENT_LIST"), root_1);
				// Java.g:978:55: ( expressionList )?
				if ( stream_expressionList.hasNext() ) {
					adaptor.addChild(root_1, stream_expressionList.nextTree());
				}
				stream_expressionList.reset();

				adaptor.addChild(root_0, root_1);
				}

			}


			retval.tree = root_0;
			}

			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 110, arguments_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "arguments"


	public static class literal_return extends ParserRuleReturnScope {
		CommonTree tree;
		@Override
		public CommonTree getTree() { return tree; }
	};


	// $ANTLR start "literal"
	// Java.g:981:1: literal : ( HEX_LITERAL | OCTAL_LITERAL | DECIMAL_LITERAL | FLOATING_POINT_LITERAL | CHARACTER_LITERAL | STRING_LITERAL | TRUE | FALSE | NULL );
	public final JavaParser.literal_return literal() throws RecognitionException {
		JavaParser.literal_return retval = new JavaParser.literal_return();
		retval.start = input.LT(1);
		int literal_StartIndex = input.index();

		CommonTree root_0 = null;

		Token set530=null;

		CommonTree set530_tree=null;

		try {
			if ( state.backtracking>0 && alreadyParsedRule(input, 111) ) { return retval; }

			// Java.g:982:5: ( HEX_LITERAL | OCTAL_LITERAL | DECIMAL_LITERAL | FLOATING_POINT_LITERAL | CHARACTER_LITERAL | STRING_LITERAL | TRUE | FALSE | NULL )
			// Java.g:
			{
			root_0 = (CommonTree)adaptor.nil();


			set530=input.LT(1);
			if ( input.LA(1)==CHARACTER_LITERAL||input.LA(1)==DECIMAL_LITERAL||input.LA(1)==FALSE||input.LA(1)==FLOATING_POINT_LITERAL||input.LA(1)==HEX_LITERAL||input.LA(1)==NULL||input.LA(1)==OCTAL_LITERAL||input.LA(1)==STRING_LITERAL||input.LA(1)==TRUE ) {
				input.consume();
				if ( state.backtracking==0 ) adaptor.addChild(root_0, (CommonTree)adaptor.create(set530));
				state.errorRecovery=false;
				state.failed=false;
			}
			else {
				if (state.backtracking>0) {state.failed=true; return retval;}
				MismatchedSetException mse = new MismatchedSetException(null,input);
				throw mse;
			}
			}

			retval.stop = input.LT(-1);

			if ( state.backtracking==0 ) {
			retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
			adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
			}
		}
		catch (RecognitionException re) {
			reportError(re);
			recover(input,re);
			retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);
		}
		finally {
			// do for sure before leaving
			if ( state.backtracking>0 ) { memoize(input, 111, literal_StartIndex); }

		}
		return retval;
	}
	// $ANTLR end "literal"

	// $ANTLR start synpred14_Java
	public final void synpred14_Java_fragment() throws RecognitionException {
		// Java.g:295:9: ( GREATER_THAN )
		// Java.g:295:9: GREATER_THAN
		{
		match(input,GREATER_THAN,FOLLOW_GREATER_THAN_in_synpred14_Java5078); if (state.failed) return;

		}

	}
	// $ANTLR end synpred14_Java

	// $ANTLR start synpred15_Java
	public final void synpred15_Java_fragment() throws RecognitionException {
		// Java.g:296:9: ( SHIFT_RIGHT )
		// Java.g:296:9: SHIFT_RIGHT
		{
		match(input,SHIFT_RIGHT,FOLLOW_SHIFT_RIGHT_in_synpred15_Java5088); if (state.failed) return;

		}

	}
	// $ANTLR end synpred15_Java

	// $ANTLR start synpred16_Java
	public final void synpred16_Java_fragment() throws RecognitionException {
		// Java.g:297:9: ( BIT_SHIFT_RIGHT )
		// Java.g:297:9: BIT_SHIFT_RIGHT
		{
		match(input,BIT_SHIFT_RIGHT,FOLLOW_BIT_SHIFT_RIGHT_in_synpred16_Java5098); if (state.failed) return;

		}

	}
	// $ANTLR end synpred16_Java

	// $ANTLR start synpred17_Java
	public final void synpred17_Java_fragment() throws RecognitionException {
		// Java.g:302:15: ( bound )
		// Java.g:302:15: bound
		{
		pushFollow(FOLLOW_bound_in_synpred17_Java5128);
		bound();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred17_Java

	// $ANTLR start synpred32_Java
	public final void synpred32_Java_fragment() throws RecognitionException {
		// Java.g:359:9: ( STATIC block )
		// Java.g:359:9: STATIC block
		{
		match(input,STATIC,FOLLOW_STATIC_in_synpred32_Java5628); if (state.failed) return;

		pushFollow(FOLLOW_block_in_synpred32_Java5630);
		block();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred32_Java

	// $ANTLR start synpred42_Java
	public final void synpred42_Java_fragment() throws RecognitionException {
		Token ident=null;


		// Java.g:361:13: ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) |ident= IDENT formalParameterList ( throwsClause )? block ) )
		// Java.g:361:13: ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) |ident= IDENT formalParameterList ( throwsClause )? block )
		{
		// Java.g:361:13: ( genericTypeParameterList )?
		int alt162=2;
		int LA162_0 = input.LA(1);
		if ( (LA162_0==LESS_THAN) ) {
			alt162=1;
		}
		switch (alt162) {
			case 1 :
				// Java.g:361:13: genericTypeParameterList
				{
				pushFollow(FOLLOW_genericTypeParameterList_in_synpred42_Java5667);
				genericTypeParameterList();
				state._fsp--;
				if (state.failed) return;

				}
				break;

		}

		// Java.g:362:13: ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) |ident= IDENT formalParameterList ( throwsClause )? block )
		int alt169=3;
		switch ( input.LA(1) ) {
		case BOOLEAN:
		case BYTE:
		case CHAR:
		case DOUBLE:
		case FLOAT:
		case INT:
		case LONG:
		case SHORT:
			{
			alt169=1;
			}
			break;
		case IDENT:
			{
			int LA169_2 = input.LA(2);
			if ( (LA169_2==DOT||LA169_2==IDENT||LA169_2==LBRACK||LA169_2==LESS_THAN) ) {
				alt169=1;
			}
			else if ( (LA169_2==LPAREN) ) {
				alt169=3;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return;}
				int nvaeMark = input.mark();
				try {
					input.consume();
					NoViableAltException nvae =
						new NoViableAltException("", 169, 2, input);
					throw nvae;
				} finally {
					input.rewind(nvaeMark);
				}
			}

			}
			break;
		case VOID:
			{
			alt169=2;
			}
			break;
		default:
			if (state.backtracking>0) {state.failed=true; return;}
			NoViableAltException nvae =
				new NoViableAltException("", 169, 0, input);
			throw nvae;
		}
		switch (alt169) {
			case 1 :
				// Java.g:362:17: type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI )
				{
				pushFollow(FOLLOW_type_in_synpred42_Java5686);
				type();
				state._fsp--;
				if (state.failed) return;

				match(input,IDENT,FOLLOW_IDENT_in_synpred42_Java5688); if (state.failed) return;

				pushFollow(FOLLOW_formalParameterList_in_synpred42_Java5690);
				formalParameterList();
				state._fsp--;
				if (state.failed) return;

				// Java.g:362:48: ( arrayDeclaratorList )?
				int alt163=2;
				int LA163_0 = input.LA(1);
				if ( (LA163_0==LBRACK) ) {
					alt163=1;
				}
				switch (alt163) {
					case 1 :
						// Java.g:362:48: arrayDeclaratorList
						{
						pushFollow(FOLLOW_arrayDeclaratorList_in_synpred42_Java5692);
						arrayDeclaratorList();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				// Java.g:362:69: ( throwsClause )?
				int alt164=2;
				int LA164_0 = input.LA(1);
				if ( (LA164_0==THROWS) ) {
					alt164=1;
				}
				switch (alt164) {
					case 1 :
						// Java.g:362:69: throwsClause
						{
						pushFollow(FOLLOW_throwsClause_in_synpred42_Java5695);
						throwsClause();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				// Java.g:362:83: ( block | SEMI )
				int alt165=2;
				int LA165_0 = input.LA(1);
				if ( (LA165_0==LCURLY) ) {
					alt165=1;
				}
				else if ( (LA165_0==SEMI) ) {
					alt165=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return;}
					NoViableAltException nvae =
						new NoViableAltException("", 165, 0, input);
					throw nvae;
				}

				switch (alt165) {
					case 1 :
						// Java.g:362:84: block
						{
						pushFollow(FOLLOW_block_in_synpred42_Java5699);
						block();
						state._fsp--;
						if (state.failed) return;

						}
						break;
					case 2 :
						// Java.g:362:92: SEMI
						{
						match(input,SEMI,FOLLOW_SEMI_in_synpred42_Java5703); if (state.failed) return;

						}
						break;

				}

				}
				break;
			case 2 :
				// Java.g:364:17: VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI )
				{
				match(input,VOID,FOLLOW_VOID_in_synpred42_Java5765); if (state.failed) return;

				match(input,IDENT,FOLLOW_IDENT_in_synpred42_Java5767); if (state.failed) return;

				pushFollow(FOLLOW_formalParameterList_in_synpred42_Java5769);
				formalParameterList();
				state._fsp--;
				if (state.failed) return;

				// Java.g:364:48: ( throwsClause )?
				int alt166=2;
				int LA166_0 = input.LA(1);
				if ( (LA166_0==THROWS) ) {
					alt166=1;
				}
				switch (alt166) {
					case 1 :
						// Java.g:364:48: throwsClause
						{
						pushFollow(FOLLOW_throwsClause_in_synpred42_Java5771);
						throwsClause();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				// Java.g:364:62: ( block | SEMI )
				int alt167=2;
				int LA167_0 = input.LA(1);
				if ( (LA167_0==LCURLY) ) {
					alt167=1;
				}
				else if ( (LA167_0==SEMI) ) {
					alt167=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return;}
					NoViableAltException nvae =
						new NoViableAltException("", 167, 0, input);
					throw nvae;
				}

				switch (alt167) {
					case 1 :
						// Java.g:364:63: block
						{
						pushFollow(FOLLOW_block_in_synpred42_Java5775);
						block();
						state._fsp--;
						if (state.failed) return;

						}
						break;
					case 2 :
						// Java.g:364:71: SEMI
						{
						match(input,SEMI,FOLLOW_SEMI_in_synpred42_Java5779); if (state.failed) return;

						}
						break;

				}

				}
				break;
			case 3 :
				// Java.g:366:17: ident= IDENT formalParameterList ( throwsClause )? block
				{
				ident=(Token)match(input,IDENT,FOLLOW_IDENT_in_synpred42_Java5838); if (state.failed) return;

				pushFollow(FOLLOW_formalParameterList_in_synpred42_Java5840);
				formalParameterList();
				state._fsp--;
				if (state.failed) return;

				// Java.g:366:49: ( throwsClause )?
				int alt168=2;
				int LA168_0 = input.LA(1);
				if ( (LA168_0==THROWS) ) {
					alt168=1;
				}
				switch (alt168) {
					case 1 :
						// Java.g:366:49: throwsClause
						{
						pushFollow(FOLLOW_throwsClause_in_synpred42_Java5842);
						throwsClause();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				pushFollow(FOLLOW_block_in_synpred42_Java5845);
				block();
				state._fsp--;
				if (state.failed) return;

				}
				break;

		}

		}

	}
	// $ANTLR end synpred42_Java

	// $ANTLR start synpred43_Java
	public final void synpred43_Java_fragment() throws RecognitionException {
		Token ident=null;


		// Java.g:360:9: ( modifierList ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) |ident= IDENT formalParameterList ( throwsClause )? block ) | type classFieldDeclaratorList SEMI ) )
		// Java.g:360:9: modifierList ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) |ident= IDENT formalParameterList ( throwsClause )? block ) | type classFieldDeclaratorList SEMI )
		{
		pushFollow(FOLLOW_modifierList_in_synpred43_Java5653);
		modifierList();
		state._fsp--;
		if (state.failed) return;

		// Java.g:361:9: ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) |ident= IDENT formalParameterList ( throwsClause )? block ) | type classFieldDeclaratorList SEMI )
		int alt178=2;
		switch ( input.LA(1) ) {
		case LESS_THAN:
		case VOID:
			{
			alt178=1;
			}
			break;
		case BOOLEAN:
		case BYTE:
		case CHAR:
		case DOUBLE:
		case FLOAT:
		case INT:
		case LONG:
		case SHORT:
			{
			int LA178_2 = input.LA(2);
			if ( (synpred42_Java()) ) {
				alt178=1;
			}
			else if ( (true) ) {
				alt178=2;
			}

			}
			break;
		case IDENT:
			{
			int LA178_3 = input.LA(2);
			if ( (synpred42_Java()) ) {
				alt178=1;
			}
			else if ( (true) ) {
				alt178=2;
			}

			}
			break;
		default:
			if (state.backtracking>0) {state.failed=true; return;}
			NoViableAltException nvae =
				new NoViableAltException("", 178, 0, input);
			throw nvae;
		}
		switch (alt178) {
			case 1 :
				// Java.g:361:13: ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) |ident= IDENT formalParameterList ( throwsClause )? block )
				{
				// Java.g:361:13: ( genericTypeParameterList )?
				int alt170=2;
				int LA170_0 = input.LA(1);
				if ( (LA170_0==LESS_THAN) ) {
					alt170=1;
				}
				switch (alt170) {
					case 1 :
						// Java.g:361:13: genericTypeParameterList
						{
						pushFollow(FOLLOW_genericTypeParameterList_in_synpred43_Java5667);
						genericTypeParameterList();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				// Java.g:362:13: ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI ) | VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI ) |ident= IDENT formalParameterList ( throwsClause )? block )
				int alt177=3;
				switch ( input.LA(1) ) {
				case BOOLEAN:
				case BYTE:
				case CHAR:
				case DOUBLE:
				case FLOAT:
				case INT:
				case LONG:
				case SHORT:
					{
					alt177=1;
					}
					break;
				case IDENT:
					{
					int LA177_2 = input.LA(2);
					if ( (LA177_2==DOT||LA177_2==IDENT||LA177_2==LBRACK||LA177_2==LESS_THAN) ) {
						alt177=1;
					}
					else if ( (LA177_2==LPAREN) ) {
						alt177=3;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return;}
						int nvaeMark = input.mark();
						try {
							input.consume();
							NoViableAltException nvae =
								new NoViableAltException("", 177, 2, input);
							throw nvae;
						} finally {
							input.rewind(nvaeMark);
						}
					}

					}
					break;
				case VOID:
					{
					alt177=2;
					}
					break;
				default:
					if (state.backtracking>0) {state.failed=true; return;}
					NoViableAltException nvae =
						new NoViableAltException("", 177, 0, input);
					throw nvae;
				}
				switch (alt177) {
					case 1 :
						// Java.g:362:17: type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? ( block | SEMI )
						{
						pushFollow(FOLLOW_type_in_synpred43_Java5686);
						type();
						state._fsp--;
						if (state.failed) return;

						match(input,IDENT,FOLLOW_IDENT_in_synpred43_Java5688); if (state.failed) return;

						pushFollow(FOLLOW_formalParameterList_in_synpred43_Java5690);
						formalParameterList();
						state._fsp--;
						if (state.failed) return;

						// Java.g:362:48: ( arrayDeclaratorList )?
						int alt171=2;
						int LA171_0 = input.LA(1);
						if ( (LA171_0==LBRACK) ) {
							alt171=1;
						}
						switch (alt171) {
							case 1 :
								// Java.g:362:48: arrayDeclaratorList
								{
								pushFollow(FOLLOW_arrayDeclaratorList_in_synpred43_Java5692);
								arrayDeclaratorList();
								state._fsp--;
								if (state.failed) return;

								}
								break;

						}

						// Java.g:362:69: ( throwsClause )?
						int alt172=2;
						int LA172_0 = input.LA(1);
						if ( (LA172_0==THROWS) ) {
							alt172=1;
						}
						switch (alt172) {
							case 1 :
								// Java.g:362:69: throwsClause
								{
								pushFollow(FOLLOW_throwsClause_in_synpred43_Java5695);
								throwsClause();
								state._fsp--;
								if (state.failed) return;

								}
								break;

						}

						// Java.g:362:83: ( block | SEMI )
						int alt173=2;
						int LA173_0 = input.LA(1);
						if ( (LA173_0==LCURLY) ) {
							alt173=1;
						}
						else if ( (LA173_0==SEMI) ) {
							alt173=2;
						}

						else {
							if (state.backtracking>0) {state.failed=true; return;}
							NoViableAltException nvae =
								new NoViableAltException("", 173, 0, input);
							throw nvae;
						}

						switch (alt173) {
							case 1 :
								// Java.g:362:84: block
								{
								pushFollow(FOLLOW_block_in_synpred43_Java5699);
								block();
								state._fsp--;
								if (state.failed) return;

								}
								break;
							case 2 :
								// Java.g:362:92: SEMI
								{
								match(input,SEMI,FOLLOW_SEMI_in_synpred43_Java5703); if (state.failed) return;

								}
								break;

						}

						}
						break;
					case 2 :
						// Java.g:364:17: VOID IDENT formalParameterList ( throwsClause )? ( block | SEMI )
						{
						match(input,VOID,FOLLOW_VOID_in_synpred43_Java5765); if (state.failed) return;

						match(input,IDENT,FOLLOW_IDENT_in_synpred43_Java5767); if (state.failed) return;

						pushFollow(FOLLOW_formalParameterList_in_synpred43_Java5769);
						formalParameterList();
						state._fsp--;
						if (state.failed) return;

						// Java.g:364:48: ( throwsClause )?
						int alt174=2;
						int LA174_0 = input.LA(1);
						if ( (LA174_0==THROWS) ) {
							alt174=1;
						}
						switch (alt174) {
							case 1 :
								// Java.g:364:48: throwsClause
								{
								pushFollow(FOLLOW_throwsClause_in_synpred43_Java5771);
								throwsClause();
								state._fsp--;
								if (state.failed) return;

								}
								break;

						}

						// Java.g:364:62: ( block | SEMI )
						int alt175=2;
						int LA175_0 = input.LA(1);
						if ( (LA175_0==LCURLY) ) {
							alt175=1;
						}
						else if ( (LA175_0==SEMI) ) {
							alt175=2;
						}

						else {
							if (state.backtracking>0) {state.failed=true; return;}
							NoViableAltException nvae =
								new NoViableAltException("", 175, 0, input);
							throw nvae;
						}

						switch (alt175) {
							case 1 :
								// Java.g:364:63: block
								{
								pushFollow(FOLLOW_block_in_synpred43_Java5775);
								block();
								state._fsp--;
								if (state.failed) return;

								}
								break;
							case 2 :
								// Java.g:364:71: SEMI
								{
								match(input,SEMI,FOLLOW_SEMI_in_synpred43_Java5779); if (state.failed) return;

								}
								break;

						}

						}
						break;
					case 3 :
						// Java.g:366:17: ident= IDENT formalParameterList ( throwsClause )? block
						{
						ident=(Token)match(input,IDENT,FOLLOW_IDENT_in_synpred43_Java5838); if (state.failed) return;

						pushFollow(FOLLOW_formalParameterList_in_synpred43_Java5840);
						formalParameterList();
						state._fsp--;
						if (state.failed) return;

						// Java.g:366:49: ( throwsClause )?
						int alt176=2;
						int LA176_0 = input.LA(1);
						if ( (LA176_0==THROWS) ) {
							alt176=1;
						}
						switch (alt176) {
							case 1 :
								// Java.g:366:49: throwsClause
								{
								pushFollow(FOLLOW_throwsClause_in_synpred43_Java5842);
								throwsClause();
								state._fsp--;
								if (state.failed) return;

								}
								break;

						}

						pushFollow(FOLLOW_block_in_synpred43_Java5845);
						block();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				}
				break;
			case 2 :
				// Java.g:369:13: type classFieldDeclaratorList SEMI
				{
				pushFollow(FOLLOW_type_in_synpred43_Java5909);
				type();
				state._fsp--;
				if (state.failed) return;

				pushFollow(FOLLOW_classFieldDeclaratorList_in_synpred43_Java5911);
				classFieldDeclaratorList();
				state._fsp--;
				if (state.failed) return;

				match(input,SEMI,FOLLOW_SEMI_in_synpred43_Java5913); if (state.failed) return;

				}
				break;

		}

		}

	}
	// $ANTLR end synpred43_Java

	// $ANTLR start synpred44_Java
	public final void synpred44_Java_fragment() throws RecognitionException {
		// Java.g:372:9: ( typeDeclaration )
		// Java.g:372:9: typeDeclaration
		{
		pushFollow(FOLLOW_typeDeclaration_in_synpred44_Java5958);
		typeDeclaration();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred44_Java

	// $ANTLR start synpred50_Java
	public final void synpred50_Java_fragment() throws RecognitionException {
		// Java.g:378:13: ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI | VOID IDENT formalParameterList ( throwsClause )? SEMI ) )
		// Java.g:378:13: ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI | VOID IDENT formalParameterList ( throwsClause )? SEMI )
		{
		// Java.g:378:13: ( genericTypeParameterList )?
		int alt181=2;
		int LA181_0 = input.LA(1);
		if ( (LA181_0==LESS_THAN) ) {
			alt181=1;
		}
		switch (alt181) {
			case 1 :
				// Java.g:378:13: genericTypeParameterList
				{
				pushFollow(FOLLOW_genericTypeParameterList_in_synpred50_Java6002);
				genericTypeParameterList();
				state._fsp--;
				if (state.failed) return;

				}
				break;

		}

		// Java.g:379:13: ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI | VOID IDENT formalParameterList ( throwsClause )? SEMI )
		int alt185=2;
		int LA185_0 = input.LA(1);
		if ( (LA185_0==BOOLEAN||LA185_0==BYTE||LA185_0==CHAR||LA185_0==DOUBLE||LA185_0==FLOAT||LA185_0==IDENT||LA185_0==INT||LA185_0==LONG||LA185_0==SHORT) ) {
			alt185=1;
		}
		else if ( (LA185_0==VOID) ) {
			alt185=2;
		}

		else {
			if (state.backtracking>0) {state.failed=true; return;}
			NoViableAltException nvae =
				new NoViableAltException("", 185, 0, input);
			throw nvae;
		}

		switch (alt185) {
			case 1 :
				// Java.g:379:17: type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI
				{
				pushFollow(FOLLOW_type_in_synpred50_Java6021);
				type();
				state._fsp--;
				if (state.failed) return;

				match(input,IDENT,FOLLOW_IDENT_in_synpred50_Java6023); if (state.failed) return;

				pushFollow(FOLLOW_formalParameterList_in_synpred50_Java6025);
				formalParameterList();
				state._fsp--;
				if (state.failed) return;

				// Java.g:379:48: ( arrayDeclaratorList )?
				int alt182=2;
				int LA182_0 = input.LA(1);
				if ( (LA182_0==LBRACK) ) {
					alt182=1;
				}
				switch (alt182) {
					case 1 :
						// Java.g:379:48: arrayDeclaratorList
						{
						pushFollow(FOLLOW_arrayDeclaratorList_in_synpred50_Java6027);
						arrayDeclaratorList();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				// Java.g:379:69: ( throwsClause )?
				int alt183=2;
				int LA183_0 = input.LA(1);
				if ( (LA183_0==THROWS) ) {
					alt183=1;
				}
				switch (alt183) {
					case 1 :
						// Java.g:379:69: throwsClause
						{
						pushFollow(FOLLOW_throwsClause_in_synpred50_Java6030);
						throwsClause();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				match(input,SEMI,FOLLOW_SEMI_in_synpred50_Java6033); if (state.failed) return;

				}
				break;
			case 2 :
				// Java.g:381:17: VOID IDENT formalParameterList ( throwsClause )? SEMI
				{
				match(input,VOID,FOLLOW_VOID_in_synpred50_Java6091); if (state.failed) return;

				match(input,IDENT,FOLLOW_IDENT_in_synpred50_Java6093); if (state.failed) return;

				pushFollow(FOLLOW_formalParameterList_in_synpred50_Java6095);
				formalParameterList();
				state._fsp--;
				if (state.failed) return;

				// Java.g:381:48: ( throwsClause )?
				int alt184=2;
				int LA184_0 = input.LA(1);
				if ( (LA184_0==THROWS) ) {
					alt184=1;
				}
				switch (alt184) {
					case 1 :
						// Java.g:381:48: throwsClause
						{
						pushFollow(FOLLOW_throwsClause_in_synpred50_Java6097);
						throwsClause();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				match(input,SEMI,FOLLOW_SEMI_in_synpred50_Java6100); if (state.failed) return;

				}
				break;

		}

		}

	}
	// $ANTLR end synpred50_Java

	// $ANTLR start synpred51_Java
	public final void synpred51_Java_fragment() throws RecognitionException {
		// Java.g:377:9: ( modifierList ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI | VOID IDENT formalParameterList ( throwsClause )? SEMI ) | type interfaceFieldDeclaratorList SEMI ) )
		// Java.g:377:9: modifierList ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI | VOID IDENT formalParameterList ( throwsClause )? SEMI ) | type interfaceFieldDeclaratorList SEMI )
		{
		pushFollow(FOLLOW_modifierList_in_synpred51_Java5988);
		modifierList();
		state._fsp--;
		if (state.failed) return;

		// Java.g:378:9: ( ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI | VOID IDENT formalParameterList ( throwsClause )? SEMI ) | type interfaceFieldDeclaratorList SEMI )
		int alt191=2;
		switch ( input.LA(1) ) {
		case LESS_THAN:
		case VOID:
			{
			alt191=1;
			}
			break;
		case BOOLEAN:
		case BYTE:
		case CHAR:
		case DOUBLE:
		case FLOAT:
		case INT:
		case LONG:
		case SHORT:
			{
			int LA191_2 = input.LA(2);
			if ( (synpred50_Java()) ) {
				alt191=1;
			}
			else if ( (true) ) {
				alt191=2;
			}

			}
			break;
		case IDENT:
			{
			int LA191_3 = input.LA(2);
			if ( (synpred50_Java()) ) {
				alt191=1;
			}
			else if ( (true) ) {
				alt191=2;
			}

			}
			break;
		default:
			if (state.backtracking>0) {state.failed=true; return;}
			NoViableAltException nvae =
				new NoViableAltException("", 191, 0, input);
			throw nvae;
		}
		switch (alt191) {
			case 1 :
				// Java.g:378:13: ( genericTypeParameterList )? ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI | VOID IDENT formalParameterList ( throwsClause )? SEMI )
				{
				// Java.g:378:13: ( genericTypeParameterList )?
				int alt186=2;
				int LA186_0 = input.LA(1);
				if ( (LA186_0==LESS_THAN) ) {
					alt186=1;
				}
				switch (alt186) {
					case 1 :
						// Java.g:378:13: genericTypeParameterList
						{
						pushFollow(FOLLOW_genericTypeParameterList_in_synpred51_Java6002);
						genericTypeParameterList();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				// Java.g:379:13: ( type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI | VOID IDENT formalParameterList ( throwsClause )? SEMI )
				int alt190=2;
				int LA190_0 = input.LA(1);
				if ( (LA190_0==BOOLEAN||LA190_0==BYTE||LA190_0==CHAR||LA190_0==DOUBLE||LA190_0==FLOAT||LA190_0==IDENT||LA190_0==INT||LA190_0==LONG||LA190_0==SHORT) ) {
					alt190=1;
				}
				else if ( (LA190_0==VOID) ) {
					alt190=2;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return;}
					NoViableAltException nvae =
						new NoViableAltException("", 190, 0, input);
					throw nvae;
				}

				switch (alt190) {
					case 1 :
						// Java.g:379:17: type IDENT formalParameterList ( arrayDeclaratorList )? ( throwsClause )? SEMI
						{
						pushFollow(FOLLOW_type_in_synpred51_Java6021);
						type();
						state._fsp--;
						if (state.failed) return;

						match(input,IDENT,FOLLOW_IDENT_in_synpred51_Java6023); if (state.failed) return;

						pushFollow(FOLLOW_formalParameterList_in_synpred51_Java6025);
						formalParameterList();
						state._fsp--;
						if (state.failed) return;

						// Java.g:379:48: ( arrayDeclaratorList )?
						int alt187=2;
						int LA187_0 = input.LA(1);
						if ( (LA187_0==LBRACK) ) {
							alt187=1;
						}
						switch (alt187) {
							case 1 :
								// Java.g:379:48: arrayDeclaratorList
								{
								pushFollow(FOLLOW_arrayDeclaratorList_in_synpred51_Java6027);
								arrayDeclaratorList();
								state._fsp--;
								if (state.failed) return;

								}
								break;

						}

						// Java.g:379:69: ( throwsClause )?
						int alt188=2;
						int LA188_0 = input.LA(1);
						if ( (LA188_0==THROWS) ) {
							alt188=1;
						}
						switch (alt188) {
							case 1 :
								// Java.g:379:69: throwsClause
								{
								pushFollow(FOLLOW_throwsClause_in_synpred51_Java6030);
								throwsClause();
								state._fsp--;
								if (state.failed) return;

								}
								break;

						}

						match(input,SEMI,FOLLOW_SEMI_in_synpred51_Java6033); if (state.failed) return;

						}
						break;
					case 2 :
						// Java.g:381:17: VOID IDENT formalParameterList ( throwsClause )? SEMI
						{
						match(input,VOID,FOLLOW_VOID_in_synpred51_Java6091); if (state.failed) return;

						match(input,IDENT,FOLLOW_IDENT_in_synpred51_Java6093); if (state.failed) return;

						pushFollow(FOLLOW_formalParameterList_in_synpred51_Java6095);
						formalParameterList();
						state._fsp--;
						if (state.failed) return;

						// Java.g:381:48: ( throwsClause )?
						int alt189=2;
						int LA189_0 = input.LA(1);
						if ( (LA189_0==THROWS) ) {
							alt189=1;
						}
						switch (alt189) {
							case 1 :
								// Java.g:381:48: throwsClause
								{
								pushFollow(FOLLOW_throwsClause_in_synpred51_Java6097);
								throwsClause();
								state._fsp--;
								if (state.failed) return;

								}
								break;

						}

						match(input,SEMI,FOLLOW_SEMI_in_synpred51_Java6100); if (state.failed) return;

						}
						break;

				}

				}
				break;
			case 2 :
				// Java.g:384:13: type interfaceFieldDeclaratorList SEMI
				{
				pushFollow(FOLLOW_type_in_synpred51_Java6163);
				type();
				state._fsp--;
				if (state.failed) return;

				pushFollow(FOLLOW_interfaceFieldDeclaratorList_in_synpred51_Java6165);
				interfaceFieldDeclaratorList();
				state._fsp--;
				if (state.failed) return;

				match(input,SEMI,FOLLOW_SEMI_in_synpred51_Java6167); if (state.failed) return;

				}
				break;

		}

		}

	}
	// $ANTLR end synpred51_Java

	// $ANTLR start synpred52_Java
	public final void synpred52_Java_fragment() throws RecognitionException {
		// Java.g:387:9: ( typeDeclaration )
		// Java.g:387:9: typeDeclaration
		{
		pushFollow(FOLLOW_typeDeclaration_in_synpred52_Java6212);
		typeDeclaration();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred52_Java

	// $ANTLR start synpred58_Java
	public final void synpred58_Java_fragment() throws RecognitionException {
		// Java.g:426:9: ( arrayDeclarator )
		// Java.g:426:9: arrayDeclarator
		{
		pushFollow(FOLLOW_arrayDeclarator_in_synpred58_Java6506);
		arrayDeclarator();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred58_Java

	// $ANTLR start synpred76_Java
	public final void synpred76_Java_fragment() throws RecognitionException {
		// Java.g:475:23: ( arrayDeclaratorList )
		// Java.g:475:23: arrayDeclaratorList
		{
		pushFollow(FOLLOW_arrayDeclaratorList_in_synpred76_Java6895);
		arrayDeclaratorList();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred76_Java

	// $ANTLR start synpred77_Java
	public final void synpred77_Java_fragment() throws RecognitionException {
		// Java.g:480:28: ( arrayDeclaratorList )
		// Java.g:480:28: arrayDeclaratorList
		{
		pushFollow(FOLLOW_arrayDeclaratorList_in_synpred77_Java6939);
		arrayDeclaratorList();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred77_Java

	// $ANTLR start synpred79_Java
	public final void synpred79_Java_fragment() throws RecognitionException {
		// Java.g:490:20: ( DOT typeIdent )
		// Java.g:490:20: DOT typeIdent
		{
		match(input,DOT,FOLLOW_DOT_in_synpred79_Java7026); if (state.failed) return;

		pushFollow(FOLLOW_typeIdent_in_synpred79_Java7028);
		typeIdent();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred79_Java

	// $ANTLR start synpred90_Java
	public final void synpred90_Java_fragment() throws RecognitionException {
		// Java.g:519:40: ( COMMA genericTypeArgument )
		// Java.g:519:40: COMMA genericTypeArgument
		{
		match(input,COMMA,FOLLOW_COMMA_in_synpred90_Java7251); if (state.failed) return;

		pushFollow(FOLLOW_genericTypeArgument_in_synpred90_Java7253);
		genericTypeArgument();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred90_Java

	// $ANTLR start synpred92_Java
	public final void synpred92_Java_fragment() throws RecognitionException {
		// Java.g:525:18: ( genericWildcardBoundType )
		// Java.g:525:18: genericWildcardBoundType
		{
		pushFollow(FOLLOW_genericWildcardBoundType_in_synpred92_Java7307);
		genericWildcardBoundType();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred92_Java

	// $ANTLR start synpred97_Java
	public final void synpred97_Java_fragment() throws RecognitionException {
		// Java.g:550:42: ( COMMA formalParameterStandardDecl )
		// Java.g:550:42: COMMA formalParameterStandardDecl
		{
		match(input,COMMA,FOLLOW_COMMA_in_synpred97_Java7508); if (state.failed) return;

		pushFollow(FOLLOW_formalParameterStandardDecl_in_synpred97_Java7510);
		formalParameterStandardDecl();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred97_Java

	// $ANTLR start synpred99_Java
	public final void synpred99_Java_fragment() throws RecognitionException {
		// Java.g:550:13: ( formalParameterStandardDecl ( COMMA formalParameterStandardDecl )* ( COMMA formalParameterVarArgDecl )? )
		// Java.g:550:13: formalParameterStandardDecl ( COMMA formalParameterStandardDecl )* ( COMMA formalParameterVarArgDecl )?
		{
		pushFollow(FOLLOW_formalParameterStandardDecl_in_synpred99_Java7505);
		formalParameterStandardDecl();
		state._fsp--;
		if (state.failed) return;

		// Java.g:550:41: ( COMMA formalParameterStandardDecl )*
		loop194:
		while (true) {
			int alt194=2;
			int LA194_0 = input.LA(1);
			if ( (LA194_0==COMMA) ) {
				int LA194_1 = input.LA(2);
				if ( (synpred97_Java()) ) {
					alt194=1;
				}

			}

			switch (alt194) {
			case 1 :
				// Java.g:550:42: COMMA formalParameterStandardDecl
				{
				match(input,COMMA,FOLLOW_COMMA_in_synpred99_Java7508); if (state.failed) return;

				pushFollow(FOLLOW_formalParameterStandardDecl_in_synpred99_Java7510);
				formalParameterStandardDecl();
				state._fsp--;
				if (state.failed) return;

				}
				break;

			default :
				break loop194;
			}
		}

		// Java.g:550:78: ( COMMA formalParameterVarArgDecl )?
		int alt195=2;
		int LA195_0 = input.LA(1);
		if ( (LA195_0==COMMA) ) {
			alt195=1;
		}
		switch (alt195) {
			case 1 :
				// Java.g:550:79: COMMA formalParameterVarArgDecl
				{
				match(input,COMMA,FOLLOW_COMMA_in_synpred99_Java7515); if (state.failed) return;

				pushFollow(FOLLOW_formalParameterVarArgDecl_in_synpred99_Java7517);
				formalParameterVarArgDecl();
				state._fsp--;
				if (state.failed) return;

				}
				break;

		}

		}

	}
	// $ANTLR end synpred99_Java

	// $ANTLR start synpred100_Java
	public final void synpred100_Java_fragment() throws RecognitionException {
		// Java.g:553:13: ( formalParameterVarArgDecl )
		// Java.g:553:13: formalParameterVarArgDecl
		{
		pushFollow(FOLLOW_formalParameterVarArgDecl_in_synpred100_Java7572);
		formalParameterVarArgDecl();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred100_Java

	// $ANTLR start synpred101_Java
	public final void synpred101_Java_fragment() throws RecognitionException {
		Token ident=null;


		// Java.g:574:13: ( DOT ident= IDENT )
		// Java.g:574:13: DOT ident= IDENT
		{
		match(input,DOT,FOLLOW_DOT_in_synpred101_Java7803); if (state.failed) return;

		ident=(Token)match(input,IDENT,FOLLOW_IDENT_in_synpred101_Java7807); if (state.failed) return;

		}

	}
	// $ANTLR end synpred101_Java

	// $ANTLR start synpred102_Java
	public final void synpred102_Java_fragment() throws RecognitionException {
		// Java.g:581:9: ( annotation )
		// Java.g:581:9: annotation
		{
		pushFollow(FOLLOW_annotation_in_synpred102_Java7856);
		annotation();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred102_Java

	// $ANTLR start synpred114_Java
	public final void synpred114_Java_fragment() throws RecognitionException {
		// Java.g:633:9: ( modifierList type ( IDENT LPAREN RPAREN ( annotationDefaultValue )? SEMI | classFieldDeclaratorList SEMI ) )
		// Java.g:633:9: modifierList type ( IDENT LPAREN RPAREN ( annotationDefaultValue )? SEMI | classFieldDeclaratorList SEMI )
		{
		pushFollow(FOLLOW_modifierList_in_synpred114_Java8274);
		modifierList();
		state._fsp--;
		if (state.failed) return;

		pushFollow(FOLLOW_type_in_synpred114_Java8276);
		type();
		state._fsp--;
		if (state.failed) return;

		// Java.g:634:9: ( IDENT LPAREN RPAREN ( annotationDefaultValue )? SEMI | classFieldDeclaratorList SEMI )
		int alt200=2;
		int LA200_0 = input.LA(1);
		if ( (LA200_0==IDENT) ) {
			int LA200_1 = input.LA(2);
			if ( (LA200_1==LPAREN) ) {
				alt200=1;
			}
			else if ( (LA200_1==ASSIGN||LA200_1==COMMA||LA200_1==LBRACK||LA200_1==SEMI) ) {
				alt200=2;
			}

			else {
				if (state.backtracking>0) {state.failed=true; return;}
				int nvaeMark = input.mark();
				try {
					input.consume();
					NoViableAltException nvae =
						new NoViableAltException("", 200, 1, input);
					throw nvae;
				} finally {
					input.rewind(nvaeMark);
				}
			}

		}

		else {
			if (state.backtracking>0) {state.failed=true; return;}
			NoViableAltException nvae =
				new NoViableAltException("", 200, 0, input);
			throw nvae;
		}

		switch (alt200) {
			case 1 :
				// Java.g:634:13: IDENT LPAREN RPAREN ( annotationDefaultValue )? SEMI
				{
				match(input,IDENT,FOLLOW_IDENT_in_synpred114_Java8290); if (state.failed) return;

				match(input,LPAREN,FOLLOW_LPAREN_in_synpred114_Java8292); if (state.failed) return;

				match(input,RPAREN,FOLLOW_RPAREN_in_synpred114_Java8294); if (state.failed) return;

				// Java.g:634:33: ( annotationDefaultValue )?
				int alt199=2;
				int LA199_0 = input.LA(1);
				if ( (LA199_0==DEFAULT) ) {
					alt199=1;
				}
				switch (alt199) {
					case 1 :
						// Java.g:634:33: annotationDefaultValue
						{
						pushFollow(FOLLOW_annotationDefaultValue_in_synpred114_Java8296);
						annotationDefaultValue();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				match(input,SEMI,FOLLOW_SEMI_in_synpred114_Java8299); if (state.failed) return;

				}
				break;
			case 2 :
				// Java.g:636:13: classFieldDeclaratorList SEMI
				{
				pushFollow(FOLLOW_classFieldDeclaratorList_in_synpred114_Java8341);
				classFieldDeclaratorList();
				state._fsp--;
				if (state.failed) return;

				match(input,SEMI,FOLLOW_SEMI_in_synpred114_Java8343); if (state.failed) return;

				}
				break;

		}

		}

	}
	// $ANTLR end synpred114_Java

	// $ANTLR start synpred116_Java
	public final void synpred116_Java_fragment() throws RecognitionException {
		// Java.g:654:9: ( localVariableDeclaration SEMI )
		// Java.g:654:9: localVariableDeclaration SEMI
		{
		pushFollow(FOLLOW_localVariableDeclaration_in_synpred116_Java8474);
		localVariableDeclaration();
		state._fsp--;
		if (state.failed) return;

		match(input,SEMI,FOLLOW_SEMI_in_synpred116_Java8476); if (state.failed) return;

		}

	}
	// $ANTLR end synpred116_Java

	// $ANTLR start synpred117_Java
	public final void synpred117_Java_fragment() throws RecognitionException {
		// Java.g:655:9: ( typeDeclaration )
		// Java.g:655:9: typeDeclaration
		{
		pushFollow(FOLLOW_typeDeclaration_in_synpred117_Java8487);
		typeDeclaration();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred117_Java

	// $ANTLR start synpred121_Java
	public final void synpred121_Java_fragment() throws RecognitionException {
		ParserRuleReturnScope elseStat =null;


		// Java.g:672:13: ( ELSE elseStat= statement )
		// Java.g:672:13: ELSE elseStat= statement
		{
		match(input,ELSE,FOLLOW_ELSE_in_synpred121_Java8767); if (state.failed) return;

		pushFollow(FOLLOW_statement_in_synpred121_Java8771);
		elseStat=statement();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred121_Java

	// $ANTLR start synpred123_Java
	public final void synpred123_Java_fragment() throws RecognitionException {
		// Java.g:676:13: ( forInit SEMI forCondition SEMI forUpdater RPAREN statement )
		// Java.g:676:13: forInit SEMI forCondition SEMI forUpdater RPAREN statement
		{
		pushFollow(FOLLOW_forInit_in_synpred123_Java8950);
		forInit();
		state._fsp--;
		if (state.failed) return;

		match(input,SEMI,FOLLOW_SEMI_in_synpred123_Java8952); if (state.failed) return;

		pushFollow(FOLLOW_forCondition_in_synpred123_Java8954);
		forCondition();
		state._fsp--;
		if (state.failed) return;

		match(input,SEMI,FOLLOW_SEMI_in_synpred123_Java8956); if (state.failed) return;

		pushFollow(FOLLOW_forUpdater_in_synpred123_Java8958);
		forUpdater();
		state._fsp--;
		if (state.failed) return;

		match(input,RPAREN,FOLLOW_RPAREN_in_synpred123_Java8960); if (state.failed) return;

		pushFollow(FOLLOW_statement_in_synpred123_Java8962);
		statement();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred123_Java

	// $ANTLR start synpred130_Java
	public final void synpred130_Java_fragment() throws RecognitionException {
		// Java.g:683:47: ( switchBlockLabels )
		// Java.g:683:47: switchBlockLabels
		{
		pushFollow(FOLLOW_switchBlockLabels_in_synpred130_Java9285);
		switchBlockLabels();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred130_Java

	// $ANTLR start synpred143_Java
	public final void synpred143_Java_fragment() throws RecognitionException {
		ParserRuleReturnScope c0 =null;


		// Java.g:712:11: (c0= switchCaseLabels )
		// Java.g:712:11: c0= switchCaseLabels
		{
		pushFollow(FOLLOW_switchCaseLabels_in_synpred143_Java9874);
		c0=switchCaseLabels();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred143_Java

	// $ANTLR start synpred145_Java
	public final void synpred145_Java_fragment() throws RecognitionException {
		ParserRuleReturnScope c1 =null;


		// Java.g:712:52: (c1= switchCaseLabels )
		// Java.g:712:52: c1= switchCaseLabels
		{
		pushFollow(FOLLOW_switchCaseLabels_in_synpred145_Java9882);
		c1=switchCaseLabels();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred145_Java

	// $ANTLR start synpred146_Java
	public final void synpred146_Java_fragment() throws RecognitionException {
		// Java.g:717:9: ( switchCaseLabel )
		// Java.g:717:9: switchCaseLabel
		{
		pushFollow(FOLLOW_switchCaseLabel_in_synpred146_Java9928);
		switchCaseLabel();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred146_Java

	// $ANTLR start synpred149_Java
	public final void synpred149_Java_fragment() throws RecognitionException {
		// Java.g:729:9: ( localVariableDeclaration )
		// Java.g:729:9: localVariableDeclaration
		{
		pushFollow(FOLLOW_localVariableDeclaration_in_synpred149_Java10002);
		localVariableDeclaration();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred149_Java

	// $ANTLR start synpred150_Java
	public final void synpred150_Java_fragment() throws RecognitionException {
		// Java.g:730:9: ( expressionList )
		// Java.g:730:9: expressionList
		{
		pushFollow(FOLLOW_expressionList_in_synpred150_Java10024);
		expressionList();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred150_Java

	// $ANTLR start synpred193_Java
	public final void synpred193_Java_fragment() throws RecognitionException {
		// Java.g:866:9: ( LPAREN type RPAREN unaryExpression )
		// Java.g:866:9: LPAREN type RPAREN unaryExpression
		{
		match(input,LPAREN,FOLLOW_LPAREN_in_synpred193_Java11527); if (state.failed) return;

		pushFollow(FOLLOW_type_in_synpred193_Java11529);
		type();
		state._fsp--;
		if (state.failed) return;

		match(input,RPAREN,FOLLOW_RPAREN_in_synpred193_Java11531); if (state.failed) return;

		pushFollow(FOLLOW_unaryExpression_in_synpred193_Java11533);
		unaryExpression();
		state._fsp--;
		if (state.failed) return;

		}

	}
	// $ANTLR end synpred193_Java

	// $ANTLR start synpred221_Java
	public final void synpred221_Java_fragment() throws RecognitionException {
		// Java.g:934:13: ( ( arrayDeclarator )+ ( DOT CLASS ) )
		// Java.g:934:13: ( arrayDeclarator )+ ( DOT CLASS )
		{
		// Java.g:934:13: ( arrayDeclarator )+
		int cnt224=0;
		loop224:
		while (true) {
			int alt224=2;
			int LA224_0 = input.LA(1);
			if ( (LA224_0==LBRACK) ) {
				alt224=1;
			}

			switch (alt224) {
			case 1 :
				// Java.g:934:17: arrayDeclarator
				{
				pushFollow(FOLLOW_arrayDeclarator_in_synpred221_Java13384);
				arrayDeclarator();
				state._fsp--;
				if (state.failed) return;

				}
				break;

			default :
				if ( cnt224 >= 1 ) break loop224;
				if (state.backtracking>0) {state.failed=true; return;}
				EarlyExitException eee = new EarlyExitException(224, input);
				throw eee;
			}
			cnt224++;
		}

		// Java.g:936:13: ( DOT CLASS )
		// Java.g:936:17: DOT CLASS
		{
		match(input,DOT,FOLLOW_DOT_in_synpred221_Java13451); if (state.failed) return;

		match(input,CLASS,FOLLOW_CLASS_in_synpred221_Java13453); if (state.failed) return;

		}

		}

	}
	// $ANTLR end synpred221_Java

	// $ANTLR start synpred229_Java
	public final void synpred229_Java_fragment() throws RecognitionException {
		Token outerDot=null;
		Token Super=null;
		Token innerDot=null;


		// Java.g:939:13: (outerDot= DOT ( CLASS | genericTypeArgumentListSimplified (Super= SUPER arguments | SUPER innerDot= DOT IDENT arguments | IDENT arguments ) | THIS |Super= SUPER arguments | innerNewExpression ) )
		// Java.g:939:13: outerDot= DOT ( CLASS | genericTypeArgumentListSimplified (Super= SUPER arguments | SUPER innerDot= DOT IDENT arguments | IDENT arguments ) | THIS |Super= SUPER arguments | innerNewExpression )
		{
		outerDot=(Token)match(input,DOT,FOLLOW_DOT_in_synpred229_Java13584); if (state.failed) return;

		// Java.g:940:13: ( CLASS | genericTypeArgumentListSimplified (Super= SUPER arguments | SUPER innerDot= DOT IDENT arguments | IDENT arguments ) | THIS |Super= SUPER arguments | innerNewExpression )
		int alt227=5;
		switch ( input.LA(1) ) {
		case CLASS:
			{
			alt227=1;
			}
			break;
		case LESS_THAN:
			{
			alt227=2;
			}
			break;
		case THIS:
			{
			alt227=3;
			}
			break;
		case SUPER:
			{
			alt227=4;
			}
			break;
		case NEW:
			{
			alt227=5;
			}
			break;
		default:
			if (state.backtracking>0) {state.failed=true; return;}
			NoViableAltException nvae =
				new NoViableAltException("", 227, 0, input);
			throw nvae;
		}
		switch (alt227) {
			case 1 :
				// Java.g:940:17: CLASS
				{
				match(input,CLASS,FOLLOW_CLASS_in_synpred229_Java13602); if (state.failed) return;

				}
				break;
			case 2 :
				// Java.g:941:17: genericTypeArgumentListSimplified (Super= SUPER arguments | SUPER innerDot= DOT IDENT arguments | IDENT arguments )
				{
				pushFollow(FOLLOW_genericTypeArgumentListSimplified_in_synpred229_Java13665);
				genericTypeArgumentListSimplified();
				state._fsp--;
				if (state.failed) return;

				// Java.g:942:17: (Super= SUPER arguments | SUPER innerDot= DOT IDENT arguments | IDENT arguments )
				int alt226=3;
				int LA226_0 = input.LA(1);
				if ( (LA226_0==SUPER) ) {
					int LA226_1 = input.LA(2);
					if ( (LA226_1==DOT) ) {
						alt226=2;
					}
					else if ( (LA226_1==LPAREN) ) {
						alt226=1;
					}

					else {
						if (state.backtracking>0) {state.failed=true; return;}
						int nvaeMark = input.mark();
						try {
							input.consume();
							NoViableAltException nvae =
								new NoViableAltException("", 226, 1, input);
							throw nvae;
						} finally {
							input.rewind(nvaeMark);
						}
					}

				}
				else if ( (LA226_0==IDENT) ) {
					alt226=3;
				}

				else {
					if (state.backtracking>0) {state.failed=true; return;}
					NoViableAltException nvae =
						new NoViableAltException("", 226, 0, input);
					throw nvae;
				}

				switch (alt226) {
					case 1 :
						// Java.g:942:21: Super= SUPER arguments
						{
						Super=(Token)match(input,SUPER,FOLLOW_SUPER_in_synpred229_Java13689); if (state.failed) return;

						pushFollow(FOLLOW_arguments_in_synpred229_Java13691);
						arguments();
						state._fsp--;
						if (state.failed) return;

						}
						break;
					case 2 :
						// Java.g:943:21: SUPER innerDot= DOT IDENT arguments
						{
						match(input,SUPER,FOLLOW_SUPER_in_synpred229_Java13741); if (state.failed) return;

						innerDot=(Token)match(input,DOT,FOLLOW_DOT_in_synpred229_Java13745); if (state.failed) return;

						match(input,IDENT,FOLLOW_IDENT_in_synpred229_Java13747); if (state.failed) return;

						pushFollow(FOLLOW_arguments_in_synpred229_Java13749);
						arguments();
						state._fsp--;
						if (state.failed) return;

						}
						break;
					case 3 :
						// Java.g:944:21: IDENT arguments
						{
						match(input,IDENT,FOLLOW_IDENT_in_synpred229_Java13799); if (state.failed) return;

						pushFollow(FOLLOW_arguments_in_synpred229_Java13801);
						arguments();
						state._fsp--;
						if (state.failed) return;

						}
						break;

				}

				}
				break;
			case 3 :
				// Java.g:946:17: THIS
				{
				match(input,THIS,FOLLOW_THIS_in_synpred229_Java13876); if (state.failed) return;

				}
				break;
			case 4 :
				// Java.g:947:17: Super= SUPER arguments
				{
				Super=(Token)match(input,SUPER,FOLLOW_SUPER_in_synpred229_Java13942); if (state.failed) return;

				pushFollow(FOLLOW_arguments_in_synpred229_Java13944);
				arguments();
				state._fsp--;
				if (state.failed) return;

				}
				break;
			case 5 :
				// Java.g:948:17: innerNewExpression
				{
				pushFollow(FOLLOW_innerNewExpression_in_synpred229_Java13992);
				innerNewExpression();
				state._fsp--;
				if (state.failed) return;

				}
				break;

		}

		}

	}
	// $ANTLR end synpred229_Java

	// $ANTLR start synpred237_Java
	public final void synpred237_Java_fragment() throws RecognitionException {
		// Java.g:973:37: ( LBRACK expression RBRACK )
		// Java.g:973:37: LBRACK expression RBRACK
		{
		match(input,LBRACK,FOLLOW_LBRACK_in_synpred237_Java14387); if (state.failed) return;

		pushFollow(FOLLOW_expression_in_synpred237_Java14390);
		expression();
		state._fsp--;
		if (state.failed) return;

		match(input,RBRACK,FOLLOW_RBRACK_in_synpred237_Java14392); if (state.failed) return;

		}

	}
	// $ANTLR end synpred237_Java

	// Delegated rules

	public final boolean synpred79_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred79_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred90_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred90_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred15_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred15_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred130_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred130_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred117_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred117_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred42_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred42_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred114_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred114_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred76_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred76_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred50_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred50_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred92_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred92_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred116_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred116_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred14_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred14_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred17_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred17_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred121_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred121_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred102_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred102_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred221_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred221_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred146_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred146_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred58_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred58_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred16_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred16_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred44_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred44_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred97_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred97_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred149_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred149_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred143_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred143_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred193_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred193_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred52_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred52_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred101_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred101_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred32_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred32_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred77_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred77_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred237_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred237_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred123_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred123_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred100_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred100_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred99_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred99_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred229_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred229_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred145_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred145_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred43_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred43_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred51_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred51_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}
	public final boolean synpred150_Java() {
		state.backtracking++;
		int start = input.mark();
		try {
			synpred150_Java_fragment(); // can never throw exception
		} catch (RecognitionException re) {
			System.err.println("impossible: "+re);
		}
		boolean success = !state.failed;
		input.rewind(start);
		state.backtracking--;
		state.failed=false;
		return success;
	}



	public static final BitSet FOLLOW_compilationUnit_in_javaSource4468 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_annotationList_in_compilationUnit4505 = new BitSet(new long[]{0x0100000800400012L,0x0080000084000004L,0x0010010414040E02L});
	public static final BitSet FOLLOW_packageDeclaration_in_compilationUnit4515 = new BitSet(new long[]{0x0100000800400012L,0x0080000084000004L,0x0010010414040E00L});
	public static final BitSet FOLLOW_importDeclaration_in_compilationUnit4526 = new BitSet(new long[]{0x0100000800400012L,0x0080000084000004L,0x0010010414040E00L});
	public static final BitSet FOLLOW_typeDecls_in_compilationUnit4537 = new BitSet(new long[]{0x0100000800400012L,0x0080000080000004L,0x0010010414040E00L});
	public static final BitSet FOLLOW_typeDeclaration_in_typeDecls4557 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_typeDecls4567 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_PACKAGE_in_packageDeclaration4587 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_qualifiedIdentifier_in_packageDeclaration4589 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_packageDeclaration4591 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IMPORT_in_importDeclaration4623 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L,0x0000000004000000L});
	public static final BitSet FOLLOW_STATIC_in_importDeclaration4625 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_qualifiedIdentifier_in_importDeclaration4628 = new BitSet(new long[]{0x0010000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_DOTSTAR_in_importDeclaration4630 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_importDeclaration4633 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_modifierList_in_typeDeclaration4668 = new BitSet(new long[]{0x0100000800400000L,0x0000000080000000L});
	public static final BitSet FOLLOW_classTypeDeclaration_in_typeDeclaration4683 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_interfaceTypeDeclaration_in_typeDeclaration4698 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_enumTypeDeclaration_in_typeDeclaration4713 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_annotationTypeDeclaration_in_typeDeclaration4728 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_CLASS_in_classTypeDeclaration4759 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_classTypeDeclaration4761 = new BitSet(new long[]{0x4000000000000000L,0x0000028001000000L});
	public static final BitSet FOLLOW_genericTypeParameterList_in_classTypeDeclaration4763 = new BitSet(new long[]{0x4000000000000000L,0x0000008001000000L});
	public static final BitSet FOLLOW_classExtendsClause_in_classTypeDeclaration4766 = new BitSet(new long[]{0x0000000000000000L,0x0000008001000000L});
	public static final BitSet FOLLOW_implementsClause_in_classTypeDeclaration4769 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_classBody_in_classTypeDeclaration4772 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_EXTENDS_in_classExtendsClause4835 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_classExtendsClause4837 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_EXTENDS_in_interfaceExtendsClause4874 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_typeList_in_interfaceExtendsClause4876 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IMPLEMENTS_in_implementsClause4913 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_typeList_in_implementsClause4915 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LESS_THAN_in_genericTypeParameterList4952 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_genericTypeParameter_in_genericTypeParameterList4954 = new BitSet(new long[]{0x0000020000800000L,0x0000000000080000L,0x0000000000200000L});
	public static final BitSet FOLLOW_COMMA_in_genericTypeParameterList4957 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_genericTypeParameter_in_genericTypeParameterList4959 = new BitSet(new long[]{0x0000020000800000L,0x0000000000080000L,0x0000000000200000L});
	public static final BitSet FOLLOW_genericTypeListClosing_in_genericTypeParameterList4963 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_GREATER_THAN_in_genericTypeListClosing5078 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SHIFT_RIGHT_in_genericTypeListClosing5088 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_BIT_SHIFT_RIGHT_in_genericTypeListClosing5098 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_genericTypeParameter5126 = new BitSet(new long[]{0x4000000000000002L});
	public static final BitSet FOLLOW_bound_in_genericTypeParameter5128 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_EXTENDS_in_bound5166 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_bound5168 = new BitSet(new long[]{0x0000000000000022L});
	public static final BitSet FOLLOW_AND_in_bound5171 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_bound5173 = new BitSet(new long[]{0x0000000000000022L});
	public static final BitSet FOLLOW_ENUM_in_enumTypeDeclaration5214 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_enumTypeDeclaration5216 = new BitSet(new long[]{0x0000000000000000L,0x0000008001000000L});
	public static final BitSet FOLLOW_implementsClause_in_enumTypeDeclaration5218 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_enumBody_in_enumTypeDeclaration5221 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LCURLY_in_enumBody5264 = new BitSet(new long[]{0x0000000000400000L,0x0000000000400000L});
	public static final BitSet FOLLOW_enumScopeDeclarations_in_enumBody5266 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000008000L});
	public static final BitSet FOLLOW_RCURLY_in_enumBody5268 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_enumConstants_in_enumScopeDeclarations5305 = new BitSet(new long[]{0x0000020000000002L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_COMMA_in_enumScopeDeclarations5308 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_enumClassScopeDeclarations_in_enumScopeDeclarations5313 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_enumClassScopeDeclarations5333 = new BitSet(new long[]{0x0120000A14400012L,0x00808280A0400014L,0x0014010414840E00L});
	public static final BitSet FOLLOW_classScopeDeclarations_in_enumClassScopeDeclarations5335 = new BitSet(new long[]{0x0120000A14400012L,0x00808280A0400014L,0x0014010414840E00L});
	public static final BitSet FOLLOW_enumConstant_in_enumConstants5374 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_COMMA_in_enumConstants5377 = new BitSet(new long[]{0x0000000000400000L,0x0000000000400000L});
	public static final BitSet FOLLOW_enumConstant_in_enumConstants5380 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_annotationList_in_enumConstant5401 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_enumConstant5403 = new BitSet(new long[]{0x0000000000000002L,0x0001008000000000L});
	public static final BitSet FOLLOW_arguments_in_enumConstant5406 = new BitSet(new long[]{0x0000000000000002L,0x0000008000000000L});
	public static final BitSet FOLLOW_classBody_in_enumConstant5409 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_INTERFACE_in_interfaceTypeDeclaration5430 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_interfaceTypeDeclaration5432 = new BitSet(new long[]{0x4000000000000000L,0x0000028000000000L});
	public static final BitSet FOLLOW_genericTypeParameterList_in_interfaceTypeDeclaration5434 = new BitSet(new long[]{0x4000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_interfaceExtendsClause_in_interfaceTypeDeclaration5437 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_interfaceBody_in_interfaceTypeDeclaration5440 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_type_in_typeList5486 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_COMMA_in_typeList5489 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_typeList5492 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_LCURLY_in_classBody5513 = new BitSet(new long[]{0x0120000A14400010L,0x00808280A0400014L,0x0014010414848E00L});
	public static final BitSet FOLLOW_classScopeDeclarations_in_classBody5515 = new BitSet(new long[]{0x0120000A14400010L,0x00808280A0400014L,0x0014010414848E00L});
	public static final BitSet FOLLOW_RCURLY_in_classBody5518 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LCURLY_in_interfaceBody5556 = new BitSet(new long[]{0x0120000A14400010L,0x00808200A0400014L,0x0014010414848E00L});
	public static final BitSet FOLLOW_interfaceScopeDeclarations_in_interfaceBody5558 = new BitSet(new long[]{0x0120000A14400010L,0x00808200A0400014L,0x0014010414848E00L});
	public static final BitSet FOLLOW_RCURLY_in_interfaceBody5561 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_block_in_classScopeDeclarations5599 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_STATIC_in_classScopeDeclarations5628 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_block_in_classScopeDeclarations5630 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_modifierList_in_classScopeDeclarations5653 = new BitSet(new long[]{0x0020000214000000L,0x0000820020400010L,0x0004000000800000L});
	public static final BitSet FOLLOW_genericTypeParameterList_in_classScopeDeclarations5667 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0004000000800000L});
	public static final BitSet FOLLOW_type_in_classScopeDeclarations5686 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_classScopeDeclarations5688 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_classScopeDeclarations5690 = new BitSet(new long[]{0x0000000000000000L,0x000000C000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_classScopeDeclarations5692 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_classScopeDeclarations5695 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_block_in_classScopeDeclarations5699 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_classScopeDeclarations5703 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_VOID_in_classScopeDeclarations5765 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_classScopeDeclarations5767 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_classScopeDeclarations5769 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_classScopeDeclarations5771 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_block_in_classScopeDeclarations5775 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_classScopeDeclarations5779 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_classScopeDeclarations5838 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_classScopeDeclarations5840 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000004000000000L});
	public static final BitSet FOLLOW_throwsClause_in_classScopeDeclarations5842 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_block_in_classScopeDeclarations5845 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_type_in_classScopeDeclarations5909 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_classFieldDeclaratorList_in_classScopeDeclarations5911 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_classScopeDeclarations5913 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_typeDeclaration_in_classScopeDeclarations5958 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_classScopeDeclarations5968 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_modifierList_in_interfaceScopeDeclarations5988 = new BitSet(new long[]{0x0020000214000000L,0x0000820020400010L,0x0004000000800000L});
	public static final BitSet FOLLOW_genericTypeParameterList_in_interfaceScopeDeclarations6002 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0004000000800000L});
	public static final BitSet FOLLOW_type_in_interfaceScopeDeclarations6021 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_interfaceScopeDeclarations6023 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_interfaceScopeDeclarations6025 = new BitSet(new long[]{0x0000000000000000L,0x0000004000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_interfaceScopeDeclarations6027 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_interfaceScopeDeclarations6030 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_interfaceScopeDeclarations6033 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_VOID_in_interfaceScopeDeclarations6091 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_interfaceScopeDeclarations6093 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_interfaceScopeDeclarations6095 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_interfaceScopeDeclarations6097 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_interfaceScopeDeclarations6100 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_type_in_interfaceScopeDeclarations6163 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_interfaceFieldDeclaratorList_in_interfaceScopeDeclarations6165 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_interfaceScopeDeclarations6167 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_typeDeclaration_in_interfaceScopeDeclarations6212 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_interfaceScopeDeclarations6222 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_classFieldDeclarator_in_classFieldDeclaratorList6242 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_COMMA_in_classFieldDeclaratorList6245 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_classFieldDeclarator_in_classFieldDeclaratorList6247 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_variableDeclaratorId_in_classFieldDeclarator6286 = new BitSet(new long[]{0x0000000000200002L});
	public static final BitSet FOLLOW_ASSIGN_in_classFieldDeclarator6289 = new BitSet(new long[]{0x0020600614000000L,0x5505A28028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_variableInitializer_in_classFieldDeclarator6291 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_interfaceFieldDeclarator_in_interfaceFieldDeclaratorList6332 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_COMMA_in_interfaceFieldDeclaratorList6335 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_interfaceFieldDeclarator_in_interfaceFieldDeclaratorList6337 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_variableDeclaratorId_in_interfaceFieldDeclarator6376 = new BitSet(new long[]{0x0000000000200000L});
	public static final BitSet FOLLOW_ASSIGN_in_interfaceFieldDeclarator6378 = new BitSet(new long[]{0x0020600614000000L,0x5505A28028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_variableInitializer_in_interfaceFieldDeclarator6380 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_variableDeclaratorId6418 = new BitSet(new long[]{0x0000000000000002L,0x0000004000000000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_variableDeclaratorId6421 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arrayInitializer_in_variableInitializer6441 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_expression_in_variableInitializer6451 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LBRACK_in_arrayDeclarator6470 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000004000L});
	public static final BitSet FOLLOW_RBRACK_in_arrayDeclarator6472 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arrayDeclarator_in_arrayDeclaratorList6506 = new BitSet(new long[]{0x0000000000000002L,0x0000004000000000L});
	public static final BitSet FOLLOW_LCURLY_in_arrayInitializer6544 = new BitSet(new long[]{0x0020600614000000L,0x5505A28028600032L,0x0004020860808008L});
	public static final BitSet FOLLOW_variableInitializer_in_arrayInitializer6547 = new BitSet(new long[]{0x0000020000000000L,0x0000000000000000L,0x0000000000008000L});
	public static final BitSet FOLLOW_COMMA_in_arrayInitializer6550 = new BitSet(new long[]{0x0020600614000000L,0x5505A28028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_variableInitializer_in_arrayInitializer6552 = new BitSet(new long[]{0x0000020000000000L,0x0000000000000000L,0x0000000000008000L});
	public static final BitSet FOLLOW_COMMA_in_arrayInitializer6556 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000008000L});
	public static final BitSet FOLLOW_RCURLY_in_arrayInitializer6561 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_THROWS_in_throwsClause6599 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_qualifiedIdentList_in_throwsClause6601 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_modifier_in_modifierList6638 = new BitSet(new long[]{0x0000000000400012L,0x0080000000000004L,0x0010010414000E00L});
	public static final BitSet FOLLOW_PUBLIC_in_modifier6678 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_PROTECTED_in_modifier6688 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_PRIVATE_in_modifier6698 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_STATIC_in_modifier6708 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_ABSTRACT_in_modifier6718 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_NATIVE_in_modifier6728 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SYNCHRONIZED_in_modifier6738 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_TRANSIENT_in_modifier6748 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_VOLATILE_in_modifier6758 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_STRICTFP_in_modifier6768 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_localModifier_in_modifier6778 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_localModifier_in_localModifierList6797 = new BitSet(new long[]{0x0000000000400002L,0x0000000000000004L});
	public static final BitSet FOLLOW_FINAL_in_localModifier6834 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_annotation_in_localModifier6844 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_simpleType_in_type6863 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_objectType_in_type6873 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_primitiveType_in_simpleType6893 = new BitSet(new long[]{0x0000000000000002L,0x0000004000000000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_simpleType6895 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_qualifiedTypeIdent_in_objectType6937 = new BitSet(new long[]{0x0000000000000002L,0x0000004000000000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_objectType6939 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_qualifiedTypeIdentSimplified_in_objectTypeSimplified6980 = new BitSet(new long[]{0x0000000000000002L,0x0000004000000000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_objectTypeSimplified6982 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_typeIdent_in_qualifiedTypeIdent7023 = new BitSet(new long[]{0x0008000000000002L});
	public static final BitSet FOLLOW_DOT_in_qualifiedTypeIdent7026 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_typeIdent_in_qualifiedTypeIdent7028 = new BitSet(new long[]{0x0008000000000002L});
	public static final BitSet FOLLOW_typeIdentSimplified_in_qualifiedTypeIdentSimplified7067 = new BitSet(new long[]{0x0008000000000002L});
	public static final BitSet FOLLOW_DOT_in_qualifiedTypeIdentSimplified7070 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_typeIdentSimplified_in_qualifiedTypeIdentSimplified7072 = new BitSet(new long[]{0x0008000000000002L});
	public static final BitSet FOLLOW_IDENT_in_typeIdent7111 = new BitSet(new long[]{0x0000000000000002L,0x0000020000000000L});
	public static final BitSet FOLLOW_genericTypeArgumentList_in_typeIdent7114 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_typeIdentSimplified7134 = new BitSet(new long[]{0x0000000000000002L,0x0000020000000000L});
	public static final BitSet FOLLOW_genericTypeArgumentListSimplified_in_typeIdentSimplified7137 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LESS_THAN_in_genericTypeArgumentList7246 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000802000L});
	public static final BitSet FOLLOW_genericTypeArgument_in_genericTypeArgumentList7248 = new BitSet(new long[]{0x0000020000800000L,0x0000000000080000L,0x0000000000200000L});
	public static final BitSet FOLLOW_COMMA_in_genericTypeArgumentList7251 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000802000L});
	public static final BitSet FOLLOW_genericTypeArgument_in_genericTypeArgumentList7253 = new BitSet(new long[]{0x0000020000800000L,0x0000000000080000L,0x0000000000200000L});
	public static final BitSet FOLLOW_genericTypeListClosing_in_genericTypeArgumentList7257 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_type_in_genericTypeArgument7295 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_QUESTION_in_genericTypeArgument7305 = new BitSet(new long[]{0x4000000000000002L,0x0000000000000000L,0x0000000040000000L});
	public static final BitSet FOLLOW_genericWildcardBoundType_in_genericTypeArgument7307 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_set_in_genericWildcardBoundType7345 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_genericWildcardBoundType7354 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LESS_THAN_in_genericTypeArgumentListSimplified7373 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000802000L});
	public static final BitSet FOLLOW_genericTypeArgumentSimplified_in_genericTypeArgumentListSimplified7375 = new BitSet(new long[]{0x0000020000800000L,0x0000000000080000L,0x0000000000200000L});
	public static final BitSet FOLLOW_COMMA_in_genericTypeArgumentListSimplified7378 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000802000L});
	public static final BitSet FOLLOW_genericTypeArgumentSimplified_in_genericTypeArgumentListSimplified7380 = new BitSet(new long[]{0x0000020000800000L,0x0000000000080000L,0x0000000000200000L});
	public static final BitSet FOLLOW_genericTypeListClosing_in_genericTypeArgumentListSimplified7384 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_type_in_genericTypeArgumentSimplified7422 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_QUESTION_in_genericTypeArgumentSimplified7432 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_qualifiedIdentifier_in_qualifiedIdentList7451 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_COMMA_in_qualifiedIdentList7454 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_qualifiedIdentifier_in_qualifiedIdentList7457 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_LPAREN_in_formalParameterList7478 = new BitSet(new long[]{0x0020000214400000L,0x0000800020400014L,0x0000000000820000L});
	public static final BitSet FOLLOW_formalParameterStandardDecl_in_formalParameterList7505 = new BitSet(new long[]{0x0000020000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_COMMA_in_formalParameterList7508 = new BitSet(new long[]{0x0020000214400000L,0x0000800020400014L,0x0000000000800000L});
	public static final BitSet FOLLOW_formalParameterStandardDecl_in_formalParameterList7510 = new BitSet(new long[]{0x0000020000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_COMMA_in_formalParameterList7515 = new BitSet(new long[]{0x0020000214400000L,0x0000800020400014L,0x0000000000800000L});
	public static final BitSet FOLLOW_formalParameterVarArgDecl_in_formalParameterList7517 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_formalParameterVarArgDecl_in_formalParameterList7572 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_formalParameterList7647 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_localModifierList_in_formalParameterStandardDecl7666 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_formalParameterStandardDecl7668 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_variableDeclaratorId_in_formalParameterStandardDecl7670 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_localModifierList_in_formalParameterVarArgDecl7710 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_formalParameterVarArgDecl7712 = new BitSet(new long[]{0x0040000000000000L});
	public static final BitSet FOLLOW_ELLIPSIS_in_formalParameterVarArgDecl7714 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_variableDeclaratorId_in_formalParameterVarArgDecl7716 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_qualifiedIdentifier7760 = new BitSet(new long[]{0x0008000000000002L});
	public static final BitSet FOLLOW_DOT_in_qualifiedIdentifier7803 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_qualifiedIdentifier7807 = new BitSet(new long[]{0x0008000000000002L});
	public static final BitSet FOLLOW_annotation_in_annotationList7856 = new BitSet(new long[]{0x0000000000400002L});
	public static final BitSet FOLLOW_AT_in_annotation7890 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_qualifiedIdentifier_in_annotation7893 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
	public static final BitSet FOLLOW_annotationInit_in_annotation7895 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LPAREN_in_annotationInit7915 = new BitSet(new long[]{0x0020600614400000L,0x5505A28028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_annotationInitializers_in_annotationInit7917 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_annotationInit7919 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_annotationInitializer_in_annotationInitializers7956 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_COMMA_in_annotationInitializers7959 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_annotationInitializer_in_annotationInitializers7961 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_annotationElementValue_in_annotationInitializers7991 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_annotationInitializer8028 = new BitSet(new long[]{0x0000000000200000L});
	public static final BitSet FOLLOW_ASSIGN_in_annotationInitializer8031 = new BitSet(new long[]{0x0020600614400000L,0x5505A28028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_annotationElementValue_in_annotationInitializer8034 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_annotationElementValueExpression_in_annotationElementValue8053 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_annotation_in_annotationElementValue8063 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_annotationElementValueArrayInitializer_in_annotationElementValue8073 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_conditionalExpression_in_annotationElementValueExpression8092 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LCURLY_in_annotationElementValueArrayInitializer8128 = new BitSet(new long[]{0x0020620614400000L,0x5505A28028600032L,0x0004020860808008L});
	public static final BitSet FOLLOW_annotationElementValue_in_annotationElementValueArrayInitializer8131 = new BitSet(new long[]{0x0000020000000000L,0x0000000000000000L,0x0000000000008000L});
	public static final BitSet FOLLOW_COMMA_in_annotationElementValueArrayInitializer8134 = new BitSet(new long[]{0x0020600614400000L,0x5505A28028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_annotationElementValue_in_annotationElementValueArrayInitializer8136 = new BitSet(new long[]{0x0000020000000000L,0x0000000000000000L,0x0000000000008000L});
	public static final BitSet FOLLOW_COMMA_in_annotationElementValueArrayInitializer8143 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000008000L});
	public static final BitSet FOLLOW_RCURLY_in_annotationElementValueArrayInitializer8147 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_AT_in_annotationTypeDeclaration8186 = new BitSet(new long[]{0x0000000000000000L,0x0000000080000000L});
	public static final BitSet FOLLOW_INTERFACE_in_annotationTypeDeclaration8188 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_annotationTypeDeclaration8190 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_annotationBody_in_annotationTypeDeclaration8192 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LCURLY_in_annotationBody8231 = new BitSet(new long[]{0x0120000A14400010L,0x00808000A0400014L,0x0010010414808E00L});
	public static final BitSet FOLLOW_annotationScopeDeclarations_in_annotationBody8233 = new BitSet(new long[]{0x0120000A14400010L,0x00808000A0400014L,0x0010010414808E00L});
	public static final BitSet FOLLOW_RCURLY_in_annotationBody8236 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_modifierList_in_annotationScopeDeclarations8274 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_annotationScopeDeclarations8276 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_annotationScopeDeclarations8290 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_LPAREN_in_annotationScopeDeclarations8292 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_annotationScopeDeclarations8294 = new BitSet(new long[]{0x0000800000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_annotationDefaultValue_in_annotationScopeDeclarations8296 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_annotationScopeDeclarations8299 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_classFieldDeclaratorList_in_annotationScopeDeclarations8341 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_annotationScopeDeclarations8343 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_typeDeclaration_in_annotationScopeDeclarations8388 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_DEFAULT_in_annotationDefaultValue8407 = new BitSet(new long[]{0x0020600614400000L,0x5505A28028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_annotationElementValue_in_annotationDefaultValue8410 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LCURLY_in_block8431 = new BitSet(new long[]{0x0124700E1C500010L,0x5585A280A8E000B6L,0x0034072D74858E08L});
	public static final BitSet FOLLOW_blockStatement_in_block8433 = new BitSet(new long[]{0x0124700E1C500010L,0x5585A280A8E000B6L,0x0034072D74858E08L});
	public static final BitSet FOLLOW_RCURLY_in_block8436 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_localVariableDeclaration_in_blockStatement8474 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_blockStatement8476 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_typeDeclaration_in_blockStatement8487 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_statement_in_blockStatement8497 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_localModifierList_in_localVariableDeclaration8516 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_localVariableDeclaration8518 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_classFieldDeclaratorList_in_localVariableDeclaration8520 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_block_in_statement8561 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_ASSERT_in_statement8571 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_statement8575 = new BitSet(new long[]{0x0000010000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_COLON_in_statement8589 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_statement8593 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_statement8595 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_statement8658 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IF_in_statement8747 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_parenthesizedExpression_in_statement8749 = new BitSet(new long[]{0x002470061C100000L,0x5505A28028E000B2L,0x0024062D60850008L});
	public static final BitSet FOLLOW_statement_in_statement8753 = new BitSet(new long[]{0x0080000000000002L});
	public static final BitSet FOLLOW_ELSE_in_statement8767 = new BitSet(new long[]{0x002470061C100000L,0x5505A28028E000B2L,0x0024062D60850008L});
	public static final BitSet FOLLOW_statement_in_statement8771 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_FOR_in_statement8934 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_LPAREN_in_statement8936 = new BitSet(new long[]{0x0020600614400000L,0x5505A20028600036L,0x0004020860840008L});
	public static final BitSet FOLLOW_forInit_in_statement8950 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_statement8952 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860840008L});
	public static final BitSet FOLLOW_forCondition_in_statement8954 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_statement8956 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860820008L});
	public static final BitSet FOLLOW_forUpdater_in_statement8958 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_statement8960 = new BitSet(new long[]{0x002470061C100000L,0x5505A28028E000B2L,0x0024062D60850008L});
	public static final BitSet FOLLOW_statement_in_statement8962 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_localModifierList_in_statement8996 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_statement8998 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_statement9000 = new BitSet(new long[]{0x0000010000000000L});
	public static final BitSet FOLLOW_COLON_in_statement9002 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_statement9004 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_statement9006 = new BitSet(new long[]{0x002470061C100000L,0x5505A28028E000B2L,0x0024062D60850008L});
	public static final BitSet FOLLOW_statement_in_statement9008 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_WHILE_in_statement9122 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_parenthesizedExpression_in_statement9124 = new BitSet(new long[]{0x002470061C100000L,0x5505A28028E000B2L,0x0024062D60850008L});
	public static final BitSet FOLLOW_statement_in_statement9126 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_DO_in_statement9175 = new BitSet(new long[]{0x002470061C100000L,0x5505A28028E000B2L,0x0024062D60850008L});
	public static final BitSet FOLLOW_statement_in_statement9177 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0020000000000000L});
	public static final BitSet FOLLOW_WHILE_in_statement9179 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_parenthesizedExpression_in_statement9181 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_statement9183 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_TRY_in_statement9224 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_block_in_statement9226 = new BitSet(new long[]{0x0000000080000000L,0x0000000000000008L});
	public static final BitSet FOLLOW_catches_in_statement9229 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000008L});
	public static final BitSet FOLLOW_finallyClause_in_statement9231 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_finallyClause_in_statement9236 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SWITCH_in_statement9279 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_parenthesizedExpression_in_statement9281 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_LCURLY_in_statement9283 = new BitSet(new long[]{0x0000800020000000L,0x0000000000000000L,0x0000000000008000L});
	public static final BitSet FOLLOW_switchBlockLabels_in_statement9285 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000008000L});
	public static final BitSet FOLLOW_RCURLY_in_statement9288 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SYNCHRONIZED_in_statement9315 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_parenthesizedExpression_in_statement9317 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_block_in_statement9319 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_RETURN_in_statement9365 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860840008L});
	public static final BitSet FOLLOW_expression_in_statement9367 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_statement9370 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_THROW_in_statement9435 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_statement9437 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_statement9439 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_BREAK_in_statement9504 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L,0x0000000000040000L});
	public static final BitSet FOLLOW_IDENT_in_statement9506 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_statement9509 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_CONTINUE_in_statement9579 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L,0x0000000000040000L});
	public static final BitSet FOLLOW_IDENT_in_statement9581 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_statement9584 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_statement9651 = new BitSet(new long[]{0x0000010000000000L});
	public static final BitSet FOLLOW_COLON_in_statement9653 = new BitSet(new long[]{0x002470061C100000L,0x5505A28028E000B2L,0x0024062D60850008L});
	public static final BitSet FOLLOW_statement_in_statement9655 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_expression_in_statement9722 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_statement9724 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_statement9735 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_catchClause_in_catches9755 = new BitSet(new long[]{0x0000000080000002L});
	public static final BitSet FOLLOW_CATCH_in_catchClause9793 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_LPAREN_in_catchClause9796 = new BitSet(new long[]{0x0020000214400000L,0x0000800020400014L,0x0000000000800000L});
	public static final BitSet FOLLOW_formalParameterStandardDecl_in_catchClause9799 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_catchClause9801 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_block_in_catchClause9804 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_FINALLY_in_finallyClause9823 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_block_in_finallyClause9825 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_switchCaseLabels_in_switchBlockLabels9874 = new BitSet(new long[]{0x0000800020000000L});
	public static final BitSet FOLLOW_switchDefaultLabel_in_switchBlockLabels9877 = new BitSet(new long[]{0x0000000020000000L});
	public static final BitSet FOLLOW_switchCaseLabels_in_switchBlockLabels9882 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_switchCaseLabel_in_switchCaseLabels9928 = new BitSet(new long[]{0x0000000020000002L});
	public static final BitSet FOLLOW_CASE_in_switchCaseLabel9948 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_switchCaseLabel9951 = new BitSet(new long[]{0x0000010000000000L});
	public static final BitSet FOLLOW_COLON_in_switchCaseLabel9953 = new BitSet(new long[]{0x0124700E1C500012L,0x5585A280A8E000B6L,0x0034072D74850E08L});
	public static final BitSet FOLLOW_blockStatement_in_switchCaseLabel9956 = new BitSet(new long[]{0x0124700E1C500012L,0x5585A280A8E000B6L,0x0034072D74850E08L});
	public static final BitSet FOLLOW_DEFAULT_in_switchDefaultLabel9976 = new BitSet(new long[]{0x0000010000000000L});
	public static final BitSet FOLLOW_COLON_in_switchDefaultLabel9979 = new BitSet(new long[]{0x0124700E1C500012L,0x5585A280A8E000B6L,0x0034072D74850E08L});
	public static final BitSet FOLLOW_blockStatement_in_switchDefaultLabel9982 = new BitSet(new long[]{0x0124700E1C500012L,0x5585A280A8E000B6L,0x0034072D74850E08L});
	public static final BitSet FOLLOW_localVariableDeclaration_in_forInit10002 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_expressionList_in_forInit10024 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_expression_in_forCondition10108 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_expressionList_in_forUpdater10146 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LPAREN_in_parenthesizedExpression10186 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_parenthesizedExpression10188 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_parenthesizedExpression10190 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_expression_in_expressionList10227 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_COMMA_in_expressionList10230 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_expressionList10233 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_assignmentExpression_in_expression10254 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_conditionalExpression_in_assignmentExpression10290 = new BitSet(new long[]{0x0002000001200042L,0x0048000000000000L,0x0100000002500011L});
	public static final BitSet FOLLOW_ASSIGN_in_assignmentExpression10308 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_PLUS_ASSIGN_in_assignmentExpression10327 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_MINUS_ASSIGN_in_assignmentExpression10346 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_STAR_ASSIGN_in_assignmentExpression10365 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_DIV_ASSIGN_in_assignmentExpression10384 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_AND_ASSIGN_in_assignmentExpression10403 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_OR_ASSIGN_in_assignmentExpression10422 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_XOR_ASSIGN_in_assignmentExpression10441 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_MOD_ASSIGN_in_assignmentExpression10460 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_SHIFT_LEFT_ASSIGN_in_assignmentExpression10479 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_SHIFT_RIGHT_ASSIGN_in_assignmentExpression10498 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_BIT_SHIFT_RIGHT_ASSIGN_in_assignmentExpression10517 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_assignmentExpression_in_assignmentExpression10538 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_logicalOrExpression_in_conditionalExpression10559 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0000000000002000L});
	public static final BitSet FOLLOW_QUESTION_in_conditionalExpression10562 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_assignmentExpression_in_conditionalExpression10565 = new BitSet(new long[]{0x0000010000000000L});
	public static final BitSet FOLLOW_COLON_in_conditionalExpression10567 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_conditionalExpression_in_conditionalExpression10570 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_logicalAndExpression_in_logicalOrExpression10591 = new BitSet(new long[]{0x0000000000000002L,0x0000400000000000L});
	public static final BitSet FOLLOW_LOGICAL_OR_in_logicalOrExpression10594 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_logicalAndExpression_in_logicalOrExpression10597 = new BitSet(new long[]{0x0000000000000002L,0x0000400000000000L});
	public static final BitSet FOLLOW_inclusiveOrExpression_in_logicalAndExpression10618 = new BitSet(new long[]{0x0000000000000002L,0x0000100000000000L});
	public static final BitSet FOLLOW_LOGICAL_AND_in_logicalAndExpression10621 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_inclusiveOrExpression_in_logicalAndExpression10624 = new BitSet(new long[]{0x0000000000000002L,0x0000100000000000L});
	public static final BitSet FOLLOW_exclusiveOrExpression_in_inclusiveOrExpression10645 = new BitSet(new long[]{0x0000000000000002L,0x8000000000000000L});
	public static final BitSet FOLLOW_OR_in_inclusiveOrExpression10648 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_exclusiveOrExpression_in_inclusiveOrExpression10651 = new BitSet(new long[]{0x0000000000000002L,0x8000000000000000L});
	public static final BitSet FOLLOW_andExpression_in_exclusiveOrExpression10672 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0080000000000000L});
	public static final BitSet FOLLOW_XOR_in_exclusiveOrExpression10675 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_andExpression_in_exclusiveOrExpression10678 = new BitSet(new long[]{0x0000000000000002L,0x0000000000000000L,0x0080000000000000L});
	public static final BitSet FOLLOW_equalityExpression_in_andExpression10699 = new BitSet(new long[]{0x0000000000000022L});
	public static final BitSet FOLLOW_AND_in_andExpression10702 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_equalityExpression_in_andExpression10705 = new BitSet(new long[]{0x0000000000000022L});
	public static final BitSet FOLLOW_instanceOfExpression_in_equalityExpression10726 = new BitSet(new long[]{0x0400000000000002L,0x0800000000000000L});
	public static final BitSet FOLLOW_EQUAL_in_equalityExpression10744 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_NOT_EQUAL_in_equalityExpression10763 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_instanceOfExpression_in_equalityExpression10792 = new BitSet(new long[]{0x0400000000000002L,0x0800000000000000L});
	public static final BitSet FOLLOW_relationalExpression_in_instanceOfExpression10822 = new BitSet(new long[]{0x0000000000000002L,0x0000000010000000L});
	public static final BitSet FOLLOW_INSTANCEOF_in_instanceOfExpression10825 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_instanceOfExpression10828 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_shiftExpression_in_relationalExpression10849 = new BitSet(new long[]{0x0000000000000002L,0x00000300000C0000L});
	public static final BitSet FOLLOW_LESS_OR_EQUAL_in_relationalExpression10867 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_GREATER_OR_EQUAL_in_relationalExpression10886 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_LESS_THAN_in_relationalExpression10905 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_GREATER_THAN_in_relationalExpression10924 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_shiftExpression_in_relationalExpression10953 = new BitSet(new long[]{0x0000000000000002L,0x00000300000C0000L});
	public static final BitSet FOLLOW_additiveExpression_in_shiftExpression10983 = new BitSet(new long[]{0x0000000000800002L,0x0000000000000000L,0x0000000000280000L});
	public static final BitSet FOLLOW_BIT_SHIFT_RIGHT_in_shiftExpression11001 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_SHIFT_RIGHT_in_shiftExpression11020 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_SHIFT_LEFT_in_shiftExpression11039 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_additiveExpression_in_shiftExpression11068 = new BitSet(new long[]{0x0000000000800002L,0x0000000000000000L,0x0000000000280000L});
	public static final BitSet FOLLOW_multiplicativeExpression_in_additiveExpression11098 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L,0x0000000000000008L});
	public static final BitSet FOLLOW_PLUS_in_additiveExpression11116 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_MINUS_in_additiveExpression11135 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_multiplicativeExpression_in_additiveExpression11164 = new BitSet(new long[]{0x0000000000000002L,0x0004000000000000L,0x0000000000000008L});
	public static final BitSet FOLLOW_unaryExpression_in_multiplicativeExpression11194 = new BitSet(new long[]{0x0001000000000002L,0x0010000000000000L,0x0000000001000000L});
	public static final BitSet FOLLOW_STAR_in_multiplicativeExpression11212 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_DIV_in_multiplicativeExpression11231 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_MOD_in_multiplicativeExpression11250 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_unaryExpression_in_multiplicativeExpression11279 = new BitSet(new long[]{0x0001000000000002L,0x0010000000000000L,0x0000000001000000L});
	public static final BitSet FOLLOW_PLUS_in_unaryExpression11309 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_unaryExpression_in_unaryExpression11311 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_MINUS_in_unaryExpression11338 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_unaryExpression_in_unaryExpression11340 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_INC_in_unaryExpression11366 = new BitSet(new long[]{0x0020400614000000L,0x5101820020600032L,0x0004020860800000L});
	public static final BitSet FOLLOW_postfixedExpression_in_unaryExpression11368 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_DEC_in_unaryExpression11392 = new BitSet(new long[]{0x0020400614000000L,0x5101820020600032L,0x0004020860800000L});
	public static final BitSet FOLLOW_postfixedExpression_in_unaryExpression11394 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_unaryExpressionNotPlusMinus_in_unaryExpression11418 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_NOT_in_unaryExpressionNotPlusMinus11437 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_unaryExpression_in_unaryExpressionNotPlusMinus11439 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LOGICAL_NOT_in_unaryExpressionNotPlusMinus11486 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_unaryExpression_in_unaryExpressionNotPlusMinus11488 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LPAREN_in_unaryExpressionNotPlusMinus11527 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_unaryExpressionNotPlusMinus11529 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_unaryExpressionNotPlusMinus11531 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_unaryExpression_in_unaryExpressionNotPlusMinus11533 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_postfixedExpression_in_unaryExpressionNotPlusMinus11568 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_primaryExpression_in_postfixedExpression11600 = new BitSet(new long[]{0x0008200000000002L,0x0000004008000000L});
	public static final BitSet FOLLOW_DOT_in_postfixedExpression11662 = new BitSet(new long[]{0x0000000000000000L,0x0100020000400000L,0x0000000840000000L});
	public static final BitSet FOLLOW_genericTypeArgumentListSimplified_in_postfixedExpression11684 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_postfixedExpression11766 = new BitSet(new long[]{0x0008200000000002L,0x0001004008000000L});
	public static final BitSet FOLLOW_arguments_in_postfixedExpression11844 = new BitSet(new long[]{0x0008200000000002L,0x0000004008000000L});
	public static final BitSet FOLLOW_THIS_in_postfixedExpression11918 = new BitSet(new long[]{0x0008200000000002L,0x0000004008000000L});
	public static final BitSet FOLLOW_SUPER_in_postfixedExpression11981 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_postfixedExpression11983 = new BitSet(new long[]{0x0008200000000002L,0x0000004008000000L});
	public static final BitSet FOLLOW_SUPER_in_postfixedExpression12036 = new BitSet(new long[]{0x0008000000000000L});
	public static final BitSet FOLLOW_DOT_in_postfixedExpression12040 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_postfixedExpression12042 = new BitSet(new long[]{0x0008200000000002L,0x0001004008000000L});
	public static final BitSet FOLLOW_arguments_in_postfixedExpression12109 = new BitSet(new long[]{0x0008200000000002L,0x0000004008000000L});
	public static final BitSet FOLLOW_innerNewExpression_in_postfixedExpression12180 = new BitSet(new long[]{0x0008200000000002L,0x0000004008000000L});
	public static final BitSet FOLLOW_LBRACK_in_postfixedExpression12237 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_postfixedExpression12239 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000004000L});
	public static final BitSet FOLLOW_RBRACK_in_postfixedExpression12241 = new BitSet(new long[]{0x0008200000000002L,0x0000004008000000L});
	public static final BitSet FOLLOW_INC_in_postfixedExpression12302 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_DEC_in_postfixedExpression12326 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_parenthesizedExpression_in_primaryExpression12366 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_literal_in_primaryExpression12376 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_newExpression_in_primaryExpression12386 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_qualifiedIdentExpression_in_primaryExpression12396 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_genericTypeArgumentListSimplified_in_primaryExpression12406 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L,0x0000000840000000L});
	public static final BitSet FOLLOW_SUPER_in_primaryExpression12420 = new BitSet(new long[]{0x0008000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_primaryExpression12438 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_DOT_in_primaryExpression12498 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_primaryExpression12500 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_primaryExpression12502 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_primaryExpression12569 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_primaryExpression12571 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_THIS_in_primaryExpression12626 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_primaryExpression12628 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_THIS_in_primaryExpression12693 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_primaryExpression12761 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SUPER_in_primaryExpression12826 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_primaryExpression12828 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SUPER_in_primaryExpression12884 = new BitSet(new long[]{0x0008000000000000L});
	public static final BitSet FOLLOW_DOT_in_primaryExpression12886 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_primaryExpression12888 = new BitSet(new long[]{0x0000000000000002L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_primaryExpression12912 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_primitiveType_in_primaryExpression13054 = new BitSet(new long[]{0x0008000000000000L,0x0000004000000000L});
	public static final BitSet FOLLOW_arrayDeclarator_in_primaryExpression13113 = new BitSet(new long[]{0x0008000000000000L,0x0000004000000000L});
	public static final BitSet FOLLOW_DOT_in_primaryExpression13172 = new BitSet(new long[]{0x0000000800000000L});
	public static final BitSet FOLLOW_CLASS_in_primaryExpression13174 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_VOID_in_primaryExpression13234 = new BitSet(new long[]{0x0008000000000000L});
	public static final BitSet FOLLOW_DOT_in_primaryExpression13236 = new BitSet(new long[]{0x0000000800000000L});
	public static final BitSet FOLLOW_CLASS_in_primaryExpression13238 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_qualifiedIdentifier_in_qualifiedIdentExpression13314 = new BitSet(new long[]{0x0008000000000002L,0x0001004000000000L});
	public static final BitSet FOLLOW_arrayDeclarator_in_qualifiedIdentExpression13384 = new BitSet(new long[]{0x0008000000000000L,0x0000004000000000L});
	public static final BitSet FOLLOW_DOT_in_qualifiedIdentExpression13451 = new BitSet(new long[]{0x0000000800000000L});
	public static final BitSet FOLLOW_CLASS_in_qualifiedIdentExpression13453 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arguments_in_qualifiedIdentExpression13523 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_DOT_in_qualifiedIdentExpression13584 = new BitSet(new long[]{0x0000000800000000L,0x0100020000000000L,0x0000000840000000L});
	public static final BitSet FOLLOW_CLASS_in_qualifiedIdentExpression13602 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_genericTypeArgumentListSimplified_in_qualifiedIdentExpression13665 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L,0x0000000040000000L});
	public static final BitSet FOLLOW_SUPER_in_qualifiedIdentExpression13689 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_qualifiedIdentExpression13691 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SUPER_in_qualifiedIdentExpression13741 = new BitSet(new long[]{0x0008000000000000L});
	public static final BitSet FOLLOW_DOT_in_qualifiedIdentExpression13745 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_qualifiedIdentExpression13747 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_qualifiedIdentExpression13749 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_qualifiedIdentExpression13799 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_qualifiedIdentExpression13801 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_THIS_in_qualifiedIdentExpression13876 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SUPER_in_qualifiedIdentExpression13942 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_qualifiedIdentExpression13944 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_innerNewExpression_in_qualifiedIdentExpression13992 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_NEW_in_newExpression14068 = new BitSet(new long[]{0x0020000214000000L,0x0000820020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_primitiveType_in_newExpression14082 = new BitSet(new long[]{0x0000000000000000L,0x0000004000000000L});
	public static final BitSet FOLLOW_newArrayConstruction_in_newExpression14084 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_genericTypeArgumentListSimplified_in_newExpression14128 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_qualifiedTypeIdentSimplified_in_newExpression14131 = new BitSet(new long[]{0x0000000000000000L,0x0001004000000000L});
	public static final BitSet FOLLOW_newArrayConstruction_in_newExpression14149 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arguments_in_newExpression14214 = new BitSet(new long[]{0x0000000000000002L,0x0000008000000000L});
	public static final BitSet FOLLOW_classBody_in_newExpression14216 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_NEW_in_innerNewExpression14311 = new BitSet(new long[]{0x0000000000000000L,0x0000020000400000L});
	public static final BitSet FOLLOW_genericTypeArgumentListSimplified_in_innerNewExpression14313 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_innerNewExpression14316 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_innerNewExpression14318 = new BitSet(new long[]{0x0000000000000002L,0x0000008000000000L});
	public static final BitSet FOLLOW_classBody_in_innerNewExpression14320 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_newArrayConstruction14366 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_arrayInitializer_in_newArrayConstruction14368 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LBRACK_in_newArrayConstruction14378 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_newArrayConstruction14381 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000004000L});
	public static final BitSet FOLLOW_RBRACK_in_newArrayConstruction14383 = new BitSet(new long[]{0x0000000000000002L,0x0000004000000000L});
	public static final BitSet FOLLOW_LBRACK_in_newArrayConstruction14387 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_newArrayConstruction14390 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000004000L});
	public static final BitSet FOLLOW_RBRACK_in_newArrayConstruction14392 = new BitSet(new long[]{0x0000000000000002L,0x0000004000000000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_newArrayConstruction14397 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LPAREN_in_arguments14417 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860820008L});
	public static final BitSet FOLLOW_expressionList_in_arguments14419 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_arguments14422 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_GREATER_THAN_in_synpred14_Java5078 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SHIFT_RIGHT_in_synpred15_Java5088 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_BIT_SHIFT_RIGHT_in_synpred16_Java5098 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_bound_in_synpred17_Java5128 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_STATIC_in_synpred32_Java5628 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_block_in_synpred32_Java5630 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_genericTypeParameterList_in_synpred42_Java5667 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0004000000800000L});
	public static final BitSet FOLLOW_type_in_synpred42_Java5686 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred42_Java5688 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_synpred42_Java5690 = new BitSet(new long[]{0x0000000000000000L,0x000000C000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_synpred42_Java5692 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_synpred42_Java5695 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_block_in_synpred42_Java5699 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_synpred42_Java5703 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_VOID_in_synpred42_Java5765 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred42_Java5767 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_synpred42_Java5769 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_synpred42_Java5771 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_block_in_synpred42_Java5775 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_synpred42_Java5779 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_synpred42_Java5838 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_synpred42_Java5840 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000004000000000L});
	public static final BitSet FOLLOW_throwsClause_in_synpred42_Java5842 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_block_in_synpred42_Java5845 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_modifierList_in_synpred43_Java5653 = new BitSet(new long[]{0x0020000214000000L,0x0000820020400010L,0x0004000000800000L});
	public static final BitSet FOLLOW_genericTypeParameterList_in_synpred43_Java5667 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0004000000800000L});
	public static final BitSet FOLLOW_type_in_synpred43_Java5686 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred43_Java5688 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_synpred43_Java5690 = new BitSet(new long[]{0x0000000000000000L,0x000000C000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_synpred43_Java5692 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_synpred43_Java5695 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_block_in_synpred43_Java5699 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_synpred43_Java5703 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_VOID_in_synpred43_Java5765 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred43_Java5767 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_synpred43_Java5769 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_synpred43_Java5771 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_block_in_synpred43_Java5775 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SEMI_in_synpred43_Java5779 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_synpred43_Java5838 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_synpred43_Java5840 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L,0x0000004000000000L});
	public static final BitSet FOLLOW_throwsClause_in_synpred43_Java5842 = new BitSet(new long[]{0x0000000000000000L,0x0000008000000000L});
	public static final BitSet FOLLOW_block_in_synpred43_Java5845 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_type_in_synpred43_Java5909 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_classFieldDeclaratorList_in_synpred43_Java5911 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred43_Java5913 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_typeDeclaration_in_synpred44_Java5958 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_genericTypeParameterList_in_synpred50_Java6002 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0004000000800000L});
	public static final BitSet FOLLOW_type_in_synpred50_Java6021 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred50_Java6023 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_synpred50_Java6025 = new BitSet(new long[]{0x0000000000000000L,0x0000004000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_synpred50_Java6027 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_synpred50_Java6030 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred50_Java6033 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_VOID_in_synpred50_Java6091 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred50_Java6093 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_synpred50_Java6095 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_synpred50_Java6097 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred50_Java6100 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_modifierList_in_synpred51_Java5988 = new BitSet(new long[]{0x0020000214000000L,0x0000820020400010L,0x0004000000800000L});
	public static final BitSet FOLLOW_genericTypeParameterList_in_synpred51_Java6002 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0004000000800000L});
	public static final BitSet FOLLOW_type_in_synpred51_Java6021 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred51_Java6023 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_synpred51_Java6025 = new BitSet(new long[]{0x0000000000000000L,0x0000004000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_synpred51_Java6027 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_synpred51_Java6030 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred51_Java6033 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_VOID_in_synpred51_Java6091 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred51_Java6093 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_formalParameterList_in_synpred51_Java6095 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000004000040000L});
	public static final BitSet FOLLOW_throwsClause_in_synpred51_Java6097 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred51_Java6100 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_type_in_synpred51_Java6163 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_interfaceFieldDeclaratorList_in_synpred51_Java6165 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred51_Java6167 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_typeDeclaration_in_synpred52_Java6212 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arrayDeclarator_in_synpred58_Java6506 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_synpred76_Java6895 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arrayDeclaratorList_in_synpred77_Java6939 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_DOT_in_synpred79_Java7026 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_typeIdent_in_synpred79_Java7028 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_COMMA_in_synpred90_Java7251 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000802000L});
	public static final BitSet FOLLOW_genericTypeArgument_in_synpred90_Java7253 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_genericWildcardBoundType_in_synpred92_Java7307 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_COMMA_in_synpred97_Java7508 = new BitSet(new long[]{0x0020000214400000L,0x0000800020400014L,0x0000000000800000L});
	public static final BitSet FOLLOW_formalParameterStandardDecl_in_synpred97_Java7510 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_formalParameterStandardDecl_in_synpred99_Java7505 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_COMMA_in_synpred99_Java7508 = new BitSet(new long[]{0x0020000214400000L,0x0000800020400014L,0x0000000000800000L});
	public static final BitSet FOLLOW_formalParameterStandardDecl_in_synpred99_Java7510 = new BitSet(new long[]{0x0000020000000002L});
	public static final BitSet FOLLOW_COMMA_in_synpred99_Java7515 = new BitSet(new long[]{0x0020000214400000L,0x0000800020400014L,0x0000000000800000L});
	public static final BitSet FOLLOW_formalParameterVarArgDecl_in_synpred99_Java7517 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_formalParameterVarArgDecl_in_synpred100_Java7572 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_DOT_in_synpred101_Java7803 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred101_Java7807 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_annotation_in_synpred102_Java7856 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_modifierList_in_synpred114_Java8274 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_synpred114_Java8276 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred114_Java8290 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_LPAREN_in_synpred114_Java8292 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_synpred114_Java8294 = new BitSet(new long[]{0x0000800000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_annotationDefaultValue_in_synpred114_Java8296 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred114_Java8299 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_classFieldDeclaratorList_in_synpred114_Java8341 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred114_Java8343 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_localVariableDeclaration_in_synpred116_Java8474 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred116_Java8476 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_typeDeclaration_in_synpred117_Java8487 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_ELSE_in_synpred121_Java8767 = new BitSet(new long[]{0x002470061C100000L,0x5505A28028E000B2L,0x0024062D60850008L});
	public static final BitSet FOLLOW_statement_in_synpred121_Java8771 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_forInit_in_synpred123_Java8950 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred123_Java8952 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860840008L});
	public static final BitSet FOLLOW_forCondition_in_synpred123_Java8954 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000040000L});
	public static final BitSet FOLLOW_SEMI_in_synpred123_Java8956 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860820008L});
	public static final BitSet FOLLOW_forUpdater_in_synpred123_Java8958 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_synpred123_Java8960 = new BitSet(new long[]{0x002470061C100000L,0x5505A28028E000B2L,0x0024062D60850008L});
	public static final BitSet FOLLOW_statement_in_synpred123_Java8962 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_switchBlockLabels_in_synpred130_Java9285 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_switchCaseLabels_in_synpred143_Java9874 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_switchCaseLabels_in_synpred145_Java9882 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_switchCaseLabel_in_synpred146_Java9928 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_localVariableDeclaration_in_synpred149_Java10002 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_expressionList_in_synpred150_Java10024 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LPAREN_in_synpred193_Java11527 = new BitSet(new long[]{0x0020000214000000L,0x0000800020400010L,0x0000000000800000L});
	public static final BitSet FOLLOW_type_in_synpred193_Java11529 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000020000L});
	public static final BitSet FOLLOW_RPAREN_in_synpred193_Java11531 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_unaryExpression_in_synpred193_Java11533 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_arrayDeclarator_in_synpred221_Java13384 = new BitSet(new long[]{0x0008000000000000L,0x0000004000000000L});
	public static final BitSet FOLLOW_DOT_in_synpred221_Java13451 = new BitSet(new long[]{0x0000000800000000L});
	public static final BitSet FOLLOW_CLASS_in_synpred221_Java13453 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_DOT_in_synpred229_Java13584 = new BitSet(new long[]{0x0000000800000000L,0x0100020000000000L,0x0000000840000000L});
	public static final BitSet FOLLOW_CLASS_in_synpred229_Java13602 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_genericTypeArgumentListSimplified_in_synpred229_Java13665 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L,0x0000000040000000L});
	public static final BitSet FOLLOW_SUPER_in_synpred229_Java13689 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_synpred229_Java13691 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SUPER_in_synpred229_Java13741 = new BitSet(new long[]{0x0008000000000000L});
	public static final BitSet FOLLOW_DOT_in_synpred229_Java13745 = new BitSet(new long[]{0x0000000000000000L,0x0000000000400000L});
	public static final BitSet FOLLOW_IDENT_in_synpred229_Java13747 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_synpred229_Java13749 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_IDENT_in_synpred229_Java13799 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_synpred229_Java13801 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_THIS_in_synpred229_Java13876 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_SUPER_in_synpred229_Java13942 = new BitSet(new long[]{0x0000000000000000L,0x0001000000000000L});
	public static final BitSet FOLLOW_arguments_in_synpred229_Java13944 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_innerNewExpression_in_synpred229_Java13992 = new BitSet(new long[]{0x0000000000000002L});
	public static final BitSet FOLLOW_LBRACK_in_synpred237_Java14387 = new BitSet(new long[]{0x0020600614000000L,0x5505A20028600032L,0x0004020860800008L});
	public static final BitSet FOLLOW_expression_in_synpred237_Java14390 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000000L,0x0000000000004000L});
	public static final BitSet FOLLOW_RBRACK_in_synpred237_Java14392 = new BitSet(new long[]{0x0000000000000002L});
}
