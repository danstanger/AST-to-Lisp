#!/bin/sh
java -cp .:./classes:/home/dxs/antlr3/antlr-3.5.3-complete.jar Test ../test/$1 >sexp/$2
