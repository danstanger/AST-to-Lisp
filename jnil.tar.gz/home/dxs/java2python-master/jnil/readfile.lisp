(defpackage #:javatools.parser
  (:use #:cl)
  (:export #:process-java-ast))
(in-package #:javatools.parser)

(defvar *input*)
(defvar *java-ast*)
(defun process-java-ast (project-name qualified-unit-name)
 (setf *input* (open "output.sexp" :direction :input))
 (setf *java-ast* (read *input*))
; (dolist (l *java-ast*) (pprint l))
 (close *input*)
 (apply #'process *java-ast*))

; (process-java-ast nil nil)
;(apply #'process *java-ast*)
;(defmethod process ((a (eql 'ANNOTATION_LIST)) (ast list)) (apply #defmethod ast))

(defgeneric process (eqarg &rest r)
  (:documentation "Parses java ast output")
  (:method (eqarg &rest r)
    (format t "~&defgeneric process ~a~%" eqarg)))

;; Handle package and possible multiple classes. Not sure if jnil can handle
;; more than one class in a compilation unit.
(defmethod process ((eqjs (eql 'java_source)) &rest r)
  (format t "~&process~a ~a~%" eqjs r)
  (dolist (s r) (apply #'process s)))

(defmethod process ((eqcl (eql 'CLASS)) &rest r)
  (format t "~&process~a ~a~%" eqcl r)
  (destructuring-bind (m n r1) r
   (when (listp m) (apply #'process m))
   (format t "~&name ~a~%" n)
   (apply #'process r1)))

(defmethod process ((eqctls (eql 'CLASS_TOP_LEVEL_SCOPE)) &rest r)
  (format t "~&process~a ~a~%" eqctls r)
  (destructuring-bind (ctls) r
   (apply #'process ctls)))

(defmethod process ((eqvmd (eql 'VOID_METHOD_DECL)) &rest r)
  (format t "~&process~a ~a~%" eqvmd r)
  (destructuring-bind (m n fpl bs) r
   (when (listp m) (apply #'process m))
   (format t "~&name ~a~%" n)
   (format t "~&fpl ~a~%" fpl)
   (apply #'process fpl)
   (apply #'process bs)))

(defmethod process ((eqim (eql 'import)) &rest r)
 (labels ((allexports (x) (eql '.* x))
          (imp (i &optional (acc nil))
          (format t "i is: ~A~%" i)
          (format t "r is: ~A~%" r)
          (format t "acc is: ~A~%" acc)
           (cond ((null i) acc)
                 ((atom i) (push i acc) acc)
                 (t (imp (second i) (push (third i) acc))))))
  (cons (imp (first r)) (allexports (second r)))))

(defmethod process ((eqml (eql 'MODIFIER_LIST)) &rest r)
  (format t "~&process~a ~a~%" eqml r)
  t)

(defmethod process ((eqvd (eql 'VAR_DECLARATION)) &rest r)
  (format t "~&process~a ~a~%" eqvd r)
  t)

(defmethod process ((eqfpl (eql 'FORMAL_PARAM_LIST)) &rest r)
  (format t "~&process~a ~a~%" eqfpl r)
  (destructuring-bind (fpsd) r
  (apply #'process fpsd)))

(defmethod process ((eqfpsd (eql 'FORMAL_PARAM_STD_DECL)) &rest r)
  (format t "~&process~a ~a~%" eqfpsd r)
  (apply #'process r))

(defmethod process ((eqlml (eql 'LOCAL_MODIFIER_LIST)) &rest r)
  (format t "~&process~a ~a~%" eqlml r)
  (destructuring-bind (ty v) r
   (apply #'process ty)
   (format t "~&variable name ~a~%" v)))

(defmethod process ((eqt (eql 'TYPE)) &rest r)
  (format t "~&process~a ~a~%" eqt r)
  (apply #'process r))

(defmethod process ((eqqti (eql 'QUALIFIED_TYPE_IDENT)) &rest r)
  (format t "~&process~a ~a~%" eqqti r)
  (apply #'process r))

(defmethod process ((eqbs (eql 'BLOCK_SCOPE)) &rest r)
  (format t "~&process~a ~a~%" eqbs r)
  (if (atom (first r)) (apply #'process r)
      (dolist (s r) (apply #'process s))))

(defmethod process ((eqe (eql 'EXPR)) &rest r)
  (format t "~&process~a ~a~%" eqe r)
  (destructuring-bind (e) r
   (apply #'process e)))

(defmethod process ((eqmc (eql 'METHOD_CALL)) &rest r)
  (format t "~&process~a ~a~%" eqmc r)
  (destructuring-bind (m al) r
;   (dolist (s r) (apply #'process s))
   (format t "~&method ~a argument list ~a~%" m al)
   (apply #'process m)
   (apply #'process al)
   ))
; (labels ((modifiers (m &optional (acc nil)))
; (trace process)
(process-java-ast nil nil)
;(format t "~&~&first java-ast is ~A~%" *java-ast*)
;(print (apply #'process *java-ast* ))
#|
(defun imp (i &optional (acc nil))
  (cond ((null i) acc)
        ((atom i) (push i acc) acc)
        (t (imp (second i) (push (third i) acc)))))
|#
