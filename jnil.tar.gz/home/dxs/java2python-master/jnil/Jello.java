class Jello {
    public static int main(String[] args) {
        System.out.println("Jello!");
	return 0;
    }
}
